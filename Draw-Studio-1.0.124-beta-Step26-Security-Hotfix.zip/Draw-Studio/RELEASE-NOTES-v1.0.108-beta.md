# Draw Studio v1.0.108-beta — Custom Palette + Verification Fix

- Fixed the false `translucent/soft brush` diagnosis during Microsoft Paint small tests.
- Color verification no longer guesses opacity from a light RGB sample; it reports stroke/selection/background mismatches accurately.
- Fixed a real preflight bug where spectrum-only custom-color calibration was shown as ready but disabled during drawing.
- Added **Adaptive exact (recommended)** to the visible Custom color workflow selector.
- Microsoft Paint can now use its calibrated **Edit colors / custom color palette** automatically when an image color is not represented closely enough by the normal palette.
- Normal palette colors are still preferred when they are close enough, avoiding unnecessary dialog openings.
- Custom spectrum and numeric RGB methods remain bounded and verified, with nearest calibrated palette fallback.
- Improved error text and removed misleading transparency/opacity claims.
- Fixed the replacement character in the isolated mouse-probe status output on some Windows code pages.
