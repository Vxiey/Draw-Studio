# Draw Studio v1.0.118-beta — Adaptive Deadline Renderer

Draw Studio now plans around a real drawing deadline instead of treating speed and quality as independent goals. The renderer asks: **what is the highest-value visual result that can be completed inside the configured render budget?**

## Time Budget Engine

- Adds named Gartic Phone and Skribbl time presets plus Custom and Unlimited / Accuracy modes.
- Keeps a configurable safety reserve before the game deadline.
- Separates total game time from usable render budget.
- Reports SAFE, CLOSE, OVER BUDGET and PANIC states.
- Legacy generic time modes remain available for backward compatibility.

## Adaptive Deadline Renderer

- Builds a full-resolution visual-importance map from edges, local contrast, foreground pressure and protected small high-contrast features.
- Scores planned operations by visual value versus estimated execution cost.
- Reduces low-value detail before sacrificing silhouette, major structure or important small features.
- Uses the real execution geometry and the existing Region Fill plan rather than a separate preview-only approximation.
- Keeps Pixel Accurate on its exact progressive PixelMap budget path so exact-color guarantees are not silently weakened.

## Progressive drawing and runtime deadline control

- Orders deadline-aware work into major coverage, structure, important details, accuracy and correction phases.
- Uses a live DeadlineScheduler while drawing to compare elapsed time, remaining predicted work and the remaining budget.
- Can skip optional low-value work if execution is falling behind.
- Activates Panic Mode when the remaining plan can no longer safely fit; Panic Mode keeps major coverage, structure and high-importance work rather than simply stopping halfway through.

## More realistic timing

- Reuses Draw Studio's operation-based draw-time estimator and local completed-drawing calibration.
- A fresh profile does not invent a machine-speed multiplier; instead the deadline planner keeps an uncertainty reserve until real measurements exist.
- Completed real drawings refine the predicted-versus-actual ratio separately per profile/speed/precision/Region Fill configuration.
- Adds a UI action to reset learned timing for the active profile configuration.
- Timing data remains local; no external telemetry or analytics service is added.

## Accuracy and preview

- Adds Raw Pixel Accuracy, Weighted Visual Accuracy, Edge Accuracy, Important Feature Accuracy and Coverage metrics for the simulated preview.
- Preview reports deadline budget/reserve/status and how many paths were removed by deadline adaptation.
- Preview and final drawing use the same accepted deadline-aware execution sequence.
- Adds an importance-map preview layer for diagnostics.

## CPU/GPU and safety

- Visual importance analysis has a vectorized CPU path and optional CuPy GPU path with VRAM budget checks and CPU fallback.
- Existing CPU/RAM/GPU controls, profile isolation, calibration, 4K/DPI handling, CanvasGuard, Region Fill safety, resume/checkpoint and correction systems remain in place.
- Background planning remains cancellable through the existing worker/generation infrastructure.

## Built-in named presets

- Gartic Phone Fast: 75 s total / 67 s render budget
- Gartic Phone Normal: 150 s / 138 s
- Gartic Phone Slow: 300 s / 283 s
- Skribbl Default: 80 s / 72 s
- Skribbl 60: 60 s / 53 s
- Skribbl 120: 120 s / 110 s
- Skribbl 150: 150 s / 138 s
- Emergency 30 s: 30 s / 26 s
- Ultra Fast 60 s: 60 s / 53 s
- Detailed 120 s: 120 s / 110 s
- Maximum 300 s: 300 s / 280 s

Custom mode allows a manually selected total time and safety reserve. Unlimited / Accuracy disables deadline pruning.
