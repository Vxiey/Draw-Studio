# Draw Studio v1.0.115-beta – High-DPI Browser Auto Setup Fix

Fixes Browser Auto Setup on large 144-DPI / 4K Gartic layouts where the palette search ROI could exceed the 1,000,000-pixel detector safety limit.

## Fixed
- Large browser palette ROIs are scanned in bounded overlapping tiles.
- The per-scan 1M-pixel safety limit remains enforced.
- Duplicate swatches from tile overlap are merged deterministically.
- Multi-monitor and negative desktop coordinates remain supported.
- Gartic canvas geometry detection is unchanged.
- Manual color calibration remains a safe fallback when a layout genuinely cannot be verified.

## Field-log case addressed
A 1873x1044 Gartic canvas at 144 DPI matched canvas geometry correctly, but Browser Auto Setup failed before palette matching because the relative palette ROI was larger than one million pixels. v1.0.115 removes that false failure without relaxing the detector's bounded-memory design.
