# Smart Drop-In Canvas Targeting — v1.0.111-beta

> **EXPERIMENTAL / VERY EARLY STAGE:** this feature may not work as planned on every Gartic/browser layout yet.

Smart Canvas Drop is an optional browser-game workflow. Draw Studio performs a read-only scan, detects a likely drawable canvas, and places a temporary drag/drop overlay over the target browser client. The detected canvas is green; surrounding game UI is invalid.

From v1.0.121, the temporary drop target is constrained to the detected drawable canvas itself. It accepts a single local image or a browser image drag that arrives as URL/text/HTML. A valid canvas drop imports the image and explicitly authorizes a one-shot Browser One-Click verification/start. Existing visual preflight, target checks and CanvasGuard remain authoritative before any drawing mouse input is sent.

Supported experimental profiles: Gartic Phone, Skribbl.io, Skribbl.io Fast, SketchHeads and Sketchful.io.

v1.0.121 accepts File Explorer drops plus common Chrome/Edge/Google Images drag payloads (files, URLs and HTML image sources). Browser/Windows drag formats can still vary, so manual Select image / URL / Ctrl+V remains the fallback when a site does not expose a usable image payload.
