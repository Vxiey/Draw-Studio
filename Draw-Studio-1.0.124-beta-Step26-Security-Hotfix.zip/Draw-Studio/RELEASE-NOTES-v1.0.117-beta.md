# Draw Studio v1.0.117-beta — Region Fill Engine

## Region Fill Engine
This release adds an outline-first, fill-heavy planning path for large connected colour regions. The planner keeps the existing stroke renderer as a per-region fallback and never treats size alone as proof that a fill is safe.

- Connected-region analysis and region statistics
- Exact closed-boundary contour plans for accepted fill regions
- Fill confidence, leak-risk and thin-neck checks
- Cost comparison between outline+fill and normal stroke/runs
- Larger bounded candidate budget than the legacy fill path
- Safe / Balanced / Aggressive fill-aggressiveness control
- Preview/log statistics for region count, fill coverage, stroke reduction and estimated time saved
- Existing CanvasGuard, tool calibration, DPI mapping and fallback renderer remain mandatory

## Pixel Accurate protection
Pixel Accurate / Exact RGB remains lossless. Region Fill Engine does not merge colours or substitute bucket fills when the existing pixel-accuracy simulator cannot prove equivalence. The normal exact renderer remains the fallback rather than risking a visually faster but incorrect result.

## More accurate final draw-time estimate
The visible estimate is no longer based only on stroke count. It now models the operations actually present in the plan, including contour travel, fill clicks, palette/tool switching, configured delays, canvas clear and verification overhead.

After a clean completed real drawing, Draw Studio stores a local calibration sample for the active profile/speed/precision/Region Fill combination and compares predicted time with measured wall-clock execution time. Future estimates are corrected using those completed drawings. Test runs, dry runs and resumed partial sessions are not used for training the estimate.

The first drawing on a new configuration still uses the deterministic operation timing model because there is no real timing history yet. The preview reports whether its estimate comes from the model, measured path throughput or completed-draw calibration. No timing telemetry is uploaded.

## Controls
- **Use Region Fill Engine**
- **Fill aggressiveness:** Safe / Balanced / Aggressive

## Safety
Unsafe/open regions always fall back to normal rendering. Hard fill blockers are not bypassed by Aggressive mode.
