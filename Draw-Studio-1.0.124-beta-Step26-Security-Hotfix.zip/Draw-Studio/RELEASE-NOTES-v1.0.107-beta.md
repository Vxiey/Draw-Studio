# v1.0.107-beta — Separate profiles + Paint probe recovery

## Börja här
Packa upp hela ZIP-filen och kör Start.bat. Välj programprofil först.
Inställningarna sparas i den valda profilens egen fil när du byter profil,
startar ritning eller avslutar. Befintliga profilfiler behålls.

## Separata profilinställningar
Alla registrerade ritinställningar återställs innan nästa profils fil läses.
En profil som saknar fil eller fält får standardvärden, inte föregående profils
värden. Detta omfattar bland annat ritförval, sketch, aktuell färg, penselbredd,
tidsgräns, CPU/GPU/RAM, verktyg och färginställningar.

Subject focus och Simple/Advanced/Developer samt preview-lagervisning sparas
också per profil. Tidigare Masterpiece-tidsminne rensas vid byte. Bildberoende
markeringar, zoom/panorering, aktivt målfönster och ritplan återställs.
Preview förblir Manual vid profilbyte och automatisk ritbehörighet återställs
inte från sparade inställningar. Inga profilbyten startar musritning.

Paint-verktygsmeny, verktygsstatus och kalibreringsknappar visas bara i Paint.
Gartics fulla setup och timer visas bara i Gartic Phone. Browser One-Click och
browser-setup visas bara i stödda webbläsarprofiler. Gemensamma ritinställningar
finns kvar, men deras värden är separata. Single-color sketch är gemensamt
 eftersom det fungerar även i ritspel.

Gamla värden som redan sparats i en profil bevaras. Patchen kan inte avgöra om
ett äldre sparat värde valdes avsiktligt eller följde med från en annan profil.

## Loggfelsökning och Paint
De fyra uppladdade loggarna visar lyckad målfönster- och muskontroll och normal
avstängning. Provritningen stoppades av färgverifiering: svart (0,0,0) väntades
men närmaste avlästa pixel var (207,207,207). Ingen kraschstack finns i loggarna.

Vid detta slags Paint-palettestopp med kalibrerad Pencil görs nu högst ett
extra omförsök på samma lilla planerade provstreck: välj penna och färg igen,
använd tätare rörelser och längre väntan för tryck/släpp, kontrollera på nytt.
Färgtoleransen är oförändrad och fortsatt fel stoppar ritningen. Metod, RGB,
resultat och mätningens förklaring loggas. Orsaken till just användarens grå
rendering är ännu inte fastställd; omförsöket garanterar inte att den försvinner.

## Verifiering
825 tester i hela befintliga sviten inklusive profiltesterna godkända.
Ytterligare 2 integrationstester verifierar det nya Paint-omförsöket: lyckad
återhämtning och fortsatt stopp vid fel färg. Totalt 827 godkända tester.
Source self-test godkänt. Windows-GUI och verklig ritning behöver provköras på
Windows; inga sådana resultat påstås här. Paketet innehåller källkod och Start.bat,
inte en nybyggd EXE. Auto Paint och Extra fast från tidigare versioner finns kvar.
