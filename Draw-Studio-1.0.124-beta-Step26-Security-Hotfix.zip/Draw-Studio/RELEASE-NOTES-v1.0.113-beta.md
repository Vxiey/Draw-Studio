# Draw Studio v1.0.113-beta — Detail-Aware Preview

This update improves the **preview system** so small but visually important source details survive downscaling much more reliably. It is aimed especially at portraits and other detailed images where ordinary preview resampling could soften or lose pupils, eye contours, nostrils, lip lines, hair boundaries and tiny shadow edges.

The feature is deterministic and pixel-based. **No AI, face recognition or ML is used.** Draw Studio analyses local source contrast and source subpixels only.

## New in v1.0.113-beta

- Added a **Preview detail** setting with four levels:
  - Fast
  - Balanced
  - Detailed — recommended default
  - Micro detail
- Added bounded **oversampled preview resampling**.
- Added **edge-priority micro-detail recovery** for high-contrast features.
- Added adaptive recovery only in detailed cells; flat regions keep normal smooth resampling.
- Added the same detail-aware preprocessing to shaded/portrait previews.
- Added preview diagnostics for recovery percentage, local contrast and oversampling factor.
- Detailed and Micro detail preview modes can use a larger bounded preview raster for better visual fidelity.
- Auto light keeps the conservative Balanced detail path for responsiveness.

## Small Feature Protection

When a source image must be reduced for the UI preview, Draw Studio now analyses several source subpixels for each preview cell. If a cell contains meaningful local contrast, the preview can blend back a representative high-contrast source color instead of allowing it to disappear into the average.

This helps preserve small structures such as:

- pupils and eye outlines
- nostrils
- lip edges
- fine facial contours
- thin hair boundaries
- small dark marks
- tiny cast-shadow edges and folds
- other narrow high-contrast contours

It does **not** label or recognize these objects. They are preserved because they are visually important micro-features in the source pixels.

## Preview-to-final consistency

The normal preview is still intentionally bounded so it remains cancellable and does not allocate the full target raster on every Build preview. The new recovery path makes that bounded preview look closer to the detail that the full-resolution final planner can see.

**Full detail preview is unchanged:** it still uses native target pixels and does not use the reconstruction/recovery pass.

The final drawing source and final full-resolution target plan are not modified by this feature.

## Performance

- Fast: normal lightweight resampling.
- Balanced: 2× bounded sampling with conservative recovery.
- Detailed: 2× bounded sampling with stronger micro-detail recovery.
- Micro detail: up to 3× bounded sampling and stronger recovery; it can take longer on large or complex images.
- Temporary oversampled preview memory is hard-bounded.

## Previous improvements retained

- v1.0.112 Contour & Detailed Shadow Rendering.
- v1.0.111 Smart Drop-In Canvas Targeting remains **EXPERIMENTAL / VERY EARLY STAGE**.
- v1.0.110 Preview Draw Time Estimate.
- v1.0.109 Advanced Color Matching.
- v1.0.108 Paint custom-palette verification fixes.
