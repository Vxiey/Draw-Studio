# Draw Studio v1.0.120-beta — Color Fidelity & Preview Tone Fix

This patch improves colour fidelity without rebuilding the renderer. It extends the existing advanced-colour, preview, game-profile and GPU palette systems.

## Main changes

- New **Color fidelity** setting: Fast, Balanced, Faithful and Exact.
- **Faithful** is the default for Gartic Phone and prioritises preserving source lightness, saturation and hue when several palette colours are similarly close.
- Palette matching is now sRGB gamma-aware and uses CIE Lab lightness for tone preservation.
- Asymmetric dark-bias penalty prevents bright source colours from being mapped to unnecessarily dark swatches.
- Gartic Phone and Skribbl turbo palette reduction now retain both a dark structural anchor and a bright active anchor.
- Rare-colour remapping uses the same fidelity-aware palette cost instead of raw RGB distance only.
- GPU palette mapping implements the same lightness/saturation/hue fidelity policy with CPU fallback.
- Pixel Accurate keeps **Exact** fidelity so no subjective tone preference is introduced.
- Removed the old 0.68 brightness multiplier from the Fill Regions preview; preview layers now preserve source sRGB tone.
- Added local colour diagnostics to plan metadata: lightness drift, luminance drift, saturation drift and sampled DeltaE76.
- Color fidelity remains profile-isolated and is saved separately with each profile.

No external analytics, AI colourisation or network service was added.
