# Draw Studio

Draw Studio is a Windows desktop drawing automation tool for Microsoft Paint and supported browser drawing canvases such as Gartic Phone and Skribbl.io.

It is deterministic and local-only. It does not use AI, ML, OCR, cloud processing or telemetry.

## Current package

**v1.0.124-beta — Step 24 Adaptive Detail Zoom Pass**

This package includes Steps 1–23 and adds a bounded internal 2x/4x source-detail recovery pass. Small edges, color accents and micro details can be revisited after global planning without changing Paint/browser zoom or invalidating canvas calibration.

Step 23 Universal GPU Acceleration remains available for OKLab, palette, DeltaE, quantization, edge and pixel workloads on NVIDIA/AMD/Intel hardware with CPU fallback.

Step 22 Universal Hardware Auto Benchmark remains the hardware discovery and measurement foundation used by the universal acceleration layer.

## Main features

- Microsoft Paint, Gartic Phone and Skribbl.io profiles
- Source-relative Visual Accuracy and OKLab color diagnostics
- OKLab color matching, dominant hue preservation and adaptive color count
- Time-aware color budgeting for 60 / 75 / 80 / 150 / 300 second targets
- Extra Fast 2.0 connected-region rendering with safe fill/scanline fallback
- Deadline-aware scheduler with Catch-up and Panic mode
- Profile-isolated palette, timing, tool and calibration caches
- Preview diagnostics: Original, Quantized Target, Simulated Final and DeltaE heatmap
- Local benchmark suite and golden image regression tests
- Safe final-canvas scoring, correction pass, correction review and before/after history
- Beginner setup wizard and clearer Start-blocking messages
- Universal CPU/GPU hardware benchmark with per-workload backend recommendations
- NVIDIA CUDA + AMD/Intel/NVIDIA OpenCL real workload acceleration with per-workload CPU fallback
- Hardware-signature invalidation and automatic local re-benchmark after hardware/runtime changes
- Adaptive Detail Zoom: internal Auto/2x/4x source re-analysis for small details, with deadline-aware optional paths and no target-app zoom changes

## Requirements

- Windows 10/11 x64
- Python 3.10+ for source mode
- Microsoft Paint or a supported browser target
- Optional: NVIDIA CUDA/CuPy for CUDA image-analysis acceleration
- Optional: PyOpenCL + vendor graphics-driver OpenCL runtime for AMD/Intel/NVIDIA image-analysis acceleration

## Run from source

```powershell
pip install -r requirements.txt
python DrawBot.py
```

Or double-click:

```text
Start.bat
```

## Build a Windows release

```powershell
Build-Release.bat
```

This runs tests, builds the PyInstaller onedir app, smoke-tests the frozen EXE, creates a release ZIP and writes SHA-256 checksums.

## Validate source release hygiene

```powershell
python ReleasePackage.py --check
```

This blocks runtime logs, safety reports, diagnostics, crash dumps, build folders and nested release archives from the publishable source package.

## Create a clean source ZIP

```powershell
python ReleasePackage.py --source-zip release\Draw-Studio-1.0.124-beta-Source.zip --manifest release\DrawStudio-1.0.124-beta-ReleaseManifest.json
```

## Quick setup

1. Choose the correct profile: Microsoft Paint, Gartic Phone or Skribbl.io.
2. Open the target app/canvas.
3. Load an image in Draw Studio.
4. Run the Setup wizard.
5. Select or verify the drawing area.
6. Calibrate palette/tools when required.
7. Build preview.
8. Run dry run.
9. Unlock and start the real drawing.

## Safety model

Draw Studio sends mouse/keyboard input only after the target is selected, verified and locked. CanvasGuard, dry run, target fingerprints and preflight checks are designed to prevent drawing outside the chosen canvas.

Run Draw Studio and the target app at the same privilege level. Normally both should run without administrator rights.

## Privacy

Everything runs locally. Runtime logs and safety reports stay on the computer. The release packager intentionally excludes logs, screenshots, crops, thumbnails, crash dumps, diagnostics, image bytes and nested generated packages.

## Documentation

- `RELEASE-CHECKLIST.md` — release steps
- `docs/PUBLISHING.md` — local and GitHub publishing
- `docs/RELEASE-STRUCTURE.md` — artifact structure
- `VERSION-HISTORY.md` — full version history
- `STEP-21-BUILD-PUBLISHER-GITHUB-RELEASE.md` — Step 21 implementation notes
- `STEP-22-UNIVERSAL-HARDWARE-AUTO-BENCHMARK.md` — Step 22 hardware benchmark design
- `STEP-23-UNIVERSAL-GPU-ACCELERATION.md` — Step 23 real workload routing
- `STEP-24-ADAPTIVE-DETAIL-ZOOM.md` — Step 24 internal micro-detail recovery
- `ROADMAP-STEP22-PLUS.md` — Step 27+ feature roadmap
