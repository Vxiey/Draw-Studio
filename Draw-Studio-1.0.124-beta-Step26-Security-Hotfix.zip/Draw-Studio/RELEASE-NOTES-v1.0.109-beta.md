# Draw Studio v1.0.109-beta — Advanced Color Matching

## Advanced Color Matching Engine
- Measures the visible source image before color selection.
- Tracks mean RGB, median RGB, dominant RGB, coverage and local color spread for every planned color region.
- Flat artwork keeps the exact dominant source RGB. Noisy or antialiased regions use a robust representative and snap it back to a real source pixel when possible.
- Alpha pixels are evaluated as their visible composited color instead of silently discarding transparency.

## Microsoft Paint exact RGB
- Adaptive exact image colors prefer calibrated Red/Green/Blue fields when available.
- Draw Studio types the measured image RGB directly into Paint.
- If Selected-color preview is calibrated, the preview is sampled as a small median patch before OK.
- A mismatching numeric preview is typed again once.
- A still-wrong numeric result can fall back to the calibrated Paint spectrum.
- A spectrum result that is visibly too far from the target can fall back to numeric RGB.
- A custom color that cannot be proven safe is cancelled instead of knowingly clicking OK; normal calibrated palette fallback remains available.
- Canvas color verification still runs before the full color batch is painted.

## Calibration recommendation
For best Paint accuracy, Smart custom palette calibration should capture Open custom color, Red/Green/Blue fields, Selected-color preview, Confirm, and both spectrum corners. Brightness scale and Eyedropper remain optional.
