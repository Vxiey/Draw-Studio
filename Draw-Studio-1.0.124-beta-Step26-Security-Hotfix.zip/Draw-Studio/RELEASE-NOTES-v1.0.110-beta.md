# Draw Studio v1.0.110-beta — Preview Draw Time Estimate

Adds a visible estimated draw time after Build preview so users can judge whether an image is practical before starting the real drawing.

## Added
- Preview workspace now shows an estimated final draw time immediately after preview planning.
- Sidebar Safety & draw card shows the same estimate beside stroke count, fills and colour phases.
- Safe previews that are smaller than the selected target canvas now display a full-target projection with an estimate range and confidence label.
- Full detail preview and final plans show the native plan estimate directly.
- Status and summary text now start with the estimated draw time, then show preview-plan estimate, strokes, palette/color phases and resources.

## Notes
- The preview estimate is intentionally approximate when the preview is downscaled. Start Drawing still rebuilds the final plan with the selected CPU/GPU/quality settings before any mouse input is sent.
