# Draw Studio v1.0.121-beta — Direct Game Canvas Web Drop

This release upgrades Smart Canvas Drop into a practical one-shot browser workflow.

## Direct drop on the real game canvas

For supported browser profiles (Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.io), press **Arm game canvas image drop**. Draw Studio performs a read-only canvas scan and places a temporary 60-second OS drag/drop target exactly over the detected drawable canvas.

You can then drag an image directly from:

- Google Images
- Chrome / Edge
- File Explorer
- a direct HTTP/HTTPS image URL payload

Releasing the image on the highlighted game canvas performs:

`drop -> image import/download -> browser canvas/palette re-verification -> final deadline plan -> automatic drawing start`

The overlay closes immediately after a valid drop so it cannot remain over the game while rendering.

## Browser drag payload support

Chrome/Edge do not always send a normal file path. Draw Studio now accepts:

- local image paths
- `file://` image URIs
- plain HTTP/HTTPS image URLs
- browser HTML fragments containing `img src`, `data-src` or `data-original`
- Google Images CDN URLs
- Google `imgres?imgurl=...` links, unwrapped locally without loading the search page

Only PNG/JPG/JPEG/WEBP/BMP local files are accepted through this path. Remote payloads still pass through Draw Studio's existing bounded image downloader and decoder.
The downloader now sends a normal browser-style image `Accept`/`User-Agent` header to reduce hotlink/CDN rejection when the drag came directly from a browser.

## One-shot automatic start

A valid drop directly on the detected game canvas is treated as explicit one-shot authorization to run the existing Browser One-Click setup for that image, even if the persistent Browser One-Click switch is off.

This does **not** bypass safety. Before mouse input, Draw Studio still performs target verification, canvas/palette setup, visual preflight, CanvasGuard and the normal browser input checks. Microsoft Paint is excluded from direct auto-start and retains its stricter safety flow.

## Draw Studio window drops

The main Draw Studio window and preview canvases now accept both file drops and browser URL/text drops. A normal window drop imports only. A direct drop on a Draw Studio preview canvas can use the existing browser auto-start path when a supported profile is selected.

## UI

The old experimental button is renamed to **Arm game canvas image drop** and explains the 60-second canvas listener. The listener covers only the actual detected canvas instead of the whole browser client area.
