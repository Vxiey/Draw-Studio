# Draw Studio v1.0.124-beta

Windows desktop drawing automation for Microsoft Paint and supported browser drawing canvases. Local-only, deterministic, no AI/ML/OCR and no telemetry.

## Recommended download

- `DrawStudio-1.0.124-beta-Windows-x64.zip` — portable Windows build
- `DrawStudio-1.0.124-beta-Windows-x64-Setup.exe` — optional per-user installer, when attached
- `DrawStudio-1.0.124-beta-SHA256.txt` — verify hashes before running

## Main beta highlights

- Source-relative Visual Accuracy / OKLab diagnostics
- OKLab color matching, dominant hue preservation and region-aware color quantization
- Adaptive color count and time-aware color budget
- Extra Fast 2.0, deadline-aware scheduler and Panic mode
- Profile-isolated calibration, palette, timing and verified-color caches
- Preview diagnostics, DeltaE heatmaps and local benchmark suite
- Post-draw verification, correction pass, correction review and before/after history
- Golden image regression tests and stability hardening
- Paint/Gartic/Skribbl profile polish and setup wizard

## Safety notes

Draw Studio sends mouse/keyboard input only after the target is selected, checked and locked. Run Paint/browser and Draw Studio at the same privilege level, normally without administrator rights.

Runtime logs and safety reports stay local. Source packages intentionally exclude logs, screenshots, crash dumps, diagnostics and generated release artifacts.

## Quick start

1. Extract the portable ZIP into a normal folder.
2. Run `DrawStudio.exe`.
3. Choose profile: Microsoft Paint, Gartic Phone or Skribbl.io.
4. Use the Setup wizard.
5. Build preview, run dry run, unlock and start.
