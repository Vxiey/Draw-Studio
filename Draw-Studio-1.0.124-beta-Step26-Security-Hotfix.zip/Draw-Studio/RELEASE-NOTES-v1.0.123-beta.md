# Draw Studio v1.0.123-beta — Adaptive Palette Fidelity & Anti-Posterization Engine

## Why
A field preview exposed severe posterization: a rich source image was reduced to a very small red/orange/dark palette. The underlying Gartic calibration had 72 swatches available, but the real-speed policy could cap a 60-second Faithful render at only six colours.

## Changes
- Replaces fixed browser 4/6/8-colour Faithful limits with adaptive palette capacity.
- Gartic Phone Faithful at 60 seconds may retain up to 28 useful calibrated colours when image complexity benefits from them.
- Preserves dark + bright anchors, five perceptual lightness bands, chromatic hue families and dominant colours across a bounded 3×3 spatial grid.
- Adds iterative visual-gain-per-colour-switch selection so additional colours are kept only when they materially reduce weighted perceptual error.
- Uses CIEDE2000 for palette-reduction error diagnostics.
- Adds palette coverage %, average/p95 reduction DeltaE2000, posterization risk and midtone-loss diagnostics.
- Gartic and Skribbl fast renderers share the same anti-posterization palette selection.
- Keeps deadline-aware path limits; this patch increases colour fidelity without blindly increasing cursor path density.

## Preserved
- v1.0.122 Exact Color Engine + Paint Color Verification
- Pixel Accurate / Exact RGB invariants
- Adaptive Deadline Renderer and safety reserve
- Region Fill Engine
- Direct Game Canvas Web Drop
- CPU/GPU and profile isolation systems
