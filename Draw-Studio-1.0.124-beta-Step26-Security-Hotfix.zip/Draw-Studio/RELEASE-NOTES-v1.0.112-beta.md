# Draw Studio v1.0.112-beta — Contour & Detailed Shadow Rendering

## New rendering analysis
- Adds deterministic **shadow analysis** at full Pixel Accurate resolution.
- Detects local darkening relative to surrounding tones instead of treating every dark pixel as the same kind of shadow.
- Adds a dedicated **contour map** combining luminance edges with real palette-region boundaries.
- Adds a **shadow-detail map** for cast-shadow borders, folds, facial shading and small dark transitions.
- No AI/ML is used; analysis is derived directly from source pixels.

## Rendering and post-processing
- Components are now tagged as base, shadow, shadow detail, contour or detail.
- Large flat forms remain early in the render.
- Broad shadows are prioritized in the mid-detail pass.
- Strong contours and detailed shadow transitions are moved toward fine-detail/cleanup passes.
- Protected contours and shadow details receive higher post-processing priority so important edges survive optimization and time pressure.
- The source PixelMap remains lossless: the feature changes scheduling/importance, not the target colors or geometry.

## Diagnostics
- Preview/final planning logs now report contour %, shadow-detail %, contour regions, shadow regions and detailed-shadow regions.
- Pixel map metadata exposes shadow/contour analysis statistics for debugging and future preview overlays.

## Previous improvements retained
- v1.0.111 experimental Smart Drop-In Canvas Targeting.
- v1.0.110 Preview Draw Time Estimate.
- v1.0.109 Advanced Color Matching.
- v1.0.108 Paint custom-palette verification fixes.
