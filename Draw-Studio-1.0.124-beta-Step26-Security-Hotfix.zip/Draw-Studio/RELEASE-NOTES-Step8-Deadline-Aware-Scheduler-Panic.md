# Draw Studio Step 8 — Deadline-aware Scheduler + Panic Mode

This patch adds live runtime deadline control on top of Steps 1–7.

- Continuously learns actual execution speed while drawing.
- Reprojects remaining work with a bounded EMA and typed operation costs.
- NORMAL keeps planned quality.
- CATCH_UP switches to coverage-first scheduling and trims low-value detail/accuracy before the plan falls behind.
- PANIC switches to structure-first scheduling, drops cleanup/corrections, and preserves only major coverage, silhouettes and exceptionally important cheap details.
- Structural coverage is protected before micro-detail.
- The hard render-budget guard stops optional work before the Time Budget Engine safety reserve is consumed.
- Runtime telemetry shows strategy, live timing multiplier, samples, predicted finish, schedule headroom, structural coverage and skipped work.
- No unsafe geometry rewrite, RGB change, canvas-safety bypass or renderer rebuild is introduced.

Step 8 keeps Extra Fast 2.0's safe connected paths as the execution strategy and changes scheduling priority only when real measured speed requires it.
