# Draw Studio v1.0.116-beta – 4K + Automatic DPI Recognition Fix

This release hardens target/canvas coordinate handling on 4K and mixed-DPI Windows systems.

## Fixed

- Centralized automatic target DPI detection with a fallback chain:
  `GetDpiForWindow` → monitor effective DPI → desktop DPI → safe 96-DPI fallback.
- Stronger Per-Monitor DPI v2 process awareness before the GUI is created.
- Target probes now report DPI source, scale factor and monitor bounds for diagnostics.
- Browser discovery and normal target capture now use the same DPI detector.
- Region selection no longer immediately fails on a plausible uniform logical/physical scaling mismatch; it maps the selection back to physical capture pixels.
- Improved handling of 125%, 150%, 175% and 200% display scaling.
- Better support for 4K, multi-monitor and negative virtual-desktop coordinates.
- Target DPI is re-read before drawing and logged with the monitor it came from.
- Existing safety behavior remains intact: if a non-browser target truly moves to a different DPI and cannot be safely rebased/calibrated, drawing is blocked before input is sent.

## Diagnostics

Session logs now include automatic DPI source, effective scale and monitor bounds, making 4K/mixed-DPI issues easier to reproduce.
