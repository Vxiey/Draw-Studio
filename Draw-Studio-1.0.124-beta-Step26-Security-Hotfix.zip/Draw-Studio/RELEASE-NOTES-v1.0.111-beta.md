# Draw Studio v1.0.111-beta — Smart Drop-In Canvas Targeting

> **EXPERIMENTAL / VERY EARLY STAGE:** Smart Canvas Drop may not work as planned on every Gartic/browser layout yet. Keep the normal manual canvas-selection workflow available as a fallback.

## New
- Adds **Drop on game canvas (Experimental)** for Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.io.
- Draw Studio performs a read-only scan for the actual drawable canvas instead of treating the whole browser window as drawable.
- A temporary overlay is positioned over the detected browser client. The detected canvas is shown as a green valid drop zone; toolbar/chat/sidebar areas are invalid.
- Dropping one image file inside the canvas locks that canvas geometry for the import. Drops outside it are rejected.
- Existing Browser One-Click can then re-verify canvas/palette and enter the normal drawing preflight. If One-Click is disabled, Smart Drop only auto-starts through the legacy one-shot path when its full guard is already ready.
- Uses screen-space geometry and negative-coordinate-safe overlay placement for multi-monitor setups.
- Target lock, CanvasGuard and browser visual preflight are not bypassed.

## Important limitations
- This is an early-stage Windows drag/drop workflow and has not been field-tested against every live Gartic/browser layout.
- It currently expects a single image file dragged from File Explorer. Browser-native image drags and arbitrary clipboard payloads are not treated as file drops.
- Dynamic page redesigns, browser overlays or unusual DPI/window layouts can make visual canvas detection fail closed. Use manual canvas selection when that happens.

## Previous improvements retained
- v1.0.110 Preview Draw Time Estimate.
- v1.0.109 Advanced Color Matching.
- v1.0.108 Paint custom-palette verification fixes.
