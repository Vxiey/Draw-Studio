# Draw Studio v1.0.119-beta — Deadline Reliability & Runtime Optimizer

## Deadline reliability
- Legacy 30/60/90 s and minute presets now use the same automatic safety-reserve policy as the named game presets.
- A 60 s timer defaults to a 53 s render budget plus a 7 s reserve. `Off` remains an advanced explicit override.
- Planning metadata separates game time, render budget, reserve and hard stop.
- Cold profiles use a conservative timing multiplier until three completed real drawings are available.
- Runtime operation timing is recorded locally per isolated profile and used alongside estimated-vs-actual calibration.

## Runtime scheduler
- DeadlineScheduler now has NORMAL, CATCH_UP and PANIC states.
- Catch-up starts before the plan actually misses the deadline and removes low-value corrections/detail first.
- Panic remains sticky and preserves major coverage/structure.
- Medium/micro detail is gated until weighted structural coverage reaches 75%.
- Live local telemetry reports elapsed time, remaining budget, predicted finish, schedule delta, operations/s, current phase, structural coverage and skipped low-value work.

## CPU/GPU/backend selection
- Manual/Auto Full preview is no longer forced permanently to one CPU worker; workload-aware preview scheduling uses 1–4 workers while keeping cancellation bounded.
- Connected components, importance mapping, region scoring and correction scoring have dedicated worker policies.
- GPU status distinguishes detected hardware, CuPy availability, active GPU analysis and CPU fallback reason.
- CUDA Auto mode performs a tiny cached execution probe before reporting the backend active.

## Browser and Start Drawing reliability
- Browser Auto Setup ranks near-tied windows using previous target handle, foreground window and monitor/layout context before asking the user to disambiguate.
- Start Drawing now records explicit START_ACCEPTED → PREFLIGHT → PLAN_READY → INPUT_ARMED → DRAWING → COMPLETED/ABORTED states and logs the current block reason.

## Region Fill
- Region Fill cost selection now includes `seconds_saved_per_visual_error` so deadline mode prefers fills with meaningful time savings and low visual/leak risk rather than merely using a fixed aggressiveness threshold.

Existing Pixel Accurate, CanvasGuard, 4K/DPI, profile isolation, calibration, Region Fill safety blockers, recovery/resume and CPU fallback behavior remain preserved.


## Validation
- Python compileall: passed.
- pytest: 914 passed, plus 6 subtests passed.
- unittest discovery: 899 tests passed.
- `DrawBot.py --self-test`: passed (exit 0).

The Windows/browser field path still learns actual timing locally from completed drawings; these source tests do not substitute for real Gartic/Skribbl timing measurements.
