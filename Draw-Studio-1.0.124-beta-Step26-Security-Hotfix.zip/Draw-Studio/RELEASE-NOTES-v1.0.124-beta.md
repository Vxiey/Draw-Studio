# Draw Studio v1.0.124-beta — Paint Color Selection Recovery & Exact Swatch Verification

This release fixes the Paint color-recovery bug observed in real Windows field logs and makes Faithful Paint rendering use verified custom RGB more aggressively when the calibrated 20-color palette is perceptually insufficient.

## Paint color recovery
- A failed standard-palette probe can now genuinely switch to calibrated numeric RGB, spectrum, or eyedropper recovery.
- Fixed the old control-flow bug where `select(index, "numeric")` on a palette selector clicked the same palette coordinate again.
- Exact/custom modal color is verified before confirmation when a selected-color preview is calibrated.
- Optional Active Color 1 / foreground-swatch calibration can verify the selected Paint color before any stroke is drawn and immediately switch a stale palette click to numeric RGB/spectrum recovery.
- Color-selection verification and rendered-stroke verification are reported separately.
- Successfully recovered colors continue to use the existing verified per-profile cache.

## Faithful custom RGB policy
- Microsoft Paint Faithful mode raises the bounded custom-RGB budget, lowers the DeltaE2000 threshold for using an exact color, and the Auto Paint policy now permits up to 32 planned source colors.
- Exact mode may use the entire bounded color plan as custom RGB when calibration is available.
- Browser/game profiles retain the previous conservative custom-color budget.
- Metadata now reports the custom color threshold and active profile policy.

All existing target, DPI, CanvasGuard, profile isolation, deadline, Region Fill, preview and Pixel Accurate behavior remains in place.
