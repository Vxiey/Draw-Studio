# Draw Studio v1.0.122-beta — Exact Color Engine + Paint Color Verification

This release replaces rough nearest-colour decisions with a stricter perceptual colour pipeline and improves Microsoft Paint recovery when a calibrated palette click does not render the expected colour.

## Exact Color Engine

- Adds CIE Lab + CIEDE2000 colour comparison for Faithful/Exact palette decisions.
- Source regions retain mean, median and dominant RGB, but the selected representative is source-backed rather than an invented average.
- Faithful matching adds explicit lightness, saturation, hue and asymmetric darkening penalties.
- Bright/high-importance colours receive stronger protection against gloomy/dull remapping.
- Dynamic exact-colour planning uses CIEDE2000 for palette fallback quality and requests Paint custom RGB more aggressively when the calibrated palette is visibly wrong.
- Faithful/Exact palette mapping stays on the CIEDE2000 CPU path so preview and final planning cannot disagree with the older Euclidean-Lab CUDA candidate selector. GPU acceleration remains available for other analysis/simulation workloads.

## Paint custom colour verification and recovery

- Paint numeric/custom RGB preview checks now use perceptual CIEDE2000 instead of only weighted RGB distance.
- A palette-render mismatch in Microsoft Paint can automatically recover through calibrated exact numeric RGB or spectrum controls before stopping the whole drawing.
- The fallback palette index is preserved correctly even when a palette selector temporarily switches into custom-colour recovery.
- Successfully verified Paint custom colours are cached per profile with requested RGB, actual rendered RGB, method, confidence and DeltaE2000.
- Final rendered Paint colour probes receive an additional perceptual verification gate.

This specifically addresses the field-log failure where Paint requested `(0, 0, 0)` but the rendered probe remained around `(207, 207, 207)`: the renderer now tries a calibrated exact-colour recovery path instead of repeating only the same palette selection when exact Paint controls are available.

## Preview colour diagnostics

Preview/final plan metadata now also reports:

- average and maximum DeltaE2000
- lightness drift
- luminance drift
- saturation drift
- hue drift
- dark-bias detection
- fidelity rating: Excellent / Good / Acceptable / Poor / Very Poor

The existing DeltaE76 metric remains for backwards-compatible diagnostics.

## Compatibility

- v1.0.121 Direct Game Canvas Web Drop remains intact.
- Region Fill, Adaptive Deadline Renderer, Pixel Accurate, correction passes, profile isolation, CPU/GPU/RAM controls and existing calibration flows remain intact.
- Pixel Accurate / Exact does not perform destructive tone remapping or colour merging.
