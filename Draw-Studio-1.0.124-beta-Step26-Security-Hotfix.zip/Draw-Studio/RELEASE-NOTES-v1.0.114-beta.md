# Draw Studio v1.0.114-beta – Automatic Canvas Clear

This update adds an opt-in **automatic target-canvas clear** before a real full drawing, so repeated Gartic/Paint sessions do not require manually erasing the previous image every time.

## New

- New **Auto clear target canvas before full drawing** switch.
- **Microsoft Paint:** uses Select All → Delete → Esc after the target is activated and CanvasGuard is ready.
- **Drawing games / browser apps:** prefers a user-calibrated **Clear canvas** button.
- If no one-click Clear control is calibrated, Draw Studio can use a **CanvasGuard-bounded Eraser sweep** when both Brush and Eraser are calibrated.
- Brush is restored automatically after an Eraser sweep.
- App-tool calibration now supports **Brush / Fill / Eraser / Clear**.
- Clear time is included in the final draw-time estimate when the destructive prelude will actually run.

## Safety behavior

Automatic clear is **off by default** because it is destructive. It runs only after an explicit full Start. It never erases during **Small Test**, sends no clear click/key during **Dry Run**, and is skipped for a compatible **Render Resume** so completed color batches are not destroyed. All Eraser sweep coordinates remain inside CanvasGuard. No browser Clear button coordinate is guessed; it must be anchored by calibration first.

## Compatibility

All v1.0.113 Detail-Aware Preview, v1.0.112 contour/shadow rendering, v1.0.111 experimental Smart Drop-In, v1.0.110 time estimates and v1.0.109 color matching remain included.

## Verification

871 automated tests pass and `DrawBot.py --self-test` passes in the source environment. Real Windows Paint/Gartic interaction still needs field testing on the user's exact app/browser layout.
