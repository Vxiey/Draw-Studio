# Publishing Draw Studio

## Local source release check

```powershell
python ReleasePackage.py --check
```

This validates that required release files exist and that runtime-only files are not present in the publishable source tree.

## Create a source package

```powershell
python ReleasePackage.py --source-zip release\Draw-Studio-1.0.124-beta-Source.zip --manifest release\DrawStudio-1.0.124-beta-ReleaseManifest.json
```

## Build Windows release locally

Use a Windows x64 machine with Python 3.10+.

```powershell
Build-Release.bat
```

The build script runs tests, builds `DrawStudio.exe`, runs the frozen binary self-test, creates a release ZIP and writes SHA-256 checksums.

## Optional installer

If Inno Setup 6 is installed, `Build-Release.bat` automatically asks the release builder to create a per-user installer.

## GitHub release

The GitHub workflow runs on tags matching `v*` and can also be started manually.

```powershell
git tag v1.0.124-beta
git push origin v1.0.124-beta
```

The tag name must match `Version.py` exactly: `v<APP_VERSION>`.

## Files that must not be published

Do not include:

- `logs/`
- `safety-reports/`
- crash dumps
- diagnostics folders
- `.build-venv/`, `build/`, `dist/`, `release/`
- nested release ZIPs or Setup EXEs

Run `python ReleasePackage.py --check` before uploading anything manually.
