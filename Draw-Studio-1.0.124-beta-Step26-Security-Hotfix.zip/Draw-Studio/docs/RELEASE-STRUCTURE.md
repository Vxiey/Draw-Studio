# Release structure

## Source ZIP

The source ZIP contains code, tests, docs, workflow files, golden regression assets and build scripts. It does not contain runtime logs, user diagnostics, build folders, generated EXEs or nested release archives.

## Portable Windows ZIP

The portable ZIP contains the PyInstaller onedir output under `DrawStudio/` and end-user docs bundled by `build_exe.py`.

## Installer

The installer wraps the portable onedir output as a per-user install under LocalAppData and does not require administrator privileges by default.

## Checksums

Every release artifact should be listed in the generated SHA-256 file. The checksum file should be attached to the GitHub Release with the ZIP and installer.

## Version source of truth

`Version.py` is the application version source of truth. `version_info.txt`, release file names and Git tags must match it.
