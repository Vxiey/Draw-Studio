# Smart Drop-In Canvas Targeting — v1.0.111-beta

> **EXPERIMENTAL / VERY EARLY STAGE:** this feature may not work as planned on every Gartic/browser layout yet.

Smart Canvas Drop is an optional browser-game workflow. Draw Studio performs a read-only scan, detects a likely drawable canvas, and places a temporary drag/drop overlay over the target browser client. The detected canvas is green; surrounding game UI is invalid.

A single image file dropped inside the green canvas area is imported and the detected canvas becomes the target area for that import. A drop on chat, toolbars, sidebars or outside the canvas is rejected. Existing Browser One-Click, visual preflight, target checks and CanvasGuard remain authoritative before any drawing mouse input is sent.

Supported experimental profiles: Gartic Phone, Skribbl.io, Skribbl.io Fast, SketchHeads and Sketchful.io.

Current limitation: the overlay expects a file drop such as an image dragged from File Explorer. It is not a guarantee that browser-native image drags, every web redesign, every browser overlay, or every Windows DPI/layout combination will work. Use manual canvas selection whenever detection fails.
