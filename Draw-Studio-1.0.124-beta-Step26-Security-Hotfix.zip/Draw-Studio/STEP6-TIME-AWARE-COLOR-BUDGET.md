# Step 6 — Time-aware Color Budget

`Exact color count = Auto` now composes Step 5's image-complexity recommendation with the usable active deadline.

- Manual and Unlimited preserve the Step 5 recommendation.
- Built-in 60/75/80/150/300-second game budgets use their existing safety reserve and usable render budget.
- Locally measured `palette_change` / `color_change` and completed-path timings are preferred when available.
- Before calibration, profile-specific palette timing and the existing 0.78 s custom-RGB selector model are used.
- Dominant hue families and light/dark tonal structure form a protected minimum.
- Explicit numeric color counts are never overridden.
- This step does not change renderer geometry, fill strategy, mouse delivery, palette extraction, or stroke ordering.
