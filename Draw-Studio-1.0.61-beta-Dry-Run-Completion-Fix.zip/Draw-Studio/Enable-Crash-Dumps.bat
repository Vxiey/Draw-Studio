@echo off
setlocal
set "DUMP_DIR=%LOCALAPPDATA%\DrawBotStudio\dumps"
if not exist "%DUMP_DIR%" mkdir "%DUMP_DIR%" >nul 2>&1

echo Enabling Windows LocalDumps for the current user...
for %%E in (DrawStudio.exe python.exe pythonw.exe) do (
  reg add "HKCU\Software\Microsoft\Windows\Windows Error Reporting\LocalDumps\%%E" /v DumpFolder /t REG_EXPAND_SZ /d "%DUMP_DIR%" /f >nul
  if errorlevel 1 goto error
  reg add "HKCU\Software\Microsoft\Windows\Windows Error Reporting\LocalDumps\%%E" /v DumpCount /t REG_DWORD /d 5 /f >nul
  reg add "HKCU\Software\Microsoft\Windows\Windows Error Reporting\LocalDumps\%%E" /v DumpType /t REG_DWORD /d 1 /f >nul
)

echo.
echo Done. Crash dumps will be stored in:
echo %DUMP_DIR%
echo.
echo Administrator rights are not required because these settings use HKCU.
pause
exit /b 0
:error
echo Could not enable crash dumps. Error code: %errorlevel%
pause
exit /b 1
