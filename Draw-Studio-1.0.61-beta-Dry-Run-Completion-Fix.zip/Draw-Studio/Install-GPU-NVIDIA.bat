@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo Draw Studio - Optional NVIDIA CUDA acceleration
echo ============================================================
echo.
if not exist ".venv\Scripts\python.exe" (
  echo Draw Studio environment was not found. Run Start.bat once first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r requirements-gpu-nvidia.txt
if errorlevel 1 goto :fail
echo.
echo CUDA package installed. Start Draw Studio and run Tools ^> Test GPU.
pause
exit /b 0
:fail
echo.
echo GPU package installation failed. Draw Studio can still run on CPU.
pause
exit /b 1
