"""Deterministic render-resume/checkpoint helpers for Draw Studio v1.0.42.

The checkpoint only says which complete color batches are already present on
canvas. It never contains, restores, or implies native-input authorization.
"""
from __future__ import annotations

import hashlib
import json

SCHEMA = 1


def _clean_rgb(value):
    try:
        return tuple(max(0, min(255, int(v))) for v in value[:3])
    except Exception:
        return (0, 0, 0)


def active_color_order(plan):
    groups = plan.get('groups') or []
    execution_groups = plan.get('execution_groups')
    requested = (plan.get('options') or {}).get('color_order') or list(range(len(groups)))
    result = []
    for raw in requested:
        try:
            index = int(raw)
        except (TypeError, ValueError):
            continue
        if not 0 <= index < len(groups):
            continue
        has_strokes = bool(groups[index])
        has_paths = bool(execution_groups is not None and index < len(execution_groups) and execution_groups[index])
        if has_strokes or has_paths:
            result.append(index)
    return result


def batch_key(plan, index):
    colors = plan.get('colors') or ()
    selectors = plan.get('color_selectors') or ()
    rgb = _clean_rgb(colors[index] if index < len(colors) else (0, 0, 0))
    selector = selectors[index] if index < len(selectors) and isinstance(selectors[index], dict) else {}
    payload = {
        'index': int(index),
        'rgb': rgb,
        'kind': str(selector.get('kind') or 'palette'),
        'palette_index': selector.get('palette_index'),
        'fallback_palette_index': selector.get('fallback_palette_index'),
    }
    raw = json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()[:20]


def plan_fingerprint(plan):
    """Fingerprint the deterministic final plan without persisting source pixels."""
    h = hashlib.sha256()
    image = plan.get('image')
    if image is not None:
        try:
            rgb = image.convert('RGB')
            h.update(f'image:{rgb.width}x{rgb.height}:'.encode())
            h.update(rgb.tobytes())
        except Exception:
            h.update(repr(getattr(image, 'size', None)).encode())
    h.update(repr(tuple(plan.get('fitted') or ())).encode())
    h.update(repr(tuple(_clean_rgb(c) for c in (plan.get('colors') or ()))).encode())
    order = active_color_order(plan)
    h.update(repr(tuple(order)).encode())
    h.update(str(int(plan.get('count') or 0)).encode())
    selectors = []
    for index in order:
        src = (plan.get('color_selectors') or ())
        selector = src[index] if index < len(src) and isinstance(src[index], dict) else {}
        selectors.append((selector.get('kind'), selector.get('palette_index'), selector.get('fallback_palette_index'), _clean_rgb(selector.get('rgb') or (0,0,0))))
    h.update(repr(tuple(selectors)).encode())
    return h.hexdigest()


def new_progress(plan):
    order = active_color_order(plan)
    return {
        'schema': SCHEMA,
        'plan_fingerprint': plan_fingerprint(plan),
        'total_colors': len(order),
        'completed_count': 0,
        'completed_keys': [],
        'next_color': 1 if order else 0,
        'prelude_complete': False,
    }


def checkpoint_after_batch(plan, completed_count, *, prelude_complete=True):
    order = active_color_order(plan)
    completed = max(0, min(int(completed_count), len(order)))
    return {
        'schema': SCHEMA,
        'plan_fingerprint': plan_fingerprint(plan),
        'total_colors': len(order),
        'completed_count': completed,
        'completed_keys': [batch_key(plan, index) for index in order[:completed]],
        'next_color': completed + 1 if completed < len(order) else 0,
        'prelude_complete': bool(prelude_complete),
    }


def validate_progress(value):
    if not isinstance(value, dict) or int(value.get('schema', 0)) != SCHEMA:
        return None
    fp = value.get('plan_fingerprint')
    try:
        total = max(0, int(value.get('total_colors', 0)))
        completed = max(0, min(int(value.get('completed_count', 0)), total))
    except (TypeError, ValueError):
        return None
    keys = value.get('completed_keys') or []
    if not isinstance(fp, str) or len(fp) != 64 or not isinstance(keys, list):
        return None
    keys = [str(k)[:40] for k in keys[:completed]]
    if len(keys) != completed:
        return None
    return {
        'schema': SCHEMA,
        'plan_fingerprint': fp,
        'total_colors': total,
        'completed_count': completed,
        'completed_keys': keys,
        'next_color': completed + 1 if completed < total else 0,
        'prelude_complete': bool(value.get('prelude_complete')),
    }


def resolve_resume(plan, state):
    """Return safe resume metadata; mismatch means start from color 1."""
    clean = validate_progress(state)
    order = active_color_order(plan)
    if not clean or not clean['completed_count']:
        return {'compatible': False, 'completed_count': 0, 'total_colors': len(order), 'reason': 'no completed color batches'}
    if plan.get('execution_sequence'):
        return {'compatible': False, 'completed_count': 0, 'total_colors': len(order), 'reason': 'progressive passes cannot resume by whole color batch'}
    current_fp = plan_fingerprint(plan)
    if clean['plan_fingerprint'] != current_fp:
        return {'compatible': False, 'completed_count': 0, 'total_colors': len(order), 'reason': 'final plan fingerprint changed'}
    if clean['total_colors'] != len(order):
        return {'compatible': False, 'completed_count': 0, 'total_colors': len(order), 'reason': 'color batch count changed'}
    expected = [batch_key(plan, index) for index in order[:clean['completed_count']]]
    if expected != clean['completed_keys']:
        return {'compatible': False, 'completed_count': 0, 'total_colors': len(order), 'reason': 'completed color sequence changed'}
    return {
        'compatible': True,
        'completed_count': clean['completed_count'],
        'total_colors': len(order),
        'next_color': clean['next_color'],
        'prelude_complete': bool(clean['prelude_complete']),
        'reason': '',
    }
