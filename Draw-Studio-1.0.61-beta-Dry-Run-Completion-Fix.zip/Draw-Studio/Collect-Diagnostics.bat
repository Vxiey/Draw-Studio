@echo off
setlocal
set "APPDATA_DIR=%LOCALAPPDATA%\DrawBotStudio"
set "OUT=%APPDATA_DIR%\DrawStudio-Diagnostics"
set "ZIP=%APPDATA_DIR%\DrawStudio-Diagnostics.zip"
if not exist "%APPDATA_DIR%" mkdir "%APPDATA_DIR%" >nul 2>&1
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%" >nul 2>&1
mkdir "%OUT%\dumps" >nul 2>&1

echo Collecting Draw Studio diagnostics...
if exist "%TEMP%\DrawStudio-start.log" copy /y "%TEMP%\DrawStudio-start.log" "%OUT%\" >nul
for %%F in ("DrawStudio-crash.log" "DrawStudio-crash.log.1" "DrawStudio-session.log" "DrawStudio-session.log.1" "DrawStudio-mouse-probe.log" "DrawStudio-target-probe.log") do (
  if exist "%APPDATA_DIR%\logs\%%~F" copy /y "%APPDATA_DIR%\logs\%%~F" "%OUT%\" >nul
  if exist "%~dp0logs\%%~F" copy /y "%~dp0logs\%%~F" "%OUT%\source-%%~F" >nul
)


if exist "%~dp0Version.py" copy /y "%~dp0Version.py" "%OUT%\Version.py" >nul
ver > "%OUT%\windows-version.txt"
whoami >> "%OUT%\windows-version.txt" 2>&1

set "DRAWSTUDIO_EXE=%~dp0DrawStudio.exe"
if not exist "%DRAWSTUDIO_EXE%" if exist "%~dp0..\DrawStudio.exe" set "DRAWSTUDIO_EXE=%~dp0..\DrawStudio.exe"

if exist "%DRAWSTUDIO_EXE%" (
  "%DRAWSTUDIO_EXE%" --internal-mouse-probe --diagnostics-only > "%OUT%\mouse-diagnostics.txt" 2>&1
) else if exist "%~dp0.venv\Scripts\python.exe" (
  "%~dp0.venv\Scripts\python.exe" -c "import sys,platform,struct; print(sys.version); print(platform.platform()); print('executable',sys.executable); print('bits',struct.calcsize('P')*8)" > "%OUT%\python-version.txt" 2>&1
  "%~dp0.venv\Scripts\python.exe" -m pip check > "%OUT%\pip-check.txt" 2>&1
  "%~dp0.venv\Scripts\python.exe" -m pip freeze > "%OUT%\packages.txt" 2>&1
  "%~dp0.venv\Scripts\python.exe" "%~dp0MouseProbe.py" --diagnostics-only > "%OUT%\mouse-diagnostics.txt" 2>&1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='SilentlyContinue';" ^
  "Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture | Format-List | Out-File -Encoding utf8 '%OUT%\os-details.txt';" ^
  "Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,VideoModeDescription | Format-List | Out-File -Encoding utf8 '%OUT%\display-drivers.txt';" ^
  "Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,SystemType | Format-List | Out-File -Encoding utf8 '%OUT%\system.txt';" ^
  "Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=(Get-Date).AddHours(-24)} -MaxEvents 300 | Where-Object {$_.Message -match 'python|DrawStudio|Draw Studio|DrawBot'} | Select-Object TimeCreated,Id,ProviderName,LevelDisplayName,Message | Format-List | Out-File -Encoding utf8 '%OUT%\application-events.txt';" ^
  "if (Test-Path '%APPDATA_DIR%\dumps') { Get-ChildItem '%APPDATA_DIR%\dumps' -Filter '*.dmp' | Sort-Object LastWriteTime -Descending | Select-Object -First 3 | Copy-Item -Destination '%OUT%\dumps' -Force }" >nul 2>&1

for %%E in (DrawStudio.exe python.exe pythonw.exe) do reg query "HKCU\Software\Microsoft\Windows\Windows Error Reporting\LocalDumps\%%E" >> "%OUT%\localdumps-config.txt" 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%OUT%\*' -DestinationPath '%ZIP%' -Force" >nul 2>&1
if exist "%ZIP%" (
  echo Created: %ZIP%
  explorer /select,"%ZIP%"
) else (
  echo Could not create the ZIP. Raw diagnostics are in: %OUT%
)
pause
