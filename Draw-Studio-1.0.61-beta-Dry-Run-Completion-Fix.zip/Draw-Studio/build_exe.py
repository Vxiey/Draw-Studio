"""Build Draw Studio on Windows with PyInstaller.

Usage:
    py -3 build_exe.py            # recommended onedir build
    py -3 build_exe.py --onefile  # optional single-file build
"""
from pathlib import Path
import subprocess
import sys
from Version import APP_VERSION, FILE_VERSION


def main():
    if sys.platform != 'win32':
        raise SystemExit('The Windows EXE build must run on Windows. Use Build-Release.bat or the GitHub Actions workflow.')
    if sys.maxsize <= 2**32:
        raise SystemExit('Use 64-bit Python to build the Windows x64 release.')

    base = Path(__file__).resolve().parent
    version_text=(base/'version_info.txt').read_text(encoding='utf-8')
    if f"FileVersion', '{FILE_VERSION}'" not in version_text or f"ProductVersion', '{FILE_VERSION}'" not in version_text:
        raise SystemExit('Version mismatch: update version_info.txt to match Version.py before building.')
    onefile = '--onefile' in sys.argv[1:]
    gpu_build = '--gpu' in sys.argv[1:]
    builder = base / '.build-venv' / 'Scripts' / 'python.exe'
    if not builder.exists():
        subprocess.run([sys.executable, '-m', 'venv', str(base / '.build-venv')], check=True)

    subprocess.run([str(builder), '-m', 'pip', 'install', '--upgrade', 'pip'], check=True)
    subprocess.run([
        str(builder), '-m', 'pip', 'install', '-r', str(base / 'requirements.txt'),
        'pyinstaller>=6.22.2,<7'
    ], check=True)
    if gpu_build:
        subprocess.run([str(builder), '-m', 'pip', 'install', '-r', str(base / 'requirements-gpu-nvidia.txt')], check=True)

    mode = '--onefile' if onefile else '--onedir'
    command = [
        str(builder), '-m', 'PyInstaller',
        '--noconfirm', '--clean', '--noupx', '--log-level', 'WARN', mode, '--windowed',
        '--name', 'DrawStudio',
        '--manifest', str(base / 'DrawStudio.manifest'),
        '--version-file', str(base / 'version_info.txt'),
        '--hidden-import', 'PIL.ImageGrab',
        '--hidden-import', 'PIL.ImageTk',
        '--hidden-import', 'MouseProbe',
        '--hidden-import', 'TargetProbe',
        '--hidden-import', 'TargetCapture',
        '--hidden-import', 'PaintTools',
        '--hidden-import', 'PaintAutoCalibration',
        '--hidden-import', 'PaintToolCalibration',
        '--hidden-import', 'CalibrationAnchors',
        '--hidden-import', 'RuntimePaths',
        '--hidden-import', 'ReleaseState',
        '--hidden-import', 'UpdateCenter',
        '--hidden-import', 'GpuAcceleration',
        '--hidden-import', 'FillOptimizer',
        '--hidden-import', 'ColorGrouping',
        '--hidden-import', 'AdvancedColor',
        '--hidden-import', 'SmartTools',
        '--hidden-import', 'UIState',
        '--hidden-import', 'PreviewLayers',
        '--hidden-import', 'PreviewSafety',
        '--hidden-import', 'ResourceAllocation',
        '--hidden-import', 'ResourceScheduler',
        '--hidden-import', 'PerformanceAutoTuner',
        '--hidden-import', 'ProfileEngine',
        '--hidden-import', 'FastDryRun',
        '--hidden-import', 'CanvasGuard',
        '--hidden-import', 'CanvasAnchorDetection',
        '--hidden-import', 'AnchorTransform',
        '--hidden-import', 'EdgeDetection',
        '--hidden-import', 'EdgeBehavior',
        '--hidden-import', 'SafeFillMask',
        '--hidden-import', 'SafetyDebugOverlay',
        '--hidden-import', 'RuntimeSafetyReport',
        '--hidden-import', 'LocalSanitization',
        '--hidden-import', 'PerformanceProfiler',
        '--hidden-import', 'ProgressiveRenderer',
        '--hidden-import', 'PlanningWatchdog',
        '--hidden-import', 'ShapePaths',
        '--hidden-import', 'SessionRecovery',
        '--hidden-import', 'RenderResume',
        '--hidden-import', 'VisualVerification',
        '--hidden-import', 'DiagnosticsPackage',
        '--hidden-import', 'ContinuousPaths',
        '--hidden-import', 'StrokeOptimizer',
        '--hidden-import', 'AdaptiveDetail',
        '--hidden-import', 'AppToolCalibration',
        '--hidden-import', 'AppTools',
        '--hidden-import', 'Version',
        '--collect-all', 'tkinterdnd2',
        '--collect-all', 'customtkinter',
        '--hidden-import', 'keyboard',
        '--hidden-import', 'ExactColorCalibration',
        '--hidden-import', 'ExactColorTools',
        '--hidden-import', 'DynamicColors',
        '--hidden-import', 'AdaptiveColor',
    ]
    if gpu_build:
        command.extend(['--collect-all', 'cupy', '--collect-all', 'cupyx', '--hidden-import', 'cupyx.scipy.ndimage'])

    # Keep the frozen application clean: only files required at runtime or useful to end users.
    for name in [
        'Collect-Diagnostics.bat', 'Enable-Crash-Dumps.bat', 'Disable-Crash-Dumps.bat',
        'palette-index-maps.json', 'README.md', 'requirements-gpu-nvidia.txt', 'Install-GPU-NVIDIA.bat'
    ]:
        command.extend(['--add-data', f'{name}:.'])

    command.append(str(base / 'DrawBot.py'))
    subprocess.run(command, cwd=base, check=True)

    output = base / 'dist' / ('DrawStudio.exe' if onefile else 'DrawStudio/DrawStudio.exe')
    if not output.is_file() or output.read_bytes()[:2] != b'MZ':
        raise SystemExit('The build did not produce a valid Windows EXE.')

    print('\nDone!')
    print(f'EXE: {output}')
    print(f'Built Draw Studio {APP_VERSION}.')
    print('Image analysis backend: CUDA bundle included.' if gpu_build else 'Image analysis backend: CPU base build; optional CUDA available in source mode.')
    print('Manifest: asInvoker (no automatic administrator prompt).')
    print('Run Paint and Draw Studio at the same privilege level; normally both without administrator rights.')
    print('The EXE is unsigned, so Windows SmartScreen may show a warning.')


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        raise SystemExit(f'Build failed. Read the error message above. Code: {error.returncode}')

