"""Dynamic exact-color planning with perceptual color reduction.

Color Engine v3 groups nearly identical source colours perceptually, prioritises
them by coverage, and only spends exact custom-color selections when they make a
visible improvement over the nearest calibrated palette swatch.
"""
from __future__ import annotations
from math import sqrt

EXACT_COLOR_LIMITS=("Auto","8","16","24","32")


def validate_exact_color_limit(value):
    text=str(value)
    if text not in EXACT_COLOR_LIMITS:
        raise ValueError(f'Unknown exact color limit: {value}')
    return text


def resolve_exact_color_limit(value, *, draw_quality='High likeness', preview=False):
    text=validate_exact_color_limit(value)
    if text!='Auto':
        return int(text)
    if preview:
        return 8
    quality=str(draw_quality)
    if quality=='Balanced':
        return 12
    if quality=='Maximum likeness':
        return 20
    if quality=='GPU enhanced':
        return 24
    return 16


def _distance2(a,b):
    return sum((int(x)-int(y))**2 for x,y in zip(a[:3],b[:3]))


def _visible_white(rgb):
    r,g,b=map(int,rgb[:3]); hi=max(r,g,b); lo=min(r,g,b)
    return r>=245 and g>=245 and b>=245 and hi-lo<=12


def _rgb_to_space(rgb):
    r,g,b=[max(0,min(255,int(v)))/255.0 for v in rgb[:3]]
    def lin(c):
        return c/12.92 if c<=0.04045 else ((c+0.055)/1.055)**2.4
    lr,lg,lb=lin(r),lin(g),lin(b)
    y=0.2126*lr + 0.7152*lg + 0.0722*lb
    co=lr-lb
    cg=lg - (lr+lb)*0.5
    chroma=sqrt(co*co + cg*cg)
    return y,co,cg,chroma


def _perceptual_distance2(a,b):
    ay,aco,acg,ach=_rgb_to_space(a); by,bco,bcg,bch=_rgb_to_space(b)
    dy=(ay-by)*3.2; dco=(aco-bco)*1.35; dcg=(acg-bcg)*1.35; dch=(ach-bch)*1.5
    return dy*dy + dco*dco + dcg*dcg + dch*dch


def _closest_palette_index(rgb,palette):
    scores=[(_perceptual_distance2(rgb,p),i) for i,p in enumerate(palette)]
    return min(scores,key=lambda item:(item[0],item[1]))


def _weighted_rgb(items):
    total=max(1,sum(int(it['count']) for it in items))
    r=round(sum(int(it['rgb'][0])*int(it['count']) for it in items)/total)
    g=round(sum(int(it['rgb'][1])*int(it['count']) for it in items)/total)
    b=round(sum(int(it['rgb'][2])*int(it['count']) for it in items)/total)
    return (int(r),int(g),int(b)), total


def _merge_quantized(entries,max_colors,cancelled=lambda:False):
    """Greedy perceptual merge: first by closeness threshold, then by smallest pair."""
    if not entries:
        return [],{}
    total_pixels=sum(e['count'] for e in entries) or 1
    threshold2=0.0018  # perceptually very close after quantization
    clusters=[]
    source_to_cluster={}
    for item in sorted(entries,key=lambda e:e['count'],reverse=True):
        if cancelled():
            return None,None
        best_i=None; best=None
        for i,cl in enumerate(clusters):
            d2=_perceptual_distance2(item['rgb'],cl['rgb'])
            if best is None or d2<best:
                best,best_i=d2,i
        # Large or visually distinct colors keep their own bucket; tiny shades merge early.
        frac=item['count']/total_pixels
        local_threshold=threshold2*(1.0 + max(0.0,0.02-frac)*20.0)
        if best_i is not None and best<=local_threshold:
            clusters[best_i]['items'].append(item)
            rgb,count=_weighted_rgb(clusters[best_i]['items'])
            clusters[best_i]['rgb']=rgb; clusters[best_i]['count']=count
            source_to_cluster[item['qindex']]=best_i
        else:
            source_to_cluster[item['qindex']]=len(clusters)
            clusters.append({'items':[item],'rgb':tuple(item['rgb']),'count':int(item['count'])})
    # If there are still too many colours, merge the closest low-cost pair until bounded.
    while len(clusters)>int(max_colors):
        if cancelled():
            return None,None
        best_pair=None; best_cost=None
        for i in range(len(clusters)):
            for j in range(i+1,len(clusters)):
                ci,cj=clusters[i],clusters[j]
                # Merge cost balances perceptual closeness with coverage.
                d2=_perceptual_distance2(ci['rgb'],cj['rgb'])
                cost=d2*((ci['count']+cj['count'])/total_pixels)
                if best_cost is None or cost<best_cost:
                    best_cost=cost; best_pair=(i,j)
        i,j=best_pair
        merged={'items':clusters[i]['items']+clusters[j]['items']}
        rgb,count=_weighted_rgb(merged['items']); merged['rgb']=rgb; merged['count']=count
        clusters[i]=merged
        removed=clusters.pop(j)
        # rebuild mapping compactly
        for src,cidx in list(source_to_cluster.items()):
            if cidx==j: source_to_cluster[src]=i
            elif cidx>j: source_to_cluster[src]=cidx-1
    return clusters,source_to_cluster


def _add_run(groups,index,start,y,end_x):
    if index is None or start is None or end_x<start:return
    groups[index].append((int(start),int(y),int(end_x),int(y)))


def build_dynamic_color_strokes(image, palette_rgb, *, max_colors=16, skip_white=True,
                                lines=True, exact_available=False, exact_threshold=7,
                                cancelled=lambda:False):
    """Return groups, rendered colors, selectors and metadata.

    selectors are dictionaries of either:
      {kind:'palette', palette_index:N, rgb:(...)}
      {kind:'custom', rgb:(...), fallback_palette_index:N}

    The palette RGB values passed here are the RGB values measured during the
    user's calibration. No profile preset RGB is preferred over calibrated data.

    Color Engine v3:
    - quantizes to a bounded intermediate palette;
    - merges nearly identical colours perceptually;
    - prioritises colours by coverage;
    - uses exact custom colours only when the nearest calibrated palette would
      be visibly worse.
    """
    from PIL import Image
    palette=tuple(tuple(map(int,c[:3])) for c in palette_rgb)
    if not palette:
        raise ValueError('No calibrated palette colors are available for fallback.')
    if cancelled():
        return None,None,None,None
    src=image.convert('RGB')
    max_colors=max(1,int(max_colors))
    # Slightly higher temporary palette gives the reducer something to merge.
    temp_colors=max(8,min(64,max_colors*3))
    q=src.quantize(colors=temp_colors,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE)
    counts={int(index): int(count) for count,index in (q.getcolors() or [])}
    qrgb=q.convert('RGB')
    qpix=q.load(); qrgbpix=qrgb.load()
    index_to_rgb={}
    needed=set(int(k) for k in counts)
    for y in range(q.height):
        if not needed: break
        for x in range(q.width):
            qindex=int(qpix[x,y])
            if qindex in needed:
                index_to_rgb[qindex]=tuple(map(int,qrgbpix[x,y][:3]))
                needed.discard(qindex)
        if cancelled():
            return None,None,None,None
    entries=[]
    for qindex,count in counts.items():
        if cancelled():
            return None,None,None,None
        rgb=index_to_rgb.get(int(qindex))
        if rgb is None or count<=0:
            continue
        entries.append({'qindex':int(qindex),'rgb':rgb,'count':int(count)})
    if not entries:
        return [],(),(),{'mode':'dynamic-exact-v3','requested_colors':max_colors,'active_colors':0,
                         'custom_exact_colors':0,'palette_fallback_colors':0,'white_skipped':0,'exact_available':bool(exact_available)}
    clusters,source_to_cluster=_merge_quantized(entries,max_colors,cancelled=cancelled)
    if clusters is None:
        return None,None,None,None
    # Sort by coverage so large visual colours receive priority first.
    order=sorted(range(len(clusters)), key=lambda i:(-clusters[i]['count'], i))
    old_to_new={old:new for new,old in enumerate(order)}
    selected=[]
    total_pixels=sum(c['count'] for c in clusters) or 1
    for old in order:
        c=clusters[old]
        pal_d2,pal_idx=_closest_palette_index(c['rgb'],palette)
        selected.append({
            'rgb':tuple(c['rgb']),
            'count':int(c['count']),
            'coverage':c['count']/total_pixels,
            'fallback_palette_index':int(pal_idx),
            'palette_distance':sqrt(pal_d2)*20.0,
        })
    # Decide where exact custom colours are actually worth using.
    selectors=[None]*len(selected)
    rendered=[None]*len(selected)
    groups=[[] for _ in selected]
    # Keep custom dialogues bounded even if exact RGB is available.
    custom_budget=min(len(selected), max(1, min(12, max_colors//2 + 1)))
    ranked_custom=sorted(
        range(len(selected)),
        key=lambda i:(selected[i]['palette_distance']*(1.0+selected[i]['coverage']*3.0),
                      selected[i]['coverage'], -i),
        reverse=True
    )
    use_custom=set()
    if exact_available:
        for i in ranked_custom:
            item=selected[i]
            # Require visible improvement over palette. Tiny regions need an even
            # larger miss before they deserve a modal custom-colour selection.
            needed=float(exact_threshold) + (2.0 if item['coverage'] < 0.01 else 0.0)
            if item['palette_distance'] >= needed and len(use_custom) < custom_budget:
                use_custom.add(i)
    for i,item in enumerate(selected):
        fallback=int(item['fallback_palette_index'])
        if exact_available and i in use_custom:
            selectors[i]={'kind':'custom','rgb':tuple(item['rgb']),'fallback_palette_index':fallback}
            rendered[i]=tuple(item['rgb'])
        else:
            selectors[i]={'kind':'palette','palette_index':fallback,'rgb':tuple(palette[fallback])}
            rendered[i]=tuple(palette[fallback])
    # Scan the quantized source once and build line/dot groups.
    w,h=q.size
    pix=q.load()
    skipped_white=0
    final_group_by_q={}
    for src_index,old_cluster in source_to_cluster.items():
        new=old_to_new[old_cluster]
        if skip_white and _visible_white(selected[new]['rgb']):
            final_group_by_q[int(src_index)]=None
        else:
            final_group_by_q[int(src_index)]=new
    for y in range(h):
        previous=None; start=None
        for x in range(w+1):
            group=None
            if x<w:
                qidx=int(pix[x,y]); group=final_group_by_q.get(qidx)
                if group is None:
                    skipped_white+=1
            if not lines:
                if group is not None:
                    groups[group].append((x,y,x,y))
            elif group!=previous:
                _add_run(groups,previous,start,y,x-1)
                previous,start=group,(x if group is not None else None)
    active=sum(bool(g) for g in groups)
    return groups,tuple(rendered),tuple(selectors),{
        'mode':'dynamic-exact-v3',
        'requested_colors':max_colors,
        'intermediate_quantized_colors':len(entries),
        'reduced_colors':len(selected),
        'active_colors':active,
        'custom_exact_colors':sum(1 for s,g in zip(selectors,groups) if g and s['kind']=='custom'),
        'palette_fallback_colors':sum(1 for s,g in zip(selectors,groups) if g and s['kind']=='palette'),
        'white_skipped':skipped_white,
        'exact_available':bool(exact_available),
        'custom_dialog_budget':custom_budget,
        'coverage_priority':tuple(round(item['coverage'],4) for item in selected[:8]),
        'average_palette_distance': round(sum(item['palette_distance'] for item in selected)/max(1,len(selected)),3),
    }
