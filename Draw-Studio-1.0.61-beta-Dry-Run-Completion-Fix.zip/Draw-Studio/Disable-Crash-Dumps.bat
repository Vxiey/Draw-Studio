@echo off
setlocal
for %%E in (DrawStudio.exe python.exe pythonw.exe) do reg delete "HKCU\Software\Microsoft\Windows\Windows Error Reporting\LocalDumps\%%E" /f >nul 2>&1
echo Draw Studio LocalDumps settings were removed from the current user account.
pause
