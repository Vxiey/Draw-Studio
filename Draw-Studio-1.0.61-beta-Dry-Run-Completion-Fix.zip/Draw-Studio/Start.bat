@echo off
setlocal
cd /d "%~dp0"
title Draw Studio - Startup
set "DRAW_LOG=%TEMP%\DrawStudio-start.log"
set "PYTHONFAULTHANDLER=1"
set "PYTHONUNBUFFERED=1"
>"%DRAW_LOG%" echo Draw Studio startup log
echo Starting Draw Studio. The first launch can take a little longer.
echo Startup log: %DRAW_LOG%
if not exist "DrawBot.py" goto missing_files
if not exist "requirements.txt" goto missing_files
if exist ".venv\Scripts\python.exe" goto dependencies
py -3 -c "import sys; sys.exit(sys.version_info < (3,10))" >>"%DRAW_LOG%" 2>&1
if not errorlevel 1 goto create_py
python -c "import sys; sys.exit(sys.version_info < (3,10))" >>"%DRAW_LOG%" 2>&1
if not errorlevel 1 goto create_python
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" goto create_local
echo Python 3.10 or later was not found.
echo Install Python and enable "Add python.exe to PATH".
goto error
:create_py
echo Creating Python environment...
py -3 -m venv .venv >>"%DRAW_LOG%" 2>&1
goto check_venv
:create_python
echo Creating Python environment...
python -m venv .venv >>"%DRAW_LOG%" 2>&1
goto check_venv
:create_local
echo Using the local Python 3.12 installation...
"%LocalAppData%\Programs\Python\Python312\python.exe" -m venv .venv >>"%DRAW_LOG%" 2>&1
:check_venv
if errorlevel 1 goto error
:dependencies
echo Checking Python...
".venv\Scripts\python.exe" -c "import sys; print(sys.executable); print(sys.version); sys.exit(sys.version_info < (3,10))" >>"%DRAW_LOG%" 2>&1
if errorlevel 1 goto error
if /i "%~1"=="--update" goto install_dependencies
if not exist ".venv\installed-requirements.txt" goto install_dependencies
fc /b requirements.txt ".venv\installed-requirements.txt" >nul 2>&1
if errorlevel 1 goto install_dependencies
".venv\Scripts\python.exe" -c "import PIL, requests, keyboard, tkinterdnd2, customtkinter" >>"%DRAW_LOG%" 2>&1
if errorlevel 1 goto install_dependencies
".venv\Scripts\python.exe" -m pip check >>"%DRAW_LOG%" 2>&1
if errorlevel 1 goto install_dependencies
goto launch
:install_dependencies
echo Updating pip. Internet access is required...
".venv\Scripts\python.exe" -m pip install --upgrade pip --disable-pip-version-check --timeout 20 --retries 1 >>"%DRAW_LOG%" 2>&1
if errorlevel 1 echo pip could not be updated. Continuing with the installed version.
echo Checking and installing packages. Internet access is required...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --timeout 20 --retries 1 -r requirements.txt >>"%DRAW_LOG%" 2>&1
if errorlevel 1 goto error
copy /y requirements.txt ".venv\installed-requirements.txt" >nul
:launch
echo Opening Draw Studio...
".venv\Scripts\python.exe" -u DrawBot.py >>"%DRAW_LOG%" 2>&1
if errorlevel 1 goto error
echo Draw Studio closed normally.
echo Startup log: %DRAW_LOG%
pause
exit /b 0
:missing_files
echo Required files are missing. Extract the ENTIRE ZIP file before starting Draw Studio.
goto error
:error
echo.
echo STARTUP FAILED. The recorded output follows:
type "%DRAW_LOG%"
echo.
echo Create a local Diagnostics ZIP from Tools, or inspect these files:
echo %DRAW_LOG%
echo %~dp0logs\DrawStudio-crash.log
echo %~dp0logs\DrawStudio-session.log
echo %~dp0logs\DrawStudio-mouse-probe.log
echo For a hard crash, run Enable-Crash-Dumps.bat and reproduce the issue.
pause
exit /b 1
