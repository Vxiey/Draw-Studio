# Draw Studio v1.0.71-beta – Browser Auto-Recalibration

This release removes another manual setup failure point for browser drawing profiles.

## What changed

- Supported browser profiles now perform a **read-only visual re-scan immediately before native drawing input can be armed**.
- Detects browser zoom/reflow even when the Chrome window rectangle and Windows DPI did not change.
- Automatically refreshes the safe canvas, calibrated palette coordinates, target client rectangle and DPI metadata.
- Pure window movement is treated as harmless when client-relative canvas/palette geometry is unchanged.
- Client resize, DPI changes, canvas movement/scale and palette reflow are detected separately and logged.
- A real browser layout change invalidates old preflight/dry-run safety state instead of silently carrying stale coordinates forward.
- If the new layout cannot be verified with sufficient confidence, drawing stops before mouse input and manual fallback remains available.
- During an active stroke execution, layout changes still stop safely; the **next start** performs automatic recalibration. Draw Studio never tries to remap a live mouse-down stroke mid-draw.

## Supported profiles

- Gartic Phone
- Skribbl.io
- Skribbl.io Fast
- SketchHeads
- Sketchful.io

## Safety model

Auto-Recalibration is screenshot/read-only calibration. It does not click palette colors, tools or the canvas. The selected browser may be brought to the foreground so the visual scan is not obstructed by another window.

CanvasGuard, FinalMouseGuard, target monitoring and runtime safety reports remain mandatory.
