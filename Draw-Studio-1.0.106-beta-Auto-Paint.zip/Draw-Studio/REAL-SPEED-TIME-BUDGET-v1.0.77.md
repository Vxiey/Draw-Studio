# Real-Speed Time Budget — v1.0.77-beta

Browser time budgets now learn from completed local drawing executions instead of relying only on a static path-rate estimate.

- Stores an EMA of completed paths/second per supported browser profile.
- 30/60/90 second modes calculate a conservative path cap from measured throughput.
- Low budgets reduce palette colors and detail automatically in Auto profile mode.
- Large/closed structural paths receive priority when a cap must drop work, preserving outlines and recognizable forms before micro-detail.
- Gartic Phone and Skribbl Fast feed the learned max-color limit into their Turbo renderers.
- Clean Small Test runs may seed the profile with low weight; completed full drawings carry more weight.
- Interrupted/failed runs and Dry Run do not train the profile.

The local profile stores only timing counters. No images, screenshots, URLs or telemetry are recorded.
