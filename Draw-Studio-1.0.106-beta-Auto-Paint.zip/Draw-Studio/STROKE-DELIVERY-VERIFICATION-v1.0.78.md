# Stroke Delivery Verification

## Added

- Read-only per-stroke delivery verification for Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.
- Suspected missed or partial HTML5-canvas strokes retry only the affected path.
- A hard one-retry cap prevents repeated stroke loops.
- The retry automatically uses denser interpolation and slightly safer press/path/release timing.
- A stroke is marked complete only after its bounded delivery check finishes.

## Safety

- CanvasGuard and FinalMouseGuard wrap the original stroke and every retry.
- Dry Run never enables delivery retries or native clicks.
- Microsoft Paint keeps its existing Paint-specific verification/delivery path.
- If the retry still cannot be confirmed, execution stops instead of silently skipping the path.
