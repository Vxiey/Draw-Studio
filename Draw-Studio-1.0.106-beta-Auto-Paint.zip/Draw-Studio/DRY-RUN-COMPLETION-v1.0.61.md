# Fast Dry Run Completion Fix — v1.0.61-beta

## Problem fixed
Fast Dry run used a 12-second hard execution deadline but sampled up to 40 paths. On slower/longer cursor routes, the expected budget expiry surfaced as `InterruptedError: Time limit reached` and prevented the dry-run safety gate from passing even though no safety check had failed.

## New behavior
- The 12-second limit applies to cursor simulation, not target activation/countdown.
- The representative sample is reduced to up to 8 paths across up to 4 colors.
- If the 12-second cursor budget is reached with no CanvasGuard/target/safety failure, it is a normal bounded completion and the Dry Run passes.
- Real drawing timeouts remain hard stops.
- User cancellation/Esc remains a hard stop.
- No clicks, presses or releases are sent in Dry Run.
