# v1.0.103-beta — Human mode off

Human mode är borttaget från gränssnittet och alltid Off i appens ritplanering.
Gamla profilval (Subtle/Natural/Strong) ignoreras. Profilbyte och nya sparade
inställningar använder Off. Human modes extra pauser och variationer används
inte längre. Säkerhetskontroller och nödvändiga inmatningsfördröjningar behålls.

Fullständigt paket: packa upp och kör Start.bat.
Patch för v1.0.102: stäng appen och kopiera DrawBot.py, StudioUI.py, Version.py
och version_info.txt till mappen med Start.bat. Ersätt filerna och starta igen.
Kalibrering och övriga profilinställningar behålls.

803 automatiserade tester samt source self-test godkända. Det befintliga
testet av appens human_mode-val förväntar nu Off även med ett äldre sparat val.
Äldre hjälpfunktioner finns kvar för källkodskompatibilitet, men appen väljer
aldrig deras aktiva lägen. Windows-ritning har inte provkörts här.
Källkod med Start.bat; ingen nybyggd EXE.
