# Draw Studio v1.0.66-beta – Gartic Engine v2

Gartic Phone now has a dedicated deterministic Engine v2 path. It is built for the current Gartic Phone layout and keeps all safety layers intact.

## Layout

- Reference canvas aspect: about 1.79:1.
- Reference palette: 6 columns × 12 rows = 72 swatches.
- Detection helpers only verify geometry and confidence; they do not send clicks or guess unsafe coordinates.

## Renderer

- Fixed calibrated palette.
- Batch one colour at a time.
- Reduce to a small important palette in Auto mode.
- Preserve dark structure/outline colours.
- Horizontal/vertical run selection per colour.
- StrokeGraph travel optimization inside each colour batch.
- HTML5 canvas stroke delivery uses wider interpolation than Paint.

## Runtime budget

The engine has deterministic profiles for normal, large-canvas and low-time drawing. Low remaining time favours fewer colours, fewer paths and wider movement steps.

## Safety

CanvasGuard, FinalMouseGuard, target monitoring, edge clipping and safe polygon clipping remain profile-independent and cannot be disabled by Gartic Engine v2.
