# Draw Studio v1.0.90-beta — Adaptive Brush Draw Motor

This release improves the actual Pixel Accurate drawing delivery rather than changing source analysis.

## 10 draw-motor patches

1. Per-path brush width stored directly in the execution sequence.
2. Fine-detail paths use the smallest verified browser brush.
3. Protected cleanup paths use the smallest verified browser brush.
4. Thin/high-importance mid-detail regions automatically downshift brush width.
5. Unverified browser controls never trigger guessed brush clicks.
6. CPU stroke simulation respects each path's actual brush width.
7. CUDA/tiled stroke simulation respects each path's actual brush width.
8. Accuracy correction passes use the detail brush instead of the coarse fill brush.
9. Runtime changes verified browser brush controls between passes and reselects color safely when needed.
10. Small brushes automatically use denser mouse interpolation to reduce dropped/gapped HTML5-canvas strokes.

The source PixelMap and Block B geometry remain unchanged. Adaptive brush choices only improve physical delivery fidelity.
