"""Pixel-accurate analysis core for Draw Studio v1.0.86-beta.

Block A is deliberately analysis-first. Every target pixel survives into a
PixelMap before any path optimisation. CUDA is used for palette matching and
Sobel analysis when available; NumPy is the deterministic CPU fallback.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence
import math

import numpy as np
from PIL import Image, ImageOps


@dataclass
class PixelMap:
    width: int
    height: int
    rgb: np.ndarray
    palette_index: np.ndarray
    drawable_mask: np.ndarray
    edge_map: np.ndarray
    importance_map: np.ndarray
    protected_mask: np.ndarray
    metadata: dict

    @property
    def pixels(self) -> int:
        return int(self.width * self.height)

    def as_meta(self) -> dict:
        out = dict(self.metadata)
        out.update({
            "width": self.width,
            "height": self.height,
            "pixels": self.pixels,
            "drawable_pixels": int(np.count_nonzero(self.drawable_mask)),
            "protected_pixels": int(np.count_nonzero(self.protected_mask)),
            "protected_percent": round(float(np.mean(self.protected_mask) * 100.0), 3),
            "edge_mean": round(float(np.mean(self.edge_map)), 4),
            "importance_mean": round(float(np.mean(self.importance_map)), 4),
        })
        return out


def _visible_rgb_rgba(image: Image.Image) -> tuple[Image.Image, np.ndarray]:
    rgba = ImageOps.exif_transpose(image).convert("RGBA")
    raw = np.asarray(rgba, dtype=np.uint8)
    alpha = raw[..., 3:4].astype(np.float32) / 255.0
    rgb = raw[..., :3].astype(np.float32) * alpha + 255.0 * (1.0 - alpha)
    return rgba, np.rint(rgb).clip(0, 255).astype(np.uint8)


def _to_perceptual(arr: np.ndarray) -> np.ndarray:
    c = np.clip(arr.astype(np.float32) / 255.0, 0.0, 1.0)
    lin = np.where(c <= 0.04045, c / 12.92, np.power((c + 0.055) / 1.055, 2.4))
    lr, lg, lb = lin[..., 0], lin[..., 1], lin[..., 2]
    y = 0.2126 * lr + 0.7152 * lg + 0.0722 * lb
    co = lr - lb
    cg = lg - (lr + lb) * 0.5
    chroma = np.sqrt(co * co + cg * cg)
    return np.stack((y, co, cg, chroma), axis=-1)


def _cpu_palette_map(rgb: np.ndarray, palette: np.ndarray, *, perceptual: bool,
                     row_chunk: int = 96) -> np.ndarray:
    h, w = rgb.shape[:2]
    out = np.empty((h, w), dtype=np.int16)
    pal = palette.astype(np.float32)
    if perceptual:
        pal_space = _to_perceptual(pal)
        weights = np.asarray((5.0, 1.7, 1.7, 0.8), dtype=np.float32)
        for y0 in range(0, h, row_chunk):
            y1 = min(h, y0 + row_chunk)
            src = _to_perceptual(rgb[y0:y1])
            diff = src[:, :, None, :] - pal_space[None, None, :, :]
            dist = np.sum(diff * diff * weights, axis=3)
            out[y0:y1] = np.argmin(dist, axis=2).astype(np.int16)
    else:
        for y0 in range(0, h, row_chunk):
            y1 = min(h, y0 + row_chunk)
            src = rgb[y0:y1].astype(np.float32)
            diff = src[:, :, None, :] - pal[None, None, :, :]
            dist = np.sum(diff * diff, axis=3)
            out[y0:y1] = np.argmin(dist, axis=2).astype(np.int16)
    return out


def exact_palette_map(image: Image.Image, palette_rgb: Sequence[Sequence[int]], *,
                      color_rendering: str = "Perceptual match", skip_white: bool = True,
                      gpu_mode: str = "Auto", gpu_vram: str = "Auto",
                      gpu_performance: str = "High throughput") -> tuple[np.ndarray, np.ndarray, np.ndarray, dict]:
    rgba, rgb = _visible_rgb_rgba(image)
    palette = np.asarray([tuple(map(int, p[:3])) for p in palette_rgb], dtype=np.uint8)
    if palette.ndim != 2 or palette.shape[0] < 1 or palette.shape[1] != 3:
        raise ValueError("Pixel Accurate mode requires at least one RGB palette colour.")

    drawable = np.any(np.asarray(rgba, dtype=np.uint8)[..., 3:4] > 0, axis=2)
    if skip_white:
        drawable &= np.min(rgb, axis=2) < 245

    gpu_meta = None
    if gpu_mode != "CPU":
        try:
            from GpuAcceleration import palette_indices_rgba
            candidates = tuple(range(len(palette)))
            result, info = palette_indices_rgba(
                rgba, tuple(map(tuple, palette.tolist())), candidates,
                tuple(False for _ in candidates), color_rendering=color_rendering,
                custom_mode="Calibrated palette", skip_white=skip_white,
                mode=gpu_mode, vram_budget=gpu_vram, performance=gpu_performance)
            if result is not None and info.accelerated:
                index_map, gpu_drawable = result
                return (np.asarray(index_map, dtype=np.int16),
                        np.asarray(gpu_drawable, dtype=np.bool_), rgb,
                        {"palette_backend": "cuda", "palette_gpu": info.as_dict(),
                         "palette_distance": color_rendering})
            gpu_meta = info.as_dict()
        except Exception as exc:
            gpu_meta = {"accelerated": False, "reason": f"{type(exc).__name__}: {exc}"}

    perceptual = color_rendering != "RGB nearest"
    index_map = _cpu_palette_map(rgb, palette, perceptual=perceptual)
    return index_map, drawable.astype(np.bool_), rgb, {
        "palette_backend": "cpu-numpy", "palette_gpu": gpu_meta,
        "palette_distance": "Perceptual match" if perceptual else "RGB nearest",
    }


def edge_map(rgb: np.ndarray, *, gpu_mode: str = "Auto", gpu_vram: str = "Auto",
             gpu_performance: str = "High throughput") -> tuple[np.ndarray, dict]:
    gray = np.rint(rgb[..., 0] * .299 + rgb[..., 1] * .587 + rgb[..., 2] * .114).clip(0, 255).astype(np.uint8)
    image = Image.fromarray(gray, mode="L")
    if gpu_mode != "CPU":
        try:
            from GpuAcceleration import sobel
            result, info = sobel(image, mode=gpu_mode, vram_budget=gpu_vram, performance=gpu_performance)
            if result is not None and info.accelerated:
                gx, gy = result
                gx = np.asarray(gx, dtype=np.float32).reshape(gray.shape)
                gy = np.asarray(gy, dtype=np.float32).reshape(gray.shape)
                mag = np.hypot(gx, gy)
                scale = max(1.0, float(np.percentile(mag, 99.5)))
                return np.clip(mag / scale, 0.0, 1.0).astype(np.float32), {
                    "edge_backend": "cuda", "edge_gpu": info.as_dict()}
            gpu_meta = info.as_dict()
        except Exception as exc:
            gpu_meta = {"accelerated": False, "reason": f"{type(exc).__name__}: {exc}"}
    else:
        gpu_meta = None

    f = gray.astype(np.float32)
    gx = np.zeros_like(f); gy = np.zeros_like(f)
    gx[:, 1:-1] = (f[:, 2:] - f[:, :-2]) * .5
    gy[1:-1, :] = (f[2:, :] - f[:-2, :]) * .5
    mag = np.hypot(gx, gy)
    scale = max(1.0, float(np.percentile(mag, 99.5)))
    return np.clip(mag / scale, 0.0, 1.0).astype(np.float32), {
        "edge_backend": "cpu-numpy", "edge_gpu": gpu_meta}


def importance_map(rgb: np.ndarray, palette_index: np.ndarray, edges: np.ndarray,
                   drawable: np.ndarray) -> np.ndarray:
    gray = rgb.astype(np.float32).mean(axis=2) / 255.0
    local = np.zeros_like(gray, dtype=np.float32)
    local[:, 1:-1] += np.abs(gray[:, 2:] - gray[:, :-2]) * .5
    local[1:-1, :] += np.abs(gray[2:, :] - gray[:-2, :]) * .5
    local = np.clip(local, 0.0, 1.0)

    valid = palette_index[drawable]
    rarity = np.zeros_like(gray, dtype=np.float32)
    if valid.size:
        counts = np.bincount(valid.astype(np.int64), minlength=int(np.max(palette_index)) + 1).astype(np.float64)
        pixel_counts = counts[np.clip(palette_index, 0, len(counts) - 1)]
        rarity = np.where(drawable, 1.0 - np.clip(pixel_counts / max(1.0, float(valid.size)), 0.0, 1.0), 0.0).astype(np.float32)
    darkness = (1.0 - gray).astype(np.float32)
    imp = edges * .62 + local * .18 + rarity * .12 + darkness * .08
    imp *= drawable.astype(np.float32)
    return np.clip(imp, 0.0, 1.0).astype(np.float32)


def protect_tiny_features(palette_index: np.ndarray, drawable: np.ndarray,
                          edges: np.ndarray, importance: np.ndarray) -> np.ndarray:
    if not np.any(drawable):
        return np.zeros_like(drawable, dtype=np.bool_)
    scores = importance[drawable]
    hi = max(.58, float(np.percentile(scores, 88.0))) if scores.size else .58
    protected = drawable & ((importance >= hi) | (edges >= .68))
    # One-pixel dilation keeps the visual footprint of a tiny eye/edge from being
    # split by later brush-aware planning, without changing its palette index.
    grown = protected.copy()
    grown[1:, :] |= protected[:-1, :]
    grown[:-1, :] |= protected[1:, :]
    grown[:, 1:] |= protected[:, :-1]
    grown[:, :-1] |= protected[:, 1:]
    # Only protect neighbouring pixels if they are drawable and have either the
    # same colour or meaningful local importance.
    same_or_important = np.zeros_like(drawable, dtype=np.bool_)
    same_or_important[1:, :] |= palette_index[1:, :] == palette_index[:-1, :]
    same_or_important[:-1, :] |= palette_index[:-1, :] == palette_index[1:, :]
    same_or_important[:, 1:] |= palette_index[:, 1:] == palette_index[:, :-1]
    same_or_important[:, :-1] |= palette_index[:, :-1] == palette_index[:, 1:]
    return drawable & grown & (same_or_important | (importance >= .42))


def groups_from_pixel_map(pixel_map: PixelMap, palette_count: int, *, lines: bool = True,
                          cancelled=lambda: False) -> list[list[tuple[int, int, int, int]]]:
    groups = [[] for _ in range(int(palette_count))]
    idx = pixel_map.palette_index; mask = pixel_map.drawable_mask
    for y in range(pixel_map.height):
        if cancelled():
            raise InterruptedError()
        previous = None; start = None
        for x in range(pixel_map.width + 1):
            color = int(idx[y, x]) if x < pixel_map.width and bool(mask[y, x]) else None
            if not lines:
                if color is not None:
                    groups[color].append((x, y, x, y))
            elif color != previous:
                if previous is not None:
                    groups[previous].append((int(start), y, x - 1, y))
                previous = color
                start = x if color is not None else None
    return groups


def build_pixel_map(image: Image.Image, palette_rgb: Sequence[Sequence[int]], *,
                    color_rendering: str = "Perceptual match", skip_white: bool = True,
                    gpu_mode: str = "Auto", gpu_vram: str = "Auto",
                    gpu_performance: str = "High throughput") -> PixelMap:
    index_map, drawable, rgb, palette_meta = exact_palette_map(
        image, palette_rgb, color_rendering=color_rendering, skip_white=skip_white,
        gpu_mode=gpu_mode, gpu_vram=gpu_vram, gpu_performance=gpu_performance)
    edges, edge_meta = edge_map(rgb, gpu_mode=gpu_mode, gpu_vram=gpu_vram,
                                gpu_performance=gpu_performance)
    importance = importance_map(rgb, index_map, edges, drawable)
    protected = protect_tiny_features(index_map, drawable, edges, importance)
    meta = {
        "engine": "Pixel Accurate Planner Block A",
        "full_resolution": True,
        "destructive_simplification": False,
        "tiny_feature_protection": True,
        **palette_meta, **edge_meta,
    }
    return PixelMap(rgb.shape[1], rgb.shape[0], rgb, index_map, drawable,
                    edges, importance, protected, meta)
