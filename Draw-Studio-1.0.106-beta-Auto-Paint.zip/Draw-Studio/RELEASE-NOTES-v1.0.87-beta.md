# Draw Studio v1.0.87-beta — Pixel Accurate Planner, Block B

Block B converts the full-resolution PixelMap from v1.0.86 into a component-aware, lossless stroke plan.

## 10 engine patches

1. **Exact connected regions** — same-palette pixels are labeled with 4-connected run-union-find; diagonal touches stay separate.
2. **Per-region metadata** — area, bounding box, edge strength, importance and protected-pixel coverage are tracked for scheduling.
3. **Local H/V orientation** — every connected component independently chooses horizontal or vertical raster runs according to exact run cost and thin-feature geometry.
4. **Lossless local run builder** — source pixels remain represented exactly; orientation changes do not alter the palette map.
5. **Component-safe path merging** — adjacent runs can share one mouse-down only inside the same connected component.
6. **Exact coverage verifier** — every merged path is checked for both no outside pixels and 100% component coverage; unsafe/incomplete merges fall back locally to individual runs.
7. **Protected-feature handling** — tiny/high-importance regions are retained as protected cleanup work rather than being folded into large fill scheduling.
8. **CPU component scheduler** — bounded nearest-component scheduling reduces travel/color switching without changing geometry or palette assignments.
9. **Four-pass renderer** — Pixel Accurate executes `fill -> mid detail -> fine detail -> cleanup`, with component/phase metadata kept in the final plan.
10. **DrawBot/release integration** — generic Smart Paths compression/target caps are bypassed for Block B execution paths; preview, execution, logs and PyInstaller all use the new component engine.

## Safety / compatibility

- Pixel Accurate still bypasses RealSpeedBudget, reduced palette, destructive simplification and Gartic Turbo.
- Existing Fast/Balanced/GPU Enhanced modes keep their previous renderers.
- CUDA remains responsible for PixelMap palette/edge analysis when available; Block B component scheduling is CPU-side by design.
- The mouse executor is unchanged: Block B only changes the planning layer.
