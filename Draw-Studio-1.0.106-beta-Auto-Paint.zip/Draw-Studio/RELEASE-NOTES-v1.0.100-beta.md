# v1.0.100-beta — Auto sketch time budget

## Så använder du Auto

1. Välj Gartic-profil och aktivera Single-color sketch (current ink).
2. Välj svart och tunn penna i spelet.
3. Sätt **Sketch detail → Auto**.
4. Ange tiden som återstår i spelet med appens Time budget, eller en kortare
   manuell tidsgräns. Appen läser INTE Gartics timer från skärmen.
5. Bygg preview och kontrollera Auto sketch-raden. Start bygger en ny slutplan.

Auto är standard för nya inställningar. Ett tidigare sparat Simple/Balanced/
Detailed behålls: välj Auto själv en gång i den profilen.

## Vad anpassas?

Auto provar Detailed, Balanced och Simple med riktiga ritplaner och väljer den
mest detaljerade variant som beräknas hinna. 15 procent av angiven tid reserveras;
planeringstid dras också av. Om hela Simple-planen fortfarande är för lång väljs
färre hela konturer med Gartic-motorns prioritet för längre konturer först.
Ritpreviewn byggs om efter urvalet. Sammanfattningen visar vald nivå, beräknad
tid och antalet utelämnade banor. Appen låtsas inte att alla detaljer bevarats.

Exempel: vid 60 sekunders budget är ritbudgeten högst 51 sekunder, minus
planeringen. En plan på 93,8 sekunder väljs bort. Om ingen säker ritplan ryms
visas ett tydligt fel. Manuella detaljlägen ändras inte automatiskt.

## Begränsningar

Detta är automatisk detaljanpassning till appens tid, inte OCR av spelets timer.
Tid som gått före Start, webbläsarlagg och serverns timer kan göra att en ritning
ändå inte blir färdig. Ange kvarvarande tid och lämna marginal. Den vanliga
avbrytningen vid tidsgränsen är kvar. Inga mål-/muskontroller stängs av.
Utelämnade korta konturer kan innehålla viktiga detaljer; ingen AI känner igen dem.
Gäller svart kontursketch. Färg-Pixel-Accurate behåller sin befintliga policy.

## Installation

Fullständigt paket: packa upp och kör Start.bat.
Patch för v1.0.99: stäng appen och kopiera DrawBot.py, StudioUI.py,
AutoSketchBudget.py, Version.py och version_info.txt till mappen med Start.bat.
Ersätt filerna. Inställningar och kalibrering behålls.

## Verifiering

786 automatiserade tester och source self-test godkända. Fem nya tester täcker
val efter tidsbudget, planeringstid, avbrott/ogiltig tid, reducering av en riktig
konturplan och oförändrat manuellt läge. Testfallet 93,8 sekunder mot 60 sekunders
budget bygger på den uppladdade loggen; originalbilden ingick inte i loggen.
Windows-gränssnitt och verklig Gartic-ritning är inte verifierade här.
Källkod med Start.bat, ingen nybyggd EXE.
