# v1.0.104-beta — Detailed preview

## Börja här
1. Packa upp hela ZIP-filen och kör Start.bat.
2. Läs in en bild och välj ritområde som vanligt.
3. Använd Build preview för en snabb förhandsvisning.
4. Välj Full detail preview för ritplanen i målupplösning.
5. Välj 1:1 för originalstora målpixlar, +/− för zoom och dra för att panorera.
   Fit visar hela bilden igen. Full detail startar aldrig musritning.

## Stabilitet och visning
- Zoom renderar bara det synliga utsnittet. Bilden förstoras inte till en jättestor bitmap.
- Bara synliga previewflikar skapar Tk-bilder. Dolda flikars Tk-bilder släpps.
- Full detail har en förkontroll av målupplösningen mot vald RAM-budget, högst
  8 miljoner målpixlar, och använder en CPU-worker. Detta är en uppskattad
  planeringsgräns, inte en hård gräns för processens totala minnesanvändning.
- Beräkningen har avbrytningskontroller och en tidsgräns på 60 sekunder.
  En enskild biblioteksoperation kan behöva avslutas innan avbrottet märks.
- Full detail faller inte tillbaka till en förenklad preview i hemlighet.
- Color map delar ritplanens bild och gör ingen separat färgkvantisering.
- Fel i hjälpkartor lämnar huvudbilden tillgänglig. Vid timeout behålls tidigare preview.
- Coverage och Accuracy förklarar när de kräver Pixel Accurate; sketch beräknar inte dessa kartor.

Förhandsvisningen simulerar den planerade ritningen, inte verkligt resultat i spelet.
Ritmotorns valda upplösning/stil gäller fortfarande. En ny plan vid Start kan
ändras av återstående tid, automatisk stil och CPU/GPU-backend.

810 automatiserade tester samt source self-test godkända på Linux.
Windows-GUI, verklig musritning och CUDA har inte provkörts i denna miljö.
Paketet innehåller källkod och Start.bat; ingen nybyggd EXE.
