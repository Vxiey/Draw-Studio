# Draw Studio v1.0.60-beta — Performance Auto Tuner

## New

- Local **Performance Auto Tuner** in Tools and Advanced CPU/RAM controls.
- Benchmark-only, Benchmark & apply, and Apply saved recommendation actions.
- Benchmarks safe CPU worker scaling and current RAM headroom.
- Tests optional NVIDIA CUDA throughput/VRAM when available; safely falls back to CPU.
- Recommends Resource Scheduler workers, RAM budget, GPU/VRAM policy and planning resolution.
- Saves the recommendation locally for reuse.

## Safety / privacy

- The tuner never arms mouse input.
- CanvasGuard, FinalMouseGuard, Safe Fill, edge verification and all drawing safety controls are untouched.
- No telemetry, cloud benchmark, background request or upload.
- GPU benchmark failure is contained and produces a CPU recommendation.

## Release verification

- 512/512 unit tests passed.
- `compileall` passed.
- `DrawBot.py --self-test` passed.
- PyInstaller configuration includes `PerformanceAutoTuner`.
