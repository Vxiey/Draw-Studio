# Browser Visual Preflight — v1.0.72-beta

Before a supported browser profile can start drawing, Draw Studio performs a read-only visual verification of the current browser client.

Checks:
- calibrated safe canvas still matches the visually detected canvas,
- representative palette swatches still show their calibrated RGB values,
- screenshot/client dimensions are stable,
- one automatic Browser Auto-Recalibration retry is allowed,
- persistent mismatch blocks all drawing input.

This step sends no mouse or keyboard input.
