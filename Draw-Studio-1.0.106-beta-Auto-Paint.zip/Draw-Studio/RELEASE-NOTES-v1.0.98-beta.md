# v1.0.98-beta — Gartic connected contours

Sketchmotorn för Gartic.io och Gartic Phone följer nu sammanhängande svarta
konturer i stället för att behandla dem som separata horisontella rader.

- Diagonaler, kurvor och slutna konturer följs med sammanhängande ritbanor.
- Längre konturer planeras först, sedan korta detaljer. Ordningen behålls vid ritning.
- Exakt raka mellanpunkter tas bort. Inga genvägar över tomma ytor och inga
  borttagna komponenter i den nya konturspåraren.
- Mycket punktintensiva banor delas med gemensamma ändpunkter.
- Den tidigare svartvita kantbehandlingen behålls. Detta är inte AI och
  identifierar inte automatiskt vilket föremål som är viktigast.

## Användning

Välj Gartic.io eller Gartic Phone. Slå på Single-color sketch (current ink),
välj svart och en tunn penna i spelet och börja på en tom canvas. Markera ritytan,
bygg preview och tryck Start. Den nya motorn används automatiskt för Gartic-sketch.
Den används också med Black contour sketch och kalibrerad svart färgruta.
Färgritning och Pixel Accurate i färg behåller sina befintliga motorer.

## Installera patchen på v1.0.97

Stäng appen. Packa upp patchen och kopiera DrawBot.py, GarticSketchPaths.py,
Version.py och version_info.txt till mappen med Start.bat. Välj Ersätt och starta
med Start.bat. Inställningar och kalibrering lämnas kvar. Fullständigt paket
finns för separat installation. Ingen nybyggd EXE.

## Verifiering och begränsningar

777 automatiserade tester samt source self-test godkända. Syntetiska tester
kontrollerar diagonaler, slutna kurvor, förgreningar, isolerade punkter, delning,
avbrott, rasterbevarande och att körningen behåller konturordningen.
På en syntetisk bild (160×120, oval och triangel) minskade banorna från 29 till 3.
Beräknad ritningstid ändrades bara från 5,04 till 4,98 sekunder: färre musnedtryck
är inte samma sak som en proportionell hastighetsökning. Detta är ett litet
test av motorn, ingen representativ mätning av bilder eller Gartics inputfördröjning.
Konturspårningen bevarar det analyserade rastret; skalad preview och spelets
pensel kan ändå ge olika pixelresultat. Tidsgränsen kan avbryta före alla detaljer.
Windows-gränssnitt och faktisk Gartic-ritning är inte provkörda här.
