# Draw Studio v1.0.91-beta — Unified Draw Motor

This release merges the two v1.0.90 development branches. The Upscaling package lacked the separately released adaptive brush motor; both are now integrated using v1.0.89 as their common base.

Included: adaptive per-path browser brush selection, CPU/CUDA brush-aware simulation, detail-brush corrections, crash diagnostics and Windows dump setup, mouse-probe fixes, bounded CUDA batches, Subject Focus, content-based image format detection, transparency information, 2×/4× upscaling and Undo.

Subject Focus keeps its 1 px path policy, subject-first ordering and disabled background-restoring correction passes. Adaptive brush policy recognizes subject/background phase prefixes. Both v1.0.90 release histories are preserved under distinct filenames. Small Swedish guides are also included in the Windows build resources.

Validation: 739 automated tests passed; source self-test passed; Python syntax and archive integrity checked. Windows GUI/input, native dumps and real NVIDIA CUDA remain unverified here. This is a source release with Start.bat, not a built Windows executable.

Read PATCH-AUDIT-v1.0.91.md for the archive comparison, missing-branch finding, merge details and user-data limitations.
