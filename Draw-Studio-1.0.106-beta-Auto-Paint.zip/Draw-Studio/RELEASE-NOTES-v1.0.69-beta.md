# Draw Studio v1.0.69-beta – Mobile Preview Live

## Added

- New **Mobile Preview** button in the Preview workspace and Tools.
- Starts an opt-in local HTTP preview page only after the user explicitly requests it.
- Phone/tablet page shows **Drawing Preview**, **Original** and **Safety Map**.
- Auto-refreshes approximately once per second when Draw Studio publishes a new preview.
- Uses a random per-session URL token and keeps preview images in memory only.
- Displays a QR code when QR support is installed; the local address can always be copied manually.
- Responsive mobile page uses no external JavaScript, fonts, analytics or cloud assets.

## Network / privacy

- Mobile Preview binds only while explicitly running and stops when Draw Studio closes or the user presses Stop.
- It is intended for devices on the same Wi-Fi/LAN.
- No cloud relay, telemetry, account, upload service or internet API is used by Mobile Preview.
- If Windows Firewall prompts, allow the app on **Private networks** only.

## Unchanged safety

- Mobile Preview is read-only and never arms mouse input.
- CanvasGuard, FinalMouseGuard, Dry Run, target monitoring and drawing execution are unchanged.
