# Draw Studio v1.0.59-beta — GitHub Update Center

## Added
- Manual **Check for updates** button in Tools.
- Shows current version, latest compatible GitHub release and update availability.
- Opens the official Draw Studio GitHub Release page.
- Beta channel can see prerelease/beta and stable releases; stable channel ignores prereleases.

## Privacy / safety
- No background update checks.
- No telemetry or device identifiers.
- No automatic downloads or installation.
- GitHub is contacted only after an explicit **Check for updates** click.
- Update checks use the public GitHub Releases API with a generic DrawStudio version User-Agent.

## GitHub Publisher compatibility
The Windows workflow can build from either a normal checked-out source tree or a source ZIP stored in the repository root. This is useful for GitHub's web upload limit when the project contains many files.
