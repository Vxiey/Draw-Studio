# Draw Studio v1.0.64-beta — Skribbl Turbo Renderer

- Dedicated Skribbl.io Fast planning path.
- Uses calibrated palette only; no custom RGB modal workflow in Fast mode.
- Reduces active colors to a small high-coverage palette while preserving dark structure.
- Remaps rare colors to the nearest retained calibrated color.
- Coalesces adjacent same-color raster runs.
- Joins overlapping rows into continuous safe paths to reduce press/release overhead.
- 60-second default Fast budget with automatic path cap.
- 12 px browser stroke interpolation under Normal precision for fewer native cursor events.
- Microsoft Paint and other profiles are unchanged.
- No AI/ML/OCR.
