# Layout Fingerprint v2 — v1.0.76-beta

Supported browser profiles now cache verified layout metadata locally:

- canvas geometry relative to the browser client
- palette layout and calibrated RGB values
- browser client size
- Windows DPI
- geometry-derived browser zoom/layout signature

On a repeated layout Draw Studio takes one read-only screenshot and samples a few saved palette control points. A verified match restores the canvas and anchored palette immediately without running the full palette/canvas detector. A mismatch falls back to normal Browser Auto Setup.

The cache contains no screenshots, source images, URLs or telemetry. Browser Visual Preflight remains mandatory before native drawing input.
