# Draw Studio v1.0.92-beta — Compact Workspace

Replaces the wide three-column workspace with section-based settings, a preview selector, scrollable readiness/tools and wrapping action rows. All nine preview modes and drawing safety gates remain available. Blue-grey theme with a blue accent; constrained menus and responsive header reduce horizontal overflow.

Coalesced pointer-local scrolling replaces competing global CTk scroll handlers. Window lifecycle management hides the app for calibration/capture and restores prior normal/maximized state on completion. Manual calibration point captures hide their own windows too. Paint auto-calibration runs in a worker. Palette/exact-colour helper output is drained while waiting, with cancellation.

Manual GitHub checks show “You are on the latest version.” or “Download version X”. The download button opens the GitHub release. Failed checks and no published releases are reported separately. No automatic installation.

All v1.0.91 source files retained. 752 automated tests pass and source self-test passes. Windows UI/DPI/scroll and live GitHub connectivity remain unverified in this Linux environment. See WORKSPACE-v1.0.92.md.
