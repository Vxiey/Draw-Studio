# v1.0.97-beta — Single-color sketch for games

## Gartic.io och Gartic Phone

1. Välj rätt spelprofil i Draw Studio.
2. Aktivera **Single-color sketch (current ink)** under profilvalet.
3. Välj svart och en tunn penna i spelet, helst 1 px. Börja på en tom vit canvas.
4. Lägg in bilden och markera ritytan som vanligt.
5. Bygg förhandsvisningen och klicka Start när du är redo.

Ingen färgpalett behöver kalibreras för detta läge. Boten använder den färg
som redan är vald i spelet. Den kan inte garantera svart om du själv valt en
annan färg; förhandsvisningen visar svart. Spelprofiler använder enkla konturer
och stänger av motivfokus för att undvika inställningskonflikten i v1.0.95.

Gartic Phones automatiska kontroll läser nu canvasen utan att kräva en komplett
färgpalett. Kontroll av rityta, målfönster och mus behålls. Visa en tydligt synlig,
tom canvas om automatisk detektion misslyckas. Färgläget kräver fortsatt palett.
Paints befintliga enfärgsläge med valbar skuggning behålls.

För färgritning: stäng av både Single-color sketch och Black contour sketch,
och läs in färgpaletten igen. Dina profiler sparar enfärgsinställningen.

## Installera patchen på v1.0.96

Stäng Draw Studio. Packa upp patchen och kopiera de sex kod-/versionsfilerna
till din befintliga Draw-Studio-mapp där Start.bat ligger. Välj Ersätt filer.
Starta sedan med Start.bat. Patchen ändrar inga kalibrerings- eller inställningsfiler.
Hela paketet finns också för en separat installation.

## Verifiering

770 automatiserade tester och source self-test godkända. Nya tester kontrollerar
profilstöd, UI-reglaget, konturritning utan palettklick, canvas-kontroll utan
palett samt att flyttad/saknad canvas och färgläge utan palett fortfarande stoppas.
Windows-gränssnitt och faktisk ritning i spelen har inte provkörts här.
Källkodspaket med Start.bat; ingen ny Windows-EXE.
