# Draw Studio v1.0.82-rc2 — RC1 field-log fixes

This release candidate is a focused bug-fix release based on real RC1 session logs.

## Fixed

- Canvas edge verification now distinguishes an unsafe edge inside the selected canvas from a conservative selected inset. A visible edge outside the selected area no longer blocks drawing because CanvasGuard is already tighter than the detected edge.
- Fixes Gartic Phone false stops such as `bottom edge +21px` caused by stacked-paper decoration below the canvas.
- CustomTkinter scroll guard prevents contained mouse-wheel callback exceptions when Tk reports a destroyed widget as a Tcl path string.
- Stop/Cancel no longer writes `Manual Drop-In Start disarmed: stop requested` every poll tick after the state is already idle.
- Browser One-Click has an idle-loop fallback that re-schedules a queued setup if its original Tk `after()` callback is lost/cancelled.

## Safety

- Edges that fall inside the selected canvas still hard-stop before mouse input.
- CanvasGuard, FinalMouseGuard, Visual Preflight and Auto-Recalibration remain mandatory where applicable.
- No automatic retry can bypass a failed inward-boundary check.
