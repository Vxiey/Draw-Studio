# v1.0.106-beta — Auto setup Paint

## Så gör du
1. Packa upp hela ZIP-filen och kör Start.bat.
2. Öppna ett Paint-fönster med en tom, helt synlig rityta.
   Använd ljus appdesign, visa hela verktygsfältet och stäng öppna menyer.
3. Välj Microsoft Paint i Draw Studio och tryck Auto setup Paint.
4. Draw Studio minimeras och läser av rityta, 20 färger, Pencil, Fill och Eraser.
   Du behöver inte först markera ritytan. Inga ritklick skickas vid kalibreringen.
5. Appens Auto-verktyg väljer Pencil. Ställ Pencil på 1 px i Paint och kör Small test.
6. Lägg in din bild, välj exempelvis Extra fast och bygg preview innan Start.

Penselbredden kan ännu inte läsas automatiskt med tillräcklig säkerhet.
Brush-menyn och dess penseltyper kalibreras inte av detta flöde: Pencil används
som ett direkt, opakt ritverktyg och Fill får en separat verifierad position.

## Vad som ändrats
- Tidigare gissningar från ikonernas täthet/ordning används inte längre.
- Modern Paint identifieras genom färgrutornas inbördes placering och jämförelse
  med Pencil-, Fill- och Eraser-ikonerna från den uppladdade referensen.
- Riktiga RGB-värden läses från 20 verifierade färgrutor; dubletter undviks.
- Koordinater förankras i Paint-fönstret och inkluderar skärmens position.
- Storleken på analysbilderna begränsas och arbetet körs i bakgrundstråden.
- Täckta eller okända verktyg, flera Paint-fönster, täckta färger och osäker
  rityta ger ett tydligt fel. Manuell kalibrering finns kvar.
- Auto setup startar inte ritning eller väljer Done/Fill genom att klicka.

## Verifiering och begränsningar
821 automatiserade tester samt source self-test godkända på Linux.
Den uppladdade Paint-bilden och skalade kopior vid 80/100/125/150/200 procent
har kontrollerats. Det är bildtester, inte provkörning av verkliga Windows
DPI-inställningar. Själva Windows-aktiveringen, GUI-flödet och ritningen måste
fortfarande verifieras på Windows.

Detta är stöd för den moderna ljusa Paint-layouten i referensbilden, inte ett
löfte om alla äldre/nya Paint-versioner, mörkt tema eller hopfällda verktygsfält.
Befintliga bilder och ritytor som ligger utanför fönstret väljs manuellt.
Paketet innehåller källkod och Start.bat; ingen nybyggd EXE.

---

# v1.0.105-beta — Extra fast

## Använd läget
1. Packa upp hela paketet och kör Start.bat.
2. Välj programprofil och kalibrera rityta och färgpalett som vanligt.
3. För bucket fill behöver profilen även ha Brush/Pencil och Fill kalibrerade.
4. Välj Drawing preset → Extra fast. Läs in bilden och bygg preview.
5. Kör Safety preflight / ett litet prov på tom rityta före vanlig Start.

Extra fast använder befintliga Closed regions v2: ritar slutna konturer i
regionens färg, fyller deras insidor och fortsätter med kvarvarande penseldrag.
Konturer och fyllningar grupperas per färg; det är inte en separat svart
kontur över hela bilden. Inga automatiska klick sker när förvalet väljs.

En ny kostnadsberäkning inkluderar konturrörelse, verktygsbyten och väntetider.
Fyllning väljs bara om uppskattningen är minst 25 procent snabbare än regionens
scanlines. Detta är en uppskattning, ingen uppmätt hastighetsgaranti jämfört med
alla andra ritmotorer. Högst 12 regioner från den befintliga regiondetektorn
utvärderas. Avvisade regioner behåller vanliga penseldrag.

Läget använder kalibrerad palett, slutna regioner, ingen bakgrundsfyllning av
hela duken och inga extra färglager. Det fungerar bäst för illustrationer,
logotyper och stora enhetliga färgytor. Foton kan få få eller inga fyllningar.
Utan Fill-kalibrering används Smart paths. Vid enfärg/Outline används enkel
svart sketch utan fyllning. Eraser stöds inte i detta förval.

Befintliga kontroller av rityta, fyllningsfärg och förändringar utanför regionen
behålls. Kantnära, öppna och osäkra regioner faller tillbaka till penseldrag.
Analysen av stora sammanhängande ytor har tätare avbrytningskontroller.
Minnesgränser och preview-förbättringar från v1.0.104 finns kvar.

815 automatiserade tester och source self-test godkända på Linux.
Windows-GUI, musritning och verklig Gartic/Paint-fyllning är inte provkörda här.
Källkod med Start.bat; ingen nybyggd EXE. Tidigare sparade inställningar behålls.

---

# v1.0.104-beta — Detailed preview

## Börja här
1. Packa upp hela ZIP-filen och kör Start.bat.
2. Läs in en bild och välj ritområde som vanligt.
3. Använd Build preview för en snabb förhandsvisning.
4. Välj Full detail preview för ritplanen i målupplösning.
5. Välj 1:1 för originalstora målpixlar, +/− för zoom och dra för att panorera.
   Fit visar hela bilden igen. Full detail startar aldrig musritning.

## Stabilitet och visning
- Zoom renderar bara det synliga utsnittet. Bilden förstoras inte till en jättestor bitmap.
- Bara synliga previewflikar skapar Tk-bilder. Dolda flikars Tk-bilder släpps.
- Full detail har en förkontroll av målupplösningen mot vald RAM-budget, högst
  8 miljoner målpixlar, och använder en CPU-worker. Detta är en uppskattad
  planeringsgräns, inte en hård gräns för processens totala minnesanvändning.
- Beräkningen har avbrytningskontroller och en tidsgräns på 60 sekunder.
  En enskild biblioteksoperation kan behöva avslutas innan avbrottet märks.
- Full detail faller inte tillbaka till en förenklad preview i hemlighet.
- Color map delar ritplanens bild och gör ingen separat färgkvantisering.
- Fel i hjälpkartor lämnar huvudbilden tillgänglig. Vid timeout behålls tidigare preview.
- Coverage och Accuracy förklarar när de kräver Pixel Accurate; sketch beräknar inte dessa kartor.

Förhandsvisningen simulerar den planerade ritningen, inte verkligt resultat i spelet.
Ritmotorns valda upplösning/stil gäller fortfarande. En ny plan vid Start kan
ändras av återstående tid, automatisk stil och CPU/GPU-backend.

810 automatiserade tester samt source self-test godkända på Linux.
Windows-GUI, verklig musritning och CUDA har inte provkörts i denna miljö.
Paketet innehåller källkod och Start.bat; ingen nybyggd EXE.

---

# v1.0.103-beta — Human mode off

Human mode är borttaget från gränssnittet och alltid Off i appens ritplanering.
Gamla profilval (Subtle/Natural/Strong) ignoreras. Profilbyte och nya sparade
inställningar använder Off. Human modes extra pauser och variationer används
inte längre. Säkerhetskontroller och nödvändiga inmatningsfördröjningar behålls.

Fullständigt paket: packa upp och kör Start.bat.
Patch för v1.0.102: stäng appen och kopiera DrawBot.py, StudioUI.py, Version.py
och version_info.txt till mappen med Start.bat. Ersätt filerna och starta igen.
Kalibrering och övriga profilinställningar behålls.

803 automatiserade tester samt source self-test godkända. Det befintliga
testet av appens human_mode-val förväntar nu Off även med ett äldre sparat val.
Äldre hjälpfunktioner finns kvar för källkodskompatibilitet, men appen väljer
aldrig deras aktiva lägen. Windows-ritning har inte provkörts här.
Källkod med Start.bat; ingen nybyggd EXE.

---

# Draw Studio v1.0.102-beta

## Enklaste arbetsflödet

1. Packa upp hela paketet och kör **Start.bat**. Behåll din tidigare mapp.
2. Välj **Gartic Phone**. Visa en tom spelcanvas i webbläsaren.
3. Klicka **Auto setup Gartic — full canvas**. Appen minimeras, söker en
   entydig spelvy och kalibrerar hela ritytan och paletten. Ingen ritning startas.
4. Lägg in bilden. Välj **Drawing preset → Auto**.
5. Bygg preview, kontrollera resultatet och klicka Start. Gartics timer läses
   vid Start om Read Gartic timer är aktivt och du inte valt Unlimited.

Penselstorleken verifieras med den befintliga avläsningen före ritning.
Single-color sketch använder färgen som redan är vald i spelet: välj svart.
Fullfärgsläget använder den kalibrerade paletten. En skymd/oklar spelvy kan
kräva manuell markering; detta är inte garanti för alla zoomnivåer eller teman.

## Drawing preset

| Val | Funktion |
| --- | --- |
| Auto | Klassificerar grovt med vitandel, färger och textur. Linjegrafik använder konturer; platta färgillustrationer Shape paths; fotoliknande färgbilder Smart paths. Befintligt enfärgsläge respekteras och får Auto-sketchdetaljer. |
| Manual | Dina egna motor-, kvalitets- och sketchval behålls. |
| Masterpiece | Ingen ritningstimer. Färgbilder använder Pixel Accurate utan snabbprofilens förenkling. Enfärg/sketch använder Detailed med den befintliga konturmotorn. |

Auto är en regelbaserad rekommendation, ingen AI eller visuell förståelse av
motivet. Du kan välja Manual om motorvalet inte passar bilden. Masterpiece är
namnet på kvalitetspreseten, ingen garanti för konstnärligt resultat. Det är
fortfarande den valda paletten, penseln och konturmotorns upplösning som begränsar
resultatet. Kontursketch använder fortsatt högst 720 pixlar på längsta sidan;
färg-Pixel-Accurate arbetar med hela målupplösningen.

## Unlimited

Välj **Unlimited** bland tidsinställningarna. Den vanliga ritningstimern och
Gartic-timeravläsningen används då inte. Stop/Esc, pauskontroll, mus-/fönstervakter,
resursbegränsningar och planerings-watchdog finns kvar. Unlimited förlänger inte
Gartics runda. Använd det i Paint eller ett spelläge som tillåter tillräckligt med tid.
Masterpiece väljer Unlimited automatiskt. Auto med Unlimited prioriterar
Pixel Accurate för färg och Detailed för enfärg.

## Clear image / Clear cached drawing

- **Clear image** stoppar arbetet och tar bort källbild, preview, ritplan och
  lokalt återupptagningscache. Lägg sedan in en ny bild.
- **Clear cached drawing** stoppar arbetet och rensar plan/återupptagning men
  behåller källbilden för en ny planering.

Knapparna kan användas under arbete. Rensningen väntar tills den avbrutna
arbetstråden är klar. Sena bild-/planresultat ignoreras under rensningen så att
den gamla bilden inte kommer tillbaka. Sparade profiler och kalibrering behålls.
Detta raderar INTE redan målade pixlar i Paint eller Gartic.

## Kalibreringsfix

Den stora förhandsvisningen av vald färg kunde felaktigt väljas som svart
palettknapp. Gartics 6×12-rutnät verifieras nu geometriskt och varje färgpunkt
kontrolleras mot skärmens färg. Kalibreringen ger inte klick på Done/Restore.
På den uppladdade hela skärmbilden hittades 72 färger och canvas
(496,244)-(1446,774), alltså 950×530 pixlar. Även skalade kopior på 80 och
125 procent gav 72 verifierade färger. Detta testar bilddetektion, inte live-input.

## Installation och verifiering

Hela paketet rekommenderas. Patchen kräver v1.0.101: stäng appen och kopiera
patchens kod-/versionsfiler till mappen med Start.bat. Ersätt filerna.

803 automatiserade tester och source self-test godkända. Nya tester täcker
motorval, Masterpiece/Unlimited, skydd mot snabbprofilens tidsöverskrivning,
cache-rensning och sena resultat, väntan på arbetstråd samt korrekt palettrutnät.
Windows-gränssnitt, upptäckt av live-fönster och faktisk ritning är fortfarande
inte provkörda här. Källkod med Start.bat; ingen nybyggd EXE.

---

# v1.0.101-beta — Read Gartic timer

## Användning

1. Välj **Gartic Phone** och ditt sketchläge. Välj svart i spelet.
2. Låt **Read Gartic timer at Start** vara aktiverat (ny standard).
3. Visa hela den runda timern och ritytan i webbläsaren.
4. Klicka Start. Appen minimeras och läser timern sju gånger under cirka sex
   sekunder. Inga mus-/tangenttryck skickas under avläsningen.
5. Status visar ungefärliga sekunder kvar och en försiktigare ritbudget.
   Sketch använder Auto-detaljer utifrån den uppmätta tiden.

Om avläsningen inte är säker stoppas starten. Visa timern tydligt och försök
igen, eller stäng av reglaget och ange tiden manuellt. Övriga spelprofiler,
små provritningar och dry run använder inte denna timeravläsning.
Preview före Start använder fortfarande appens manuella tidsbudget.

## Hur sekunderna beräknas

En ensam bild av cirkeln innehåller ingen total rundtid. Detektorn mäter den
vita andelen längs flera cirklar och följer minskningen. Andel kvar dividerad
med minskning per sekund ger en uppskattning av sekunder kvar. Ingen OCR/AI
eller antagen fast rundlängd används.

Ringen måste ha rätt form/färg, vara entydig och finnas utanför den valda
ritytan. En skymd ring, en stillastående timer, en återställning eller ojämn
minskning stoppar mätningen. Mätosäkerheten ger en lägre, konservativ budget.
Auto-sketch lämnar sedan sin vanliga marginal. Det kan ge färre detaljer,
men appen presenterar inte uppskattningen som exakta sekunder.

En absolut sluttid följer planen och begränsar musmotorn. Planering, väntan och
paus flyttar inte fram den. Om för mycket tid gått före ritstart stoppas den.
Motorn läser inte timern kontinuerligt medan den ritar: ändras spelets timer
senare kan den tidigare uppskattningen vara inaktuell. Stop/Esc finns kvar.

## Installation

Hela paketet: packa upp och kör Start.bat. Behåll den gamla mappen.
Patch för v1.0.100: stäng appen och kopiera DrawBot.py, StudioUI.py,
GarticTimer.py, Version.py och version_info.txt till mappen med Start.bat.
Välj Ersätt filer. Inställningar och kalibrering behålls.

## Verifiering

794 automatiserade tester och source self-test godkända. Åtta nya tester
kontrollerar skalning/andelar, flera rundlängder, återställning/stillastående
ring, avbrott, tidsbudget över gamla presets, simulerad avläsningsserie och
att en utgången sluttid inte skickar musnedtryck.

Den uppladdade timerbilden hittades vid bildkoordinater (100,64)-(176,140)
med cirka 46,5 procent vit fyllning. Den bilden ensam kan inte validera sekunder.
Tidmätningen har testats med syntetiska bildserier, inte en inspelning från
användarens riktiga runda. Windows-gränssnitt, live-avläsning och faktisk ritning
behöver fortfarande provköras. Källkod med Start.bat, ingen nybyggd EXE.

---

# v1.0.100-beta — Auto sketch time budget

## Så använder du Auto

1. Välj Gartic-profil och aktivera Single-color sketch (current ink).
2. Välj svart och tunn penna i spelet.
3. Sätt **Sketch detail → Auto**.
4. Ange tiden som återstår i spelet med appens Time budget, eller en kortare
   manuell tidsgräns. Appen läser INTE Gartics timer från skärmen.
5. Bygg preview och kontrollera Auto sketch-raden. Start bygger en ny slutplan.

Auto är standard för nya inställningar. Ett tidigare sparat Simple/Balanced/
Detailed behålls: välj Auto själv en gång i den profilen.

## Vad anpassas?

Auto provar Detailed, Balanced och Simple med riktiga ritplaner och väljer den
mest detaljerade variant som beräknas hinna. 15 procent av angiven tid reserveras;
planeringstid dras också av. Om hela Simple-planen fortfarande är för lång väljs
färre hela konturer med Gartic-motorns prioritet för längre konturer först.
Ritpreviewn byggs om efter urvalet. Sammanfattningen visar vald nivå, beräknad
tid och antalet utelämnade banor. Appen låtsas inte att alla detaljer bevarats.

Exempel: vid 60 sekunders budget är ritbudgeten högst 51 sekunder, minus
planeringen. En plan på 93,8 sekunder väljs bort. Om ingen säker ritplan ryms
visas ett tydligt fel. Manuella detaljlägen ändras inte automatiskt.

## Begränsningar

Detta är automatisk detaljanpassning till appens tid, inte OCR av spelets timer.
Tid som gått före Start, webbläsarlagg och serverns timer kan göra att en ritning
ändå inte blir färdig. Ange kvarvarande tid och lämna marginal. Den vanliga
avbrytningen vid tidsgränsen är kvar. Inga mål-/muskontroller stängs av.
Utelämnade korta konturer kan innehålla viktiga detaljer; ingen AI känner igen dem.
Gäller svart kontursketch. Färg-Pixel-Accurate behåller sin befintliga policy.

## Installation

Fullständigt paket: packa upp och kör Start.bat.
Patch för v1.0.99: stäng appen och kopiera DrawBot.py, StudioUI.py,
AutoSketchBudget.py, Version.py och version_info.txt till mappen med Start.bat.
Ersätt filerna. Inställningar och kalibrering behålls.

## Verifiering

786 automatiserade tester och source self-test godkända. Fem nya tester täcker
val efter tidsbudget, planeringstid, avbrott/ogiltig tid, reducering av en riktig
konturplan och oförändrat manuellt läge. Testfallet 93,8 sekunder mot 60 sekunders
budget bygger på den uppladdade loggen; originalbilden ingick inte i loggen.
Windows-gränssnitt och verklig Gartic-ritning är inte verifierade här.
Källkod med Start.bat, ingen nybyggd EXE.

---

# v1.0.99-beta — Simpler sketches

## Användning

Under ritinställningarna finns nu **Sketch detail**:

- **Simple** (standard): kraftigare utjämning och filtrering av små kantfragment.
- **Balanced**: mellannivå som behåller mer struktur.
- **Detailed**: tidigare kantbehandling från v1.0.98.

Använd Single-color sketch eller Black contour sketch, välj detaljnivå och
tryck Build preview. För Gartic används fortsatt motorn som följer sammanhängande
konturer. Välj svart och en tunn penna i spelet när du använder current ink.
Detaljnivån sparas per profil. Gamla profiler utan värdet får Simple.
Ändring av nivån startar ingen ritning och följer befintligt Manual Preview-läge.
Det tidigare gränssnittet och färgmotorn behålls.

Simple kan ta bort tunna eller svagt kontrasterande detaljer, även i motivet.
Välj Balanced eller Detailed om viktiga drag försvinner. Funktionen känner
inte igen människor eller skiljer semantiskt mellan motiv och bakgrund.

## Installation

Fullständigt paket: packa upp och kör Start.bat. Behåll tidigare installation.
Patch för v1.0.98: stäng programmet och kopiera DrawBot.py, StudioUI.py,
SketchPlanner.py, Version.py och version_info.txt till mappen med Start.bat.
Välj Ersätt filer. Inställningar och kalibrering behålls.

## Verifiering

781 automatiserade tester och source self-test godkända. Nya tester kontrollerar
texturdämpning med bevarad huvudkontur, tidigare Detailed-resultat, transparenta
och enfärgade bilder samt felaktig detaljnivå.
På en syntetisk 240×180-bild med tunna grå bakgrundslinjer och en svart oval:
Detailed gav 92 banor, Balanced 4 och Simple 2. Det är ett avgränsat test,
inte en mätning av användarens fotografi eller hastigheten i Gartic.
Windows-gränssnitt och faktisk ritning är inte provkörda här. Källkod med
Start.bat, ingen nybyggd EXE.

---

# v1.0.98-beta — Gartic connected contours

Sketchmotorn för Gartic.io och Gartic Phone följer nu sammanhängande svarta
konturer i stället för att behandla dem som separata horisontella rader.

- Diagonaler, kurvor och slutna konturer följs med sammanhängande ritbanor.
- Längre konturer planeras först, sedan korta detaljer. Ordningen behålls vid ritning.
- Exakt raka mellanpunkter tas bort. Inga genvägar över tomma ytor och inga
  borttagna komponenter i den nya konturspåraren.
- Mycket punktintensiva banor delas med gemensamma ändpunkter.
- Den tidigare svartvita kantbehandlingen behålls. Detta är inte AI och
  identifierar inte automatiskt vilket föremål som är viktigast.

## Användning

Välj Gartic.io eller Gartic Phone. Slå på Single-color sketch (current ink),
välj svart och en tunn penna i spelet och börja på en tom canvas. Markera ritytan,
bygg preview och tryck Start. Den nya motorn används automatiskt för Gartic-sketch.
Den används också med Black contour sketch och kalibrerad svart färgruta.
Färgritning och Pixel Accurate i färg behåller sina befintliga motorer.

## Installera patchen på v1.0.97

Stäng appen. Packa upp patchen och kopiera DrawBot.py, GarticSketchPaths.py,
Version.py och version_info.txt till mappen med Start.bat. Välj Ersätt och starta
med Start.bat. Inställningar och kalibrering lämnas kvar. Fullständigt paket
finns för separat installation. Ingen nybyggd EXE.

## Verifiering och begränsningar

777 automatiserade tester samt source self-test godkända. Syntetiska tester
kontrollerar diagonaler, slutna kurvor, förgreningar, isolerade punkter, delning,
avbrott, rasterbevarande och att körningen behåller konturordningen.
På en syntetisk bild (160×120, oval och triangel) minskade banorna från 29 till 3.
Beräknad ritningstid ändrades bara från 5,04 till 4,98 sekunder: färre musnedtryck
är inte samma sak som en proportionell hastighetsökning. Detta är ett litet
test av motorn, ingen representativ mätning av bilder eller Gartics inputfördröjning.
Konturspårningen bevarar det analyserade rastret; skalad preview och spelets
pensel kan ändå ge olika pixelresultat. Tidsgränsen kan avbryta före alla detaljer.
Windows-gränssnitt och faktisk Gartic-ritning är inte provkörda här.

---

# v1.0.97-beta — Single-color sketch for games

## Gartic.io och Gartic Phone

1. Välj rätt spelprofil i Draw Studio.
2. Aktivera **Single-color sketch (current ink)** under profilvalet.
3. Välj svart och en tunn penna i spelet, helst 1 px. Börja på en tom vit canvas.
4. Lägg in bilden och markera ritytan som vanligt.
5. Bygg förhandsvisningen och klicka Start när du är redo.

Ingen färgpalett behöver kalibreras för detta läge. Boten använder den färg
som redan är vald i spelet. Den kan inte garantera svart om du själv valt en
annan färg; förhandsvisningen visar svart. Spelprofiler använder enkla konturer
och stänger av motivfokus för att undvika inställningskonflikten i v1.0.95.

Gartic Phones automatiska kontroll läser nu canvasen utan att kräva en komplett
färgpalett. Kontroll av rityta, målfönster och mus behålls. Visa en tydligt synlig,
tom canvas om automatisk detektion misslyckas. Färgläget kräver fortsatt palett.
Paints befintliga enfärgsläge med valbar skuggning behålls.

För färgritning: stäng av både Single-color sketch och Black contour sketch,
och läs in färgpaletten igen. Dina profiler sparar enfärgsinställningen.

## Installera patchen på v1.0.96

Stäng Draw Studio. Packa upp patchen och kopiera de sex kod-/versionsfilerna
till din befintliga Draw-Studio-mapp där Start.bat ligger. Välj Ersätt filer.
Starta sedan med Start.bat. Patchen ändrar inga kalibrerings- eller inställningsfiler.
Hela paketet finns också för en separat installation.

## Verifiering

770 automatiserade tester och source self-test godkända. Nya tester kontrollerar
profilstöd, UI-reglaget, konturritning utan palettklick, canvas-kontroll utan
palett samt att flyttad/saknad canvas och färgläge utan palett fortfarande stoppas.
Windows-gränssnitt och faktisk ritning i spelen har inte provkörts här.
Källkodspaket med Start.bat; ingen ny Windows-EXE.

---

v1.0.96-beta — Sketch start fix. Se RELEASE-NOTES-v1.0.96-beta.md.

# Draw Studio v1.0.95-beta — Black contour sketch

## Användning

1. Packa upp hela ZIP-filen och kör **Start.bat**. Behåll din gamla mapp som säkerhetskopia.
2. Lägg in en bild och välj programmets profil och rityta som vanligt.
3. Slå på **Black contour sketch** i steg 4, vid ritinställningarna.
4. Välj en tunn penna, helst 1 px, i ritprogrammet. I **Single-color Paint** måste du själv välja svart. Med kalibrerad färgpalett väljer boten den svarta färgrutan.
5. Bygg förhandsvisningen, kontrollera resultatet och klicka Start när du är redo.

Reglaget ersätter den tidigare avancerade inställningen Outline only. Avstängt återgår planeringen till färgläget. Det tidigare gränssnittet behålls.

Läs [ändringar och begränsningar](RELEASE-NOTES-v1.0.95-beta.md).

---

# Draw Studio v1.0.94-beta

**Tidigare UI återställt:** samma layout, tema och preview-flikar som i v1.0.91. Uppdateringskontroll, kalibreringsminimering och startfixen behålls.

Packa upp och kör Start.bat. Den separata Restore-UI-patchen ersätter bara StudioUI.py i en befintlig v1.0.92/1.0.93-installation, utan att flytta inställningar eller kalibrering. Den patchen ändrar inte versionsnumret som visas i den gamla installationen.

Tidigare guider längre ned beskriver historiska layouter. Läs RELEASE-NOTES-v1.0.94-beta.md för den aktuella ändringen.

# Draw Studio v1.0.93-beta — startfix

Rättar felet **name release_page_btn is not defined** som hindrade v1.0.92 från att öppna gränssnittet. Packa upp och kör Start.bat. Behåll din tidigare mapp med kalibrering och inställningar.

# Draw Studio v1.0.92-beta

**Kompakt UI, förbättrad scrollhantering och automatisk minimering vid kalibrering.** Packa upp hela ZIP-filen och kör **Start.bat**. Behåll din gamla programmapp med inställningar och kalibrering.

Välj sektion i vänsterpanelen. Välj preview-vy ovanför bilden. **Tools** innehåller Readiness, diagnostik och Check for updates. Se [den nya UI-guiden](WORKSPACE-v1.0.92.md).

752 automatiserade tester godkända; Windows-gränssnittet behöver fortfarande provköras. Detta är ett källkodspaket, ingen färdig EXE.

# Draw Studio v1.0.91-beta

Sammanslagen version med adaptiv penselmotor, kraschfixar, motivfokus, formatidentifiering och bilduppskalning.

**Start:** packa upp hela ZIP-filen och kör **Start.bat**. Behåll din gamla programmapp tills inställningar och kalibrering är kontrollerade. Se [patchkontrollen](PATCH-AUDIT-v1.0.91.md) och [ändringsloggen](RELEASE-NOTES-v1.0.91-beta.md).

739 automatiserade tester godkända. Windows-körning återstår att verifiera. Paketet innehåller källkod, ingen färdig EXE.

# Nytt: bilduppskalning

**Add image → Upscale image…** ger 2×/4×, Smooth/Pixel art och Undo. Se [svensk guide](UPSCALING.md). Ingen AI och ingen automatisk ritstart vid uppskalning.

# Nytt: motivet först

Vill du lägga rit­tiden på människor och föremål? Välj **Configure drawing → Subject focus → Subject first** eller **Subject only**. Klicka **Mark subject…**, markera motivet och kontrollera **Check subject mask**. Se [den korta svenska guiden](MOTIVFOKUS.md).

ZIP-paketet innehåller källkod och **Start.bat**. Ingen ny Windows-EXE har byggts i den här granskningen.

# Draw Studio

**v1.0.90-beta — Review & crash diagnostics:** fixes a reproduced Auto Fill regression, out-of-bounds simulation, checkpoint ordering, input disarming, probe output handling and diagnostic export. Adds corrected Windows LocalDumps setup. See `RELEASE-NOTES-v1.0.90-beta.md`.

**v1.0.89-beta — Pixel Accurate Planner Block D:** accelerates Block C with NVIDIA CUDA stroke simulation and score reduction, VRAM-aware row tiles/rectangle batches, parallel CPU component processing, and progressive accuracy under explicit time limits. Pixel Accurate still preserves full-resolution source information before speed decisions.

**v1.0.85-rc1:** adds a one-click automatic NVIDIA CUDA bootstrap. `Start.bat` detects NVIDIA hardware, installs or repairs the local CuPy/CUDA runtime automatically, removes conflicting CuPy packages, validates a real CUDA kernel, and falls back to CPU without blocking startup if GPU setup fails.

**v1.0.84-rc1:** fixes the browser palette safety false-positive seen in field logs, exposes NVIDIA detection/benchmark directly in GPU settings, and reports the effective backend in planner benchmarks.

**v1.0.83-rc3:** NVIDIA GPU discovery now works independently of CuPy, source startup can automatically prepare the CUDA backend on NVIDIA systems, and dropping an image directly on the preview canvas can start a ready non-Paint target in one shot.


Draw Studio is a Windows desktop drawing automation tool for Microsoft Paint and supported browser drawing apps. The renderer is deterministic: **no AI/ML/OCR models are used**.

## Download / install

For normal users, download one of the Windows assets from **GitHub Releases**:

- `DrawStudio-<version>-Windows-x64-Setup.exe` — recommended installer.
- `DrawStudio-<version>-Windows-x64.zip` — portable onedir build. Extract the whole ZIP before launching `DrawStudio.exe`.
- `DrawStudio-<version>-SHA256.txt` — checksums for both release files.

The EXE does not require Python. Draw Studio runs as the current user (`asInvoker`) and normally should not be run as administrator. Unsigned beta builds may trigger Windows SmartScreen until the project is code-signed.

## First use

1. Open the target app (Microsoft Paint is recommended for the first test).
2. Start Draw Studio and choose the matching profile.
3. Select, paste or drag in an image.
4. For Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.io, **Browser Auto Setup** handles the palette automatically; manual calibration is fallback-only.
5. **Select drawing area** once. Supported browser profiles immediately auto-scan/refine the safe canvas and anchored palette.
6. Run the small drawing test.
7. Run **Lock setup → Safety preflight → Fast Dry run**.
8. Check the Drawing preview / Safety map / Debug overlay.
9. Press **Unlock full drawing**, then **Start drawing**.

`Esc` stops immediately. `F6` pauses/resumes. Do not manually move the mouse while a real drawing is running.

### Why so many safety steps?

CanvasGuard, SafePolygon, brush inset, safe Fill masks, segment clipping, edge verification and FinalMouseGuard are intentionally independent from renderer/profile settings. A profile cannot disable them. The preview uses the same edge/safety policy as execution.


## Mobile Preview Live (v1.0.69)

Press **📱 Mobile Preview** in the Preview workspace to view the current Draw Studio preview from a phone or tablet on the same Wi-Fi/LAN. The local page includes Drawing Preview, Original and Safety Map and refreshes automatically.

Mobile Preview is strictly opt-in: no local server is started until you press the button, and it stops when you press **Stop Mobile Preview** or close Draw Studio. It uses a random session URL and no cloud relay, analytics or telemetry. If Windows Firewall asks for permission, allow **Private networks** only.

## Runtime Safety UI (v1.0.58)

After every Fast Dry run or real drawing, Draw Studio writes a local JSON + TXT report under the app-data `safety-reports` folder. **Tools → Runtime safety report** shows the latest counters for drawn, clipped, skipped, edge-followed and blocked paths and can open the report/folder.

These reports stay local. Draw Studio **does not include telemetry, a bug-report upload server or automatic crash-report sending**. If support is needed, use **Tools → Create diagnostics** and share the generated ZIP manually.

## Update center

Tools → **Update center** can manually query the official Draw Studio GitHub Releases page. The app never checks in the background, never auto-downloads an update and never installs one automatically.

## Tooltips and guide

Hover important safety controls for a short explanation. **Quick guide** in the header reopens the first-run instructions at any time.

## Run from source

Requirements: Windows 10/11 x64, Python 3.10+ and internet for first dependency install.

```bat
Start.bat
```

`Start.bat` creates `.venv`, installs `requirements.txt`, detects NVIDIA hardware with `nvidia-smi`/Windows CIM, and opens Draw Studio. On an NVIDIA system it also checks the CUDA backend and automatically installs `requirements-gpu-nvidia.txt` when needed. GPU setup is retried automatically whenever the CUDA smoke test is not healthy. `Start.bat --update` forces a package refresh/repair. The CUDA runtime is installed only inside `.venv`; Draw Studio does not require a system-wide CUDA Toolkit.

## Build a Windows release locally

On Windows:

```bat
Build-Release.bat
```

The builder:

1. installs declared dependencies,
2. runs the unit tests + source self-test,
3. builds a PyInstaller onedir EXE,
4. runs `DrawStudio.exe --self-test`,
5. creates the portable ZIP,
6. creates an Inno Setup installer when Inno Setup 6 is installed,
7. writes SHA-256 checksums.

Artifacts are written to `release\`.

## GitHub Actions / publisher

The repository includes `.github/workflows/build-windows.yml`. A manual workflow run builds downloadable artifacts. Pushing a tag that exactly matches the app version publishes a GitHub Release automatically.

For this version use:

```powershell
git tag v1.0.89-beta
git push origin v1.0.89-beta
```

The workflow verifies the release on `windows-latest`, builds the installer/portable ZIP, uploads Actions artifacts, then attaches the release assets and checksum to the GitHub Release. The tag must match `Version.py` or the release build fails.

## Privacy

- No telemetry.
- No remote bug-report/reporting backend.
- No automatic diagnostics upload.
- Source images are not included in diagnostics ZIPs.
- Runtime safety reports are local-only.
- Image URLs are the only normal feature that may make an HTTP/HTTPS request when explicitly used by the user.


## Version history and docs

Use these files to see what was added in each version:

- `VERSION-HISTORY.md` — full readable version timeline.
- `README-INDEX.md` — quick map of all README/release/history files.
- `docs/README.md` — documentation landing page.
- `docs/history/README.md` — index of historical feature notes.

Inside the app, open **About → Version history** to read the packaged timeline.

## Developer verification

```powershell
python -m unittest discover -v
python DrawBot.py --self-test
```

A public beta should still be tested on a clean Windows 10/11 x64 machine with the real target applications before publishing broadly.

## v1.0.64 Skribbl Turbo Renderer

Skribbl.io Fast uses calibrated-palette color batches, aggressive palette reduction and continuous horizontal run compression to minimize palette switches, mouse-down boundaries and cursor events. Paint behavior is unchanged.

## v1.0.65 Gartic Phone Turbo Renderer

Gartic Phone now uses calibrated-palette color batches and dual-axis run compression. For each retained color, Draw Studio compares horizontal and vertical raster runs and chooses the orientation that needs fewer separate mouse strokes. The profile keeps a small palette, uses a 60-second target and does not alter Paint or Skribbl behavior.
## v1.0.67 Manual Drop-In Start

Browser/game canvas profiles now have a one-shot **Arm Drop-In Start** control. After the target canvas and palette are ready, arm it once and the next dropped, selected, pasted or URL-loaded image starts drawing automatically after load. The arm expires after 120 seconds, is never persisted, and is disabled for Microsoft Paint's strict safety chain.

## v1.0.66 Gartic Engine v2

Gartic Phone now uses a dedicated Engine v2: 6×12 / 72-color palette support, wide-canvas geometry checks, fixed-palette batching, horizontal/vertical run selection, StrokeGraph travel optimization and timer-aware runtime settings. From v1.0.70, the normal Gartic browser flow auto-detects/anchors the palette and canvas; manual tool capture remains an optional fallback for advanced Fill/Eraser workflows.


## v1.0.68 Version History & README Index

The source ZIP and frozen Windows build now include a dedicated `VERSION-HISTORY.md`, `README-INDEX.md`, docs landing page, history index and an About-window **Version history** viewer so users can see what was added without digging through scattered files.


## v1.0.70 Browser Auto Calibration

Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.io no longer require normal manual palette capture. After the target canvas is selected, Draw Studio activates the already selected browser window, takes a read-only screenshot, verifies the visible palette, saves anchored color positions and refines the safe canvas when confidence is high. No mouse input is generated during Auto Setup. Manual calibration remains available only when a site layout changes or for optional advanced tools.

## v1.0.71 Browser Auto-Recalibration

For Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.io, Draw Studio now performs a read-only visual verification immediately before drawing input is armed. Chrome zoom, resize, window movement and Windows DPI changes no longer require manual palette/canvas calibration when the new layout can be verified safely. A layout change during an active stroke still stops the run; the next start recalibrates automatically before continuing.


## v1.0.72 Browser Visual Preflight

Supported browser profiles now perform a second read-only verification immediately before planning/input: the detected canvas must still match the calibrated safe canvas and a representative set of palette swatches must still show the expected colors. A mismatch gets one automatic Browser Auto-Recalibration retry; a persistent mismatch blocks drawing before any mouse click or stroke is sent.


## v1.0.75 Per-Game Input Engine

Gartic Phone, Skribbl.io/Fast and SketchHeads use separate native input timings for interpolation, stroke spacing, mouse-down/up settle and palette/control clicks. v1.0.75 also includes v1.0.74 Automatic Brush Size, which visually verifies game brush controls and never guesses low-confidence clicks.

## v1.0.74 Automatic Brush Size

Supported browser profiles detect their brush-size controls from the already verified layout, select the nearest requested preset when safe, and use a conservative CanvasGuard fallback if the control row cannot be verified.

## v1.0.73 Drop-In Synchronization

A manually armed browser Drop-In now waits for Auto Setup, Auto-Recalibration or Visual Preflight instead of being rejected because the read-only setup pipeline is busy. The queue is bounded to 30 seconds, the latest image replaces any older pending image, and a browser/profile target change cancels the request before native input.


### Layout Fingerprint v2 (v1.0.76)
Supported browser profiles cache verified canvas/palette geometry, DPI and zoom/reflow signatures locally so repeated Auto Setup can reuse a known layout after a quick read-only swatch check. Browser Visual Preflight still runs before drawing.


### Smart Recovery / Resume (v1.0.79)

Recoverable browser interruptions save the active color and exact next unfinished path. The next explicit Start runs normal read-only Auto-Recalibration and Visual Preflight, then resumes without redrawing completed paths. Canvas/target geometry safety failures remain hard stops.

### Stroke Delivery Verification (v1.0.78)

Supported browser canvases verify each meaningful stroke after delivery. If a path appears missed or partial, only that stroke is replayed once with denser/safer input timing. The retry cap is hard-coded to one, so a bad path cannot loop forever.

### Real-Speed Time Budget (v1.0.77)
Supported browser profiles learn completed local paths/second. Preset 30/60/90-second budgets then adapt path caps, palette size and detail level conservatively, prioritizing large outlines/forms before micro-detail. Timing counters stay local and contain no images or telemetry.


## Crash troubleshooting (v1.0.90)

This source ZIP does not contain a built EXE. Extract the entire ZIP to a new folder and run **Start.bat** normally.

1. To prepare native Windows `.dmp` files, right-click **Enable-Crash-Dumps.bat → Run as administrator** once. Check the result; do not assume success if an error is shown.
2. Start **Start.bat normally**, then repeat the action that crashes. The drawing app must not inherit administrator rights from the setup script.
3. After a native crash, inspect `%LOCALAPPDATA%\DrawBotStudio\dumps` for a new `.dmp`.
4. Run **Collect-Diagnostics.bat** or **Tools → Create diagnostics** for the logs ZIP. Send the ZIP and, if needed, the new `.dmp` separately.
5. **Disable-Crash-Dumps.bat**, run as administrator, restores values saved by the new setup. Values changed afterwards by another tool are preserved. Existing dump files are kept.

For source mode the setup configures `python.exe` and `pythonw.exe` as well as `DrawStudio.exe`. This also affects other processes with those executable names. Mini dumps can contain fragments of process memory; they are kept locally and are not added to the diagnostics ZIP automatically.

A handled Python exception normally produces a traceback in the logs, not a native `.dmp`. Force-killing a process, a power loss or some debugger configurations may also prevent a crash dump. A dump provides evidence to analyze; it does not automatically establish the root cause.

The old HKCU LocalDumps script did not use Microsoft's documented HKLM location. It is replaced; no registry changes are made just by starting Draw Studio. [Microsoft LocalDumps documentation](https://learn.microsoft.com/en-us/windows/win32/wer/collecting-user-mode-dumps).
