# Draw Studio v1.0.68-beta – Version History & README Index

## Added

- New root-level `VERSION-HISTORY.md` with a readable release timeline.
- New root-level `README-INDEX.md` explaining which README/release/history files to open.
- New `docs/README.md` and `docs/history/README.md` indexes.
- Recent release notes are mirrored into `docs/history/` so the ZIP has one complete history folder.
- About window has a **Version history** button for reading what changed without leaving the app.
- PyInstaller build includes the user-facing docs/history files inside the Windows bundle.

## Changed

- README now points users to the version history and docs index.
- Build status and version resource updated to `1.0.68-beta`.

## Safety / privacy

- Documentation changes only.
- No change to drawing execution, CanvasGuard, FinalMouseGuard, Drop-In Start, Gartic, Skribbl, Paint, telemetry or diagnostics behavior.
