# Paint Stroke Delivery — v1.0.62-beta

The renderer geometry is unchanged. This layer improves native delivery of planned strokes to Paint.

Real Microsoft Paint drags use dense 2 px interpolation, a 5 ms delivery floor, button transition settling, and non-coalesced absolute SendInput mouse-move events. This is designed to prevent Paint's UI event queue from collapsing intermediate programmatic moves into visible gaps.

Dry Run remains click-free and does not enable this real-drag backend.
