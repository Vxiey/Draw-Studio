# v1.0.105-beta — Extra fast

## Använd läget
1. Packa upp hela paketet och kör Start.bat.
2. Välj programprofil och kalibrera rityta och färgpalett som vanligt.
3. För bucket fill behöver profilen även ha Brush/Pencil och Fill kalibrerade.
4. Välj Drawing preset → Extra fast. Läs in bilden och bygg preview.
5. Kör Safety preflight / ett litet prov på tom rityta före vanlig Start.

Extra fast använder befintliga Closed regions v2: ritar slutna konturer i
regionens färg, fyller deras insidor och fortsätter med kvarvarande penseldrag.
Konturer och fyllningar grupperas per färg; det är inte en separat svart
kontur över hela bilden. Inga automatiska klick sker när förvalet väljs.

En ny kostnadsberäkning inkluderar konturrörelse, verktygsbyten och väntetider.
Fyllning väljs bara om uppskattningen är minst 25 procent snabbare än regionens
scanlines. Detta är en uppskattning, ingen uppmätt hastighetsgaranti jämfört med
alla andra ritmotorer. Högst 12 regioner från den befintliga regiondetektorn
utvärderas. Avvisade regioner behåller vanliga penseldrag.

Läget använder kalibrerad palett, slutna regioner, ingen bakgrundsfyllning av
hela duken och inga extra färglager. Det fungerar bäst för illustrationer,
logotyper och stora enhetliga färgytor. Foton kan få få eller inga fyllningar.
Utan Fill-kalibrering används Smart paths. Vid enfärg/Outline används enkel
svart sketch utan fyllning. Eraser stöds inte i detta förval.

Befintliga kontroller av rityta, fyllningsfärg och förändringar utanför regionen
behålls. Kantnära, öppna och osäkra regioner faller tillbaka till penseldrag.
Analysen av stora sammanhängande ytor har tätare avbrytningskontroller.
Minnesgränser och preview-förbättringar från v1.0.104 finns kvar.

815 automatiserade tester och source self-test godkända på Linux.
Windows-GUI, musritning och verklig Gartic/Paint-fyllning är inte provkörda här.
Källkod med Start.bat; ingen nybyggd EXE. Tidigare sparade inställningar behålls.
