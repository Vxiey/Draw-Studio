# v1.0.96-beta — Sketch start fix

Rättar ritstart som stoppades med "Subject focus needs full colour drawing".
Black contour sketch prioriteras nu över sparat Subject focus i planeringen.
Gränssnittet förklarar att sketch måste stängas av innan motivfokus kan aktiveras.
Svarta konturer och det tidigare gränssnittet behålls. Säkerhetskontroller för
mus och målfönster behålls.

## Installera startpatchen (kräver v1.0.95)

1. Stäng Draw Studio.
2. Packa upp Draw-Studio-1.0.96-Start-Fix-Patch.zip.
3. Kopiera DrawBot.py, Version.py och version_info.txt till din befintliga
   Draw-Studio-mapp, där Start.bat ligger. Välj Ersätt filer.
4. Kör Start.bat. Versionen ska visa 1.0.96-beta.

Patchen innehåller inga inställningar eller kalibreringsfiler. De behålls.
Alternativ: packa upp hela v1.0.96-paketet för en separat installation.

764 automatiserade tester och source self-test godkända. Tre nya tester
kontrollerar båda motivlägena med sketch, UI-konflikten och vanligt motivfokus.
Loggarna visade lyckade mus-, mål- och palettester. Faktisk ritning i Windows
är inte verifierad här. Detta är källkod, ingen nybyggd EXE.
