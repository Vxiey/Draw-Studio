# v1.0.99-beta — Simpler sketches

## Användning

Under ritinställningarna finns nu **Sketch detail**:

- **Simple** (standard): kraftigare utjämning och filtrering av små kantfragment.
- **Balanced**: mellannivå som behåller mer struktur.
- **Detailed**: tidigare kantbehandling från v1.0.98.

Använd Single-color sketch eller Black contour sketch, välj detaljnivå och
tryck Build preview. För Gartic används fortsatt motorn som följer sammanhängande
konturer. Välj svart och en tunn penna i spelet när du använder current ink.
Detaljnivån sparas per profil. Gamla profiler utan värdet får Simple.
Ändring av nivån startar ingen ritning och följer befintligt Manual Preview-läge.
Det tidigare gränssnittet och färgmotorn behålls.

Simple kan ta bort tunna eller svagt kontrasterande detaljer, även i motivet.
Välj Balanced eller Detailed om viktiga drag försvinner. Funktionen känner
inte igen människor eller skiljer semantiskt mellan motiv och bakgrund.

## Installation

Fullständigt paket: packa upp och kör Start.bat. Behåll tidigare installation.
Patch för v1.0.98: stäng programmet och kopiera DrawBot.py, StudioUI.py,
SketchPlanner.py, Version.py och version_info.txt till mappen med Start.bat.
Välj Ersätt filer. Inställningar och kalibrering behålls.

## Verifiering

781 automatiserade tester och source self-test godkända. Nya tester kontrollerar
texturdämpning med bevarad huvudkontur, tidigare Detailed-resultat, transparenta
och enfärgade bilder samt felaktig detaljnivå.
På en syntetisk 240×180-bild med tunna grå bakgrundslinjer och en svart oval:
Detailed gav 92 banor, Balanced 4 och Simple 2. Det är ett avgränsat test,
inte en mätning av användarens fotografi eller hastigheten i Gartic.
Windows-gränssnitt och faktisk ritning är inte provkörda här. Källkod med
Start.bat, ingen nybyggd EXE.
