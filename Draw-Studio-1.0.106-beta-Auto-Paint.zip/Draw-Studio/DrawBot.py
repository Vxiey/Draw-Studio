"""Draw Studio: English desktop UI, image preview and cancellable drawing."""
import json
import math
import queue
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from io import BytesIO
from pathlib import Path
from urllib.parse import urlparse

from Colors import allColors, enable_dpi_awareness, DATA_DIR, load_calibration, reset_palette, CALIBRATION_FILE, normalize_rgb
from PixelData import closest_color, prepare_image, build_strokes
from PortraitPlanner import prepare_portrait_image, portrait_strokes
from GpuAcceleration import (ACCELERATION_MODES, VRAM_BUDGETS, GPU_PERFORMANCE_MODES,
                             acceleration_info, benchmark as gpu_benchmark,
                             clear_gpu_cache as gpu_clear_cache,
                             validate_acceleration_mode, validate_vram_budget, validate_gpu_performance)
from FillOptimizer import (detect_background, detect_fill_regions, remove_filled_region_strokes, simplify_background,
                           FILL_ENGINES, validate_background_fill, validate_background_simplification, validate_fill_engine)
from SafeFillMask import (filter_fill_regions_by_source_mask, filter_fill_regions_by_runtime_mask,
                          source_fill_margin_px)
from ColorGrouping import COLOR_GROUPING_MODES, group_palette_strokes, validate_color_grouping
from AdvancedColor import (COLOR_RENDERING_MODES, COLOR_LAYER_MODES, CUSTOM_COLOR_WORKFLOWS,
                           build_color_strokes, validate_color_rendering, validate_color_layers,
                           validate_custom_color_workflow)
from SmartTools import TOOL_STRATEGIES, choose_paint_tool, validate_tool_strategy
from Precision import CanvasTransform, precision_path, precision_path_count, validate_precision
from HumanMode import HUMAN_MODES, HumanCadence, human_overhead_seconds, humanize_strokes, stable_seed, validate_human_mode
from SpeedOptimizer import (SPEED_PROFILES, base_delay as speed_base_delay, estimated_motion_seconds,
                            normalize_speed, optimize_strokes, phase_delay, profile as speed_profile)
from StrokeDelivery import resolve_stroke_delivery
from SkribblFastRenderer import optimize_skribbl_groups
from GarticPhoneFastRenderer import optimize_gartic_phone_groups, build_gartic_execution_paths
from GarticEngineV2 import choose_runtime_profile
from ContinuousPaths import (SMART_PATH_MODE, SHAPE_PATH_MODE, LEGACY_LINE_MODE, DOT_MODE, DRAWING_MODES,
                             build_execution_paths, order_paths, stats as continuous_path_stats)
from StrokeOptimizer import (STROKE_OPTIMIZER_MODES, optimize_execution_groups,
                             resolve_stroke_optimizer, validate_stroke_optimizer)
from AdaptiveDetail import (ADAPTIVE_DETAIL_MODES, apply_adaptive_detail, prune_flat_micro_strokes,
                            validate_adaptive_detail)
from VisualVerification import (VISUAL_VERIFICATION_MODES, resolve_visual_verification,
                                validate_visual_verification, planned_batch_points,
                                planned_batch_boxes, compare_batch_snapshot, summarize_result)
from ShapePaths import (STROKE_CAPS, SHAPE_ORDERS, SHAPE_MODEL_MODES, build_shape_execution_paths,
                        validate_shape_order, validate_stroke_cap, validate_shape_model)
from TimeBudget import (TIME_BUDGET_MODES, TARGET_STROKE_COUNTS, apply_target_path_cap,
                        resolve_time_budget_seconds, resolve_target_stroke_count,
                        validate_time_budget_mode, validate_target_stroke_count,
                        parse_custom_stroke_count)
from ProgressiveRenderer import (PROGRESSIVE_RENDERING_MODES, build_progressive_sequence,
                                progressive_enabled, validate_progressive_rendering)
from PlanningWatchdog import (PLANNING_WATCHDOG_MODES, build_planning_attempts,
                              validate_planning_watchdog)
from ResourceAllocation import (CPU_WORKER_CHOICES, CPU_ENGINE_MODES, RAM_BUDGETS, PLANNING_RESOLUTION_MODES,
                                resolve_allocation, resolve_planning_limits, benchmark_allocation,
                                validate_cpu_workers, validate_cpu_engine,
                                validate_ram_budget, validate_planning_resolution, parse_custom_ram_mb)
from ResourceScheduler import (RESOURCE_SCHEDULER_MODES, benchmark_scheduler,
                               load_recommendation as load_resource_recommendation,
                               resolve_resource_schedule, validate_resource_scheduler)
from PerformanceProfiler import (begin as profiler_begin, start as profiler_start, stop as profiler_stop,
                                 finalize as profiler_finalize, format_profile as format_performance_profile,
                                 dominant_phase as profiler_dominant_phase)
from DynamicColors import (EXACT_COLOR_LIMITS, validate_exact_color_limit, resolve_exact_color_limit, build_dynamic_color_strokes)
from ExactColorTools import (custom_rgb_available, eyedropper_available, spectrum_available, numeric_rgb_available,
                             resolved_controls as resolve_exact_color_controls)

from GameProfiles import PROFILES, profile_defaults, profile_ui
from ProfileEngine import (PROFILE_ENGINE_MODES, policy_summary, resolve_profile_policy, validate_profile_engine)
from FastDryRun import sample_plan as sample_dry_run_plan, DRY_RUN_EXECUTION_SECONDS, DryRunBudgetComplete
from DropInStart import DROP_IN_ACTION, DROP_IN_ARM_SECONDS, action_for_import, can_arm as can_arm_drop_in, normalize_action as normalize_drop_in_action
from DropInSynchronization import (
    IDLE as DROP_SYNC_IDLE, AUTO_SETUP_RUNNING as DROP_SYNC_AUTO_SETUP,
    AUTO_RECALIBRATING as DROP_SYNC_AUTO_RECALIBRATING,
    VISUAL_PREFLIGHT_RUNNING as DROP_SYNC_VISUAL_PREFLIGHT,
    READY_TO_DRAW as DROP_SYNC_READY, DRAW_PENDING as DROP_SYNC_PENDING,
    DRAWING as DROP_SYNC_DRAWING, PENDING_TIMEOUT_SECONDS as DROP_SYNC_TIMEOUT_SECONDS,
    make_request as make_pending_drop_in_request, request_expired as pending_drop_in_expired,
    should_wait as drop_in_should_wait, target_fingerprint as drop_in_target_fingerprint,
    target_matches as pending_drop_in_target_matches,
)
from CanvasGuard import CanvasGuard, FinalMouseGuard, normalize_canvas_anchors, CanvasSafetyStop
from AnchorTransform import rebase_canvas_area, transform_points, area_inside_client
from EdgeDetection import verify_canvas_edges_from_capture
from EdgeBehavior import (EDGE_BEHAVIOR_MODES, apply_edge_behavior, resolve_edge_behavior,
                          validate_edge_behavior)
from PreviewSafety import (build_preview_safety_plan, draw_safe_paths,
                           render_preview_safety_map)
from SafetyDebugOverlay import render_safety_debug_overlay
from RuntimeSafetyReport import (RuntimeSafetySession, safe_save as save_runtime_safety_report,
                                 latest_report as load_latest_runtime_safety_report, compact_summary as runtime_safety_compact_summary, REPORT_DIR as RUNTIME_SAFETY_REPORT_DIR)
from RuntimePaths import atomic_write_text, data_dir
from PerformanceAutoTuner import run_auto_tune, load_tune_result, format_tune_summary
from Version import APP_VERSION, BUILD_CHANNEL
from VersionHistory import read_version_history
from MobilePreview import MobilePreviewServer
from CrashDiagnostics import (install as install_crash_diagnostics, begin_run_marker,
                              log_event, previous_run_unclean, clean_exit)

install_crash_diagnostics()

BASE = DATA_DIR
SETTINGS = BASE / 'settings.json'
QUALITY = {'Quick sketch': 6, 'Balanced': 8, 'High detail': 9, 'Maximum detail': 10}
SPEED = {name: speed_base_delay(name) for name in SPEED_PROFILES}
MAX_SOURCE_BYTES = 50 * 1024 * 1024
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024
MAX_SOURCE_PIXELS = 25_000_000
MAX_CAPTURE_PIXELS = 40_000_000
# v1.0.11: the live UI preview is intentionally lighter than the final
# Start Drawing plan. The final plan is still generated at full selected canvas
# size immediately before mouse input is armed.
PREVIEW_MAX_PIXELS = 320_000
PREVIEW_MAX_DIMENSION = 760
PREVIEW_PLAN_TIMEOUT_SECONDS = 14.0
PREVIEW_FALLBACK_TIMEOUT_SECONDS = 6.0
PREVIEW_MODES = ('Manual', 'Auto light', 'Auto full')
COLOR_WORKFLOWS = ('Finish color first', 'Progressive passes')


def apply_profile_defaults(app, profile_name):
    """Apply safe profile defaults before profile-specific saved settings are read."""
    values=profile_defaults(profile_name)
    for name,value in values.items():
        var=getattr(app,name,None)
        setter=getattr(var,'set',None)
        if setter is not None:
            setter(value)


def validate_preview_mode(value):
    if value not in PREVIEW_MODES:
        raise ValueError('Choose a valid preview mode.')
    return value


def preview_safe_options(options, mode='Manual', *, fallback=False):
    """Return a cancellable, bounded planner configuration for UI previews.

    Preview is intentionally an approximation of the final plan.  Heavy final
    settings (Extreme resolution, worker batches, CUDA initialization and color
    layering) are kept for Start Drawing, where the planning watchdog can manage
    them.  The preview path stays small enough that cancellation is checked often.
    """
    out=dict(options)
    requested_resolution=str(out.get('planning_resolution','Auto'))
    requested_color=str(out.get('color_rendering','Perceptual match'))
    requested_layers=str(out.get('color_layers','Off'))
    out['_preview_safe_pipeline']=True
    out['_preview_requested_planning_resolution']=requested_resolution
    out['_preview_requested_color_rendering']=requested_color
    out['_preview_requested_color_layers']=requested_layers

    # Never use a blocking worker pool for a Tk preview.  The serial color pass
    # checks the cancellation callback every row, so the timeout actually works.
    out['cpu_workers']='1'
    out['cpu_workers_resolved']=1
    out['cpu_engine']='Threads'
    out['gpu_mode']='CPU'
    out['gpu_performance']='Balanced'

    # Auto light is deliberately tiny. Manual/Auto full may use High internally,
    # but Ultra/Extreme are final-plan settings and are unsafe for a live preview.
    if fallback or mode=='Auto light':
        effective_resolution='Standard'
    elif requested_resolution in ('High','Ultra','Extreme'):
        effective_resolution='High'
    else:
        effective_resolution='Standard' if requested_resolution=='Auto' else requested_resolution
    out['planning_resolution']=effective_resolution

    # Layer mixing is the most expensive preview color path and can spend a long
    # time inside one row before a cancellation check.  Preview the base palette
    # perceptually; final drawing still uses the user's requested layer mode.
    out['color_layers']='Off'
    if requested_color=='Layered color mix':
        out['color_rendering']='Perceptual match'
    if fallback:
        out['color_rendering']='RGB nearest'
        out['draw_quality']='Balanced' if out.get('draw_quality') in ('GPU enhanced','Pixel Accurate') else out.get('draw_quality','Balanced')
        out['background_fill']='Off'
        out['background_simplification']='Strong'
        out['target_stroke_count']='800'
        out['target_stroke_count_resolved']=800
        out['max_stroke_cap']='1000' if out.get('drawing_mode')=='Shape paths' else out.get('max_stroke_cap','Auto')
    else:
        cap=800 if mode=='Auto light' else 1600
        current=out.get('target_stroke_count_resolved')
        try:
            out['target_stroke_count_resolved']=min(int(current),cap) if current is not None else cap
        except (TypeError,ValueError):
            out['target_stroke_count_resolved']=cap
    return out



def uses_paint_color(app):
    # Legacy name retained for saved profiles and callers; current ink works in all apps.
    return bool(hasattr(app,'paint_simple') and app.paint_simple.get())


def uses_paint_eraser(app):
    return (hasattr(app,'game') and app.game.get()=='Microsoft Paint'
            and hasattr(app,'paint_tool') and app.paint_tool.get()=='Eraser')


def bypasses_palette(app):
    return uses_paint_color(app) or uses_paint_eraser(app)


def runtime_palette_guard_colors(profile_key, palette_positions, colors):
    """Return the palette map that ScreenGuard should verify before input.

    Supported browser games already run Browser Visual Preflight immediately
    before planning/input. Their swatches can contain selection borders, hover
    states and browser antialiasing, so applying Paint's strict per-pixel palette
    guard afterwards can false-stop a valid Gartic/Skribbl/SketchHeads session.
    Paint and generic calibrated apps retain the strict legacy guard.
    """
    try:
        from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
        if str(profile_key or '').lower() in SUPPORTED_BROWSER_PROFILES:
            return {}
    except Exception:
        pass
    return dict(zip(tuple(palette_positions or ()), [tuple(c.RGB) for c in colors]))


def FindClosestRGB(rgb):
    return closest_color(normalize_rgb(rgb))


def load_image(source, cancelled=lambda: False):
    from PIL import Image, ImageOps, UnidentifiedImageError
    raw_source = str(source).strip()
    if not raw_source:
        raise ValueError('Choose an image first.')
    source_obj = raw_source
    if raw_source.lower().startswith(('http://', 'https://')):
        import requests
        data = bytearray()
        started = time.monotonic()
        try:
            with requests.get(raw_source, timeout=(10, 15), stream=True) as response:
                response.raise_for_status()
                content_type = response.headers.get('Content-Type', '').lower()
                if 'text/html' in content_type:
                    raise ValueError('The link points to a web page. Right-click the image and choose Copy image address.')
                content_length = response.headers.get('Content-Length')
                if content_length:
                    try:
                        if int(content_length) > MAX_DOWNLOAD_BYTES:
                            raise ValueError('The image download is larger than 20 MB. Choose a smaller image.')
                    except (TypeError, ValueError) as error:
                        if isinstance(error, ValueError) and str(error).startswith('The image download'):
                            raise
                for chunk in response.iter_content(65536):
                    if cancelled():
                        raise InterruptedError()
                    if time.monotonic() - started > 45:
                        raise ValueError('The download took too long. Save the image to your computer and select it locally.')
                    if not chunk:
                        continue
                    data.extend(chunk)
                    if len(data) > MAX_DOWNLOAD_BYTES:
                        raise ValueError('The image is larger than 20 MB. Choose a smaller image.')
        except requests.RequestException as error:
            raise ValueError(f'Could not download the image: {error}') from error
        source_obj = BytesIO(data)
    elif '://' in raw_source:
        raise ValueError('The image URL must start with https:// or http://.')
    else:
        path = Path(raw_source)
        try:
            if not path.is_file():
                raise ValueError('The selected image file no longer exists.')
            if path.stat().st_size > MAX_SOURCE_BYTES:
                raise ValueError('The image file is larger than 50 MB. Choose a smaller image.')
        except OSError as error:
            raise ValueError(f'Could not access the selected image: {error}') from error
        source_obj = path
    try:
        with Image.open(source_obj) as image:
            if image.width <= 0 or image.height <= 0:
                raise ValueError('The image has invalid dimensions.')
            if image.width * image.height > MAX_SOURCE_PIXELS:
                raise ValueError('The image is larger than 25 megapixels. Resize it first.')
            detected_format = image.format or 'Unknown'
            result = ImageOps.exif_transpose(image).convert('RGBA')
            result.info['draw_studio_format'] = detected_format
            return result
    except UnidentifiedImageError as error:
        raise ValueError('Could not read the image. Choose PNG, JPG, WEBP or BMP, or use a direct image URL.') from error
    except OSError as error:
        raise ValueError(f'Could not decode the image: {error}') from error


def grab_area(area):
    from PIL import ImageGrab
    x, y, w, h = map(int, area)
    if w < 1 or h < 1:
        raise ValueError('The capture area is empty.')
    if w * h > MAX_CAPTURE_PIXELS:
        raise ValueError('The selected drawing area is too large to capture safely. Select a smaller canvas.')
    return ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True).convert('RGB')



def preview_area_for(area, *, max_pixels=PREVIEW_MAX_PIXELS, max_dimension=PREVIEW_MAX_DIMENSION):
    """Return a safe live-preview canvas size for a selected drawing area.

    The drawing worker still generates the final plan at the real Paint canvas
    size.  This function keeps automatic UI previews responsive on large Paint
    selections and with expensive colour/fill/GPU-enhanced settings.
    """
    try:
        width, height = [max(1, int(round(v))) for v in area[:2]]
    except (TypeError, ValueError, IndexError) as error:
        raise ValueError('Preview area must contain width and height.') from error
    pixels = width * height
    scale = min(1.0, max_dimension / max(width, height), (max_pixels / max(1, pixels)) ** 0.5)
    if scale >= 0.999:
        return width, height
    return max(1, int(round(width * scale))), max(1, int(round(height * scale)))


def is_preview_plan(options):
    return bool(options.get('_preview_plan'))


def _resource_log_text(options):
    """Compact resource summary for diagnostics; never touches the GUI."""
    try:
        return (
            f"planning={options.get('planning_resolution', 'Auto')} "
            f"cpu={options.get('cpu_workers_resolved', options.get('cpu_workers', '?'))}/"
            f"{options.get('logical_cpus', '?')} "
            f"engine={options.get('cpu_engine', 'Auto')} "
            f"ram={options.get('ram_budget_mb', options.get('ram_budget', '?'))}MB "
            f"gpu={options.get('gpu_mode', 'Auto')} "
            f"vram={options.get('gpu_vram', 'Auto')} "
            f"perf={options.get('gpu_performance', 'Balanced')}"
        )
    except Exception:
        return 'resource-summary-unavailable'



def _ensure_time_budget_options(options):
    """Resolve Step 2 budget controls for both GUI and direct test calls."""
    options = dict(options)
    if options.get('unlimited_time') or options.get('time_budget_mode')=='Unlimited':
        options.update(unlimited_time=True,time_budget_mode='Unlimited',time_budget_active=False,max_seconds=3600,time_budget_seconds=3600,target_stroke_count_resolved=None)
        options.pop('gartic_timer_deadline',None)
        return options
    pixel_accurate = str(options.get('draw_quality') or '') == 'Pixel Accurate'
    if pixel_accurate:
        # Block D may honor an explicit timer progressively, but it never lets
        # the legacy speed policy reduce source resolution/colours/components.
        options['target_stroke_count']='Auto'
        options['target_stroke_count_resolved']=None
        options.pop('real_speed_budget_meta',None)
    time_budget_mode = options.get('time_budget_mode', 'Manual')
    manual_limit = options.get('manual_max_seconds', options.get('max_seconds', 180))
    try:
        effective_limit, time_budget_active = resolve_time_budget_seconds(time_budget_mode, manual_limit)
        target_cap, target_meta = resolve_target_stroke_count(
            options.get('target_stroke_count', 'Auto'), options.get('target_stroke_custom', '2500'),
            time_budget_mode=time_budget_mode, effective_time_seconds=effective_limit,
            speed=options.get('speed', 'Balanced'),
            drawing_mode=options.get('drawing_mode', SMART_PATH_MODE),
            preview=is_preview_plan(options))
        options.update(target_meta)
        options['max_seconds'] = effective_limit
        options['manual_max_seconds'] = int(manual_limit)
        options['time_budget_mode'] = time_budget_mode
        options['time_budget_seconds'] = effective_limit
        options['time_budget_active'] = time_budget_active
        options['target_stroke_count_resolved'] = None if pixel_accurate else target_cap
        # v1.0.77: browser preset budgets learn from completed real execution
        # throughput instead of relying only on the original static path-rate.
        if time_budget_active and not is_preview_plan(options) and not pixel_accurate:
            try:
                from RealSpeedBudget import apply_budget_policy
                options=apply_budget_policy(options)
            except Exception as error:
                log_event(f'Real-Speed Time Budget fallback to static policy: {error!r}')
    except ValueError:
        # The UI normally validates before this point. Direct legacy callers keep
        # their old max_seconds behaviour instead of failing inside planning.
        options.setdefault('time_budget_mode', 'Manual')
        options.setdefault('time_budget_seconds', int(options.get('max_seconds', 180)))
        options.setdefault('time_budget_active', False)
        options.setdefault('target_stroke_count', 'Auto')
        options.setdefault('target_stroke_count_resolved', None)
        options.setdefault('target_stroke_count_reason', 'legacy')
    return options

def _plan_log_text(plan):
    options = plan.get('options', {}) if isinstance(plan, dict) else {}
    advanced = options.get('advanced_color_meta') or {}
    portrait = options.get('portrait_stats') or {}
    backend = advanced.get('acceleration_backend') or portrait.get('acceleration_backend') or advanced.get('cpu_backend') or 'CPU'
    device = advanced.get('acceleration_device') or portrait.get('acceleration_device') or ''
    extra = f" {device}" if device else ''
    try:
        source = int(plan.get('source_count', plan.get('count', 0)) or 0)
        execution = int(plan.get('count', 0) or 0)
        estimate = float(plan.get('estimate', 0.0) or 0.0)
    except Exception:
        source, execution, estimate = 0, 0, 0.0
    path_stats = plan.get('path_stats') or {} if isinstance(plan, dict) else {}
    shape_bits = ''
    if path_stats.get('mode') == 'Shape paths':
        shape_bits = (
            f" shape_components={path_stats.get('shape_components', 0)}"
            f" shape_model={path_stats.get('shape_model', 'Auto')}"
            f" skipped_tiny={path_stats.get('skipped_tiny_details', 0)}"
            f" skipped_cap={path_stats.get('skipped_due_cap', 0)}"
            f" cap={path_stats.get('max_stroke_cap_resolved', path_stats.get('max_stroke_cap', '?'))}"
        )
    if path_stats.get('progressive_enabled'):
        shape_bits += (
            f" progressive={path_stats.get('progressive_phase_order', 'enabled')}"
            f" foundation={path_stats.get('progressive_foundation_paths', 0)}"
            f" contours={path_stats.get('progressive_contour_paths', 0)}"
            f" details={path_stats.get('progressive_detail_paths', 0)}"
        )
    attempt_bits = ''
    if options.get('planning_attempt_name'):
        attempt_bits = f" watchdog_attempt={options.get('planning_attempt_name')} level={options.get('planning_watchdog_fallback_level',0)}"
    target_bits = ''
    if options.get('time_budget_active') or options.get('target_stroke_count') not in (None, 'Auto'):
        target_bits = (
            f" time_budget={options.get('time_budget_mode', 'Manual')}:{options.get('time_budget_seconds', options.get('max_seconds', '?'))}s"
            f" target={options.get('target_stroke_count_resolved', options.get('target_stroke_count', '?'))}"
            f" target_skipped={path_stats.get('target_skipped_paths', 0)}"
        )
    policy_meta=options.get('profile_policy_meta') or {}
    policy_bits=''
    if policy_meta:
        policy_bits=(f" profile_policy={policy_meta.get('policy','?')}"
                     f" policy_mode={policy_meta.get('mode','Auto')}"
                     f" policy_changes={int(policy_meta.get('changed_count',0) or 0)}")
    turbo_meta=options.get('skribbl_fast_meta') or {}
    budget_meta=options.get('real_speed_budget_meta') or {}
    real_speed_bits=(f" real_speed={float(budget_meta.get('paths_per_second',0) or 0):.2f}pps"
                     f" learned={bool(budget_meta.get('learned'))} cap={budget_meta.get('path_cap','?')} colors={budget_meta.get('max_colors','?')}") if budget_meta else ''
    turbo_bits=''
    if turbo_meta.get('active'):
        turbo_bits=(f" skribbl_turbo=on colors={int(turbo_meta.get('active_colors_after',0) or 0)}"
                    f" runs={int(turbo_meta.get('runs_before',0) or 0)}->{int(turbo_meta.get('runs_after',0) or 0)}")
    performance = plan.get('performance_profile') if isinstance(plan, dict) else None
    profiler_bits = f" profiler=[{format_performance_profile(performance, compact=True)}]" if performance else ''
    optimizer_bits = ''
    if path_stats.get('stroke_optimizer_effective') not in (None,'Off'):
        optimizer_bits = (f" optimizer={path_stats.get('stroke_optimizer_effective')}"
                          f" merged={int(path_stats.get('optimizer_merged_paths',0) or 0)}"
                          f" travel_reduction={float(path_stats.get('optimizer_travel_reduction',0) or 0)*100:.0f}%")
    pixel_meta=options.get('pixel_map_meta') or {}
    pixel_bits=''
    if pixel_meta:
        pixel_bits=(f" pixelmap={int(pixel_meta.get('width',0))}x{int(pixel_meta.get('height',0))}"
                    f" protected={float(pixel_meta.get('protected_percent',0) or 0):.1f}%"
                    f" palette={pixel_meta.get('palette_backend','?')}"
                    f" edges={pixel_meta.get('edge_backend','?')}")
    pixel_stroke=options.get('pixel_stroke_meta') or {}
    if pixel_stroke:
        orient=pixel_stroke.get('orientation_counts') or {}
        pixel_bits+=(f" regions={int(pixel_stroke.get('component_count',0) or 0)}"
                     f" local_runs=H{int(orient.get('horizontal',0) or 0)}/V{int(orient.get('vertical',0) or 0)}"
                     f" passes={int(pixel_stroke.get('fill_paths',0) or 0)}/"
                     f"{int(pixel_stroke.get('mid_detail_paths',0) or 0)}/"
                     f"{int(pixel_stroke.get('fine_detail_paths',0) or 0)}/"
                     f"{int(pixel_stroke.get('cleanup_paths',0) or 0)}"
                     f" merge_fallbacks={int(pixel_stroke.get('safe_merge_fallbacks',0) or 0)}")
    pixel_accuracy=options.get('pixel_accuracy_meta') or {}
    if pixel_accuracy:
        pixel_bits+=(f" accuracy={float(pixel_accuracy.get('final_accuracy_percent',0) or 0):.2f}%"
                     f" coverage={float(pixel_accuracy.get('coverage_percent',0) or 0):.2f}%"
                     f" edge_accuracy={float(pixel_accuracy.get('edge_accuracy_percent',0) or 0):.2f}%"
                     f" corrections={int(pixel_accuracy.get('correction_paths_added',0) or 0)}"
                     f" errors={int(pixel_accuracy.get('final_error_pixels',0) or 0)}"
                     f" sim={pixel_accuracy.get('simulation_backend','?')}")
        prog=pixel_accuracy.get('progressive_time_budget') or {}
        if prog.get('active'):
            pixel_bits+=(f" progressive_budget={int(prog.get('base_path_budget',0) or 0)}/"
                         f"{int(prog.get('path_budget',0) or 0)}"
                         f" omitted={int(prog.get('paths_omitted',0) or 0)}")
    detail_meta=options.get('adaptive_detail_meta') or {}
    detail_bits=''
    if detail_meta.get('adaptive_detail_effective') not in (None,'Off'):
        detail_bits=(f" adaptive_detail={detail_meta.get('adaptive_detail_effective')}"
                     f" complexity={float(detail_meta.get('adaptive_detail_complexity',0) or 0):.2f}"
                     f" protected={float(detail_meta.get('adaptive_detail_protected_percent',0) or 0):.0f}%"
                     f" pruned_micro={int(detail_meta.get('adaptive_detail_pruned_micro_strokes',0) or 0)}")
    return (
        f"source_strokes={source} execution_paths={execution} estimate={estimate:.1f}s{shape_bits}{target_bits}{attempt_bits}{optimizer_bits}{detail_bits}{pixel_bits}{policy_bits}{real_speed_bits}{turbo_bits}{profiler_bits} "
        f"effective_resolution={options.get('planning_resolution_effective', options.get('planning_resolution', 'Standard'))} "
        f"sample_limit={options.get('planner_sample_limit', '?')} "
        f"max_pixels={options.get('planner_max_pixels', '?')} "
        f"backend={backend}{extra} "
        f"{_resource_log_text(options)}"
    )

def make_plan(original, area, options, cancelled=lambda: False):
    from PIL import Image, ImageEnhance, ImageDraw, ImageFilter, ImageOps
    from AutoDrawing import resolve_drawing
    options=resolve_drawing(original,options)
    # Sketch wins over stale/restored subject settings before any colour policy.
    if options.get('outline'):
        options = dict(options, subject_focus='Off')
    options = _ensure_time_budget_options(options)
    if options.get('outline') and options.get('sketch_detail')=='Auto':
        from AutoSketchBudget import choose_sketch
        return choose_sketch(original,area,options,make_plan,finish_plan,cancelled)
    if options.get('subject_focus', 'Off') != 'Off':
        if options.get('outline') or options.get('paint_current_color') or options.get('erase_mode'):
            raise ValueError('Subject focus needs full colour drawing. Turn off Outline, Eraser and current-colour-only mode.')
        options['draw_quality'] = 'Pixel Accurate'
        options['brush_px'] = 1
    profiler_begin(options)
    try:
        if 'cpu_workers_resolved' not in options or 'ram_budget_mb' not in options:
            options.update(resolve_allocation(options.get('cpu_workers', 'Auto'),
                                              options.get('cpu_engine', 'Auto'),
                                              options.get('ram_budget', 'Auto'),
                                              options.get('ram_custom_mb', '2048')))
    except ValueError:
        options.update({'cpu_workers':'1','cpu_workers_resolved':1,'cpu_engine':'Auto',
                        'ram_budget':'512 MB','ram_budget_mb':512,
                        'logical_cpus':1,'available_ram_mb':None})
    try:
        if 'resource_scheduler_plan' not in options:
            schedule=resolve_resource_schedule(
                options, mode=options.get('resource_scheduler','Auto'), area=area,
                drawing_mode=options.get('drawing_mode', SMART_PATH_MODE),
                gpu_mode=options.get('gpu_mode','Auto'),
                gpu_available=(options.get('gpu_mode','Auto')!='CPU' and options.get('draw_quality') in ('GPU enhanced','Pixel Accurate')),
                preview=is_preview_plan(options))
            options['resource_scheduler_plan']=schedule
            if options.get('resource_scheduler','Auto')!='Off':
                options['cpu_workers_resolved']=int(schedule.get('effective_cpu_workers',options.get('cpu_workers_resolved',1)) or 1)
                options['cpu_engine']=schedule.get('recommended_engine',options.get('cpu_engine','Auto'))
    except (ValueError,TypeError,KeyError):
        options['resource_scheduler_plan']={'version':2,'mode':'Off','phases':{},'reason':'scheduler unavailable'}

    try:
        planning_limits = resolve_planning_limits(options.get('detail', 8), area,
            planning_resolution=options.get('planning_resolution', 'Auto'),
            cpu_workers=options.get('cpu_workers_resolved', 1),
            ram_budget_mb=options.get('ram_budget_mb', 512),
            preview=is_preview_plan(options))
    except ValueError:
        planning_limits = resolve_planning_limits(options.get('detail', 8), area,
            planning_resolution='Standard', cpu_workers=1, ram_budget_mb=512, preview=is_preview_plan(options))
    options.update(planning_limits)
    if str(options.get('draw_quality') or '') == 'Pixel Accurate':
        # Block A: preserve the complete target raster. One analysed pixel maps
        # to one target pixel; later run building may combine adjacent equal
        # pixels losslessly, but resolution is no longer discarded here.
        target_w=max(1,int(area[0]));target_h=max(1,int(area[1]))
        options['planner_sample_limit']=max(target_w,target_h)
        options['planner_max_pixels']=target_w*target_h
        options['planning_resolution_effective']='Pixel Accurate / full target'
        options['adaptive_detail']='Off'
        options['background_simplification']='Off'
        options['color_grouping']='Accurate'
        options['stroke_optimizer']='Travel only'
        options['target_stroke_count_resolved']=None
        # Block D may keep an explicit timer active, but it never enables
        # destructive resolution/palette/path caps.
        options.pop('real_speed_budget_meta',None)
    render_style = options.get('render_style', 'Auto')

    # Auto uses the portrait renderer for single-colour Paint sketches because
    # photographs lose most facial tone when reduced to one binary threshold.
    # Palette drawings keep the faster colour-run planner unless Portrait is
    # explicitly selected.
    portrait_mode = render_style == 'Portrait / shaded' or (
        render_style == 'Auto' and options.get('paint_current_color') and not options.get('erase_mode'))
    if portrait_mode and options.get('paint_current_color') and not options.get('outline'):
        draw_quality = options.get('draw_quality', 'High likeness')
        gpu_mode = options.get('gpu_mode', 'Auto')
        gpu_vram = options.get('gpu_vram', 'Auto')
        gpu_performance = options.get('gpu_performance', 'Balanced')
        acceleration_meta = {}
        _prof_pre = profiler_start(options, 'preprocessing')
        gray, fitted = prepare_portrait_image(original, area, options['detail'], options['contrast'], options.get('portrait_focus',True), draw_quality,
                                               gpu_mode=gpu_mode, acceleration_meta=acceleration_meta, gpu_vram=gpu_vram, gpu_performance=gpu_performance)
        profiler_stop(options, 'preprocessing', _prof_pre)
        # Fit portrait complexity to the configured time limit.  This avoids the
        # previous situation where High/Balanced previews looked good but Start
        # drawing immediately rejected them for exceeding the default 180 s.
        speed_name = normalize_speed(options.get('speed', 'Balanced'))
        seconds_per_stroke = {'Safe': .18, 'Balanced': .12, 'Fast': .08}[speed_name] + options['delay'] * 2.0
        time_budget = max(120, int(options.get('max_seconds', 180) / seconds_per_stroke * .90))
        _prof_color = profiler_start(options, 'color_planning')
        groups, stats = portrait_strokes(gray, options['detail'], options['lines'], cancelled,
                                         include_edges=True, max_strokes=time_budget,
                                         draw_quality=draw_quality, subject_focus=options.get('portrait_focus', True),
                                         gpu_mode=gpu_mode, acceleration_meta=acceleration_meta, gpu_vram=gpu_vram, gpu_performance=gpu_performance)
        profiler_stop(options, 'color_planning', _prof_color)
        plan_options = dict(options)
        # Paint produces continuous brush lines between cursor positions; a
        # slightly larger interpolation step makes shaded portraits practical
        # without changing the generated stroke geometry.
        plan_options['stroke_step_px'] = 12
        plan_options['portrait_stats'] = {
            'tone_strokes': stats.tone_strokes, 'edge_strokes': stats.edge_strokes,
            'levels': stats.levels, 'sample_size': stats.sample_size,
            'priority_strokes': stats.priority_strokes, 'draw_quality': stats.draw_quality,
            'acceleration_backend': stats.acceleration_backend, 'acceleration_device': stats.acceleration_device,
            'gpu_accelerated': stats.gpu_accelerated, 'gpu_requested': gpu_mode,
            'gpu_vram': gpu_vram, 'gpu_performance': gpu_performance,
            'vram_budget_mb': acceleration_meta.get('vram_budget_mb'),
            'pool_used_mb': acceleration_meta.get('pool_used_mb'), 'pool_cached_mb': acceleration_meta.get('pool_cached_mb'),
            'compute_capability': acceleration_meta.get('compute_capability',''), 'multiprocessors': acceleration_meta.get('multiprocessors'),
            'allocation_mode': acceleration_meta.get('allocation_mode','Adaptive'), 'tile_rows': acceleration_meta.get('tile_rows'),
            'workspace_estimate_mb': acceleration_meta.get('workspace_estimate_mb'), 'cuda_execution': acceleration_meta.get('cuda_execution',''),
            'scaler': acceleration_meta.get('scaler','CPU Lanczos'),
            'acceleration_reason': str(acceleration_meta.get('reason',''))[:240]}
        plan = finish_plan(gray.convert('RGBA'), fitted, groups, plan_options, cancelled)
        # The estimator also accounts for physical line length, so a count-only
        # budget can still be too slow on a large Paint canvas.  Thin the edge
        # and tone sets evenly (never just truncate the top of the image) until
        # the planned run fits with a small safety margin.
        target_seconds = max(5.0, options.get('max_seconds', 180) * .92)
        for _ in range(3):
            if plan['estimate'] <= target_seconds or plan['count'] <= 100:
                break
            ratio = max(.12, min(.95, target_seconds / max(plan['estimate'], .001) * .92))
            strokes = plan['groups'][0]
            edge_count = int(plan_options['portrait_stats']['edge_strokes'])
            edges, tones = strokes[:edge_count], strokes[edge_count:]
            def evenly_sample(items, wanted):
                if wanted >= len(items): return list(items)
                if wanted <= 0: return []
                return [items[min(len(items)-1, int((i + .5) * len(items) / wanted))] for i in range(wanted)]
            edge_keep = min(len(edges), max(24, int(len(edges) * ratio))) if edges else 0
            tone_keep = min(len(tones), max(48, int(len(tones) * ratio))) if tones else 0
            edges = evenly_sample(edges, edge_keep)
            tones = evenly_sample(tones, tone_keep)
            plan_options = dict(plan_options)
            plan_options['portrait_stats'] = dict(plan_options['portrait_stats'],
                edge_strokes=len(edges), tone_strokes=len(tones),
                priority_strokes=min(int(plan_options['portrait_stats'].get('priority_strokes', 0)), len(tones)),
                time_fitted=True)
            plan = finish_plan(gray.convert('RGBA'), fitted, [edges + tones], plan_options, cancelled)
        return plan

    if options.get('outline'):
        if options.get('erase_mode'):raise ValueError('Black sketch requires Pencil or Brush, not Eraser.')
        from SketchPlanner import contour_image,black_index
        from PixelData import monochrome_strokes
        _prof_pre=profiler_start(options,'preprocessing')
        image,fitted=prepare_image(original,area,10,sample_limit=min(720,max(area)),max_pixels=518400)
        image=contour_image(image,cancelled,detail=options.get('sketch_detail','Detailed'))
        profiler_stop(options,'preprocessing',_prof_pre)
        ink=monochrome_strokes(image,True,cancelled)[0]
        plan_options=dict(options)
        plan_options.update(black_sketch=True,skip_white=True,background_fill='Off',fill_regions=[],
            fill_tool_actions=[],background_simplification='Off',adaptive_detail='Off',
            color_layers='Off',custom_color_workflow='Off',color_selectors=(),
            drawing_mode=SMART_PATH_MODE,smart_paths=True,lines=True,stroke_optimizer='Travel only',
            target_stroke_count_resolved=None,color_workflow='Finish color first',progressive_rendering='Off')
        plan_options.pop('background_fill_plan',None)
        plan_options.pop('real_speed_budget_meta',None)
        plan_options.pop('plan_palette_rgb',None)
        if options.get('paint_current_color'):
            groups=[ink]
        else:
            groups=[[] for _ in allColors]
            if ink:groups[black_index(tuple(c.RGB for c in allColors))]=ink
        if options.get('profile_key') in ('gartic-phone','gartic-io') or options.get('profile_name') in ('Gartic Phone','Gartic.io'):
            from GarticSketchPaths import trace_contours
            paths,sketch_meta=trace_contours(image,cancelled)
            execution=[[] for _ in groups]
            index=0 if options.get('paint_current_color') else black_index(tuple(c.RGB for c in allColors)) if ink else 0
            if execution:execution[index]=paths
            plan_options['sketch_execution_groups']=execution
            plan_options['gartic_sketch_meta']=sketch_meta
            plan_options['stroke_optimizer']='Off'
        return finish_plan(image,fitted,groups,plan_options,cancelled)

    _prof_pre = profiler_start(options, 'preprocessing')
    image, fitted = prepare_image(original, area, options['detail'], sample_limit=options.get('planner_sample_limit'), max_pixels=options.get('planner_max_pixels'))
    alpha = image.getchannel('A')
    image = ImageEnhance.Contrast(image.convert('RGB')).enhance(options['contrast'])
    image.putalpha(alpha)
    profiler_stop(options, 'preprocessing', _prof_pre)
    if options.get('paint_current_color'):
        from PixelData import monochrome_strokes
        _prof_color = profiler_start(options, 'color_planning')
        groups=monochrome_strokes(image,options['lines'],cancelled,
                                  cpu_workers=options.get('cpu_workers_resolved',1),
                                  cpu_engine=options.get('cpu_engine','Auto'),
                                  ram_budget_mb=options.get('ram_budget_mb',512),
                                  preview_plan=is_preview_plan(options))
        profiler_stop(options, 'color_planning', _prof_color)
        return finish_plan(image,fitted,groups,options,cancelled)

    # v1.0.86 Block A: Pixel Accurate Planner. Build a full-resolution PixelMap
    # before any background simplification, adaptive pruning, reduced palette or
    # browser turbo policy can remove source information. Horizontal same-colour
    # runs are lossless compression of the pixel map, not geometric simplification.
    if str(options.get('draw_quality') or '') == 'Pixel Accurate' and not options.get('outline'):
        from PixelAccuratePlanner import build_pixel_map
        from PixelStrokeEngine import build_pixel_stroke_plan
        _prof_color = profiler_start(options, 'color_planning')
        pixel_map=build_pixel_map(
            image, tuple(c.RGB for c in allColors),
            color_rendering=options.get('color_rendering','Perceptual match'),
            skip_white=bool(options.get('skip_white',True)),
            gpu_mode=options.get('gpu_mode','Auto'),
            gpu_vram=options.get('gpu_vram','Auto'),
            gpu_performance=options.get('gpu_performance','High throughput'))
        from SubjectFocus import focused_stroke_plan
        pixel_map,stroke_plan=focused_stroke_plan(
            pixel_map,image,len(allColors),options.get('subject_focus','Off'),options.get('subject_region'),lines=bool(options.get('lines',True)),
            cpu_workers=int(options.get('cpu_workers_resolved',1) or 1),cancelled=cancelled)
        from AdaptiveBrushEngine import assign_adaptive_brushes
        adaptive_brush=assign_adaptive_brushes(
            stroke_plan['execution_sequence'],profile_key=str(options.get('profile_key') or ''),
            default_brush_px=max(1,int(options.get('brush_px',1) or 1)),
            browser_brush_plan=options.get('browser_brush_plan'))
        stroke_plan['execution_sequence']=adaptive_brush['execution_sequence']
        stroke_plan['metadata']=dict(stroke_plan.get('metadata') or {})
        stroke_plan['metadata']['adaptive_brush']=adaptive_brush['metadata']
        # v1.0.89 Block D: preserve the full Block-B plan, then optionally fit
        # execution to a user timer by phase/importance only. CUDA performs the
        # expensive brush simulation when available; corrections stay inside the
        # same progressive path budget.
        from PixelAccuracyEngine import (refine_with_corrections, execution_groups_from_sequence,
                                         render_coverage_map, render_error_map, progressive_time_budget,
                                         progressive_accuracy_checkpoints)
        progressive_budget=progressive_time_budget(
            stroke_plan['execution_sequence'],active=bool(options.get('time_budget_active')),
            seconds=int(options.get('time_budget_seconds') or options.get('max_seconds') or 600),
            profile_key=str(options.get('profile_key') or ''),
            correction_reserve_ratio=(0 if options.get('subject_focus','Off')!='Off' else .12))
        base_sequence=progressive_budget['execution_sequence']
        accuracy_plan=refine_with_corrections(
            pixel_map,base_sequence,tuple(c.RGB for c in allColors),
            brush_px=max(1,int(options.get('brush_px',1) or 1)),max_passes=(0 if options.get('subject_focus','Off')!='Off' else 2),
            correction_brush_px=int(adaptive_brush['metadata'].get('detail_brush_px',options.get('brush_px',1)) or 1),
            max_total_paths=(progressive_budget.get('path_budget') if progressive_budget.get('active') else None),
            gpu_mode=options.get('gpu_mode','Auto'),gpu_vram=options.get('gpu_vram','Auto'),
            gpu_performance=options.get('gpu_performance','High throughput'),cancelled=cancelled)
        stroke_plan['execution_sequence']=accuracy_plan['execution_sequence']
        stroke_plan['execution_groups']=execution_groups_from_sequence(
            stroke_plan['execution_sequence'],len(allColors))
        groups=stroke_plan['groups']
        plan_options=dict(options)
        plan_options['pixel_accurate']=True
        plan_options['pixel_map_meta']=pixel_map.as_meta()
        plan_options['plan_palette_rgb']=tuple(c.RGB for c in allColors)
        plan_options['adaptive_detail_effective']='Off'
        plan_options['adaptive_detail_meta']={
            'adaptive_detail_requested':'Off','adaptive_detail_effective':'Off',
            'adaptive_detail_pruned_micro_strokes':0,'adaptive_detail_pruned_micro_pixels':0,
            'protected_pixels':int(pixel_map.as_meta().get('protected_pixels',0))}
        plan_options['background_simplification_meta']={
            'requested':'Off','effective':'Off','pixel_accurate_bypass':True}
        plan_options['advanced_color_meta']={
            'mode':'pixel-accurate-map','backend':pixel_map.metadata.get('palette_backend','cpu-numpy'),
            'edge_backend':pixel_map.metadata.get('edge_backend','cpu-numpy'),
            'full_resolution':True,'destructive_simplification':False}
        # v1.0.87 Block B supplies exact component-aware execution paths and a
        # four-pass sequence. These runtime-only fields are consumed by
        # finish_plan; they never enter saved settings or mouse calibration.
        plan_options['_pixel_execution_groups']=stroke_plan['execution_groups']
        plan_options['_pixel_execution_sequence']=stroke_plan['execution_sequence']
        plan_options['pixel_stroke_meta']=stroke_plan['metadata']
        plan_options['pixel_stroke_engine']='Block B + C + D + Adaptive Brush v2'
        checkpoints=progressive_accuracy_checkpoints(
            pixel_map,stroke_plan['execution_sequence'],tuple(c.RGB for c in allColors),
            brush_px=max(1,int(options.get('brush_px',1) or 1)),cancelled=cancelled)
        accuracy_meta=dict(accuracy_plan['metadata'])
        accuracy_meta['progressive_time_budget']={k:v for k,v in progressive_budget.items() if k!='execution_sequence'}
        accuracy_meta['accuracy_checkpoints']=checkpoints
        accuracy_meta['block_d']=True
        if options.get('subject_focus','Off')!='Off':
            accuracy_meta['automatic_corrections']=False
            accuracy_meta['correction_note']='Subject focus uses exact 1 px paths; correction passes disabled to avoid restoring intentionally omitted background.'
        accuracy_meta['adaptive_brush']=adaptive_brush['metadata']
        accuracy_meta['draw_motor']='Adaptive Brush Draw Motor v2'
        plan_options['pixel_accuracy_meta']=accuracy_meta
        plan_options['_pixel_coverage_preview']=render_coverage_map(pixel_map,accuracy_plan['simulation'])
        plan_options['_pixel_error_preview']=render_error_map(pixel_map,accuracy_plan['simulation'])
        plan_options['color_workflow']='Progressive passes'
        plan_options['progressive_rendering']='On'
        plan_options['target_stroke_count_resolved']=None
        plan_options['stroke_optimizer']='Travel only'
        plan_options['color_grouping']='Accurate'
        plan_options.pop('real_speed_budget_meta',None)
        profiler_stop(plan_options,'color_planning',_prof_color)
        return finish_plan(image,fitted,groups,plan_options,cancelled)

    plan_options=dict(options)
    _prof_color = profiler_start(plan_options, 'color_planning')
    # Work on a white-flattened palette image. This is the same visible result
    # build_strokes used to derive from alpha, but it lets v1.0.7 simplify only
    # a border-connected background before palette quantization.
    backdrop=Image.new('RGBA',image.size,'white');backdrop.alpha_composite(image)
    palette_image=backdrop.convert('RGB')

    # v1.0.38: local adaptive-detail pass.  Important high-contrast structure is
    # protected while low-detail texture is simplified before palette planning.
    # Outline-only plans already reduce the source to edges and therefore bypass
    # this pass to avoid processing the same structure twice.
    adaptive_mask=None
    adaptive_stats=None
    adaptive_mode=options.get('adaptive_detail','Auto')
    if adaptive_mode!='Off' and not options.get('outline'):
        adaptive_rgba,adaptive_mask,adaptive_stats=apply_adaptive_detail(
            palette_image.convert('RGBA'),adaptive_mode,
            subject_focus=bool(options.get('portrait_focus',False)),
            drawing_mode=options.get('drawing_mode'),preview=is_preview_plan(options),cancelled=cancelled)
        palette_image=adaptive_rgba.convert('RGB')
        plan_options['adaptive_detail_meta']=adaptive_stats.as_dict()
        plan_options['adaptive_detail_effective']=adaptive_stats.effective_mode
    elif adaptive_mode=='Off':
        plan_options['adaptive_detail_meta']={'adaptive_detail_requested':'Off','adaptive_detail_effective':'Off',
                                             'adaptive_detail_pruned_micro_strokes':0,'adaptive_detail_pruned_micro_pixels':0}
        plan_options['adaptive_detail_effective']='Off'

    simplification_mode=options.get('background_simplification','Balanced')
    palette_image,simplification=simplify_background(palette_image,simplification_mode)
    plan_options['background_simplification_meta']=simplification.as_dict()
    image=palette_image.convert('RGBA')

    fill_plan=None;fill_regions=[]
    fill_mode=options.get('background_fill','Balanced')
    safe_fill_margin=source_fill_margin_px(options.get('brush_px',3),2,palette_image.size)
    plan_options['safe_fill_mask_margin_px']=safe_fill_margin
    if fill_mode!='Off' and options.get('fill_tool_available') and not options.get('outline'):
        fill_plan=detect_background(palette_image,fill_mode,safe_margin_px=safe_fill_margin)
        if options.get('extra_fast'):
            # Extra fast only fills bounded interior regions, never the whole canvas.
            fill_plan=None
        if fill_plan is not None and fill_plan.enabled:
            bg_dict=fill_plan.as_dict();bg_dict['safe_fill_mask']=True;bg_dict['safe_fill_margin_px']=safe_fill_margin
            plan_options['background_fill_plan']=bg_dict
        # Interior bucket fills are deliberately restricted to large, mask-safe
        # connected components. Their perimeter is drawn before the bucket click
        # during execution, and unsafe edge-adjacent regions remain scanline strokes.
        fill_regions,fill_region_meta=detect_fill_regions(palette_image,fill_mode,engine=options.get('fill_engine','Auto'),cancelled=cancelled,return_meta=True,safe_margin_px=safe_fill_margin)
        fill_region_dicts=[region.as_dict() for region in fill_regions]
        fill_region_dicts,safe_fill_meta=filter_fill_regions_by_source_mask(fill_region_dicts,palette_image.size,margin_px=safe_fill_margin)
        if options.get('extra_fast'):
            from ExtraFast import select_fast_regions
            fill_region_dicts,fast_meta=select_fast_regions(fill_region_dicts,palette_image.size,fitted,options,cancelled)
            plan_options['extra_fast_meta']=fast_meta
        fill_region_meta=dict(fill_region_meta);fill_region_meta['safe_fill_mask']=safe_fill_meta
        fill_region_meta['accepted_regions']=len(fill_region_dicts)
        fill_region_meta['fallback_scanline_regions']=int(fill_region_meta.get('fallback_scanline_regions',0))+int(safe_fill_meta.get('rejected_regions',0))
        plan_options['fill_engine_meta']=fill_region_meta
        if fill_region_dicts:
            plan_options['fill_regions']=fill_region_dicts

    # A non-white Fill can cover white/highlight holes, so white correction
    # strokes are kept whenever any bucket operation is planned.
    planner_skip_white=options['skip_white']
    needs_white_correction=(fill_plan is not None and fill_plan.enabled) or any(float(region.get('bbox_density',1.0)) < .9999 for region in (plan_options.get('fill_regions') or []))
    if needs_white_correction:
        planner_skip_white=False
    color_rendering=options.get('color_rendering','Perceptual match')
    color_layers=options.get('color_layers','Off')
    custom_color_workflow=options.get('custom_color_workflow','Calibrated palette')
    dynamic_exact=(custom_color_workflow in ('Exact custom + palette fallback','Adaptive exact (recommended)'))
    if dynamic_exact:
        # Exact-color planning is bounded: cluster the image into a useful number
        # of colors. Each cluster uses exact RGB when calibrated; otherwise it
        # *always* resolves to the nearest actually calibrated palette swatch.
        limit=resolve_exact_color_limit(options.get('exact_color_limit','Auto'),draw_quality=options.get('draw_quality','High likeness'),preview=is_preview_plan(options))
        groups,plan_colors,selectors,color_render_meta=build_dynamic_color_strokes(
            image,tuple(c.RGB for c in allColors),max_colors=limit,skip_white=planner_skip_white,
            lines=options['lines'],exact_available=bool(options.get('exact_color_available')),cancelled=cancelled)
        if groups is None:raise InterruptedError()
        if adaptive_mask is not None and options.get('lines',True):
            groups,prune_meta=prune_flat_micro_strokes(groups,adaptive_mask,
                plan_options.get('adaptive_detail_effective','Off'),cancelled=cancelled)
            meta=dict(plan_options.get('adaptive_detail_meta') or {});meta.update(prune_meta);plan_options['adaptive_detail_meta']=meta
        plan_options['plan_palette_rgb']=tuple(plan_colors)
        plan_options['color_selectors']=tuple(selectors)
        plan_options['advanced_color_meta']=color_render_meta
        # Bucket fill plans use static palette indexes; disable them for a mixed
        # dynamic/custom selector plan rather than risk a wrong color click.
        plan_options.pop('background_fill_plan',None);plan_options['fill_regions']=[]
        grouping_mode=options.get('color_grouping','Smart')
        if bool(options.get('exact_color_available')) and grouping_mode=='Reduced palette':
            # Exact custom RGB means exact: do not silently merge two selected
            # custom colors just because the speed profile requested reduction.
            grouping_mode='Smart'
        groups,color_order,color_meta=group_palette_strokes(groups,tuple(plan_colors),grouping_mode)
        color_meta=dict(color_meta);color_meta['requested_mode']=options.get('color_grouping','Smart')
        plan_options['color_order']=color_order;plan_options['color_grouping_meta']=color_meta
        profiler_stop(plan_options,'color_planning',_prof_color)
        return finish_plan(image,fitted,groups,plan_options,cancelled)
    if color_rendering=='RGB nearest' and color_layers=='Off' and custom_color_workflow=='Calibrated palette' and options.get('gpu_mode','CPU')=='CPU':
        groups = build_strokes(image, options['lines'], planner_skip_white, cancelled,
                                cpu_workers=options.get('cpu_workers_resolved',1),
                                cpu_engine=options.get('cpu_engine','Auto'),
                                ram_budget_mb=options.get('ram_budget_mb',512),
                                preview_plan=is_preview_plan(options))
        color_render_meta={'color_rendering':'RGB nearest','color_layers':'Off','custom_color_workflow':'Calibrated palette','layered_pixels':0,'base_colors':sum(bool(g) for g in groups) if groups else 0,'overlay_colors':0,'cpu_backend':'parallel' if options.get('cpu_workers_resolved',1)>1 else 'serial','cpu_chunks':0}
    else:
        groups, color_render_meta = build_color_strokes(
            image, lines=options['lines'], skip_white=planner_skip_white,
            color_rendering=color_rendering, color_layers=color_layers,
            custom_color_workflow=custom_color_workflow, cancelled=cancelled,
            cpu_workers=options.get('cpu_workers_resolved',1),
            cpu_engine=options.get('cpu_engine','Auto'),
            ram_budget_mb=options.get('ram_budget_mb',512),
            preview_plan=is_preview_plan(options),
            gpu_mode=options.get('gpu_mode','CPU'),
            gpu_vram=options.get('gpu_vram','Auto'),
            gpu_performance=options.get('gpu_performance','Balanced'))
    if groups is None:
        raise InterruptedError()
    if options['skip_white'] and needs_white_correction and not (fill_plan is not None and fill_plan.enabled):
        from FillOptimizer import restrict_white_corrections
        groups=restrict_white_corrections(groups,tuple(c.RGB for c in allColors),plan_options.get('fill_regions') or [])

    # v1.0.77: under a measured browser time budget, deliberately merge rare
    # colors before path building. This preserves the darkest structural color
    # and reduces expensive palette switches. Dedicated Gartic/Skribbl Turbo
    # may reduce further afterwards.
    real_speed_color_meta=None
    if options.get('real_speed_max_colors') and str(options.get('profile_key') or '') in ('gartic-phone','skribbl','skribbl-fast','sketchheads','sketchful'):
        try:
            from RealSpeedBudget import reduce_palette_groups
            groups,real_speed_color_meta=reduce_palette_groups(groups,tuple(c.RGB for c in allColors),int(options.get('real_speed_max_colors')))
            plan_options['real_speed_color_meta']=real_speed_color_meta
        except Exception as error:
            log_event(f'Real-Speed palette reduction skipped: {error!r}')
    if adaptive_mask is not None and options.get('lines',True):
        groups,prune_meta=prune_flat_micro_strokes(groups,adaptive_mask,
            plan_options.get('adaptive_detail_effective','Off'),cancelled=cancelled)
        meta=dict(plan_options.get('adaptive_detail_meta') or {});meta.update(prune_meta);plan_options['adaptive_detail_meta']=meta
    # v1.0.64: Skribbl Fast gets a dedicated fixed-palette run compressor.
    # It mirrors the classic fast autodraw strategy: one calibrated colour batch
    # at a time, long horizontal runs instead of pixel-sized strokes, and no
    # custom-colour modal workflow. Paint and all other profiles are untouched.
    if (str(options.get('profile_name') or '') == 'Skribbl.io Fast' and options.get('lines', True) and str(options.get('profile_engine') or 'Auto') != 'Manual settings'):
        groups, skribbl_fast_meta = optimize_skribbl_groups(
            groups, tuple(c.RGB for c in allColors),
            max_colors=int(options.get('skribbl_fast_max_colors', 6) or 6),
            gap_join=int(options.get('skribbl_fast_gap_join', 1) or 1),
            min_run=int(options.get('skribbl_fast_min_run', 2) or 2))
        plan_options['skribbl_fast_meta'] = skribbl_fast_meta
        plan_options['skribbl_fast_direct_paths'] = True
        # Browser canvases tolerate wider cursor interpolation than Paint. This
        # cuts native move events substantially while keeping exact endpoints.
        plan_options['stroke_step_px'] = max(float(plan_options.get('stroke_step_px', 8) or 8), 12.0)

    # v1.0.65: Gartic Phone gets the same fixed-palette batching idea but
    # with a dual-axis raster optimizer. The classic Gartic bot uses vertical
    # column runs while Skribbl-style bots use horizontal rows; choosing the
    # cheaper orientation per colour reduces press/release boundaries further.
    if (str(options.get('profile_name') or '') == 'Gartic Phone' and options.get('lines', True) and str(options.get('profile_engine') or 'Auto') != 'Manual settings'):
        runtime_profile = choose_runtime_profile(
            options.get('time_left_seconds'),
            canvas_size=plan_options.get('area') or fitted,
            requested_speed=options.get('speed', 'Fast'))
        groups, gartic_fast_meta = optimize_gartic_phone_groups(
            groups, tuple(c.RGB for c in allColors),
            max_colors=int(options.get('gartic_phone_max_colors', runtime_profile.max_colors) or runtime_profile.max_colors),
            gap_join=int(options.get('gartic_phone_gap_join', 1) or 1),
            min_run=int(options.get('gartic_phone_min_run', 2) or 2))
        gartic_fast_meta = dict(gartic_fast_meta)
        gartic_fast_meta['engine_v2_runtime'] = runtime_profile.as_options()
        plan_options['gartic_phone_fast_meta'] = gartic_fast_meta
        plan_options['gartic_phone_direct_paths'] = True
        plan_options['target_stroke_count_resolved'] = min(
            int(plan_options.get('target_stroke_count_resolved') or runtime_profile.max_paths),
            runtime_profile.max_paths)
        # Gartic Phone is an HTML5 canvas. Engine v2 uses fewer browser events
        # than Paint while keeping exact endpoints. Time-critical profiles widen
        # interpolation automatically.
        plan_options['stroke_step_px'] = max(float(plan_options.get('stroke_step_px', 8) or 8), runtime_profile.stroke_step_px)

    plan_options['advanced_color_meta']=color_render_meta
    if fill_plan is not None and fill_plan.enabled and fill_plan.color_index is not None:
        idx=int(fill_plan.color_index)
        if 0<=idx<len(groups):
            groups[idx]=[]
    if plan_options.get('fill_regions'):
        groups=remove_filled_region_strokes(groups,plan_options.get('fill_regions') or [])

    # Smart color grouping never changes RGB by default: it schedules large
    # color masses first and small detail colors later. Reduced palette is the
    # only mode allowed to merge very close, rare palette colors.
    grouping_mode = options.get('color_grouping','Smart')
    # Gartic Phone Turbo has already performed its deliberate palette reduction.
    # A second merge here could move vertical runs into a group whose orientation
    # metadata says horizontal, so keep the post-Turbo stage scheduling-only.
    if plan_options.get('gartic_phone_direct_paths'):
        grouping_mode = 'Smart'
    groups,color_order,color_meta=group_palette_strokes(
        groups,tuple(c.RGB for c in allColors),grouping_mode)
    if plan_options.get('gartic_phone_direct_paths'):
        color_meta=dict(color_meta);color_meta['requested_mode']=options.get('color_grouping','Smart');color_meta['turbo_reduced']=True
    plan_options['color_order']=color_order
    plan_options['color_grouping_meta']=color_meta
    profiler_stop(plan_options, 'color_planning', _prof_color)
    return finish_plan(image,fitted,groups,plan_options,cancelled)


def finish_plan(image,fitted,groups,options,cancelled=lambda: False):
    from PIL import Image,ImageDraw
    _prof_preview = profiler_start(options, 'preview_rendering')
    # Model physical brush width and the same centered coordinates used for drawing.
    scale=1 if options.get('_full_detail_preview') else min(1,1600/max(fitted))
    size=tuple(max(1,round(v*scale)) for v in fitted)
    if options.get('erase_mode'):
        palette_rgb=((190,198,210),)  # preview-only erase mask color
    else:
        palette_rgb=((0,0,0),) if options.get('paint_current_color') else tuple(options.get('plan_palette_rgb') or tuple(c.RGB for c in allColors))
    fill_meta=options.get('background_fill_plan') or {}
    preview_bg='white'
    if fill_meta.get('enabled') and fill_meta.get('color_index') is not None:
        try:preview_bg=palette_rgb[int(fill_meta['color_index'])]
        except (IndexError,TypeError,ValueError):preview_bg='white'
    preview=Image.new('RGB',size,preview_bg);draw=ImageDraw.Draw(preview)
    brush=max(1,round(options.get('brush_px',3)*scale))
    transform=CanvasTransform(image.width,image.height,(fitted[0]*scale,fitted[1]*scale))
    execution_transform=CanvasTransform(image.width,image.height,fitted)
    def point(x,y):return transform.float_point(x,y)
    # Show planned safe interior fills in the preview before the remaining
    # detail strokes are layered on top.
    for region in options.get('fill_regions',[]) or []:
        try:
            index=int(region['color_index']);x0,y0,x1,y1=map(int,region['bbox'])
            p0=point(x0,y0);p1=point(x1,y1)
            draw.rectangle((p0[0],p0[1],p1[0],p1[1]),fill=palette_rgb[index])
        except (KeyError,TypeError,ValueError,IndexError):
            continue

    profiler_stop(options, 'preview_rendering', _prof_preview)
    drawing_mode=options.get('drawing_mode')
    if drawing_mode is None:
        # Backwards-compatible plans/tests that only provide the legacy ``lines``
        # flag keep the old execution model exactly.
        drawing_mode=LEGACY_LINE_MODE if options.get('lines',True) else DOT_MODE
    shape_enabled=drawing_mode==SHAPE_PATH_MODE and bool(options.get('lines',True))
    smart_enabled=drawing_mode==SMART_PATH_MODE and bool(options.get('lines',True))
    edge_count=None
    if smart_enabled and options.get('portrait_stats'):
        try:edge_count=int(options['portrait_stats'].get('edge_strokes',0))
        except (TypeError,ValueError,AttributeError):edge_count=0
    _prof_shape = profiler_start(options, 'shape_extraction')
    pixel_prebuilt = options.get('_pixel_execution_groups')
    if pixel_prebuilt is not None:
        # v1.0.87 Block B: the component-aware Pixel Stroke Engine already
        # produced geometry-safe local paths. Do not feed them back through the
        # generic line/shape compressors, which could discard its region/phase
        # boundaries.
        execution_groups=[list(paths) for paths in pixel_prebuilt]
        path_meta=continuous_path_stats(groups,execution_groups)
        path_meta=dict(path_meta)
        stroke_meta=dict(options.get('pixel_stroke_meta') or {})
        path_meta.update({
            'mode':'Pixel Accurate component paths',
            'pixel_component_engine':True,
            'pixel_component_count':int(stroke_meta.get('component_count',0) or 0),
            'pixel_fill_paths':int(stroke_meta.get('fill_paths',0) or 0),
            'pixel_mid_detail_paths':int(stroke_meta.get('mid_detail_paths',0) or 0),
            'pixel_fine_detail_paths':int(stroke_meta.get('fine_detail_paths',0) or 0),
            'pixel_cleanup_paths':int(stroke_meta.get('cleanup_paths',0) or 0),
            'pixel_safe_merge_fallbacks':int(stroke_meta.get('safe_merge_fallbacks',0) or 0),
            'pixel_accuracy_percent':float((options.get('pixel_accuracy_meta') or {}).get('final_accuracy_percent',0) or 0),
            'pixel_coverage_percent':float((options.get('pixel_accuracy_meta') or {}).get('coverage_percent',0) or 0),
            'pixel_error_pixels':int((options.get('pixel_accuracy_meta') or {}).get('final_error_pixels',0) or 0),
            'pixel_correction_paths':int((options.get('pixel_accuracy_meta') or {}).get('correction_paths_added',0) or 0),
            'stroke_optimizer_requested':options.get('stroke_optimizer','Travel only'),
            'stroke_optimizer_effective':'Component-safe scheduler',
            'optimizer_merged_paths':max(0,int(stroke_meta.get('source_horizontal_runs',0) or 0)-sum(len(g) for g in execution_groups)),
            'optimizer_travel_reduction':0.0,
        })
    elif options.get('sketch_execution_groups') is not None:
        execution_groups=[list(paths) for paths in options['sketch_execution_groups']]
        path_meta=dict(continuous_path_stats(groups,execution_groups))
        path_meta.update(options.get('gartic_sketch_meta') or {})
        path_meta['mode']='Gartic connected contours'
    elif options.get('skribbl_fast_direct_paths'):
        # Join overlapping adjacent same-colour runs under one mouse-down. The
        # connectors remain inside already-planned colour pixels, so this is both
        # faster and deterministic rather than a blind diagonal shortcut.
        execution_groups=build_execution_paths(groups,enabled=True,
                                                 portrait_edge_count=None,cancelled=cancelled)
        path_meta=continuous_path_stats(groups,execution_groups)
        path_meta=dict(path_meta)
        turbo_meta=dict(options.get('skribbl_fast_meta') or {})
        path_meta.update({
            'mode':'Skribbl turbo runs',
            'skribbl_fast':True,
            'skribbl_active_colors':turbo_meta.get('active_colors_after',0),
            'skribbl_runs_before':turbo_meta.get('runs_before',0),
            'skribbl_runs_after':turbo_meta.get('runs_after',0),
        })
    elif options.get('gartic_phone_direct_paths'):
        turbo_meta=dict(options.get('gartic_phone_fast_meta') or {})
        execution_groups=build_gartic_execution_paths(
            groups, turbo_meta.get('orientations') or {}, cancelled=cancelled)
        path_meta=continuous_path_stats(groups,execution_groups)
        path_meta=dict(path_meta)
        path_meta.update({
            'mode':'Gartic Phone Engine v2 runs',
            'gartic_phone_fast':True,
            'gartic_engine_v2':True,
            'gartic_active_colors':turbo_meta.get('active_colors_after',0),
            'gartic_runs_before':turbo_meta.get('runs_before',0),
            'gartic_runs_after':turbo_meta.get('runs_after',0),
            'gartic_vertical_wins':turbo_meta.get('vertical_wins',0),
        })
    elif shape_enabled:
        execution_groups,path_meta=build_shape_execution_paths(
            groups, brush_px=int(options.get('brush_px',3) or 3),
            order=options.get('shape_order','Fill first'),
            stroke_cap=options.get('max_stroke_cap','Auto'),
            shape_model=options.get('shape_model','Auto'),
            preview=is_preview_plan(options), cancelled=cancelled)
    else:
        execution_groups=build_execution_paths(groups,enabled=smart_enabled,
                                                 portrait_edge_count=edge_count,cancelled=cancelled)
        path_meta=continuous_path_stats(groups,execution_groups)
    profiler_stop(options, 'shape_extraction', _prof_shape)

    _prof_paths = profiler_start(options, 'path_optimization')
    if execution_groups is not None:
        if pixel_prebuilt is not None:
            # Geometry and component order were already optimized inside
            # PixelStrokeEngine. Keep every path; only attach target metadata so
            # logs stay compatible with the legacy planner.
            path_meta.update({
                'target_before_paths':sum(len(g) for g in execution_groups),
                'target_after_paths':sum(len(g) for g in execution_groups),
                'target_skipped_paths':0,
                'target_cap_applied':False,
            })
        else:
            target_cap = options.get('target_stroke_count_resolved')
            execution_groups, target_meta = apply_target_path_cap(execution_groups, target_cap, prioritize_structure=bool(options.get('real_speed_structure_priority')))
            if path_meta.get('path_phase_hints'):
                # Target-cap can remove paths after ShapePaths has produced phase hints.
                # Rebuild hints heuristically later if their shape no longer matches.
                pass
            if target_meta.get('target_skipped_paths'):
                path_meta = dict(path_meta)
                path_meta.update(target_meta)
                path_meta['execution_paths'] = target_meta['target_after_paths']
                path_meta['joined_strokes'] = max(0, int(path_meta.get('source_strokes', 0)) - int(path_meta['execution_paths']))
                raw = int(path_meta.get('source_strokes', 0) or 0)
                path_meta['compression_ratio'] = 0.0 if raw <= 0 else max(0.0, min(1.0, 1.0 - int(path_meta['execution_paths']) / raw))
            else:
                path_meta = dict(path_meta)
                path_meta.update(target_meta)

            # v1.0.37: optimize final execution paths during planning so preview,
            # estimates and real execution all use exactly the same path order.
            phase_hints = path_meta.get('path_phase_hints')
            try:
                optimized_groups, optimized_hints, optimizer_meta = optimize_execution_groups(
                    execution_groups, mode=options.get('stroke_optimizer','Auto'),
                    drawing_mode=drawing_mode, speed=normalize_speed(options.get('speed','Balanced')),
                    phase_hints=phase_hints, cancelled=cancelled)
                execution_groups = optimized_groups
                path_meta.update(optimizer_meta)
                path_meta['execution_paths'] = sum(len(g) for g in execution_groups)
                raw = int(path_meta.get('source_strokes', 0) or 0)
                path_meta['joined_strokes'] = max(0, raw - int(path_meta['execution_paths']))
                path_meta['compression_ratio'] = 0.0 if raw <= 0 else max(0.0, min(1.0, 1.0-int(path_meta['execution_paths'])/raw))
                if optimized_hints is not None and any(optimized_hints):
                    path_meta['path_phase_hints'] = optimized_hints
            except ValueError:
                path_meta.update({'stroke_optimizer_effective':'Off','optimizer_error':'invalid setting'})

    execution_sequence=[]
    if execution_groups is not None:
        pixel_sequence=options.get('_pixel_execution_sequence') if pixel_prebuilt is not None else None
        if pixel_sequence is not None:
            execution_sequence=[dict(entry) for entry in pixel_sequence]
            stroke_meta=dict(options.get('pixel_stroke_meta') or {})
            path_meta.update({
                'progressive_enabled':True,
                'progressive_sequence_paths':len(execution_sequence),
                'progressive_fill_paths':int(stroke_meta.get('fill_paths',0) or 0),
                'progressive_mid_detail_paths':int(stroke_meta.get('mid_detail_paths',0) or 0),
                'progressive_fine_detail_paths':int(stroke_meta.get('fine_detail_paths',0) or 0),
                'progressive_cleanup_paths':int(stroke_meta.get('cleanup_paths',0) or 0),
                'progressive_phase_order':('fill -> mid detail -> fine detail -> cleanup' +
                    ''.join(f" -> correction {i}" for i in range(1,int((options.get('pixel_accuracy_meta') or {}).get('correction_passes_accepted',0) or 0)+1))),
                'progressive_mode':'On',
                'color_workflow':'Progressive passes',
            })
        else:
            progressive_mode=options.get('progressive_rendering','Auto')
            color_workflow=options.get('color_workflow','Finish color first')
            enabled=(color_workflow=='Progressive passes' and progressive_enabled(progressive_mode, drawing_mode=drawing_mode, time_budget_active=bool(options.get('time_budget_active'))))
            phase_hints=path_meta.get('path_phase_hints')
            try:
                if phase_hints and sum(len(x) for x in phase_hints)==sum(len(x) for x in execution_groups):
                    hint_arg=phase_hints
                else:
                    hint_arg=None
                execution_sequence,progressive_meta=build_progressive_sequence(execution_groups, phase_hints=hint_arg, enabled=enabled)
                path_meta.update(progressive_meta)
                path_meta['progressive_mode']=progressive_mode
                path_meta['color_workflow']=color_workflow
                if color_workflow=='Finish color first':path_meta['progressive_suppressed_by_color_batching']=True
            except ValueError:
                path_meta.update({'progressive_enabled':False,'progressive_mode':progressive_mode})

    profiler_stop(options, 'path_optimization', _prof_paths)
    _prof_preview = profiler_start(options, 'preview_rendering')
    path_moves_total=0;dot_count=0
    precision=options.get('precision','High')
    speed_name=normalize_speed(options.get('speed','Balanced'))
    estimate_delivery=resolve_stroke_delivery(options, dry_run=bool(options.get('dry_run_sampled',False)))
    estimate_step_px=estimate_delivery.step_px
    preview_safety=None
    try:
        preview_safety=build_preview_safety_plan(image.size,fitted,groups,execution_groups,options,cancelled)
        options['preview_safety_meta']=preview_safety.as_dict()
        options['_preview_safety_groups']=preview_safety.groups
        draw_safe_paths(draw,preview_safety,fitted,size,palette_rgb,brush)
        for paths in preview_safety.groups:
            for path in paths:
                if len(path)==1:
                    dot_count+=1
                    continue
                for a,b in zip(path,path[1:]):
                    if a!=b:path_moves_total+=precision_path_count(a,b,precision,estimate_step_px)
    except InterruptedError:
        raise
    except Exception as error:
        # Preview Safety is a mirror/visualization layer.  A failure here must not
        # invalidate the final CanvasGuard path, so old unguarded preview drawing
        # remains a fallback and the warning is surfaced in plan metadata.
        log_event(f'Smart Preview Safety fallback: {error!r}')
        options['preview_safety_meta']={'active':False,'reason':str(error)}
        if execution_groups is not None:
            for index,paths in enumerate(execution_groups):
                if cancelled():raise InterruptedError()
                for path in paths:
                    if cancelled():raise InterruptedError()
                    mapped=[point(x,y) for x,y in path]
                    if len(mapped)==1:
                        x,y=mapped[0];radius=brush/2
                        draw.ellipse((x-radius,y-radius,x+radius,y+radius),fill=palette_rgb[index])
                        dot_count+=1
                        continue
                    draw.line([coord for p in mapped for coord in p],fill=palette_rgb[index],width=brush,joint='curve')
                    radius=brush/2
                    for x,y in (mapped[0],mapped[-1]):
                        draw.ellipse((x-radius,y-radius,x+radius,y+radius),fill=palette_rgb[index])
                    for (x1,y1),(x2,y2) in zip(path,path[1:]):
                        if (x1,y1)!=(x2,y2):
                            path_moves_total+=precision_path_count(execution_transform.point(x1,y1),execution_transform.point(x2,y2),precision,estimate_step_px)
        else:
            for index,strokes in enumerate(groups):
                if cancelled():
                    raise InterruptedError()
                for x1,y1,x2,y2 in strokes:
                    if cancelled():
                        raise InterruptedError()
                    p1,p2=point(x1,y1),point(x2,y2)
                    draw.line((*p1,*p2),fill=palette_rgb[index],width=brush)
                    radius=brush/2
                    for x,y in (p1,p2):draw.ellipse((x-radius,y-radius,x+radius,y+radius),fill=palette_rgb[index])
                    if x1==x2 and y1==y2:
                        dot_count+=1
                    else:
                        path_moves_total+=precision_path_count(execution_transform.point(x1,y1),execution_transform.point(x2,y2),precision,estimate_step_px)

    profiler_stop(options, 'preview_rendering', _prof_preview)
    _prof_estimate = profiler_start(options, 'execution_estimate')
    count=path_meta['execution_paths'];colors=sum(bool(g) for g in groups)
    motion=estimated_motion_seconds(path_moves_total,count,dot_count,options['delay'],speed_name)
    base_path_delay=phase_delay(options['delay'],speed_name,'path')
    if estimate_delivery.min_path_delay > base_path_delay:
        motion += path_moves_total * (estimate_delivery.min_path_delay-base_path_delay)
    motion += count * (estimate_delivery.press_settle+estimate_delivery.release_settle)
    # Palette and tool-control clicks keep conservative settle times even in Fast
    # mode; speed profiles accelerate drawing motion, not UI calibration clicks.
    palette_seconds=0.0 if options.get('paint_current_color') else colors*estimate_delivery.palette_click_delay
    fill_regions=options.get('fill_regions',[]) or []
    fill_seconds=(.85 if fill_meta.get('enabled') else 0.0) + len(fill_regions)*.48
    if options.get('extra_fast_meta'):
        fill_seconds=float(options['extra_fast_meta']['fill_estimated_seconds'])
    estimate=3+motion+palette_seconds+fill_seconds+count*.0015
    estimate += human_overhead_seconds(count, options.get('human_mode','Off'))
    profiler_stop(options, 'execution_estimate', _prof_estimate)
    _prof_preview = profiler_start(options, 'preview_rendering')
    try:
        from PreviewLayers import build_auxiliary_previews
        ui_previews=build_auxiliary_previews(image,size,groups,palette_rgb,point,brush,options,cancelled)
        # Color map represents the executed palette, not a second 20-colour quantization.
        ui_previews['color']=preview
        for _key,_option_key in (('coverage','_pixel_coverage_preview'),('accuracy_error','_pixel_error_preview')):
            _im=options.get(_option_key)
            if isinstance(_im,Image.Image):
                ui_previews[_key]=_im.resize(size,Image.Resampling.NEAREST)
        if preview_safety is not None:
            ui_previews['safety']=render_preview_safety_map(image,size,preview_safety,palette_rgb,brush,cancelled)
            ui_previews['safety_debug']=render_safety_debug_overlay(size,preview_safety,palette_rgb,brush,cancelled)
    except InterruptedError:
        raise
    except Exception as error:
        # Auxiliary maps are UI-only. A preview-map failure must never invalidate
        # a drawing plan or stop the safe CPU/GPU drawing pipeline.
        log_event(f'Auxiliary preview maps skipped: {error!r}')
        ui_previews={'color':preview}
    profiler_stop(options, 'preview_rendering', _prof_preview)
    performance_profile = profiler_finalize(options)
    return {'image':image,'fitted':fitted,'groups':groups,'execution_groups':execution_groups,'execution_sequence':execution_sequence,
            'preview':preview,'ui_previews':ui_previews,'count':count,'source_count':path_meta['source_strokes'],
            'path_stats':path_meta,'estimate':estimate,'options':options,'colors':palette_rgb,'color_selectors':tuple(options.get('color_selectors') or ()), 'performance_profile':performance_profile}


def make_test_plan(area,options):
    from PIL import Image
    if options.get('paint_current_color'):
        return finish_plan(Image.new('RGBA',(80,60)),(min(area[0],180),min(area[1],135)),[[(10,20,65,20)]],options)
    groups=[[] for c in allColors]
    if options.get('outline'):
        from SketchPlanner import black_index
        groups[black_index(tuple(c.RGB for c in allColors))]=[(10,20,65,20)]
    else:
        for row,index in enumerate(range(min(3,len(allColors)))):groups[index]=[(10,10+row*20,65,10+row*20)]
    return finish_plan(Image.new('RGBA',(80,60)),(min(area[0],180),min(area[1],135)),groups,options)


def execute_plan(plan, area, palette, mouse, stop, paused, report, clock=time.monotonic, dry_run=False, keyboard=None, checkpoint=None):
    """Only this function produces mouse input. Pause is at a stroke boundary.

    When dry_run=True the same path is simulated with cursor moves only.
    No native click, press or release call is made.
    """
    # Real drawing uses a hard deadline from function entry. Fast Dry run is
    # different: its 12-second budget applies only to the actual cursor
    # simulation after target activation/countdown, not to preflight/setup time.
    deadline_box=[None if dry_run or plan['options'].get('unlimited_time') else clock()+plan['options'].get('max_seconds',180)]
    if not dry_run and not plan['options'].get('unlimited_time') and plan['options'].get('gartic_timer_deadline') is not None:
        deadline_box[0]=min(deadline_box[0],float(plan['options']['gartic_timer_deadline']))
    done=0
    speed_measure_started=None
    speed_measure_completed=False
    def wait(seconds):
        deadline=deadline_box[0]
        if deadline is not None and clock()>=deadline:
            if dry_run:
                raise DryRunBudgetComplete('Dry run time budget completed normally.')
            raise InterruptedError('Time limit reached. Drawing stopped; check the result in the target application.')
        timeout=max(0.0,float(seconds))
        if deadline is not None:
            timeout=min(timeout,max(0.0,deadline-clock()))
        if stop.wait(timeout):
            raise InterruptedError()
        if deadline is not None and clock()>=deadline:
            if dry_run:
                raise DryRunBudgetComplete('Dry run time budget completed normally.')
            raise InterruptedError('Time limit reached. No automatic restart.')
    exact_color_samples={}
    color_session_cache=plan['options'].setdefault('color_session_cache',{})
    from AdaptiveColor import method_candidates,method_label,rgb_key,probe_item,confidence_text
    from RenderResume import (resolve_resume, checkpoint_after_batch, checkpoint_before_path,
                              checkpoint_after_path, items_fingerprint)
    resume_info=resolve_resume(plan,(plan.get('options') or {}).get('render_resume_state'))
    resume_completed=int(resume_info.get('completed_count',0)) if resume_info.get('compatible') else 0
    resume_path_level=bool(resume_info.get('compatible') and resume_info.get('path_level'))
    resume_skip_prelude=bool(resume_info.get('compatible') and resume_info.get('prelude_complete'))
    if resume_info.get('compatible') and (resume_completed or resume_path_level):
        if resume_path_level:
            report('status',f'Render resume verified: {resume_completed}/{resume_info.get("total_colors",0)} colors complete · color {resume_info.get("active_color_number")} resumes at path {int(resume_info.get("next_path_index",0))+1}/{resume_info.get("active_path_count",0)} after normal browser recalibration/preflight.')
        else:
            report('status',f'Render resume verified: {resume_completed}/{resume_info.get("total_colors",0)} colors already completed. Continuing from color {resume_completed+1}.')
    elif (plan.get('options') or {}).get('render_resume_state') and not dry_run:
        report('status',f'Render resume checkpoint was not compatible with this final plan ({resume_info.get("reason","changed plan")}). Starting safely from color 1.')

    def select(index, method=None):
        """Select one planned color and return the method actually used."""
        if plan['options'].get('paint_current_color'):return 'current-tool'
        if stop.is_set():raise InterruptedError()
        selectors=plan.get('color_selectors') or ()
        selector=selectors[index] if index < len(selectors) else {'kind':'palette','palette_index':index}
        if selector.get('kind')!='custom':
            palette_index=int(selector.get('palette_index',index))
            mouse.move(*palette[palette_index]); wait(max(delay,.025))
            if dry_run:
                report('status','Dry run: palette move simulated. No click was sent.');wait(max(delay,.05));return 'palette'
            mouse.click(); wait(max(delay,stroke_delivery.palette_click_delay));return 'palette'

        rgb=tuple(map(int,selector.get('rgb',(0,0,0))))
        actions=plan['options'].get('exact_color_actions') or {}
        fallback=int(selector.get('fallback_palette_index',0))
        numeric_required=('RedField','GreenField','BlueField')
        spectrum_required=('SpectrumTopLeft','SpectrumBottomRight')
        base_required=('OpenCustomColor','ConfirmColor')
        numeric_ready=all(name in actions for name in base_required+numeric_required) and keyboard is not None
        spectrum_ready=all(name in actions for name in base_required+spectrum_required)
        cache=color_session_cache.get(rgb_key(rgb),{}) if isinstance(color_session_cache,dict) else {}
        if method is None:
            cached_sample=cache.get('sample') if isinstance(cache,dict) else None
            candidates=method_candidates(selector,actions,has_sample=(rgb in exact_color_samples or bool(cached_sample)),
                                          keyboard_available=keyboard is not None,cached_method=cache.get('method'))
            method=candidates[0] if candidates else 'palette'

        def nearest_palette(reason=''):
            if not dry_run and hasattr(mouse,'reset_tracking'):mouse.reset_tracking()
            mouse.move(*palette[fallback]);wait(max(delay,.025))
            if not dry_run:mouse.click();wait(max(delay,stroke_delivery.palette_click_delay))
            else:wait(max(delay,.05))
            suffix=f' ({reason})' if reason else ''
            report('status',f'Nearest calibrated palette fallback selected for RGB {rgb}{suffix}.')
            return 'palette'

        if method=='palette':
            return nearest_palette('adaptive color fallback')

        if method=='eyedropper':
            sample=exact_color_samples.get(rgb) or (tuple(cache.get('sample')) if isinstance(cache,dict) and cache.get('sample') else None)
            if sample is None or 'Eyedropper' not in actions:
                return nearest_palette('eyedropper sample unavailable')
            if dry_run:
                mouse.move(*actions['Eyedropper']);wait(.04);mouse.move(*sample);wait(.04)
                report('status',f'Dry run: eyedropper reuse of exact RGB {rgb} simulated. No clicks were sent.');return 'eyedropper'
            mouse.move(*actions['Eyedropper']);wait(.04);mouse.click();wait(.18)
            mouse.move(*sample);wait(.04);mouse.click();wait(.20)
            for _kind,_position in plan['options'].get('tool_actions',[]):
                mouse.move(*_position);wait(.03);mouse.click();wait(.16)
            report('status',f'Exact RGB {rgb} re-selected with calibrated eyedropper.');return 'eyedropper'

        if not all(name in actions for name in base_required):
            return nearest_palette('custom-color controls incomplete')

        if dry_run:
            mouse.move(*actions['OpenCustomColor']);wait(max(delay,.03))
            if method=='spectrum' and spectrum_ready:
                for name in spectrum_required:mouse.move(*actions[name]);wait(max(delay,.03))
                if 'BrightnessTop' in actions and 'BrightnessBottom' in actions:
                    mouse.move(*actions['BrightnessTop']);wait(.03);mouse.move(*actions['BrightnessBottom']);wait(.03)
                mouse.move(*actions['ConfirmColor']);wait(.03)
                report('status',f'Dry run: Smart custom palette for RGB {rgb} simulated. No clicks or typing were sent.');return 'spectrum'
            if method=='numeric' and numeric_ready:
                for name in numeric_required:mouse.move(*actions[name]);wait(max(delay,.03))
                mouse.move(*actions['ConfirmColor']);wait(.03)
                report('status',f'Dry run: exact numeric RGB {rgb} controls simulated. No clicks or typing were sent.');return 'numeric'
            return nearest_palette('requested exact method unavailable')

        try:
            mouse.move(*actions['OpenCustomColor']);wait(.04);mouse.click();wait(.30)
            if method=='spectrum' and spectrum_ready and hasattr(mouse,'calibrated_modal_nearest_color_rect'):
                spectrum_point,seen,error=mouse.calibrated_modal_nearest_color_rect(
                    actions['SpectrumTopLeft'],actions['SpectrumBottomRight'],rgb)
                mouse.calibrated_modal_click(spectrum_point);wait(.16)
                slider_used=False
                if ('BrightnessTop' in actions and 'BrightnessBottom' in actions and
                        hasattr(mouse,'calibrated_modal_nearest_color_line')):
                    slider_point,_slider_seen,_slider_error=mouse.calibrated_modal_nearest_color_line(
                        actions['BrightnessTop'],actions['BrightnessBottom'],rgb)
                    mouse.calibrated_modal_click(slider_point);wait(.16);slider_used=True
                    spectrum_point,seen,error=mouse.calibrated_modal_nearest_color_rect(
                        actions['SpectrumTopLeft'],actions['SpectrumBottomRight'],rgb)
                    mouse.calibrated_modal_click(spectrum_point);wait(.14)
                preview_error=None;preview_rgb=None
                if 'SelectedColorPreview' in actions and hasattr(mouse,'calibrated_modal_color'):
                    preview_rgb=mouse.calibrated_modal_color(actions['SelectedColorPreview'])
                    preview_error=max(abs(int(preview_rgb[i])-rgb[i]) for i in range(3))
                accepted_error=preview_error if preview_error is not None else error
                mouse.calibrated_modal_click(actions['ConfirmColor']);wait(.32)
                if hasattr(mouse,'reset_tracking'):mouse.reset_tracking()
                detail=f'preview {preview_rgb}' if preview_rgb is not None else f'nearest visible {seen}'
                report('status',f'Smart custom palette selected RGB {rgb} ({detail}, estimated error {accepted_error:.1f}'+(' + brightness scale' if slider_used else '')+'). Canvas verification follows.')
                return 'spectrum'

            if method=='numeric' and numeric_ready:
                for name,value in zip(numeric_required,rgb):
                    if hasattr(mouse,'calibrated_modal_click'):mouse.calibrated_modal_click(actions[name])
                    else:mouse.move(*actions[name]);mouse.click()
                    wait(.05);keyboard.press_and_release('ctrl+a');wait(.02);keyboard.write(str(value),delay=.01);wait(.04)
                if hasattr(mouse,'calibrated_modal_click'):mouse.calibrated_modal_click(actions['ConfirmColor'])
                else:mouse.move(*actions['ConfirmColor']);mouse.click()
                wait(.32)
                if hasattr(mouse,'reset_tracking'):mouse.reset_tracking()
                report('status',f'Exact numeric RGB {rgb} selected. Canvas verification follows.');return 'numeric'

            if keyboard is not None:
                try:keyboard.press_and_release('esc');wait(.12)
                except Exception:pass
            if hasattr(mouse,'reset_tracking'):mouse.reset_tracking()
            return nearest_palette(f'{method_label(method)} unavailable')
        except InterruptedError:
            raise
        except Exception as error:
            if keyboard is not None:
                try:keyboard.press_and_release('esc');wait(.12)
                except Exception:pass
            if hasattr(mouse,'reset_tracking'):mouse.reset_tracking()
            return nearest_palette(f'{method_label(method)} error: {error}')

    delay = plan['options']['delay']
    speed_name=normalize_speed(plan['options'].get('speed','Balanced'))
    speed_cfg=speed_profile(speed_name)
    travel_delay=phase_delay(delay,speed_name,'travel')
    path_delay=phase_delay(delay,speed_name,'path')
    boundary_delay=phase_delay(delay,speed_name,'boundary')
    stroke_delivery=resolve_stroke_delivery(plan.get('options') or {}, dry_run=dry_run)
    stroke_step_px=stroke_delivery.step_px
    effective_path_delay=max(path_delay, stroke_delivery.min_path_delay)
    plan['options']['stroke_delivery_meta']=stroke_delivery.as_dict()
    # v1.0.78: browser canvases get per-stroke delivery confirmation.  The
    # verifier is read-only; a suspected miss can replay only the affected
    # stroke once with denser/slower input.  CanvasGuard remains authoritative.
    from StrokeDeliveryVerification import (
        StrokeDeliveryVerificationError, inspect_delivery as inspect_stroke_delivery,
        resolve_policy as resolve_delivery_verification, retry_parameters as delivery_retry_parameters)
    delivery_verify_policy=resolve_delivery_verification(plan.get('options') or {},dry_run=dry_run)
    delivery_verify_meta=plan['options'].setdefault('stroke_delivery_verification_meta',{
        'enabled':bool(delivery_verify_policy.enabled),'profile_key':delivery_verify_policy.profile_key,
        'retry_cap':int(delivery_verify_policy.retry_cap),'checked':0,'passed':0,'suspected':0,
        'retried':0,'recovered':0,'failed':0,'skipped':0})
    delivery_verify_meta.update({'enabled':bool(delivery_verify_policy.enabled),'profile_key':delivery_verify_policy.profile_key,
                                 'retry_cap':int(delivery_verify_policy.retry_cap)})
    progress_every=max(1,int(speed_cfg['progress_every']))
    width, height = plan['image'].size
    fw, fh = plan['fitted']
    left, top = area[0] + (area[2]-fw)/2, area[1] + (area[3]-fh)/2
    transform=CanvasTransform(width,height,(fw,fh),left,top)
    canvas_polygon=plan['options'].get('canvas_polygon') or plan['options'].get('canvas_safe_polygon')
    canvas_polygon_space=plan['options'].get('canvas_polygon_space') or plan['options'].get('canvas_coordinate_space')
    canvas_anchor_space=plan['options'].get('canvas_anchor_space') or canvas_polygon_space
    canvas_anchors=normalize_canvas_anchors(plan['options'].get('canvas_anchors') or (), area=area, coordinate_space=canvas_anchor_space)
    canvas_guard=CanvasGuard.from_area_or_polygon(area, polygon=canvas_polygon, coordinate_space=canvas_polygon_space,
                                                  brush_px=plan['options'].get('canvas_guard_brush_px',plan['options'].get('brush_px',3)), edge_margin_px=2, anchors=canvas_anchors,
                                                  confidence=float((plan['options'].get('canvas_anchor_meta') or {}).get('confidence',1.0)) if isinstance(plan['options'].get('canvas_anchor_meta'),dict) else 1.0)
    draw_mouse=FinalMouseGuard(mouse, canvas_guard)
    plan['options']['canvas_guard_meta']=canvas_guard.model.as_dict()
    plan['options'].setdefault('canvas_edge_verification', 'Auto')
    plan['options'].setdefault('canvas_edge_margin_px', 24)
    plan['options'].setdefault('canvas_edge_tolerance_px', 4)
    plan['options'].setdefault('canvas_edge_search_px', 24)
    runtime_edge_mode=resolve_edge_behavior(plan['options'].get('edge_behavior','Hard Clip'),
                                            profile_name=plan['options'].get('profile_name'),
                                            drawing_mode=plan['options'].get('drawing_mode'),
                                            outline=bool(plan['options'].get('outline')))
    runtime_safety=RuntimeSafetySession(
        dry_run=bool(dry_run),
        profile_name=str(plan['options'].get('profile_name') or ''),
        edge_behavior=runtime_edge_mode,
        planned_paths=int(plan.get('count') or 0),
    )

    def verify_canvas_edges_before_input():
        mode = str(plan['options'].get('canvas_edge_verification', 'Auto') or 'Auto').strip().lower()
        if mode in ('off', 'disabled', 'false', '0'):
            plan['options']['canvas_edge_meta'] = {'ok': True, 'active': False, 'reason': 'disabled'}
            return
        try:
            if hasattr(mouse, 'snapshot_canvas_with_margin'):
                capture = mouse.snapshot_canvas_with_margin(area, margin=plan['options'].get('canvas_edge_margin_px', 24))
            else:
                plan['options']['canvas_edge_meta'] = {'ok': True, 'active': False, 'reason': 'expanded snapshot unavailable'}
                report('status', 'Edge verification skipped: expanded screenshot unavailable; Canvas Guard remains active.')
                return
            result = verify_canvas_edges_from_capture(
                capture,
                tolerance_px=plan['options'].get('canvas_edge_tolerance_px', 4),
                search_px=plan['options'].get('canvas_edge_search_px', 24),
            )
            meta = result.as_dict(); meta['active'] = True
            plan['options']['canvas_edge_meta'] = meta
            report('status', result.describe())
            if not result.ok:
                raise InterruptedError(result.stop_message())
        except InterruptedError:
            raise
        except Exception as error:
            # Read-only edge detection must not become a new crash source. When
            # the screenshot backend is unavailable, CanvasGuard/FinalMouseGuard
            # still enforce hard coordinate safety.
            plan['options']['canvas_edge_meta'] = {'ok': True, 'active': False, 'reason': str(error)}
            report('status', f'Edge verification fallback: {error}. Canvas Guard remains active.')

    transform_meta=plan['options'].get('canvas_anchor_transform_meta')
    if isinstance(transform_meta,dict) and transform_meta.get('method'):
        report('status', canvas_guard.describe() +
               f" · transform={transform_meta.get('method')} dx={transform_meta.get('dx',0)} dy={transform_meta.get('dy',0)} sx={transform_meta.get('sx',1)} sy={transform_meta.get('sy',1)}")
    else:
        report('status', canvas_guard.describe())
    def point(x, y):
        return canvas_guard.protect_point(transform.point(x,y), 'planned canvas coordinate')
    def click_ui_control(position, label, settle=None):
        if stop.is_set():raise InterruptedError()
        if settle is None: settle=stroke_delivery.ui_control_delay
        mouse.move(*position);wait(max(delay,.025))
        if dry_run:
            wait(max(settle,delay))
            report('status',f'Dry run: {label} target verified. No click was sent.')
            return
        mouse.click();wait(max(settle,delay))
        report('status',f'{label} selected. Preparing the first stroke…')
    def draw_segment(start,end):
        """Draw one exact segment for a safe fill perimeter."""
        start=draw_mouse.move_point(start, 'fill perimeter start');wait(max(travel_delay,.012))
        if start==end:
            if not dry_run:draw_mouse.click('fill perimeter dot')
            wait(max(boundary_delay,.008));return
        if dry_run:
            for path_point in precision_path(start,end,plan['options'].get('precision','High'),plan['options'].get('stroke_step_px',8)):
                draw_mouse.move_point(path_point, 'fill perimeter path');wait(max(path_delay,.004))
        else:
            try:
                draw_mouse.press('fill perimeter press')
                for path_point in precision_path(start,end,plan['options'].get('precision','High'),plan['options'].get('stroke_step_px',8)):
                    draw_mouse.move_point(path_point, 'fill perimeter path');wait(max(path_delay,.004))
            finally:
                draw_mouse.release()
        wait(max(boundary_delay,.008))
    def draw_closed_contour(points):
        """Draw a closed region perimeter with one continuous mouse-down gesture.

        Better Fill v1.0.41 uses the component's traced grid boundary instead of
        assuming an axis-aligned rectangle. Keeping the perimeter in one press
        avoids tiny gaps at corners that could let Paint's bucket leak outside.
        """
        pts=[tuple(map(float,p)) for p in points or ()]
        if len(pts)<2:return
        screen=[point(x,y) for x,y in pts]
        if screen[-1]!=screen[0]:screen.append(screen[0])
        screen[0]=draw_mouse.move_point(screen[0], 'closed fill contour start');wait(max(travel_delay,.012))
        if dry_run:
            for a,b in zip(screen,screen[1:]):
                for path_point in precision_path(a,b,plan['options'].get('precision','High'),plan['options'].get('stroke_step_px',8)):
                    draw_mouse.move_point(path_point, 'fill perimeter path');wait(max(path_delay,.004))
        else:
            try:
                draw_mouse.press('closed fill contour press')
                for a,b in zip(screen,screen[1:]):
                    for path_point in precision_path(a,b,plan['options'].get('precision','High'),plan['options'].get('stroke_step_px',8)):
                        draw_mouse.move_point(path_point, 'closed fill contour path');wait(max(path_delay,.004))
            finally:
                draw_mouse.release()
        wait(max(boundary_delay,.010))
    try:
        precision=plan['options'].get('precision','High')
        if hasattr(mouse,'configure_precision'):mouse.configure_precision(precision)
        if hasattr(mouse,'configure_drag_backend'):mouse.configure_drag_backend(stroke_delivery.drag_backend)
        if hasattr(mouse,'prepare_target'):mouse.prepare_target(stop,wait,report)
        verify_canvas_edges_before_input()
        mode_label='Dry run' if dry_run else 'Starting'
        for second in (3, 2, 1):
            report('status', f'{mode_label} in {second}… Switch to the drawing application. Esc stops.')
            wait(1)
        # Validate every palette point before the first native move/click. This
        # catches stale Paint layout calibration without drawing a wrong stroke.
        if hasattr(mouse,'verify_palette_layout'):mouse.verify_palette_layout()
        if (plan['options'].get('paint_profile') or stroke_delivery.profile_key in ('gartic-phone','skribbl','skribbl-fast','sketchheads')) and not dry_run:
            report('status',f'{stroke_delivery.label}: <= {stroke_delivery.step_px:.0f}px interpolation, {stroke_delivery.min_path_delay*1000:.2f}ms path floor, palette settle={stroke_delivery.palette_click_delay*1000:.0f}ms, backend={stroke_delivery.drag_backend}.')
        brush_plan=plan['options'].get('browser_brush_plan') or {}
        if brush_plan and not resume_skip_prelude:
            target=brush_plan.get('target_position')
            if target:
                target=tuple(map(int,target))
                selected=brush_plan.get('selected_index');wanted=int(brush_plan.get('target_index',0) or 0)
                if dry_run:
                    mouse.move(*target);wait(max(.02,stroke_delivery.ui_control_delay*.45))
                    report('status',f"Dry run: automatic browser brush target {brush_plan.get('effective_px','?')} px verified. No click was sent.")
                elif selected==wanted and float(brush_plan.get('confidence',0) or 0)>=.72:
                    report('status',f"Automatic brush size verified: {brush_plan.get('effective_px','?')} px is already selected.")
                else:
                    try:
                        from BrowserBrushSize import capture_control_patch,patch_change_score
                        before=capture_control_patch(target)
                    except Exception:
                        before=None
                    mouse.move(*target);wait(max(.02,stroke_delivery.ui_control_delay*.35));mouse.click();wait(stroke_delivery.ui_control_delay)
                    try:
                        after=capture_control_patch(target)
                        change=patch_change_score(before,after) if before is not None else 0.0
                    except Exception:
                        change=0.0
                    verified=bool(change>=.35 or selected is not None)
                    plan['options']['browser_brush_runtime']={'clicked':True,'verified':verified,'visual_change_percent':round(change,3),'effective_px':brush_plan.get('effective_px')}
                    if verified:
                        report('status',f"Automatic brush size applied and visually verified: ~{brush_plan.get('effective_px','?')} px.")
                    else:
                        report('status',f"Automatic brush control accepted the safe target, but selection highlight could not be visually confirmed. Using {brush_plan.get('safe_guard_px','?')} px CanvasGuard fallback.")
            else:
                report('status',f"Automatic brush-size detection was not confident enough to click. Safe CanvasGuard fallback={brush_plan.get('safe_guard_px','?')} px; current browser brush is left untouched.")
        if dry_run:
            # The bounded timer starts here so the user gets the advertised full
            # cursor-simulation window; target activation and the 3-second
            # countdown do not consume the route-validation budget.
            deadline_box[0]=clock()+float(plan['options'].get('max_seconds',DRY_RUN_EXECUTION_SECONDS))
            report('status',f'Dry run cursor simulation started. Up to {float(plan["options"].get("max_seconds",DRY_RUN_EXECUTION_SECONDS)):.0f}s; reaching this budget is a normal PASS, not an error.')
        # Tool selection is performed only after the explicit Start/Test action,
        # after the target window is active and the guarded mouse is armed.
        labels={'tool':'Paint tool','brush-menu':'Brushes menu','brush-preset':'Brush preset','opacity':'100% brush opacity',
                'fill':'Fill tool','brush':'Brush tool','eraser':'Eraser tool'}
        fill_meta=plan['options'].get('background_fill_plan') or {}
        if fill_meta.get('enabled') and plan['options'].get('fill_tool_actions') and not resume_skip_prelude:
            runtime_safety.note_fill('background_fill_planned')
            bg_index=int(fill_meta['color_index'])
            # Choose color first, then the Fill tool. Some browser drawing apps
            # switch back to the brush when a color swatch is clicked.
            select(bg_index)
            for kind,position in plan['options'].get('fill_tool_actions',[]):
                click_ui_control(position,labels.get(kind,'Fill tool'),.24)
            seed=fill_meta.get('seed_pixel',(1,1));seed_point=transform.point(int(seed[0]),int(seed[1]))
            if not canvas_guard.safe.contains_safe(seed_point):
                raise InterruptedError('Safe Fill Mask stopped Background Fill before clicking because the seed is outside the brush-inset safe canvas.')
            seed_point=draw_mouse.move_point(seed_point, 'background fill seed');wait(max(travel_delay,.03))
            if not dry_run:
                draw_mouse.click('background fill click');runtime_safety.note_fill('background_fill_clicks');wait(max(.34,delay))
                try:
                    if hasattr(mouse,'verify_fill'):
                        mouse.verify_fill(seed_point,plan['colors'][bg_index])
                    elif hasattr(mouse,'verify_ink'):
                        mouse.verify_ink(seed_point,plan['colors'][bg_index])
                except InterruptedError as error:
                    raise InterruptedError(f'Background Fill did not render the expected color. {error}') from error
                report('status',f"Background filled first ({fill_meta.get('image_coverage',0)*100:.0f}% source coverage). Restoring the drawing tool…")
            else:
                runtime_safety.note_fill('background_fill_simulated')
                wait(max(.12,delay));report('status','Dry run: background Fill seed verified. No click was sent.')
            for kind,position in plan['options'].get('fill_restore_actions',[]):
                settle=.28 if kind in ('brush-menu','brush-preset') else (.20 if kind in ('tool','brush') else .22)
                click_ui_control(position,labels.get(kind,'Drawing tool'),settle)
        else:
            for kind,position in plan['options'].get('tool_actions',[]):
                settle=.28 if kind in ('brush-menu','brush-preset') else (.20 if kind=='tool' else .22)
                click_ui_control(position,labels.get(kind,'Paint control'),settle)
        # v1.0.41 Better Fill: accepted interior components may be irregular,
        # hole-free closed regions. Snapshot guard pixels *before* drawing the
        # perimeter, draw the traced contour continuously, bucket-fill the safe
        # interior seed, then verify both fill color and outside guards. Any
        # component rejected by planning remains as normal scanline strokes.
        fill_regions=plan['options'].get('fill_regions',[]) or []
        if fill_regions and plan['options'].get('fill_tool_actions') and not resume_skip_prelude:
            runtime_fill_mask=filter_fill_regions_by_runtime_mask(fill_regions,(width,height),transform,canvas_guard)
            plan['options']['runtime_safe_fill_mask_meta']=runtime_fill_mask.as_dict()
            if runtime_fill_mask.rejected_regions:
                raise InterruptedError('Safe Fill Mask stopped Better Fill before clicking because a planned fill seed, span or contour was outside the brush-inset safe canvas.')
            fill_regions=list(runtime_fill_mask.accepted_regions)
            runtime_safety.note_fill('better_fill_regions', len(fill_regions))
            by_color={}
            for region in fill_regions:
                try:by_color.setdefault(int(region['color_index']),[]).append(region)
                except (KeyError,TypeError,ValueError):continue
            for region_color,items in by_color.items():
                select(region_color)
                guarded=[]
                for region in items:
                    x0,y0,x1,y1=map(int,region['bbox'])
                    probes=[]
                    for raw in region.get('guard_pixels',()) or ():
                        try:
                            sx,sy=map(int,raw)
                            if 0<=sx<width and 0<=sy<height:probes.append(point(sx,sy))
                        except (TypeError,ValueError):pass
                    if not probes:
                        cx,cy=(x0+x1)//2,(y0+y1)//2
                        for sx,sy in ((x0-2,cy),(x1+2,cy),(cx,y0-2),(cx,y1+2)):
                            if 0<=sx<width and 0<=sy<height:probes.append(point(sx,sy))
                    before=mouse.snapshot_colors(probes) if probes and hasattr(mouse,'snapshot_colors') else None
                    contour=region.get('contour') or ()
                    if contour:
                        draw_closed_contour(contour)
                    else:
                        # Legacy v1.0.7 plans remain compatible.
                        corners=[point(x0,y0),point(x1,y0),point(x1,y1),point(x0,y1)]
                        for a,b in zip(corners,corners[1:]+corners[:1]):draw_segment(a,b)
                    guarded.append((region,probes,before))
                for kind,position in plan['options'].get('fill_tool_actions',[]):
                    click_ui_control(position,labels.get(kind,'Fill tool'),.22)
                for region,probes,before in guarded:
                    seed=region.get('seed_pixel',(1,1));seed_point=point(int(seed[0]),int(seed[1]))
                    draw_mouse.move_point(seed_point, 'better fill seed');wait(max(travel_delay,.02))
                    expected=plan['colors'][region_color]
                    if dry_run:
                        runtime_safety.note_fill('better_fill_simulated')
                        wait(max(.08,delay))
                    else:
                        draw_mouse.click('better fill click');runtime_safety.note_fill('better_fill_clicks');wait(max(.24,delay))
                        if hasattr(mouse,'verify_fill'):mouse.verify_fill(seed_point,expected)
                        if probes and before is not None and hasattr(mouse,'verify_unchanged'):
                            try:mouse.verify_unchanged(probes,before)
                            except InterruptedError as error:
                                raise InterruptedError('Better Fill detected color outside the protected region. The fill was stopped to prevent a canvas flood.') from error
                for kind,position in plan['options'].get('fill_restore_actions',[]):
                    settle=.28 if kind in ('brush-menu','brush-preset') else (.20 if kind in ('tool','brush') else .22)
                    click_ui_control(position,labels.get(kind,'Drawing tool'),settle)
                strategies={str(r.get('strategy','rectangle')) for r in items}
                report('status',f'Better Fill completed {len(items)} safe region(s) for one grouped color ({", ".join(sorted(strategies))}). Continuing with detail strokes…')
        done = 0
        speed_measure_started=clock()
        human_mode=plan['options'].get('human_mode','Off')
        human_seed=stable_seed(plan['groups'],human_mode)
        cadence=HumanCadence(human_mode,human_seed)
        verified_colors=set()
        visual_mode=plan['options'].get('visual_verification_resolved') or resolve_visual_verification(
            plan['options'].get('visual_verification','Off'),
            paint_profile=bool(plan['options'].get('visual_verification_enabled',False)),
            dry_run=dry_run,test=False)
        visual_previous_snapshot=None
        edge_mode=runtime_edge_mode
        plan['options']['edge_behavior_resolved']=edge_mode
        plan['options'].setdefault('edge_behavior_meta',{'active':True,'mode':edge_mode,'hard_clip':0,'hard_skip':0,'adaptive_boundary':0,'preserve_outline_boundary':0,'safe_skip':0})

        def pause_guard():
            while paused.is_set():
                if not dry_run:mouse.release()
                if hasattr(mouse,'reset_tracking'):mouse.reset_tracking()
                report('status', 'Paused. The mouse is free. Press F6 or Resume to continue.')
                while paused.is_set():
                    wait(.05)
                for second in (3, 2, 1):
                    report('status', f'Resuming in {second}… Switch to the drawing application.')
                    wait(1)
                return True
            return False

        def draw_path_item(index,item,smart_group=True,verify_color=True,verification_mode='strict',count_progress=True):
            nonlocal done
            if stop.is_set():
                raise InterruptedError()
            pause_guard()
            if smart_group:
                source_points=list(item)
                raw_canvas_points=[transform.point(x,y) for x,y in source_points]
            else:
                stroke=item
                source_points=[stroke[:2],stroke[2:]]
                raw_canvas_points=[transform.point(*stroke[:2]),transform.point(*stroke[2:])]
            try:
                edge_result=apply_edge_behavior(canvas_guard, raw_canvas_points, behavior=edge_mode,
                                                profile_name=plan['options'].get('profile_name'),
                                                drawing_mode=plan['options'].get('drawing_mode'),
                                                outline=bool(plan['options'].get('outline')),
                                                context='normal stroke')
            except CanvasSafetyStop as error:
                runtime_safety.note_blocked(error, reason='CanvasGuard blocked a planned stroke outside the selected canvas polygon.')
                raise
            runtime_safety.note_edge_result(edge_result, raw_canvas_points)
            edge_meta=plan['options'].setdefault('edge_behavior_meta',{'active':True,'mode':edge_mode})
            edge_meta['mode']=edge_mode
            edge_meta[edge_result.strategy]=int(edge_meta.get(edge_result.strategy,0))+1
            edge_meta['last']=edge_result.as_dict()
            clipped_subpaths=edge_result.subpaths
            if not clipped_subpaths:
                if count_progress:
                    done += 1
                    if done % progress_every == 0 or done == plan['count']:
                        report('progress', (done, plan['count']))
                return {'matched': True, 'skipped': True, 'reason': 'outside safe canvas'}
            canvas_points=[p for path in clipped_subpaths for p in path]
            drawn_pairs=[(a,b) for path in clipped_subpaths for a,b in zip(path,path[1:]) if a!=b]
            start=clipped_subpaths[0][0];end=clipped_subpaths[-1][-1]

            # Longest actually drawable segment is the most useful read-only
            # delivery probe. Short dots are deliberately excluded because a
            # one-pixel sample cannot distinguish a missed event reliably.
            delivery_start,delivery_end=start,end
            if drawn_pairs:
                delivery_start,delivery_end=max(drawn_pairs,key=lambda pair:(pair[1][0]-pair[0][0])**2+(pair[1][1]-pair[0][1])**2)

            def deliver_current_stroke(*, retry=False):
                retry_cfg=(delivery_retry_parameters(delivery_verify_policy,stroke_step_px,effective_path_delay) if retry else None)
                step_px=(retry_cfg['step_px'] if retry_cfg else stroke_step_px)
                if plan['options'].get('pixel_accurate'):
                    # Smaller detail brushes need denser mouse interpolation on
                    # browser canvases; otherwise a fast move can visibly skip
                    # pixels even when the planner geometry is exact.
                    step_px=min(float(step_px),max(1.0,float(current_execution_brush)*1.5))
                path_delay_now=(retry_cfg['path_delay'] if retry_cfg else effective_path_delay)
                press_settle_now=(retry_cfg['press_settle'] if retry_cfg else stroke_delivery.press_settle)
                release_settle_now=(retry_cfg['release_settle'] if retry_cfg else stroke_delivery.release_settle)
                for subpath_index,subpath in enumerate(clipped_subpaths):
                    sub_start=draw_mouse.move_point(subpath[0], 'stroke clipped retry start' if retry else 'stroke clipped start'); wait(cadence.movement_delay(travel_delay,0,1))
                    if len(subpath)==1 or all(p==sub_start for p in subpath[1:]):
                        if not dry_run:draw_mouse.click('stroke clipped retry dot' if retry else 'stroke clipped dot')
                        continue
                    if dry_run:
                        for segment_index,(segment_start,segment_end) in enumerate(zip(subpath,subpath[1:])):
                            if segment_start==segment_end:continue
                            path_points=precision_path(segment_start,segment_end,precision,step_px)
                            for path_index,path_point in enumerate(path_points):
                                draw_mouse.move_point(path_point, 'stroke clipped path');wait(max(stroke_delivery.min_path_delay, cadence.movement_delay(path_delay_now,path_index,len(path_points))))
                    else:
                        try:
                            draw_mouse.press('stroke clipped retry press' if retry else 'stroke clipped press')
                            if press_settle_now:wait(press_settle_now)
                            for segment_index,(segment_start,segment_end) in enumerate(zip(subpath,subpath[1:])):
                                if segment_start==segment_end:continue
                                path_points=precision_path(segment_start,segment_end,precision,step_px)
                                for path_index,path_point in enumerate(path_points):
                                    draw_mouse.move_point(path_point, 'stroke clipped retry path' if retry else 'stroke clipped path');wait(max(stroke_delivery.min_path_delay, cadence.movement_delay(path_delay_now,path_index,len(path_points))))
                        finally:
                            if release_settle_now:wait(release_settle_now)
                            draw_mouse.release()

            deliver_current_stroke(retry=False)
            wait(cadence.movement_delay(boundary_delay,0,1))

            # HTML5 canvas delivery can occasionally drop a mouse-down/move
            # sequence even though Windows accepted the cursor events. Confirm
            # the just-drawn stroke and retry only that path once when needed.
            if delivery_verify_policy.enabled and not dry_run:
                delivery_result=inspect_stroke_delivery(mouse,delivery_start,delivery_end,plan['colors'][index],
                                                       current_execution_brush,delivery_verify_policy)
                if delivery_result.get('checked'):
                    delivery_verify_meta['checked']=int(delivery_verify_meta.get('checked',0))+1
                    if delivery_result.get('matched'):
                        delivery_verify_meta['passed']=int(delivery_verify_meta.get('passed',0))+1
                    else:
                        delivery_verify_meta['suspected']=int(delivery_verify_meta.get('suspected',0))+1
                        recovered=False
                        for retry_no in range(1,int(delivery_verify_policy.retry_cap)+1):
                            delivery_verify_meta['retried']=int(delivery_verify_meta.get('retried',0))+1
                            report('status',f'Stroke delivery check: suspected missed/partial browser stroke. Retrying only this stroke ({retry_no}/{delivery_verify_policy.retry_cap}) with safer spacing.')
                            deliver_current_stroke(retry=True)
                            wait(delivery_verify_policy.verify_settle)
                            retry_result=inspect_stroke_delivery(mouse,delivery_start,delivery_end,plan['colors'][index],
                                                                plan['options'].get('brush_px',1),delivery_verify_policy)
                            if retry_result.get('matched'):
                                recovered=True
                                delivery_verify_meta['recovered']=int(delivery_verify_meta.get('recovered',0))+1
                                report('status','Stroke delivery check recovered the suspected browser stroke with one bounded retry.')
                                break
                            delivery_result=retry_result
                        if not recovered:
                            delivery_verify_meta['failed']=int(delivery_verify_meta.get('failed',0))+1
                            actual=tuple(delivery_result.get('actual') or ())
                            raise StrokeDeliveryVerificationError(
                                f'Stroke delivery verification failed after {delivery_verify_policy.retry_cap} retry. '
                                f'Expected RGB {tuple(plan["colors"][index])}; closest rendered RGB was {actual}. '
                                'The failed path was not marked complete, so Smart Recovery can resume from it safely.')
                else:
                    delivery_verify_meta['skipped']=int(delivery_verify_meta.get('skipped',0))+1

            verification=None
            if (not dry_run) and verify_color and not plan['options'].get('paint_current_color'):
                wait(.12)
                verify_start,verify_end=start,end
                if len(canvas_points)>2:
                    pairs=drawn_pairs
                    if pairs:
                        verify_start,verify_end=max(pairs,key=lambda pair:(pair[1][0]-pair[0][0])**2+(pair[1][1]-pair[0][1])**2)
                if verification_mode=='adaptive' and hasattr(mouse,'inspect_ink_segment'):
                    verification=mouse.inspect_ink_segment(verify_start,verify_end,plan['colors'][index],plan['options'].get('brush_px',1),
                                                           plan['options'].get('color_verification_tolerance',48))
                    if not verification.get('matched'):
                        return verification
                else:
                    try:
                        if hasattr(mouse,'verify_ink_segment'):
                            mouse.verify_ink_segment(verify_start,verify_end,plan['colors'][index],plan['options'].get('brush_px',1))
                        elif hasattr(mouse,'verify_ink'):
                            mouse.verify_ink(tuple(round((verify_start[i]+verify_end[i])/2) for i in (0,1)),plan['colors'][index])
                    except InterruptedError as error:
                        selected_tool=plan['options'].get('paint_tool','Use current tool')
                        speed_hint=(' Fast mode can outrun some drawing applications; retry Balanced or Safe if the tool calibration is correct.'
                                    if speed_name=='Fast' else '')
                        if selected_tool=='Use current tool':
                            raise InterruptedError(
                                f'{error} Draw Studio is set to Use current tool, so it cannot force Paint to use solid ink. '
                                'Choose Auto (recommended) or Pencil in Draw Studio, calibrate Pencil, then retry.'+speed_hint
                            ) from error
                        raise InterruptedError(
                            f'{error} Automatic Paint tool selection was enabled. Recalibrate Paint tools because the saved tool position may no longer match this Paint version or window layout.'+speed_hint
                        ) from error
                    verification={'matched':True,'expected':tuple(plan['colors'][index]),'actual':tuple(plan['colors'][index]),'error':0,'confidence':100.0,'sample_count':0}
                verified_colors.add(index)

            if not dry_run:
                selectors=plan.get('color_selectors') or ()
                if index < len(selectors) and selectors[index].get('kind')=='custom' and (verification is None or verification.get('matched')):
                    rgb=tuple(map(int,selectors[index].get('rgb',(0,0,0))))
                    if rgb not in exact_color_samples:
                        pairs=drawn_pairs
                        if pairs:
                            a,b=max(pairs,key=lambda pair:(pair[1][0]-pair[0][0])**2+(pair[1][1]-pair[0][1])**2)
                            exact_color_samples[rgb]=(round((a[0]+b[0])/2),round((a[1]+b[1])/2))
                        else:
                            exact_color_samples[rgb]=start
            if count_progress:
                done += 1
                natural_pause=cadence.boundary_pause(done)
                if natural_pause:wait(natural_pause)
                if done % progress_every == 0 or done == plan['count']:
                    report('progress', (done, plan['count']))
            return verification

        def verify_color_batch(index,item,smart_group,selected_method,color_number,total_colors):
            """Paint one tiny overwrite-safe probe and auto-recover selector errors."""
            if dry_run or plan['options'].get('paint_current_color') or not plan['options'].get('adaptive_color_verification',False):
                return selected_method
            probe=probe_item(item,smart_group,plan['options'].get('color_probe_source_span',4))
            selectors=plan.get('color_selectors') or ()
            selector=selectors[index] if index<len(selectors) else {'kind':'palette','palette_index':index}
            actions=plan['options'].get('exact_color_actions') or {}
            rgb=tuple(map(int,plan['colors'][index]))
            cache=color_session_cache.get(rgb_key(rgb),{}) if isinstance(color_session_cache,dict) else {}
            methods=method_candidates(selector,actions,has_sample=(rgb in exact_color_samples or bool(cache.get('sample'))),keyboard_available=keyboard is not None,cached_method=cache.get('method'))
            ordered=[]
            for candidate in (selected_method,)+tuple(methods):
                if candidate and candidate not in ordered:ordered.append(candidate)
            last=None
            for attempt,method in enumerate(ordered,1):
                actual_method=selected_method if attempt==1 else select(index,method)
                if attempt>1:
                    report('status',f'Color {color_number}/{total_colors} · RGB {rgb}: retry {attempt}/{len(ordered)} with {method_label(actual_method)}.')
                result=draw_path_item(index,probe,smart_group=smart_group,verify_color=True,verification_mode='adaptive',count_progress=False)
                last=result or {'matched':True,'actual':rgb,'error':0,'confidence':100.0}
                report('color_plan',{'current':color_number,'total':total_colors,'rgb':rgb,'method':method_label(actual_method),
                                     'confidence':float(last.get('confidence',0)),'actual':tuple(last.get('actual') or ()),'matched':bool(last.get('matched'))})
                if last.get('matched'):
                    verified_colors.add(index)
                    if isinstance(color_session_cache,dict):
                        color_session_cache[rgb_key(rgb)]={'method':actual_method,'confidence':float(last.get('confidence',0)),
                                                          'actual':tuple(last.get('actual') or ()),
                                                          'sample':tuple(exact_color_samples.get(rgb)) if rgb in exact_color_samples else None}
                    report('status',f'Color {color_number}/{total_colors} · RGB {rgb}: {method_label(actual_method)} verified at {confidence_text(last)}. Painting the full color batch now.')
                    return actual_method
                report('status',f'Color {color_number}/{total_colors} · RGB {rgb}: {method_label(actual_method)} rendered {tuple(last.get("actual") or ())} ({float(last.get("confidence",0)):.0f}% match). Trying the next safe color method.')
            selected_tool=plan['options'].get('paint_tool','Use current tool')
            actual=tuple((last or {}).get('actual') or ())
            confidence=float((last or {}).get('confidence',0))
            raise InterruptedError(
                f'Stopped on color batch {color_number}/{total_colors}: RGB {rgb} could not be verified after adaptive recovery. '
                f'Closest rendered RGB was {actual} ({confidence:.0f}% match). Previously completed color batches remain painted. '
                + ('Use Auto/Pencil and recalibrate Paint tools, then retry this drawing.' if selected_tool!='Use current tool' else 'Select a solid Paint Pencil/Brush and retry.'))

        def visual_verify_color_batch(index, ordered_items, smart_group, color_number, total_colors):
            nonlocal visual_previous_snapshot
            if dry_run or not plan['options'].get('visual_verification_enabled',False) or visual_mode=='Off':
                return None
            if not hasattr(mouse,'snapshot_canvas'):
                return {'current':color_number,'total':total_colors,'ok':True,'confidence':0.0,'summary':'snapshot unavailable on this mouse backend'}
            sample_limit={'Fast':80,'Balanced':130,'Strict':180}.get(visual_mode,130)
            brush_px=plan['options'].get('brush_px',1)
            expected=plan['colors'][index]
            planned_points=planned_batch_points(ordered_items,smart_group=smart_group,transform=point,sample_limit=sample_limit)
            expected_boxes=planned_batch_boxes(ordered_items,smart_group=smart_group,transform=point,brush_px=brush_px)
            wait(.08)
            current=mouse.snapshot_canvas(area)
            result=compare_batch_snapshot(current,visual_previous_snapshot,area,expected,planned_points,expected_boxes,brush_px=brush_px,mode=visual_mode)
            visual_previous_snapshot=current
            summary=summarize_result(result)
            payload=dict(result);payload.update({'current':color_number,'total':total_colors,'rgb':tuple(map(int,expected)),'summary':summary})
            if not result.get('ok'):
                report('visual_verification',payload)
                raise InterruptedError(
                    f'Visual verification stopped after color batch {color_number}/{total_colors}. {summary}. '
                    'The canvas may have a wrong color, missed region, leaked fill or misplaced stroke. '
                    'Previously completed render checkpoint data remains available; inspect the canvas before resuming.')
            return payload

        def checkpoint_recoverable_path(error, *, color_number, path_index, ordered_items):
            """Persist only the first not-completed path for a transient browser stop."""
            if dry_run or checkpoint is None:
                return False
            try:
                from SmartRecovery import classify_interruption
                decision=classify_interruption(error,str(plan['options'].get('profile_key') or ''))
            except Exception:
                return False
            plan['options']['smart_recovery_last_decision']=decision.as_dict()
            if not decision.recoverable:
                return False
            progress=checkpoint_before_path(plan,color_number,path_index,len(ordered_items),ordered_items=ordered_items,prelude_complete=True)
            checkpoint(progress)
            plan['options']['smart_recovery_checkpoint']=progress
            report('status',
                   f'Smart Recovery saved color {color_number}/{progress.get("total_colors",0)} · next safe path {path_index+1}/{len(ordered_items)}. '
                   'No automatic mouse restart will occur. Press Start again; browser Auto-Recalibration + Visual Preflight will run before resuming.')
            return True

        current_execution_brush=max(1,int(plan['options'].get('brush_px',1) or 1))
        def switch_execution_brush(wanted_px):
            """Switch only between read-only verified browser brush controls."""
            nonlocal current_execution_brush
            wanted=max(1,int(wanted_px or current_execution_brush))
            if wanted==current_execution_brush:return False
            brush_plan=plan['options'].get('browser_brush_plan') or {}
            try:
                positions=[tuple(map(int,p)) for p in (brush_plan.get('control_positions') or ())]
                sizes=[max(1,int(v)) for v in (brush_plan.get('nominal_sizes') or ())]
                confidence=float(brush_plan.get('confidence',0) or 0)
            except (TypeError,ValueError):
                return False
            if not brush_plan.get('target_position') or confidence<.58 or len(positions)!=len(sizes) or not sizes:
                return False
            index=min(range(len(sizes)),key=lambda i:abs(sizes[i]-wanted))
            effective=int(sizes[index]);position=positions[index]
            # AdaptiveBrushEngine never assigns larger-than-preflight widths, but
            # keep the runtime guard explicit in case a stale/custom plan reaches execution.
            if effective>max(1,int(plan['options'].get('canvas_guard_brush_px',current_execution_brush) or current_execution_brush)):
                return False
            mouse.move(*position);wait(max(.025,stroke_delivery.ui_control_delay*.45))
            if not dry_run:
                mouse.click();wait(max(.10,stroke_delivery.ui_control_delay))
            current_execution_brush=effective
            plan['options'].setdefault('adaptive_brush_runtime_meta',{'switches':0,'sizes':[]})
            runtime_meta=plan['options']['adaptive_brush_runtime_meta']
            runtime_meta['switches']=int(runtime_meta.get('switches',0))+1
            if effective not in runtime_meta.setdefault('sizes',[]):runtime_meta['sizes'].append(effective)
            report('status',f'Adaptive brush: {effective}px selected for the current detail pass.')
            return True

        execution_sequence=plan.get('execution_sequence') or []
        if execution_sequence:
            if plan['options'].get('visual_verification_enabled',False) and visual_mode!='Off' and not dry_run:
                report('visual_verification',{'current':0,'total':0,'ok':True,'confidence':0.0,'summary':'skipped for progressive passes'})
            current_color=None
            current_phase=None
            phases_present=[]
            for _entry in execution_sequence:
                _phase=str(_entry.get('phase','details'))
                if _phase not in phases_present:phases_present.append(_phase)
            pixel_four_pass=any(p in phases_present for p in ('fill','mid_detail','fine_detail','cleanup'))
            if pixel_four_pass:
                base_phases=['fill','mid_detail','fine_detail','cleanup']
                correction_phases=[p for p in phases_present if p.startswith('correction_')]
                ordered_phases=base_phases+correction_phases
                phase_numbers={p:i+1 for i,p in enumerate(ordered_phases)}
                phase_names={'fill':'large fills','mid_detail':'mid detail','fine_detail':'fine detail','cleanup':'protected cleanup'}
                for p in correction_phases:
                    try:n=int(p.rsplit('_',1)[1])
                    except (ValueError,IndexError):n=1
                    phase_names[p]=f'accuracy correction {n}'
                phase_total=len(ordered_phases)
            else:
                phase_numbers={'foundation':1,'contour':2,'details':3}
                phase_names={'foundation':'large forms','contour':'important contours','details':'small details'}
                phase_total=3
            for entry in execution_sequence:
                if stop.is_set():
                    raise InterruptedError()
                try:
                    index=int(entry['color_index'])
                    item=tuple(entry['path'])
                except (KeyError,TypeError,ValueError):
                    continue
                phase=str(entry.get('phase','details'))
                entry_brush=max(1,int(entry.get('brush_px',current_execution_brush) or current_execution_brush))
                if switch_execution_brush(entry_brush):
                    current_color=None
                if phase!=current_phase:
                    current_phase=phase
                    number=phase_numbers.get(phase,phase_total)
                    report('status',f'Progressive pass {number}/{phase_total}: drawing {phase_names.get(phase,phase)} while preserving the PixelMap geometry.')
                    current_color=None
                if current_color!=index:
                    pause_guard()
                    selected_method=select(index); current_color=index
                    if index not in verified_colors and plan['options'].get('adaptive_color_verification',False):
                        selected_method=verify_color_batch(index,item,True,selected_method,1,1)
                draw_path_item(index,item,smart_group=True,verify_color=(index not in verified_colors and not plan['options'].get('adaptive_color_verification',False) and plan['options'].get('strict_color_verification',True)))
        else:
            color_order=plan['options'].get('color_order') or list(range(len(plan['groups'])))
            execution_groups=plan.get('execution_groups')
            active_order=[int(i) for i in color_order if 0<=int(i)<len(plan['groups']) and (plan['groups'][int(i)] or (execution_groups is not None and int(i)<len(execution_groups) and execution_groups[int(i)]))]
            if (not dry_run) and plan['options'].get('visual_verification_enabled',False) and visual_mode!='Off' and hasattr(mouse,'snapshot_canvas'):
                try:
                    visual_previous_snapshot=mouse.snapshot_canvas(area)
                    report('visual_verification',{'current':0,'total':len(active_order),'ok':True,'confidence':100.0,'summary':'baseline snapshot captured'})
                except Exception as error:
                    plan['options']['visual_verification_enabled']=False
                    report('visual_verification',{'current':0,'total':len(active_order),'ok':True,'confidence':0.0,'summary':f'visual baseline unavailable: {error}'})
            for color_number,index in enumerate(active_order,1):
                if color_number <= resume_completed:
                    try:rgb_done=tuple(map(int,plan['colors'][int(index)]))
                    except Exception:rgb_done=('?', '?', '?')
                    report('color_plan',{'current':color_number,'total':len(active_order),'rgb':rgb_done,'method':'checkpoint','confidence':100.0,'actual':rgb_done,'matched':True,'completed':True,'resumed':True})
                    continue
                if not (0<=int(index)<len(plan['groups'])):continue
                index=int(index);strokes=plan['groups'][index]
                paths=(execution_groups[index] if execution_groups is not None and index<len(execution_groups) else None)
                if paths is not None:
                    if not paths:continue
                    # Smart paths keep the exact same planned pixels but group safe,
                    # overlapping same-colour rows under one mouse-down.  Ordering is
                    # path-aware instead of feeding polylines to the legacy 4-point
                    # stroke optimizer.
                    if plan['options'].get('gartic_sketch_meta') or plan.get('path_stats',{}).get('stroke_optimizer_effective') not in (None,'Off'):
                        ordered_items=list(paths)
                    else:
                        ordered_items=order_paths(paths,speed_name,allow_reverse=True)
                    smart_group=True
                else:
                    if not strokes:continue
                    speed_ordered=optimize_strokes(strokes,speed_name,allow_reverse=True)
                    ordered_items=humanize_strokes(speed_ordered,human_mode,human_seed + index * 1009)
                    smart_group=False
                try:rgb_label=tuple(map(int,plan['colors'][index]))
                except Exception:rgb_label=('?', '?', '?')
                report('status',f'Color {color_number}/{len(active_order)} · RGB {rgb_label}: finishing {len(ordered_items):,} path(s) before switching to the next color.')
                selected = False
                selected_method=None
                if ordered_items:
                    pause_guard()
                    selected_method=select(index);selected=True
                    if index not in verified_colors and plan['options'].get('adaptive_color_verification',False):
                        selected_method=verify_color_batch(index,ordered_items[0],smart_group,selected_method,color_number,len(active_order))
                resume_path_start=0
                if resume_path_level and color_number==int(resume_info.get('active_color_number',0)):
                    expected_fp=str(resume_info.get('active_items_fingerprint') or '')
                    actual_fp=items_fingerprint(ordered_items)
                    expected_count=int(resume_info.get('active_path_count',0) or 0)
                    if expected_fp==actual_fp and expected_count==len(ordered_items):
                        resume_path_start=max(0,min(int(resume_info.get('next_path_index',0) or 0),len(ordered_items)))
                        if resume_path_start:
                            report('status',f'Smart Recovery: skipping {resume_path_start} already-completed path(s) in color {color_number}; resuming at path {resume_path_start+1}/{len(ordered_items)}.')
                    else:
                        report('status','Smart Recovery path ordering changed after replanning. No path-level skip was applied; restarting only the current color batch safely.')
                for path_index,item in enumerate(ordered_items):
                    if path_index < resume_path_start:
                        continue
                    if pause_guard():
                        selected = False
                    if not selected:
                        selected_method=select(index,selected_method); selected = True
                    try:
                        draw_path_item(index,item,smart_group=smart_group,verify_color=(index not in verified_colors and not plan['options'].get('adaptive_color_verification',False) and plan['options'].get('strict_color_verification',True)))
                    except BaseException as error:
                        checkpoint_recoverable_path(error,color_number=color_number,path_index=path_index,ordered_items=ordered_items)
                        raise
                    # A lightweight periodic path checkpoint also improves crash
                    # resilience without writing a file for every stroke.
                    if checkpoint is not None and not dry_run and (path_index+1)<len(ordered_items) and (path_index+1)%25==0:
                        try:
                            progress=checkpoint_after_path(plan,color_number,path_index,len(ordered_items),ordered_items=ordered_items,prelude_complete=True)
                            checkpoint(progress)
                        except Exception as checkpoint_error:
                            log_event(f'Path-level recovery checkpoint skipped: {checkpoint_error!r}')
                visual_result=visual_verify_color_batch(index,ordered_items,smart_group,color_number,len(active_order))
                report('color_plan',{'current':color_number,'total':len(active_order),'rgb':rgb_label,'method':method_label(selected_method),'confidence':100.0,'actual':rgb_label,'matched':True,'completed':True})
                if visual_result:
                    report('visual_verification',visual_result)
                if not dry_run and checkpoint is not None:
                    progress=checkpoint_after_batch(plan,color_number,prelude_complete=True)
                    checkpoint(progress)
        runtime_safety.mark_completed()
        speed_measure_completed=True
        if dry_run:
            report('status', f'Dry run finished: {done:,} planned cursor paths simulated. No clicks, presses or releases were sent.')
        else:
            report('status', f'Finished locally: {done:,} brush strokes sent. Also verify the final result in the target application.')
    except DryRunBudgetComplete:
        # Reaching the configured Fast Dry run budget is the expected end of a
        # bounded safety sample. It must not invalidate an otherwise clean run.
        runtime_safety.mark_completed()
        plan['options']['dry_run_budget_complete']=True
        report('status',f'Dry run PASS: time budget completed normally after {done:,} safe cursor path(s). No clicks, presses or releases were sent.')
    except BaseException as error:
        runtime_safety.mark_stopped(error)
        raise
    finally:
        runtime_payload=save_runtime_safety_report(runtime_safety)
        plan['options']['runtime_safety_report']=runtime_payload
        runtime_counts=runtime_payload.get('counts') or {}
        runtime_report_path=runtime_payload.get('text_path') or runtime_payload.get('json_path')
        runtime_report_name=Path(runtime_report_path).name if runtime_report_path else 'report save failed'
        log_event(
            f"Runtime safety report: drawn={int(runtime_counts.get('drawn',0))} clipped={int(runtime_counts.get('clipped',0))} "
            f"skipped={int(runtime_counts.get('skipped',0))} edge_follow={int(runtime_counts.get('edge_follow',0))} "
            f"blocked={int(runtime_counts.get('blocked',0))} stopped={int(runtime_counts.get('stopped',0))} file={runtime_report_name!r}.")
        if (not dry_run) and speed_measure_completed and speed_measure_started is not None:
            try:
                from RealSpeedBudget import record_runtime_sample
                elapsed=max(.001,clock()-speed_measure_started)
                speed_meta=record_runtime_sample(
                    str(plan['options'].get('profile_key') or ''),done,elapsed,
                    colors=sum(bool(g) for g in (plan.get('execution_groups') or plan.get('groups') or [])),
                    test_run=bool(plan['options'].get('test_run',False)))
                plan['options']['real_speed_runtime_meta']=speed_meta
                if speed_meta.get('recorded'):
                    log_event(f"Real-Speed sample saved: profile={speed_meta.get('profile_key')} paths={done} elapsed={elapsed:.3f}s pps={float(speed_meta.get('last_sample_pps',0)):.2f} learned={float(speed_meta.get('paths_per_second',0)):.2f}.")
            except Exception as speed_error:
                log_event(f'Real-Speed sample save skipped: {speed_error!r}')
        from StabilityRC import safe_release_and_disarm
        safe_release_and_disarm(mouse,dry_run=dry_run,logger=log_event)


class DrawBotApp:
    def __init__(self, root, mouse_backend=None, keyboard_backend=None):
        if mouse_backend is None:
            from WindowsMouse import WindowsMouse
            mouse_backend=WindowsMouse()
        if keyboard_backend is None:
            import keyboard as keyboard_backend
        self.root, self.mouse, self.keyboard = root, mouse_backend, keyboard_backend
        self.events = queue.Queue()
        self.stop, self.paused = threading.Event(), threading.Event()
        self.worker = None
        self.activity = None
        self.corners = []
        self.target_window = None
        self.target_client_rect = None
        self.target_dpi = None
        self.original = self.plan = None
        self.color_session_cache = {}
        self.pending_render_resume = None
        self.canvas_anchor_detection = None
        self.small_test_passed = False
        self.capture_job = None
        self.mouse_probe_process = None
        self.closing = False
        self.controls = []
        self.photos = []
        self.hotkeys = []
        self.preview_after = None
        # Preview rendering has its own debounce job. Keeping this separate from
        # preview generation prevents Canvas <Configure> storms from recursively
        # re-entering Tk while widgets are still laying themselves out.
        self.preview_render_after = None
        self.preview_rendering = False
        self.preview_dirty_reason = ''
        # Full drawing requires a separate safety-unlock button plus a
        # separate Start Drawing click. A single accidental click can never start
        # mouse movement. Test drawing remains one explicit action.
        self.full_draw_armed_until = 0.0
        self.draw_arm_after = None
        # Step 1 safety gate: full drawing requires a recent no-click preflight pass.
        self.safety_preflight_passed = False
        self.safety_preflight_signature = None
        self.safety_preflight_valid_until = 0.0
        # Step 5 safety gate: optional-to-run by button, required before full Start.
        # It reuses the final plan and target geometry but suppresses every click,
        # press and release so users can verify the route before real drawing.
        self.dry_run_passed = False
        self.dry_run_signature = None
        self.dry_run_valid_until = 0.0
        # Step 6 safety gate: after setup is known-good, lock target geometry and
        # calibration relative to the target client area.  Preflight, dry run and
        # real drawing must fail if the window, DPI, selected canvas or palette
        # layout changes after this point.
        self.target_lock_passed = False
        self.target_lock_fingerprint = None
        self.target_lock_signature = None
        self.profile_change_after = None
        self.profile_change_in_progress = False
        self.paint_config_after = None
        self.app_tool_window = None
        self.poll_after = None
        # Step 10 crash-safe local recovery. Checkpoints never persist armed safety state.
        self.recovery_checkpoint_after = None
        self.recovery_image_pending = False
        self.hotkeys_removed = False
        self.shutdown_complete = False
        self.needs_plan = False
        self.drop_action_pending = None
        # v1.0.67: Manual Drop-In Start is a one-shot user arm.  It lets
        # browser/game profiles start drawing after the next image import/drop,
        # but it is never persisted and it is disabled for Paint's strict chain.
        self.manual_drop_in_start = tk.BooleanVar(value=False)
        self.manual_drop_in_armed_until = 0.0
        self.manual_drop_in_after = None
        # v1.0.73: Drop-In requests may wait for read-only browser setup.
        # Nothing here is persisted. Latest image wins and target/profile changes
        # cancel the pending authorization before any native input is armed.
        self.pending_drop_in_import = None
        self.pending_drop_in_after = None
        self.drop_in_start_context = None
        self.drop_in_sync_phase = DROP_SYNC_IDLE
        self.browser_auto_calibration_success = False
        # v1.0.80: persistent-in-session browser One-Click authorization. It is
        # never enabled for Paint and does not bypass read-only setup/preflight.
        self.browser_one_click_enabled = tk.BooleanVar(value=True)
        self.browser_one_click_pending = False
        self.browser_one_click_source_label = ''
        self.browser_one_click_after = None
        # v1.0.69: Mobile Preview is opt-in and local-network only. The HTTP
        # server is not created/bound until the user explicitly starts it.
        self.mobile_preview_server = None
        root.title('Draw Studio')
        root.geometry('1040x740')
        root.minsize(900, 660)
        try:
            import customtkinter as ctk
            if isinstance(root,ctk.CTk):root.configure(fg_color='#edf2f5')
            else:root.configure(bg='#edf2f5')
        except (ImportError,AttributeError,tk.TclError):
            root.configure(bg='#edf2f5')
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('.', font=('Segoe UI', 10))
        style.configure('TFrame', background='#edf2f5')
        style.configure('TLabel', background='#edf2f5', foreground='#18303d')
        style.configure('TLabelframe', background='#edf2f5')
        style.configure('TLabelframe.Label', background='#edf2f5', foreground='#087e8b', font=('Segoe UI', 11, 'bold'))
        style.configure('TButton', padding=(10, 7))
        style.configure('Stop.TButton', background='#fbe9e7', foreground='#a52a21', padding=(18,10))
        style.configure('Muted.TLabel', foreground='#526771')
        style.configure('Accent.TButton', background='#087e8b', foreground='white', font=('Segoe UI', 11, 'bold'))
        style.map('Accent.TButton', background=[('active', '#096575'), ('disabled', '#a0b2bb')])
        from GameProfiles import load_custom_profiles
        load_custom_profiles(DATA_DIR/'profiles.json')
        self.game=tk.StringVar(value='Other drawing app')
        self.profile_hint=tk.StringVar()
        self.calibration_path=CALIBRATION_FILE
        self.settings_path=SETTINGS
        # Compatibility variable only. Window drops are import-only; direct
        # preview-canvas drops may one-shot start a ready non-Paint target.
        self.drop_mode=tk.StringVar(value='Show image')
        self.paint_simple=tk.BooleanVar(value=False)
        self.paint_tool=tk.StringVar(value='Auto (recommended)')
        self.guess_pattern=tk.StringVar()
        self.guess_length=tk.StringVar()
        self.guess_result=tk.StringVar(value='Enter a length or known letters.')
        from WordGuesser import DEFAULT_WORDS,load_words
        self.guess_words=DEFAULT_WORDS
        if (DATA_DIR/'guess-words.txt').exists():
            try:self.guess_words=load_words(DATA_DIR/'guess-words.txt')
            except (OSError,ValueError):pass
        self.word_source=tk.StringVar(value=f'{len(self.guess_words)} words · you can import a custom list')
        self.url = tk.StringVar()
        self.file_label = tk.StringVar(value='No image selected')
        self.drop_in_text = tk.StringVar(value='Drop-In Start is off. Arm it after target canvas and palette are ready.')
        self.quality = tk.StringVar(value='Balanced')
        self.speed = tk.StringVar(value='Balanced')
        self.precision = tk.StringVar(value='High')
        self.mode = tk.StringVar(value=SMART_PATH_MODE)
        self.shape_order = tk.StringVar(value='Fill first')
        self.shape_model = tk.StringVar(value='Auto')
        self.max_stroke_cap = tk.StringVar(value='Auto')
        self.progressive_rendering = tk.StringVar(value='Auto')
        self.planning_watchdog = tk.StringVar(value='Auto')
        self.time_budget_mode = tk.StringVar(value='Manual')
        self.target_stroke_count = tk.StringVar(value='Auto')
        self.target_stroke_custom = tk.StringVar(value='2500')
        self.render_preset = tk.StringVar(value='Auto')
        self.sketch_detail = tk.StringVar(value='Auto')
        self.read_gartic_timer = tk.BooleanVar(value=True)
        self.render_style = tk.StringVar(value='Auto')
        self.draw_quality = tk.StringVar(value='High likeness')
        self.human_mode = tk.StringVar(value='Off')
        self.gpu_mode = tk.StringVar(value='Auto')
        self.gpu_vram = tk.StringVar(value='Auto')
        self.gpu_performance = tk.StringVar(value='High throughput')
        self.cpu_workers = tk.StringVar(value='Auto')
        self.cpu_engine = tk.StringVar(value='Auto')
        self.ram_budget = tk.StringVar(value='Auto')
        self.ram_custom_mb = tk.StringVar(value='4096')
        self.planning_resolution = tk.StringVar(value='High')
        self.resource_scheduler = tk.StringVar(value='Auto')
        self.profile_engine = tk.StringVar(value='Auto')
        self.edge_behavior = tk.StringVar(value='Auto')
        self.background_fill = tk.StringVar(value='Balanced')
        self.fill_engine = tk.StringVar(value='Auto')
        self.background_simplification = tk.StringVar(value='Balanced')
        self.color_grouping = tk.StringVar(value='Smart')
        self.color_workflow = tk.StringVar(value='Finish color first')
        self.stroke_optimizer = tk.StringVar(value='Auto')
        self.adaptive_detail = tk.StringVar(value='Auto')
        self.visual_verification = tk.StringVar(value='Auto')
        self.color_rendering = tk.StringVar(value='Perceptual match')
        self.color_layers = tk.StringVar(value='Off')
        self.custom_color_workflow = tk.StringVar(value='Calibrated palette')
        self.exact_color_limit = tk.StringVar(value='Auto')
        self.exact_color_text = tk.StringVar(value='Smart custom palette is optional. If unavailable, nearest calibrated palette color is used.')
        self.color_plan_text = tk.StringVar(value='Color verification: waiting for drawing.')
        self.runtime_safety_summary = tk.StringVar(value='No runtime safety report yet. Run Fast Dry run or Start drawing.')
        self.runtime_safety_detail = tk.StringVar(value='Local-only safety reports are saved after each execution.')
        self.update_summary = tk.StringVar(value='Updates are checked only when you press Check for updates.')
        self.update_detail = tk.StringVar(value=f'Current: {APP_VERSION} · No background update checks or automatic downloads.')
        self.auto_tune_summary = tk.StringVar(value='Performance Auto Tuner has not been run on this machine yet.')
        self.auto_tune_detail = tk.StringVar(value='Local benchmark only. No mouse input, telemetry or network access.')
        self.mobile_preview_status = tk.StringVar(value='Mobile Preview is off · local network only.')
        self.mobile_preview_url = tk.StringVar(value='')
        self.latest_release_url = 'https://github.com/yesverynice12/Draw-Studio/releases'
        self.preview_mode = tk.StringVar(value='Manual')
        self.tool_strategy = tk.StringVar(value='Auto')
        self.app_tool_text = tk.StringVar(value='Optional app tools are not calibrated.')
        self.browser_auto_text = tk.StringVar(value='Browser Auto Setup is waiting for a supported game profile and target canvas.')
        self.browser_one_click_text = tk.StringVar(value='One-Click: choose a supported browser game and add an image. Canvas, palette, brush and preflight run automatically.')
        self.subject_focus = tk.StringVar(value='Off')
        self.subject_region = None
        self.subject_hint = tk.StringVar(value='Auto: simple background or transparent PNG. Mark busy photos.')
        self.portrait_focus = tk.BooleanVar(value=True)
        self.skip_white = tk.BooleanVar(value=True)
        self.contrast = tk.DoubleVar(value=1.0)
        self.outline = tk.BooleanVar(value=False)
        self.brush_px = tk.StringVar(value='3')
        self.max_seconds = tk.StringVar(value='180')
        self.area_text = tk.StringVar(value='Drawing area not selected')
        self.palette_text = tk.StringVar(value='Colors need calibration')
        self.paint_tool_text = tk.StringVar(value='Paint tool auto-selection not calibrated')
        self.target_lock_text = tk.StringVar(value='Setup is not locked yet')
        self.status = tk.StringVar(value='Start by selecting an image in step 1.')
        # Replace Tkinter's default callback exception printer. In a recursion
        # failure the default traceback formatter can itself recurse and escape
        # mainloop; keeping reporting bounded leaves the GUI alive and logs it.
        root.report_callback_exception=self.report_tk_callback_exception
        self.summary = tk.StringVar(value='Press Build preview when you want a preview. Start Drawing always builds the final plan manually.')
        self.next_step=tk.StringVar(value='1. Select an image to begin.')
        self.palette_ready=False
        self.saved_area = None
        self.read_settings()
        from StudioUI import build_ui
        build_ui(self,QUALITY,SPEED)
        self.refresh_runtime_safety_ui()
        self.refresh_auto_tuner_ui()
        self.profile_hint.set(PROFILES[self.game.get()][2])
        try:
            self.hotkeys.append(self.keyboard.add_hotkey('esc',self.stop.set))
            self.hotkeys.append(self.keyboard.add_hotkey('f6',lambda:self.events.put(('toggle_pause',None))))
        except Exception as error:
            self.status.set(f'Global hotkeys are unavailable: {error}. Use the buttons in the window.')
        root.bind('<Control-v>',self.paste_shortcut)
        if hasattr(root,'drop_target_register'):
            try:
                from tkinterdnd2 import DND_FILES
                # Dropping on the window imports only. Dropping directly on any
                # preview canvas is a stronger user gesture: when the selected
                # non-Paint target is already safe/ready, it becomes a one-shot
                # Drop-In start. Supported browser profiles continue through
                # Browser One-Click setup/preflight before mouse input.
                root.drop_target_register(DND_FILES)
                root.dnd_bind('<<Drop>>',lambda event:self.drop_image(event,drop_to_draw=False))
                canvas_targets=tuple(
                    target for target in (
                        getattr(self,'original_canvas',None),getattr(self,'result_canvas',None),
                        getattr(self,'safety_canvas',None),getattr(self,'safety_debug_canvas',None),
                        getattr(self,'stroke_canvas',None),getattr(self,'fill_canvas',None),
                        getattr(self,'color_canvas',None)) if target is not None)
                for target in canvas_targets:
                    target.drop_target_register(DND_FILES)
                    target.dnd_bind('<<Drop>>',lambda event:self.drop_image(event,drop_to_draw=True))
                    target.dnd_bind('<<DropEnter>>',lambda event,target=target:(target.configure(bg='#254237'),'copy')[1])
                    target.dnd_bind('<<DropLeave>>',lambda event,target=target:(target.configure(bg='#131a25'),'copy')[1])
            except (ImportError,RuntimeError,tk.TclError) as error:
                log_event(f'Drag and drop unavailable: {error!r}')
                self.status.set('Drag and drop could not be enabled. Use Select image or Ctrl+V.')
        root.protocol('WM_DELETE_WINDOW',self.close)
        self.refresh_palette()
        self.refresh_tool_calibration()
        self.refresh_app_tool_calibration()
        self.set_busy(None)
        DrawBotApp._schedule_poll(self)
        unclean = previous_run_unclean()
        if unclean:
            # Recovery is offered before crash reporting so two modal dialogs cannot overlap.
            root.after(900, self.offer_safe_session_recovery)
        else:
            try:
                from ReleaseState import should_show_welcome
                if should_show_welcome():
                    root.after(650, self.show_welcome)
            except Exception as error:
                log_event(f'First-run welcome state ignored: {error!r}')

    def _recovery_option_snapshot(self):
        """Return only primitive configuration values; never safety/arming state."""
        names=(
            'quality','speed','precision','mode','shape_order','shape_model','max_stroke_cap',
            'progressive_rendering','planning_watchdog','time_budget_mode','target_stroke_count',
            'target_stroke_custom','render_style','draw_quality','human_mode','gpu_mode','gpu_vram',
            'gpu_performance','cpu_workers','cpu_engine','ram_budget','ram_custom_mb','planning_resolution','resource_scheduler',
            'background_fill','fill_engine','background_simplification','color_grouping','color_workflow','stroke_optimizer','adaptive_detail','visual_verification','color_rendering','color_layers','profile_engine','edge_behavior',
            'custom_color_workflow','exact_color_limit','tool_strategy','portrait_focus','skip_white','contrast','outline',
            'brush_px','max_seconds','paint_simple','paint_tool','sketch_detail','read_gartic_timer','render_preset')
        out={}
        for name in names:
            var=getattr(self,name,None)
            getter=getattr(var,'get',None)
            if not getter:continue
            try:value=getter()
            except Exception:continue
            if isinstance(value,bool) or type(value) in (int,float) or isinstance(value,str):out[name]=value
        # Preview mode is intentionally not checkpointed: recovery always returns to Manual.
        return out

    def _save_recovery_checkpoint(self, *, include_image=False):
        if self.closing or self.shutdown_complete or getattr(self,'_suppress_recovery',False):return
        try:
            from SessionRecovery import save_snapshot
            profile=self.game.get() if hasattr(self,'game') else ''
            area=self.saved_area or (self.corners if len(self.corners)==2 else None)
            image=self.original if include_image else None
            target_lock=getattr(self,'target_lock_fingerprint',None) if getattr(self,'target_lock_passed',False) else None
            save_snapshot(profile=profile,options=DrawBotApp._recovery_option_snapshot(self),saved_area=area,image=image,clear_render_resume=bool(include_image),target_lock=target_lock)
            log_event(f'Recovery checkpoint saved. image_cached={bool(include_image and self.original is not None)} target_lock_hint={bool(target_lock)}.')
        except Exception as error:
            log_event(f'Recovery checkpoint skipped: {error!r}')

    def _schedule_recovery_checkpoint(self, *, include_image=False, delay=250):
        if self.closing or self.shutdown_complete:return
        self.recovery_image_pending=bool(getattr(self,'recovery_image_pending',False) or include_image)
        DrawBotApp._cancel_after_attr(self,'recovery_checkpoint_after')
        for _after_name in ('browser_one_click_after','pending_drop_in_after','manual_drop_in_after','draw_arm_after','preview_after','preview_render_after','profile_change_after','paint_config_after','capture_job'):
            DrawBotApp._cancel_after_attr(self,_after_name)
        def run():
            self.recovery_checkpoint_after=None
            with_image=bool(self.recovery_image_pending);self.recovery_image_pending=False
            DrawBotApp._save_recovery_checkpoint(self,include_image=with_image)
        try:self.recovery_checkpoint_after=self.root.after(max(20,int(delay)),run)
        except (tk.TclError,RuntimeError,AttributeError):self.recovery_checkpoint_after=None

    def _clear_render_resume(self, reason='setup changed'):
        self.pending_render_resume=None
        try:
            from SessionRecovery import clear_render_progress
            clear_render_progress()
        except Exception as error:
            log_event(f'Render resume clear skipped: {error!r}')
        try:self.color_plan_text.set('Color verification: waiting for drawing.')
        except (tk.TclError,AttributeError):pass
        log_event(f'Render resume checkpoint cleared: {reason}.')

    def _apply_recovery_snapshot(self, state):
        """Restore local work only; every input safety gate remains reset/disarmed."""
        from SessionRecovery import load_cached_image
        profile=str(state.get('profile') or '')
        if profile in PROFILES and profile!=self.game.get():
            self.game.set(profile)
            self._apply_profile_change(profile)
        options=state.get('options') if isinstance(state,dict) else {}
        if isinstance(options,dict):
            for name,value in options.items():
                if name=='preview_mode':continue
                var=getattr(self,name,None);setter=getattr(var,'set',None)
                if setter:
                    try:setter(value)
                    except (tk.TclError,TypeError,ValueError):pass
        # Manual preview is a hard recovery invariant.
        self.preview_mode.set('Manual')
        area=state.get('saved_area') if isinstance(state,dict) else None
        self.saved_area=[tuple(map(int,p)) for p in area] if isinstance(area,list) and len(area)==2 else None
        image=load_cached_image()
        if image is not None:
            self.original=image;self.plan=None;self.file_label.set('Recovered local image')
        resume=state.get('render_resume') if isinstance(state,dict) else None
        self.pending_render_resume=resume if isinstance(resume,dict) else None
        if self.pending_render_resume:
            completed=int(self.pending_render_resume.get('completed_count',0));total=int(self.pending_render_resume.get('total_colors',0))
            if self.pending_render_resume.get('path_level'):
                color_no=int(self.pending_render_resume.get('active_color_number',completed+1) or completed+1)
                path_no=int(self.pending_render_resume.get('next_path_index',0) or 0)+1
                path_total=int(self.pending_render_resume.get('active_path_count',0) or 0)
                self.color_plan_text.set(f'Smart Recovery: {completed}/{total} colors complete · color {color_no} path {path_no}/{path_total} pending · DISARMED')
            else:
                self.color_plan_text.set(f'Render resume: {completed}/{total} colors completed · next color {completed+1 if completed < total else "done"} · DISARMED')
        # Never restore a live target or any passed/armed gate.
        self.corners=[];self.target_window=None;self.target_client_rect=None;self.target_dpi=None
        self.small_test_passed=False
        self.target_lock_passed=False;self.target_lock_fingerprint=None;self.target_lock_signature=None
        self.safety_preflight_passed=False;self.safety_preflight_signature=None;self.safety_preflight_valid_until=0.0
        self.dry_run_passed=False;self.dry_run_signature=None;self.dry_run_valid_until=0.0
        DrawBotApp._disarm_full_draw(self,'safe session recovery',update_text=True)
        try:
            if hasattr(self.mouse,'disarm_input'):self.mouse.disarm_input()
        except OSError:pass
        DrawBotApp._refresh_target_lock_text(self)
        self.area_text.set('Recovered area is only a suggestion. Re-select or explicitly reuse it, then run the full safety chain.')
        self._mark_plan_stale('Safe session recovered. Preview is Manual. Re-select target and rerun Small test → Lock setup → Preflight → Dry run before Start.')
        self.show_previews();self.set_busy(None)
        if self.pending_render_resume:
            completed=int(self.pending_render_resume.get('completed_count',0));total=int(self.pending_render_resume.get('total_colors',0))
            self.status.set(f'Safe session recovered DISARMED · {completed}/{total} colors completed. Rebuild the same setup and safety chain to continue from color {completed+1}.')
        else:
            self.status.set('Safe session recovered DISARMED. No target lock, preflight, dry run or drawing authorization was restored.')
        log_event('Safe session recovery applied. All native input gates reset/disarmed.')

    def offer_safe_session_recovery(self):
        if self.closing or self.activity:return
        try:
            from SessionRecovery import load_snapshot,clear_snapshot
            state=load_snapshot()
        except Exception as error:
            log_event(f'Recovery snapshot could not be read: {error!r}');state=None
        if state:
            text=('Draw Studio did not close normally and a local recovery checkpoint is available.\n\n'
                  'Recover the image/settings from the checkpoint? Drawing will remain completely DISARMED: target lock, small test, preflight, dry run and Start authorization are never restored.')
            if messagebox.askyesno('Safe session recovery',text,parent=self.root):
                try:DrawBotApp._apply_recovery_snapshot(self,state)
                except Exception as error:
                    log_event(f'Safe session recovery failed: {error!r}')
                    messagebox.showerror('Recovery failed',f'The safe session could not be restored: {error}',parent=self.root)
            else:
                clear_snapshot();log_event('User declined safe session recovery; local checkpoint cleared.')
        if previous_run_unclean():
            self.status.set('Previous session ended unexpectedly. Recovery/logs remain local; no data is sent anywhere.')

    def clear_image(self):
        DrawBotApp._request_clear_drawing(self,True)

    def clear_cached_drawing(self):
        DrawBotApp._request_clear_drawing(self,False)

    def _request_clear_drawing(self,remove_image):
        if self.closing:return
        previous=getattr(self,'pending_clear_drawing',None)
        self.pending_clear_drawing=bool(remove_image or previous)
        if previous is None:self._clear_worker=getattr(self,'worker',None)
        self._suppress_recovery=True
        self.cancel()
        for name in ('preview_after','preview_render_after','recovery_checkpoint_after','paint_config_after'):
            DrawBotApp._cancel_after_attr(self,name)
        self.status.set('Stopping the previous operation and clearing its cached drawing…')
        DrawBotApp._finish_clear_drawing(self)

    def _finish_clear_drawing(self):
        if self.closing or getattr(self,'pending_clear_drawing',None) is None:return
        worker=getattr(self,'_clear_worker',None)
        if self.activity or (worker is not None and worker.is_alive()):
            self.root.after(50,lambda:DrawBotApp._finish_clear_drawing(self));return
        remove_image=getattr(self,'pending_clear_drawing',False)
        self.plan=None;self.pending_render_resume=None;self.needs_plan=False
        self.upscale_original=None;self.small_test_passed=False
        self.color_session_cache.clear()
        if remove_image:
            self.original=None;self.subject_region=None
            self.file_label.set('No image loaded');self.url.set('')
        error=None
        try:
            from SessionRecovery import clear_snapshot,STATE_FILE,RENDER_FILE,IMAGE_FILE
            clear_snapshot()
            if any(path.exists() for path in (STATE_FILE,RENDER_FILE,IMAGE_FILE)):
                raise OSError('Some recovery files could not be deleted.')
        except Exception as exc:error=str(exc)
        self.pending_clear_drawing=None;self._clear_worker=None
        self.progress['value']=0;self.set_busy(None)
        self.summary.set('Image cleared. Add a new image.' if remove_image else 'Cached drawing cleared. Build a new preview or start again.')
        self.status.set(('Local cache could not be fully cleared: '+error) if error else ('Image and cached drawing cleared.' if remove_image else 'Cached drawing cleared; source image kept.'))
        self.show_previews();self._sync_mobile_preview()
        try:self.root.deiconify()
        except tk.TclError:pass

    def auto_setup_gartic_full(self):
        if self.activity or self.closing:return
        if self.game.get()!='Gartic Phone':
            self.status.set('Choose Gartic Phone for full automatic setup.');return
        self.cancel() # disarm any pending automatic start; setup never draws
        profile=self.game.get();path=Path(self.calibration_path)
        self.browser_auto_calibration_success=False
        def work():
            import os
            from BrowserOneClick import discover_browser_target
            from BrowserAutoCalibration import auto_calibrate_browser
            candidate=discover_browser_target('gartic-phone',exclude_pid=os.getpid())
            if self.stop.is_set():raise InterruptedError()
            meta={'handle':candidate.handle,'rect':candidate.rect,'client_rect':candidate.client_rect,'dpi':candidate.dpi}
            result=auto_calibrate_browser('gartic-phone',meta,path,screenshot=candidate.screenshot)
            from LayoutFingerprintV2 import record_from_calibration_file
            fingerprint=record_from_calibration_file('gartic-phone',meta,result.canvas_box,path,method='Full Gartic grid setup')
            payload=result.as_dict();payload.update(target_meta=meta,profile_name=profile,layout_fingerprint_meta=fingerprint)
            self.events.put(('browser_auto_calibration_complete',payload))
        self.begin_worker('browser-auto-calibration',work)

    def clear_recovery_snapshot(self):
        if self.activity:
            self.status.set('Stop the current operation before clearing recovery data.');return
        try:
            from SessionRecovery import clear_snapshot
            clear_snapshot();self.status.set('Local safe-recovery checkpoint cleared.')
            log_event('Recovery checkpoint cleared by user.')
        except Exception as error:self.status.set(f'Could not clear recovery checkpoint: {error}')

    def report_tk_callback_exception(self,exc_type,value,tb):
        import traceback
        try:
            if issubclass(exc_type,RecursionError):
                detail=f'{exc_type.__name__}: {value}'
            else:
                detail=''.join(traceback.format_exception(exc_type,value,tb,limit=30))
        except Exception:
            detail=f'{getattr(exc_type,"__name__",exc_type)}: {value}'
        log_event(f'Tk callback exception (contained)\n{detail}')
        # Do not synchronously mutate traced Tk variables from inside Tk's own
        # exception callback. That was another path into the recursion loop.
        try:
            self.root.after(25, lambda: self.status.set(f'UI error contained: {value}. See DrawStudio-session.log.') if not self.closing else None)
        except (tk.TclError,AttributeError,RuntimeError):
            pass

    def button(self,parent,text,command,**kwargs):
        button=ttk.Button(parent,text=text,command=command,**kwargs)
        self.controls.append((button,'normal'))
        return button

    def _cancel_after_attr(self, name):
        """Cancel a stored Tk after token without letting shutdown races escape."""
        token=getattr(self,name,None)
        if token is None:
            return False
        setattr(self,name,None)
        try:
            self.root.after_cancel(token)
            return True
        except (tk.TclError,ValueError,RuntimeError,AttributeError):
            return False

    def _schedule_poll(self):
        if getattr(self,'shutdown_complete',False):
            return
        DrawBotApp._cancel_after_attr(self,'poll_after')
        try:
            self.poll_after=self.root.after(50,self.poll)
        except (tk.TclError,RuntimeError,AttributeError):
            self.poll_after=None

    @staticmethod
    def _safe_widget_configure(widget, **kwargs):
        try:
            widget.configure(**kwargs)
            return True
        except (tk.TclError,RuntimeError,AttributeError):
            return False

    def _paint_tool_preflight_ready(self):
        """Cheap UI-only readiness check; no window access and no mouse input."""
        if self.game.get()!='Microsoft Paint':return True
        selected=self.paint_tool.get()
        if selected=='Use current tool':return True
        try:
            from PaintTools import load_tool_calibration
            data=load_tool_calibration()
            if data.get('version') not in (2,3):return False
            opacity=data.get('opacity_100') is not None
            if selected=='Auto (recommended)':
                return (data.get('tools',{}).get('Pencil') is not None or
                        (opacity and data.get('brush_menu') is not None and data.get('brush_preset') is not None))
            if selected=='Pencil':return data.get('tools',{}).get('Pencil') is not None
            if selected=='Brush':return opacity and data.get('brush_menu') is not None and data.get('brush_preset') is not None
            if selected=='Eraser':return data.get('tools',{}).get('Eraser') is not None
        except (OSError,ValueError,TypeError):
            return False
        return False


    def _palette_preflight_ready(self):
        """Cheap UI-only palette readiness; full validation still runs in draw()."""
        return bool(self.palette_ready or bypasses_palette(self))

    def _current_safety_signature(self):
        """Fingerprint the critical setup without doing any native input."""
        try: profile=self.game.get()
        except Exception: profile=''
        try: paint_tool=self.paint_tool.get()
        except Exception: paint_tool=''
        target=getattr(self,'target_window',None)
        handle=(target[0] if target else None)
        rect=(tuple(target[1]) if target and len(target)>1 else None)
        image=getattr(self,'original',None)
        image_sig=(id(image), getattr(image,'size',None)) if image is not None else None
        return (profile,paint_tool,tuple(tuple(p) for p in getattr(self,'corners',())),
                handle,rect,bool(self._palette_preflight_ready()),image_sig,
                bool(getattr(self,'small_test_passed',False)))

    def _safety_preflight_valid(self):
        if not bool(getattr(self,'safety_preflight_passed',False)):
            return False
        if time.monotonic() > float(getattr(self,'safety_preflight_valid_until',0.0) or 0.0):
            return False
        return getattr(self,'safety_preflight_signature',None) == DrawBotApp._current_safety_signature(self)

    def _invalidate_safety_preflight(self, reason='setup changed', *, disarm=True):
        was_valid=DrawBotApp._safety_preflight_valid(self)
        self.safety_preflight_passed=False
        self.safety_preflight_signature=None
        self.safety_preflight_valid_until=0.0
        self.dry_run_passed=False
        self.dry_run_signature=None
        self.dry_run_valid_until=0.0
        if disarm:
            DrawBotApp._disarm_full_draw(self, reason, update_text=True)
        if reason and was_valid:
            log_event(f'Safety preflight invalidated: {reason}.')

    def _dry_run_valid(self):
        if not bool(getattr(self,'dry_run_passed',False)):
            return False
        if time.monotonic() > float(getattr(self,'dry_run_valid_until',0.0) or 0.0):
            return False
        return getattr(self,'dry_run_signature',None) == DrawBotApp._current_safety_signature(self)

    def _invalidate_dry_run(self, reason='setup changed', *, disarm=True):
        was_valid=DrawBotApp._dry_run_valid(self)
        self.dry_run_passed=False
        self.dry_run_signature=None
        self.dry_run_valid_until=0.0
        if disarm:
            DrawBotApp._disarm_full_draw(self, reason, update_text=True)
        if reason and was_valid:
            log_event(f'Dry run invalidated: {reason}.')

    @staticmethod
    def _target_lock_signature_from(fingerprint):
        try:
            return json.dumps(fingerprint, sort_keys=True, separators=(',', ':'))
        except (TypeError, ValueError):
            return ''

    def _build_target_lock_fingerprint(self, *, current_client_rect=None, current_target_rect=None, current_dpi=None):
        if getattr(self, 'target_window', None) is None:
            raise ValueError('Select the drawing area again before locking setup.')
        if len(getattr(self, 'corners', ())) != 2:
            raise ValueError('Select the drawing area before locking setup.')
        client = tuple(map(int, current_client_rect or getattr(self, 'target_client_rect', None) or self.target_window[1]))
        rect = tuple(map(int, current_target_rect or self.target_window[1]))
        dpi = current_dpi if current_dpi is not None else getattr(self, 'target_dpi', None)
        profile = self.game.get() if hasattr(self, 'game') else ''
        paint_tool = self.paint_tool.get() if hasattr(self, 'paint_tool') else ''
        paint_simple = bool(self.paint_simple.get()) if hasattr(self, 'paint_simple') else False
        x, y, w, h = self.area()
        area_rel = [int(x - client[0]), int(y - client[1]), int(w), int(h)]
        corners_rel = [[int(px - client[0]), int(py - client[1])] for px, py in self.corners]
        palette_required = not bypasses_palette(self)
        palette = []
        if palette_required:
            for color in allColors:
                palette.append({
                    'name': str(getattr(color, 'name', '')),
                    'rgb': [int(v) for v in getattr(color, 'RGB', (0, 0, 0))],
                    'rel': [int(color.x - client[0]), int(color.y - client[1])],
                })
        tool_actions = []
        if profile == 'Microsoft Paint' and paint_tool != 'Use current tool':
            try:
                from PaintTools import build_tool_actions
                for kind, position in build_tool_actions(paint_tool, current_client_rect=client):
                    tool_actions.append({'kind': str(kind), 'rel': [int(position[0] - client[0]), int(position[1] - client[1])]})
            except (OSError, ValueError, TypeError) as error:
                # The caller will surface this as a setup-lock/preflight failure.
                raise ValueError(f'Paint tool calibration changed or is unavailable: {error}') from error
        exact_controls=[]
        try:
            if getattr(getattr(self,'custom_color_workflow',None),'get',lambda:'' )()=='Exact custom + palette fallback':
                key=PROFILES[profile][0]
                for name,pos in sorted(resolve_exact_color_controls(key,client).items()):
                    exact_controls.append({'name':name,'rel':[int(pos[0]-client[0]),int(pos[1]-client[1])]})
        except (OSError,ValueError,KeyError,TypeError):
            exact_controls=[]
        image = getattr(self, 'original', None)
        image_size = list(getattr(image, 'size', ())) if image is not None else None
        return {
            'version': 1,
            'profile': profile,
            'paint_tool': paint_tool,
            'paint_single_color': paint_simple,
            'target_handle': int(self.target_window[0]),
            'target_rect': [int(v) for v in rect],
            'target_client_rect': [int(v) for v in client],
            'target_dpi': (int(dpi) if dpi is not None else None),
            'drawing_area_rel': area_rel,
            'corners_rel': corners_rel,
            'image_size': image_size,
            'palette_required': palette_required,
            'palette': palette,
            'tool_actions': tool_actions,
            'exact_color_controls': exact_controls,
        }

    def _target_lock_valid(self):
        if not bool(getattr(self, 'target_lock_passed', False)):
            return False
        stored = getattr(self, 'target_lock_signature', None)
        if not stored:
            return False
        try:
            current = DrawBotApp._build_target_lock_fingerprint(self)
        except Exception:
            return False
        return stored == DrawBotApp._target_lock_signature_from(current)

    def _refresh_target_lock_text(self):
        locked = DrawBotApp._target_lock_valid(self)
        text = 'Unlock setup' if locked else 'Lock setup'
        for name in ('target_lock_button', 'target_lock_secondary'):
            widget = getattr(self, name, None)
            if widget is not None:
                DrawBotApp._safe_widget_configure(widget, text=text)
        target_text = getattr(self, 'target_lock_text', None)
        if target_text is not None:
            try:
                target_text.set('✓ Setup locked to current target window, DPI, drawing area and palette.' if locked else 'Setup not locked. Run small test, then Lock setup.')
            except (tk.TclError, RuntimeError):
                pass

    def _invalidate_target_lock(self, reason='setup changed', *, disarm=True):
        was_valid = DrawBotApp._target_lock_valid(self)
        self.target_lock_passed = False
        self.target_lock_fingerprint = None
        self.target_lock_signature = None
        cache=getattr(self,'color_session_cache',None)
        if isinstance(cache,dict):cache.clear()
        if disarm:
            DrawBotApp._invalidate_safety_preflight(self, reason, disarm=True)
        DrawBotApp._refresh_target_lock_text(self)
        if reason and was_valid:
            log_event(f'Target/setup lock invalidated: {reason}.')

    def _verify_target_lock(self):
        if not bool(getattr(self, 'target_lock_passed', False)) or not getattr(self, 'target_lock_signature', None):
            raise ValueError('Lock setup first. Full drawing is blocked until target window, DPI, area and palette are fingerprinted.')
        if getattr(self, 'target_window', None) is None:
            DrawBotApp._invalidate_target_lock(self, 'target window missing')
            raise ValueError('The target window is no longer locked. Select drawing area and Lock setup again.')
        try:
            DrawBotApp._refresh_target_for_draw(self, update_target_lock=True)
        except (OSError, ValueError, InterruptedError) as error:
            DrawBotApp._invalidate_target_lock(self, 'target anchor transform failed')
            raise ValueError(f'Target Lock failed: {error}') from error
        from TargetCapture import probe_handle_isolated
        handle = int(self.target_window[0])
        meta = probe_handle_isolated(handle)
        stored = getattr(self, 'target_lock_fingerprint', None) or {}
        expected_rect = tuple(stored.get('target_rect') or ())
        expected_client = tuple(stored.get('target_client_rect') or ())
        expected_dpi = stored.get('target_dpi')
        current_rect = tuple(meta['rect']); current_client = tuple(meta['client_rect']); current_dpi = meta.get('dpi')
        if expected_rect and current_rect != expected_rect:
            DrawBotApp._invalidate_target_lock(self, 'target window rectangle changed')
            raise ValueError('Target Lock failed: the target window moved or changed size. Select the drawing area and Lock setup again. No mouse input was sent.')
        if expected_client and current_client != expected_client:
            DrawBotApp._invalidate_target_lock(self, 'target client rectangle changed')
            raise ValueError('Target Lock failed: the target drawing window layout changed. Re-select the canvas and Lock setup again. No mouse input was sent.')
        if expected_dpi is not None and current_dpi is not None and int(current_dpi) != int(expected_dpi):
            DrawBotApp._invalidate_target_lock(self, 'target DPI changed')
            raise ValueError(f'Target Lock failed: DPI changed from {expected_dpi} to {current_dpi}. Select the drawing area and Lock setup again. No mouse input was sent.')
        paint_profile = self.game.get() == 'Microsoft Paint'
        if not bypasses_palette(self):
            load_calibration(self.calibration_path, current_client_rect=current_client, require_anchor=paint_profile)
        current = DrawBotApp._build_target_lock_fingerprint(self, current_client_rect=current_client, current_target_rect=current_rect, current_dpi=current_dpi)
        current_signature = DrawBotApp._target_lock_signature_from(current)
        if current_signature != getattr(self, 'target_lock_signature', None):
            DrawBotApp._invalidate_target_lock(self, 'target fingerprint mismatch')
            raise ValueError('Target Lock failed: drawing area, palette layout, Paint tool calibration or source image changed. Lock setup again before drawing. No mouse input was sent.')
        return True

    def _make_live_target_check(self, *, interval=0.35):
        """Return a low-cost monitor used by GuardedMouse during execution.

        Step 6 verifies the fingerprint before planning. Step 7 keeps checking
        the locked target while the cursor is moving so a window move, DPI change,
        canvas reflow or stale calibration cannot continue silently mid-drawing.
        The callback is throttled to keep fast paths responsive; GuardedMouse
        still performs its normal foreground/point checks on every movement.
        """
        if not getattr(self, 'target_lock_fingerprint', None):
            return None
        stored=dict(self.target_lock_fingerprint)
        expected_signature=getattr(self, 'target_lock_signature', None)
        expected_handle=int(stored.get('target_handle', self.target_window[0] if self.target_window else 0))
        expected_rect=tuple(stored.get('target_rect') or ())
        expected_client=tuple(stored.get('target_client_rect') or ())
        expected_dpi=stored.get('target_dpi')
        expected_area_rel=tuple(stored.get('drawing_area_rel') or ())
        check_state={'next':0.0,'last_log':0.0,'count':0}

        def fail(reason, message):
            try:
                DrawBotApp._invalidate_target_lock(self, reason, disarm=True)
            except Exception:
                pass
            log_event(f'Live target monitor stopped drawing: {reason}.')
            raise InterruptedError(message)

        def live_check(monitor, target, point=None):
            now=time.monotonic()
            if now < check_state['next']:
                return True
            check_state['next']=now+float(interval)
            check_state['count']+=1
            if not bool(getattr(self, 'target_lock_passed', False)) or getattr(self, 'target_lock_signature', None) != expected_signature:
                fail('setup lock changed during drawing', 'Stopped: setup lock changed during drawing. No automatic restart.')
            handle=int(target[0])
            if handle != expected_handle:
                fail('target handle changed during drawing', 'Stopped: the drawing target handle changed. Select the drawing area and Lock setup again.')
            try:
                rect=tuple(monitor.rectangle(handle))
                client=tuple(monitor.client_rectangle(handle))
                dpi=monitor.dpi(handle)
            except InterruptedError as error:
                fail('target became unavailable during drawing', str(error))
            if expected_rect and rect != expected_rect:
                fail('target window rectangle changed during drawing', 'Stopped: target window moved or changed size during drawing. Re-select the canvas and Lock setup again.')
            if expected_client and client != expected_client:
                fail('target client rectangle changed during drawing', 'Stopped: target client/layout changed during drawing. Re-select the canvas and Lock setup again.')
            if expected_dpi is not None and dpi is not None and int(dpi) != int(expected_dpi):
                fail('target DPI changed during drawing', f'Stopped: target DPI changed from {expected_dpi} to {dpi} during drawing. Re-select the canvas and Lock setup again.')
            if expected_area_rel and len(expected_area_rel)==4:
                try:
                    x,y,w,h=self.area()
                    area_rel=(int(x-client[0]),int(y-client[1]),int(w),int(h))
                except Exception:
                    fail('drawing area unavailable during drawing', 'Stopped: drawing area could not be validated during drawing.')
                if area_rel != expected_area_rel:
                    fail('drawing area changed during drawing', 'Stopped: selected canvas no longer matches the locked setup. Lock setup again before drawing.')
            # Rebuild the fingerprint against live in-process geometry. This catches
            # changed image/profile/palette/tool calibration state even when the
            # native window still reports the same rectangle.
            try:
                current=DrawBotApp._build_target_lock_fingerprint(self, current_client_rect=client, current_target_rect=rect, current_dpi=dpi)
                signature=DrawBotApp._target_lock_signature_from(current)
            except Exception as error:
                fail('target fingerprint could not be rebuilt during drawing', f'Stopped: setup fingerprint could not be validated during drawing: {error}')
            if signature != expected_signature:
                fail('target fingerprint mismatch during drawing', 'Stopped: target/palette/tool fingerprint changed during drawing. Lock setup again before continuing.')
            if now-check_state['last_log']>=10.0:
                check_state['last_log']=now
                log_event(f'Live target monitor OK: checks={check_state["count"]} handle={handle} rect={rect} client={client} dpi={dpi}.')
            return True

        return live_check

    def lock_setup(self):
        if self.activity or self.closing:
            return False
        if DrawBotApp._target_lock_valid(self):
            return DrawBotApp.unlock_setup(self)
        ready, message = DrawBotApp._start_guard_ready(self, require_image=True)
        if not ready:
            DrawBotApp._invalidate_target_lock(self, 'lock prerequisites incomplete')
            self.status.set(message)
            try:self.summary.set(message + ' Run the small test successfully, then press Lock setup.')
            except (tk.TclError, AttributeError):pass
            log_event(f'Target/setup lock blocked: {message}')
            return False
        try:
            current_client = self._refresh_target_for_draw()
            paint_profile = self.game.get() == 'Microsoft Paint'
            if not bypasses_palette(self):
                load_calibration(self.calibration_path, current_client_rect=current_client, require_anchor=paint_profile)
            fingerprint = DrawBotApp._build_target_lock_fingerprint(self, current_client_rect=current_client, current_target_rect=self.target_window[1], current_dpi=self.target_dpi)
        except (OSError, ValueError, InterruptedError) as error:
            DrawBotApp._invalidate_target_lock(self, 'lock failed')
            self.status.set(f'Lock setup failed: {error}')
            try:self.summary.set('Setup remains unlocked. Fix the target window, drawing area, palette or tool calibration, then run Lock setup again.')
            except (tk.TclError, AttributeError):pass
            log_event(f'Target/setup lock failed: {error!r}')
            return False
        DrawBotApp._invalidate_safety_preflight(self, 'new target lock created', disarm=True)
        self.target_lock_passed = True
        self.target_lock_fingerprint = fingerprint
        self.target_lock_signature = DrawBotApp._target_lock_signature_from(fingerprint)
        DrawBotApp._refresh_target_lock_text(self)
        self.status.set('Setup locked. Window, DPI, drawing area and palette/tool layout must stay unchanged. Next: Safety preflight.')
        try:self.summary.set('Target Lock PASS: setup fingerprint saved. If Paint/browser moves, resizes, changes DPI, or palette/tool positions change, full drawing will stop before any mouse input.')
        except (tk.TclError, AttributeError):pass
        log_event('Target/setup lock passed. Fingerprint saved for target window, DPI, drawing area, palette and tools.')
        self.set_busy(None)
        return True

    def unlock_setup(self):
        DrawBotApp._invalidate_target_lock(self, 'setup manually unlocked', disarm=True)
        self.status.set('Setup unlocked. Any previous preflight/dry run/unlock is cleared. Change settings or lock setup again before full drawing.')
        try:self.summary.set('Setup lock cleared. Full drawing is locked until Small test → Lock setup → Safety preflight → Dry run → Unlock → Start is completed again.')
        except (tk.TclError, AttributeError):pass
        log_event('Target/setup lock manually cleared.')
        self.set_busy(None)
        return True


    def _strict_safety_required(self):
        return self.game.get() == 'Microsoft Paint'

    def _start_guard_ready(self, *, require_image=True):
        """Return basic setup readiness without moving or clicking the mouse."""
        if require_image and self.original is None:
            return False, 'Start locked: load, paste, or drop an image first.'
        if len(self.corners) != 2:
            return False, 'Start locked: select the drawing area first.'
        if getattr(self,'target_window',None) is None:
            return False, 'Start locked: the target window is not locked. Select the drawing area again.'
        if not self._palette_preflight_ready():
            return False, 'Start locked: read the color palette first, or enable a Paint mode that intentionally bypasses palette clicks.'
        if not self._paint_tool_preflight_ready():
            return False, 'Start locked: calibrate Paint tools first. Auto mode needs Pencil, or Brush plus 100% opacity.'
        if DrawBotApp._strict_safety_required(self) and not bool(getattr(self,'small_test_passed',False)):
            return False, 'Start locked: run Draw small test successfully before a full Paint drawing.'
        return True, 'Basic setup ready.'

    def run_safety_preflight(self):
        """Explicit no-click gate before Unlock full drawing becomes available."""
        if self.activity or self.closing:
            return
        ready,message=DrawBotApp._start_guard_ready(self,require_image=True)
        if not ready:
            DrawBotApp._invalidate_safety_preflight(self,'preflight prerequisites incomplete')
            self.status.set(message)
            try:self.summary.set(message + ' Complete the checklist, then run Safety preflight again.')
            except (tk.TclError,AttributeError):pass
            log_event(f'Safety preflight blocked: {message}')
            return False
        if not DrawBotApp._target_lock_valid(self):
            DrawBotApp._invalidate_safety_preflight(self,'target lock missing before preflight')
            self.status.set('Safety preflight locked: press Lock setup first. The lock fingerprints target window, DPI, drawing area and palette.')
            try:self.summary.set('Target Lock is required before Safety preflight. Run the small test, press Lock setup, then run Safety preflight.')
            except (tk.TclError,AttributeError):pass
            log_event('Blocked Safety preflight because Target Lock was not valid.')
            return False
        self.status.set('Running safety preflight… No mouse input will be sent.')
        log_event('Safety preflight started. Mouse input remains DISARMED.')
        try:
            DrawBotApp._verify_target_lock(self)
            self._refresh_target_for_draw()
            ready,message=DrawBotApp._start_guard_ready(self,require_image=True)
            if not ready:raise ValueError(message.replace('Start locked: ','',1))
            self.safety_preflight_passed=True
            self.safety_preflight_signature=DrawBotApp._current_safety_signature(self)
            self.safety_preflight_valid_until=time.monotonic()+60.0
            DrawBotApp._disarm_full_draw(self,'preflight passed; waiting for explicit unlock',update_text=True)
            self.status.set('Safety preflight passed for 60 seconds. Now run Dry run, then Unlock full drawing and Start Drawing.')
            try:self.summary.set('Safety preflight PASS: image, target window, drawing area, palette/tools and small test are valid. No mouse input was sent. Next: run Dry run.')
            except (tk.TclError,AttributeError):pass
            log_event('Safety preflight passed. Valid for 60 seconds or until setup changes.')
            self.set_busy(None)
            return True
        except (OSError,ValueError,InterruptedError) as error:
            DrawBotApp._invalidate_safety_preflight(self,'preflight failed')
            self.status.set(f'Safety preflight failed: {error}')
            try:self.summary.set('Full drawing remains locked. Fix the reported setup problem and run Safety preflight again.')
            except (tk.TclError,AttributeError):pass
            log_event(f'Safety preflight failed: {error!r}')
            self.set_busy(None)
            return False

    def _full_draw_unlocked(self):
        return time.monotonic() <= float(getattr(self, 'full_draw_armed_until', 0.0) or 0.0)

    def _refresh_start_buttons_text(self):
        if getattr(self,'closing',False):
            return
        unlocked = DrawBotApp._full_draw_unlocked(self)
        start_text = '▶️  Start Drawing' if unlocked else '🔒  Start locked'
        unlock_text = '✓  Unlocked for 12s' if unlocked else '🔓  Unlock full drawing'
        for name in ('start', 'start_secondary'):
            widget = getattr(self, name, None)
            if widget is not None:
                DrawBotApp._safe_widget_configure(widget, text=start_text)
        for name in ('start_unlock', 'start_unlock_secondary'):
            widget = getattr(self, name, None)
            if widget is not None:
                DrawBotApp._safe_widget_configure(widget, text=unlock_text)

    def _disarm_full_draw(self, reason='', update_text=True):
        was_unlocked = DrawBotApp._full_draw_unlocked(self)
        self.full_draw_armed_until = 0.0
        DrawBotApp._cancel_after_attr(self, 'draw_arm_after')
        if reason and was_unlocked:
            log_event(f'Full drawing safety lock reset: {reason}.')
        if update_text:
            DrawBotApp._refresh_start_buttons_text(self)

    def _expire_full_draw_arm(self):
        self.draw_arm_after = None
        if DrawBotApp._full_draw_unlocked(self):
            return
        self.full_draw_armed_until = 0.0
        DrawBotApp._refresh_start_buttons_text(self)
        if not self.activity and not self.closing:
            try:self.status.set('Full drawing safety unlock expired. Press Unlock full drawing again when everything is ready.')
            except tk.TclError:pass

    def _manual_drop_in_armed(self):
        var=getattr(self,'manual_drop_in_start',None)
        get=getattr(var,'get',None)
        if get is None or not bool(get()):
            return False
        return time.monotonic() <= float(getattr(self,'manual_drop_in_armed_until',0.0) or 0.0)

    def _refresh_manual_drop_in_ui(self):
        armed=DrawBotApp._manual_drop_in_armed(self)
        text='⚡  Drop-In armed' if armed else '⚡  Arm Drop-In Start'
        widget=getattr(self,'drop_in_button',None)
        if widget is not None:
            DrawBotApp._safe_widget_configure(widget,text=text)
        detail=getattr(self,'drop_in_text',None)
        if detail is not None:
            try:
                if armed:
                    remaining=max(0,int(float(getattr(self,'manual_drop_in_armed_until',0.0) or 0.0)-time.monotonic()))
                    detail.set(f'Drop-In Start armed for the next image import/drop · {remaining}s left · browser/game profiles only.')
                else:
                    detail.set('Drop-In Start is off. Arm it after target canvas and palette are ready.')
            except (tk.TclError,RuntimeError):
                pass

    def _disarm_manual_drop_in(self, reason=''):
        self.drop_action_pending=None
        self.pending_drop_in_import=None
        self.drop_in_start_context=None
        DrawBotApp._cancel_after_attr(self,'pending_drop_in_after')
        self.drop_in_sync_phase=DROP_SYNC_IDLE
        var=getattr(self,'manual_drop_in_start',None)
        if getattr(var,'set',None) is not None:
            try:var.set(False)
            except (tk.TclError,RuntimeError):pass
        self.manual_drop_in_armed_until=0.0
        DrawBotApp._cancel_after_attr(self,'manual_drop_in_after')
        DrawBotApp._refresh_manual_drop_in_ui(self)
        if reason:
            log_event(f'Manual Drop-In Start disarmed: {reason}.')

    def _expire_manual_drop_in(self):
        self.manual_drop_in_after=None
        if DrawBotApp._manual_drop_in_armed(self):
            DrawBotApp._refresh_manual_drop_in_ui(self)
            try:self.manual_drop_in_after=self.root.after(1000,self._expire_manual_drop_in)
            except (tk.TclError,RuntimeError,AttributeError):self.manual_drop_in_after=None
            return
        DrawBotApp._disarm_manual_drop_in(self,'arm timeout')
        if not self.activity and not self.closing:
            try:self.status.set('Drop-In Start expired. Arm it again before importing the next image.')
            except (tk.TclError,RuntimeError):pass

    def arm_manual_drop_in(self):
        """Arm a one-shot browser/game image import that starts drawing after load."""
        if self.activity or self.closing:
            return
        ready,message=DrawBotApp._start_guard_ready(self,require_image=False)
        ok,explanation=can_arm_drop_in(self.game.get(),ready=ready,message=message)
        if not ok:
            DrawBotApp._disarm_manual_drop_in(self,'arm rejected')
            self.status.set(explanation)
            try:self.summary.set(explanation + ' This mode is one-shot and never persists between sessions.')
            except (tk.TclError,AttributeError):pass
            log_event(explanation)
            return False
        try:
            self._refresh_target_for_draw()
        except (OSError,ValueError,InterruptedError) as error:
            DrawBotApp._disarm_manual_drop_in(self,'target verification failed before arm')
            self.status.set(f'Drop-In Start blocked: {error}')
            log_event(f'Drop-In Start blocked by target verification: {error!r}')
            return False
        self.manual_drop_in_start.set(True)
        self.manual_drop_in_armed_until=time.monotonic()+DROP_IN_ARM_SECONDS
        DrawBotApp._cancel_after_attr(self,'manual_drop_in_after')
        try:self.manual_drop_in_after=self.root.after(1000,self._expire_manual_drop_in)
        except (tk.TclError,RuntimeError,AttributeError):self.manual_drop_in_after=None
        DrawBotApp._refresh_manual_drop_in_ui(self)
        self.status.set('Drop-In Start armed. Drop/select/paste/load the next image and Draw Studio will start drawing on the current canvas.')
        try:self.summary.set('Manual Drop-In Start is armed for one image import. It still uses CanvasGuard and target checks before mouse input. Paint keeps the full safety chain and is not auto-started.')
        except (tk.TclError,AttributeError):pass
        log_event('Manual Drop-In Start armed for next image import.')
        return True

    def _drop_in_fingerprint(self):
        return drop_in_target_fingerprint(
            self.game.get(), getattr(self,'target_window',None),
            getattr(self,'target_client_rect',None), getattr(self,'target_dpi',None))

    def _drop_in_wait_description(self):
        phase=getattr(self,'drop_in_sync_phase',DROP_SYNC_IDLE)
        if getattr(self,'activity',None)=='browser-auto-calibration' or phase==DROP_SYNC_AUTO_SETUP:
            return 'Auto Setup'
        if phase==DROP_SYNC_VISUAL_PREFLIGHT:
            return 'Visual Preflight'
        if phase==DROP_SYNC_AUTO_RECALIBRATING:
            return 'Auto-Recalibration'
        return 'browser setup'

    def _schedule_drop_in_sync_tick(self, delay=120):
        DrawBotApp._cancel_after_attr(self,'pending_drop_in_after')
        if self.closing:return False
        try:self.pending_drop_in_after=self.root.after(max(20,int(delay)),self._drop_in_sync_tick)
        except (tk.TclError,RuntimeError,AttributeError):self.pending_drop_in_after=None;return False
        return True

    def _drop_in_sync_tick(self):
        self.pending_drop_in_after=None
        if self.closing:return False
        request=getattr(self,'pending_drop_in_import',None)
        if request is not None:
            if pending_drop_in_expired(request):
                self.pending_drop_in_import=None
                DrawBotApp._disarm_manual_drop_in(self,'pending setup wait timeout')
                try:self.status.set('Drop-In expired: browser setup did not complete within 30 seconds. The queued image was not started.')
                except Exception:pass
                log_event('Drop-In synchronization expired while waiting for browser setup.')
                return False
            if not pending_drop_in_target_matches(request,DrawBotApp._drop_in_fingerprint(self)):
                self.pending_drop_in_import=None
                DrawBotApp._disarm_manual_drop_in(self,'target changed while waiting')
                try:self.status.set('Drop-In cancelled: target changed while waiting for browser setup.')
                except Exception:pass
                log_event('Drop-In synchronization cancelled because target/profile/DPI changed while waiting.')
                return False
            if not drop_in_should_wait(activity=getattr(self,'activity',None),phase=getattr(self,'drop_in_sync_phase',None)):
                return DrawBotApp._resume_pending_drop_in_import(self)
            DrawBotApp._schedule_drop_in_sync_tick(self,120)
            return True
        if normalize_drop_in_action(getattr(self,'drop_action_pending',None))==DROP_IN_ACTION:
            if drop_in_should_wait(activity=getattr(self,'activity',None),phase=getattr(self,'drop_in_sync_phase',None)):
                self.drop_in_sync_phase=DROP_SYNC_PENDING
                DrawBotApp._schedule_drop_in_sync_tick(self,120)
                return True
            return DrawBotApp._run_pending_drop_in_start(self)
        return False

    def _queue_pending_drop_in_import(self, source, label, action):
        action=normalize_drop_in_action(action)
        if action!=DROP_IN_ACTION or not DrawBotApp._manual_drop_in_armed(self):return False
        previous=getattr(self,'pending_drop_in_import',None)
        wait=DrawBotApp._drop_in_wait_description(self)
        active_phase=getattr(self,'drop_in_sync_phase',DROP_SYNC_IDLE)
        request=make_pending_drop_in_request(
            source,label,action,DrawBotApp._drop_in_fingerprint(self),previous=previous,
            timeout_seconds=DROP_SYNC_TIMEOUT_SECONDS)
        self.pending_drop_in_import=request
        self.drop_in_start_context=request
        # Hold the explicit one-shot authorization while the read-only setup is
        # allowed to finish. It still expires quickly and is never persisted.
        self.manual_drop_in_armed_until=max(float(getattr(self,'manual_drop_in_armed_until',0.0) or 0.0),request.deadline+1.0)
        if not drop_in_should_wait(activity=getattr(self,'activity',None),phase=active_phase):
            self.drop_in_sync_phase=DROP_SYNC_PENDING
        if previous is None:
            text=f'Drop-In queued. Waiting for {wait} to finish before loading the image…'
            log_event(f'Drop-In image queued during {wait}: {label!r}.')
        else:
            text=f'Drop-In updated: latest image wins. Waiting for {wait} to finish…'
            log_event(f'Drop-In pending image replaced: old={previous.label!r} new={label!r} sequence={request.sequence}.')
        try:self.status.set(text);self.drop_in_text.set(text)
        except Exception:pass
        DrawBotApp._schedule_drop_in_sync_tick(self,120)
        return True

    def _resume_pending_drop_in_import(self):
        request=getattr(self,'pending_drop_in_import',None)
        if request is None:return False
        if pending_drop_in_expired(request):
            self.pending_drop_in_import=None
            DrawBotApp._disarm_manual_drop_in(self,'pending setup wait timeout')
            try:self.status.set('Drop-In expired: browser setup did not complete in time.')
            except Exception:pass
            return False
        if not pending_drop_in_target_matches(request,DrawBotApp._drop_in_fingerprint(self)):
            self.pending_drop_in_import=None
            DrawBotApp._disarm_manual_drop_in(self,'target changed while waiting')
            try:self.status.set('Drop-In cancelled: target changed while waiting for setup.')
            except Exception:pass
            return False
        if self.activity or self.closing or drop_in_should_wait(activity=self.activity,phase=getattr(self,'drop_in_sync_phase',None)):
            DrawBotApp._schedule_drop_in_sync_tick(self,120);return True
        self.pending_drop_in_import=None
        self.drop_in_start_context=request
        self.drop_in_sync_phase=DROP_SYNC_READY
        try:self.status.set(f'Browser setup ready. Loading queued Drop-In image: {request.label}')
        except Exception:pass
        log_event(f'Drop-In synchronization resuming queued image after setup: {request.label!r}.')
        return bool(DrawBotApp.load_source(self,request.source,request.label,action=request.action,_from_sync=True))

    def _queue_drop_in_start(self, action, *, source_label='image'):
        action=normalize_drop_in_action(action)
        if action is None:
            if getattr(self,'drop_action_pending',None)==DROP_IN_ACTION:self.drop_action_pending=None
            return False
        if not DrawBotApp._manual_drop_in_armed(self):
            self.drop_action_pending=None
            log_event(f'Manual Drop-In Start ignored for {source_label!r}: arm expired or disabled.')
            return False
        if getattr(self,'drop_in_start_context',None) is None:
            self.drop_in_start_context=make_pending_drop_in_request(
                None,source_label,DROP_IN_ACTION,DrawBotApp._drop_in_fingerprint(self),
                timeout_seconds=DROP_SYNC_TIMEOUT_SECONDS)
        self.drop_action_pending=DROP_IN_ACTION
        self.drop_in_sync_phase=DROP_SYNC_PENDING
        log_event(f'Manual Drop-In Start queued after image import: {source_label!r}.')
        return True

    def _schedule_pending_drop_in_start(self):
        if normalize_drop_in_action(getattr(self,'drop_action_pending',None)) != DROP_IN_ACTION:
            return False
        try:self.root.after(60,self._run_pending_drop_in_start)
        except (tk.TclError,RuntimeError,AttributeError):self._run_pending_drop_in_start()
        return True

    def _run_pending_drop_in_start(self):
        if normalize_drop_in_action(getattr(self,'drop_action_pending',None)) != DROP_IN_ACTION:
            return False
        if self.closing:return False
        context=getattr(self,'drop_in_start_context',None)
        if context is not None:
            if pending_drop_in_expired(context):
                DrawBotApp._disarm_manual_drop_in(self,'pending draw timeout')
                self.status.set('Drop-In expired while waiting for browser setup. The image remains loaded.')
                log_event('Drop-In draw request expired before setup became ready.')
                return False
            if not pending_drop_in_target_matches(context,DrawBotApp._drop_in_fingerprint(self)):
                DrawBotApp._disarm_manual_drop_in(self,'target changed while waiting')
                self.status.set('Drop-In cancelled: target changed while waiting. The image remains loaded.')
                log_event('Drop-In draw request cancelled because target/profile/DPI changed while waiting.')
                return False
        if drop_in_should_wait(activity=getattr(self,'activity',None),phase=getattr(self,'drop_in_sync_phase',None)):
            wait=DrawBotApp._drop_in_wait_description(self)
            self.status.set(f'Drop-In ready with image loaded. Waiting for {wait} to finish…')
            log_event(f'Drop-In draw request waiting for {wait}.')
            DrawBotApp._schedule_drop_in_sync_tick(self,120)
            return True
        if self.activity:
            # Never piggyback a one-shot authorization onto unrelated work such
            # as an active drawing/recording. Only read-only browser setup waits.
            self.status.set(f'Drop-In cannot start while {self.activity} is active.')
            log_event(f'Drop-In draw request not started because non-waitable activity={self.activity!r}.')
            return False
        if not DrawBotApp._manual_drop_in_armed(self):
            self.status.set('Drop-In Start did not run because the arm expired before the image finished loading.')
            log_event('Manual Drop-In Start skipped: arm expired before load completed.')
            self.drop_action_pending=None
            return False
        if DrawBotApp._strict_safety_required(self):
            DrawBotApp._disarm_manual_drop_in(self,'strict Paint profile')
            self.status.set('Drop-In Start is blocked for Microsoft Paint. Use the full Paint safety chain before Start Drawing.')
            log_event('Manual Drop-In Start blocked for Microsoft Paint.')
            return False
        ready,message=DrawBotApp._start_guard_ready(self,require_image=True)
        if not ready:
            # Browser setup can still be converging after the image loader has
            # finished. Keep the explicit request alive for the bounded sync
            # window instead of rejecting it immediately.
            try:
                from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
                profile_key=PROFILES.get(self.game.get(),('',))[0]
            except Exception:
                profile_key=''
            if profile_key in SUPPORTED_BROWSER_PROFILES and context is not None and not pending_drop_in_expired(context):
                self.drop_in_sync_phase=DROP_SYNC_PENDING
                self.status.set('Drop-In waiting for browser setup readiness…')
                log_event(f'Drop-In start guard not ready yet; retaining pending request: {message}')
                DrawBotApp._schedule_drop_in_sync_tick(self,150)
                return True
            DrawBotApp._disarm_manual_drop_in(self,'start guard failed after image load')
            self.status.set('Drop-In Start blocked: '+message.replace('Start locked: ','',1))
            log_event(f'Manual Drop-In Start blocked after load: {message}')
            return False
        try:
            self._refresh_target_for_draw()
        except (OSError,ValueError,InterruptedError) as error:
            DrawBotApp._disarm_manual_drop_in(self,'target verification failed after image load')
            self.status.set(f'Drop-In Start blocked: {error}')
            log_event(f'Manual Drop-In Start target verification failed after load: {error!r}')
            return False
        # _refresh_target_for_draw may apply a safe auto-recalibration. Require
        # the same target/profile identity captured when the user dropped the
        # image; geometry changes inside that target are allowed.
        if context is not None:
            current=DrawBotApp._drop_in_fingerprint(self)
            same_identity=(context.fingerprint[0:2]==current[0:2])
            if not same_identity:
                DrawBotApp._disarm_manual_drop_in(self,'target identity changed after verification')
                self.status.set('Drop-In cancelled: the selected browser/profile changed before drawing.')
                return False
        self.drop_action_pending=None
        self.drop_in_sync_phase=DROP_SYNC_READY
        # Preserve authorization only long enough to enter draw(); then revoke it
        # before planning/native input as the one-shot action has been consumed.
        DrawBotApp._disarm_manual_drop_in(self,'image accepted')
        self.status.set('Drop-In Start accepted. Building final drawing plan now…')
        log_event('Manual Drop-In Start accepted after synchronized image import. Starting drawing with explicit drop-in authorization.')
        return DrawBotApp.draw(self,user_initiated=True)

    def run_dry_run(self):
        """Simulate the final plan with cursor moves only. No clicks are sent."""
        if self.activity or self.closing:
            return
        ready,message=DrawBotApp._start_guard_ready(self,require_image=True)
        if not ready:
            DrawBotApp._invalidate_dry_run(self,'dry run prerequisites incomplete')
            self.status.set(message)
            try:self.summary.set(message + ' Fix the setup checklist, run Safety preflight, then run Dry run.')
            except (tk.TclError,AttributeError):pass
            log_event(f'Dry run blocked: {message}')
            return
        if not DrawBotApp._target_lock_valid(self):
            DrawBotApp._invalidate_dry_run(self,'target lock missing before dry run')
            self.status.set('Dry run locked: Lock setup first, then run Safety preflight again.')
            try:self.summary.set('Target Lock must be current before Dry run. This prevents moving through an old canvas or palette layout.')
            except (tk.TclError,AttributeError):pass
            log_event('Blocked dry run because Target Lock was not valid.')
            return
        try:
            DrawBotApp._verify_target_lock(self)
        except (OSError,ValueError,InterruptedError) as error:
            DrawBotApp._invalidate_dry_run(self,'target lock failed before dry run')
            self.status.set(f'Dry run locked: {error}')
            log_event(f'Blocked dry run because Target Lock verification failed: {error!r}')
            return
        if not DrawBotApp._safety_preflight_valid(self):
            DrawBotApp._invalidate_dry_run(self,'safety preflight missing before dry run')
            self.status.set('Dry run locked: run Safety preflight first. The dry run uses the same validated setup but sends no clicks.')
            try:self.summary.set('Safety gate active: Dry run requires a current Safety preflight pass. Full drawing stays locked.')
            except (tk.TclError,AttributeError):pass
            log_event('Blocked dry run because Safety preflight was not valid.')
            return
        self.status.set('Starting fast Dry run. It samples the calibrated route for up to 12 seconds and sends no clicks.')
        log_event('Fast calibrated Dry run requested after valid Safety preflight. Native clicks remain disabled; planning and cursor simulation are time-bounded.')
        return DrawBotApp.draw(self,dry_run=True,user_initiated=True)

    def unlock_full_drawing(self):
        """Separate mouse-click safety unlock. This never starts drawing."""
        if self.activity or self.closing:
            return
        ready, message = self._start_guard_ready(require_image=True)
        if not ready:
            self._disarm_full_draw('unlock preflight not ready')
            self.status.set(message)
            try:self.summary.set(message + ' Fix the setup checklist first, then press Unlock full drawing. Start Drawing remains locked.')
            except (tk.TclError,AttributeError):pass
            log_event(message)
            return
        if not DrawBotApp._strict_safety_required(self):
            self.full_draw_armed_until = time.monotonic() + 12.0
            DrawBotApp._refresh_start_buttons_text(self)
            try:self.draw_arm_after=self.root.after(12_500, self._expire_full_draw_arm)
            except (tk.TclError,RuntimeError,AttributeError):self.draw_arm_after=None
            self.status.set('Profile setup ready. Full drawing unlocked for 12 seconds. Press Start Drawing. Small test / Lock / Preflight / Dry run are optional diagnostics for this profile.')
            log_event('Non-Paint profile safety-unlocked with simplified flow. Optional diagnostic gates were not required.')
            return True
        if not DrawBotApp._target_lock_valid(self):
            self._disarm_full_draw('target lock missing or expired')
            self.status.set('Unlock blocked: press Lock setup first, then Safety preflight and Dry run again.')
            try:self.summary.set('Target Lock must be current before Unlock full drawing.')
            except (tk.TclError,AttributeError):pass
            log_event('Blocked unlock because Target Lock was not valid.')
            return
        try:
            DrawBotApp._verify_target_lock(self)
        except (OSError,ValueError,InterruptedError) as error:
            self._disarm_full_draw('target lock failed before unlock')
            self.status.set(f'Unlock blocked: {error}')
            log_event(f'Blocked unlock because Target Lock verification failed: {error!r}')
            return
        if not DrawBotApp._safety_preflight_valid(self):
            self._disarm_full_draw('safety preflight missing or expired')
            self.status.set('Unlock blocked: run Safety preflight first. A pass is valid for 60 seconds or until setup changes.')
            try:self.summary.set('Failsafe active: Safety preflight must pass before Unlock full drawing becomes available.')
            except (tk.TclError,AttributeError):pass
            log_event('Blocked unlock because Safety preflight was not valid.')
            return
        if not DrawBotApp._dry_run_valid(self):
            self._disarm_full_draw('dry run missing or expired')
            self.status.set('Unlock blocked: run Fast Dry run first. It checks representative calibrated routes with mouse movement only and no clicks.')
            try:self.summary.set('Failsafe active: Dry run must pass before Unlock full drawing becomes available.')
            except (tk.TclError,AttributeError):pass
            log_event('Blocked unlock because Dry run was not valid.')
            return
        self.full_draw_armed_until = time.monotonic() + 12.0
        DrawBotApp._refresh_start_buttons_text(self)
        try:self.draw_arm_after=self.root.after(12_500, self._expire_full_draw_arm)
        except (tk.TclError,RuntimeError,AttributeError):self.draw_arm_after=None
        test_note = '' if self.small_test_passed else ' Small test has not passed yet; run Draw small test first for the safest path.'
        self.status.set('Full drawing unlocked for 12 seconds. Now press the separate Start Drawing button. Stop/Esc cancels.' + test_note)
        try:self.summary.set('Safety lock passed: image, area, palette/tools and target setup are ready. The next click on Start Drawing begins final planning before any mouse input.' + test_note)
        except (tk.TclError,AttributeError):pass
        log_event('Full drawing safety-unlocked by separate explicit mouse click. Waiting for Start Drawing click.')

    def start_full_drawing(self):
        """Start is separate from unlock and refuses to run while locked."""
        if self.activity or self.closing:
            return
        ready, message = self._start_guard_ready(require_image=True)
        if not ready:
            self._disarm_full_draw('start preflight not ready')
            self.status.set(message)
            try:self.summary.set(message + ' Start Drawing cannot run until setup is complete and the safety unlock is pressed.')
            except (tk.TclError,AttributeError):pass
            log_event(message)
            return
        if not DrawBotApp._strict_safety_required(self):
            if not DrawBotApp._full_draw_unlocked(self):
                self.status.set('Start Drawing is locked. Press Unlock full drawing first, then Start Drawing within 12 seconds.')
                log_event('Blocked non-Paint Start Drawing because explicit unlock was not active.')
                return
            self._disarm_full_draw('start accepted', update_text=True)
            log_event('Non-Paint Start Drawing accepted after simplified explicit unlock.')
            return DrawBotApp.draw(self,user_initiated=True)
        if not DrawBotApp._target_lock_valid(self):
            self._disarm_full_draw('target lock invalid before start')
            self.status.set('Start Drawing is locked: Target Lock expired or setup changed. Lock setup again, then rerun Safety preflight and Dry run.')
            log_event('Blocked Start Drawing because Target Lock was invalid.')
            return
        try:
            DrawBotApp._verify_target_lock(self)
        except (OSError,ValueError,InterruptedError) as error:
            self._disarm_full_draw('target lock failed before start')
            self.status.set(f'Start Drawing is locked: {error}')
            log_event(f'Blocked Start Drawing because Target Lock verification failed: {error!r}')
            return
        if not DrawBotApp._safety_preflight_valid(self):
            self._disarm_full_draw('safety preflight invalid before start')
            self.status.set('Start Drawing is locked: Safety preflight expired or setup changed. Run Safety preflight again.')
            log_event('Blocked Start Drawing because Safety preflight was invalid.')
            return
        if not DrawBotApp._dry_run_valid(self):
            self._disarm_full_draw('dry run invalid before start')
            self.status.set('Start Drawing is locked: Dry run expired or setup changed. Run Dry run again.')
            log_event('Blocked Start Drawing because Dry run was invalid.')
            return
        if not DrawBotApp._full_draw_unlocked(self):
            self.status.set('Start Drawing is locked. Press Unlock full drawing first, then Start Drawing within 12 seconds.')
            try:self.summary.set('Failsafe active: full drawing requires two different controls. This prevents accidental starts before image, area, palette and tool setup are finished.')
            except (tk.TclError,AttributeError):pass
            log_event('Blocked Start Drawing because safety unlock was not active.')
            return
        self._disarm_full_draw('start accepted', update_text=True)
        log_event('Full drawing Start button accepted after separate safety unlock.')
        return DrawBotApp.draw(self,user_initiated=True)

    def confirm_start_drawing(self):
        """Backward compatible alias: old UI/tests route here, but it is now locked."""
        return DrawBotApp.start_full_drawing(self)

    def set_busy(self,activity):
        self.activity=activity
        for widget,state in list(self.controls):
            self._safe_widget_configure(widget,state='disabled' if activity else state)
        if hasattr(self,'pause_button'):
            self._safe_widget_configure(self.pause_button,state='normal' if activity=='draw' else 'disabled',text='⏸  Pause · F6')
        if hasattr(self,'paint_check'):
            paint_enabled=(not activity and self.game.get()=='Microsoft Paint')
            self._safe_widget_configure(self.paint_check,state='disabled' if activity else 'normal')
            if hasattr(self,'paint_tool_menu'):
                self._safe_widget_configure(self.paint_tool_menu,state='normal' if paint_enabled else 'disabled')
            if hasattr(self,'paint_tool_button'):
                self._safe_widget_configure(self.paint_tool_button,state='normal' if paint_enabled else 'disabled')
            if hasattr(self,'paint_auto_button'):
                self._safe_widget_configure(self.paint_auto_button,state='normal' if paint_enabled else 'disabled')
        if hasattr(self,'app_tool_button'):
            generic_enabled=(not activity and self.game.get()!='Microsoft Paint')
            self._safe_widget_configure(self.app_tool_button,state='normal' if generic_enabled else 'disabled')
        if hasattr(self,'browser_auto_button'):
            try:
                from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
                key=PROFILES.get(self.game.get(),('',))[0]
                auto_enabled=(not activity and key in SUPPORTED_BROWSER_PROFILES)
            except Exception:
                auto_enabled=False
            self._safe_widget_configure(self.browser_auto_button,state='normal' if auto_enabled else 'disabled')
        if not activity and not self.closing:
            tool_ready=self._paint_tool_preflight_ready()
            palette_ready=self._palette_preflight_ready()
            strict=DrawBotApp._strict_safety_required(self)
            basic_ready=(self.original is not None and len(self.corners)==2 and self.target_window is not None and palette_ready and tool_ready)
            ready=basic_ready and (bool(getattr(self,'small_test_passed',False)) if strict else True)
            target_lock_valid=ready and DrawBotApp._target_lock_valid(self)
            preflight_valid=target_lock_valid and DrawBotApp._safety_preflight_valid(self)
            dry_run_valid=preflight_valid and DrawBotApp._dry_run_valid(self)
            unlocked=(dry_run_valid if strict else basic_ready) and DrawBotApp._full_draw_unlocked(self)
            if hasattr(self,'start'):
                self._safe_widget_configure(self.start,state='normal' if unlocked else 'disabled')
            if hasattr(self,'start_secondary'):
                self._safe_widget_configure(self.start_secondary,state='normal' if unlocked else 'disabled')
            if hasattr(self,'target_lock_button'):
                self._safe_widget_configure(self.target_lock_button,state='normal' if ready else 'disabled')
            if hasattr(self,'target_lock_secondary'):
                self._safe_widget_configure(self.target_lock_secondary,state='normal' if ready else 'disabled')
            if hasattr(self,'safety_preflight_button'):
                self._safe_widget_configure(self.safety_preflight_button,state='normal' if target_lock_valid else 'disabled')
            if hasattr(self,'safety_preflight_secondary'):
                self._safe_widget_configure(self.safety_preflight_secondary,state='normal' if target_lock_valid else 'disabled')
            if hasattr(self,'dry_run_button'):
                self._safe_widget_configure(self.dry_run_button,state='normal' if preflight_valid else 'disabled')
            if hasattr(self,'dry_run_secondary'):
                self._safe_widget_configure(self.dry_run_secondary,state='normal' if preflight_valid else 'disabled')
            unlock_ready=dry_run_valid if strict else basic_ready
            if hasattr(self,'start_unlock'):
                self._safe_widget_configure(self.start_unlock,state='normal' if unlock_ready else 'disabled')
            if hasattr(self,'start_unlock_secondary'):
                self._safe_widget_configure(self.start_unlock_secondary,state='normal' if unlock_ready else 'disabled')
            if not ready:self._invalidate_target_lock('setup changed',disarm=True)
            DrawBotApp._refresh_target_lock_text(self)
            DrawBotApp._refresh_start_buttons_text(self)
            if self.original is None:self.next_step.set('Select an image or drag an image file here.')
            elif len(self.corners)!=2:self.next_step.set('Press Select drawing area and mark only the drawable canvas.')
            elif not palette_ready:self.next_step.set('Read the color palette for the selected profile, or use a supported mode that intentionally bypasses palette clicks.')
            elif not tool_ready:self.next_step.set('Calibrate Paint tools. Auto mode needs Pencil, or Brush + 100% opacity.')
            elif strict and not getattr(self,'small_test_passed',False):self.next_step.set('Run Draw small test successfully before full Paint drawing.')
            elif strict and not target_lock_valid:self.next_step.set('Press Lock setup. Target window, DPI, drawing area and palette will be fingerprinted.')
            elif strict and not preflight_valid:self.next_step.set('Run Safety preflight. It sends no mouse input.')
            elif strict and not dry_run_valid:self.next_step.set('Run Fast Dry run. It samples representative calibrated routes for up to 12 seconds; reaching the budget normally counts as PASS when no safety error occurs.')
            elif not unlocked:self.next_step.set(('Dry run passed. ' if strict else '')+'Press Unlock full drawing, then Start Drawing within 12 seconds.')
            else:self.next_step.set('Unlocked. Press Start Drawing to begin real drawing.')
            if hasattr(self,'reuse'):
                self._safe_widget_configure(self.reuse,state='normal' if self.saved_area else 'disabled')
        if hasattr(self,'refresh_ui_state'):
            try:self.refresh_ui_state()
            except (tk.TclError,RuntimeError,AttributeError):pass

    def add_profile(self):
        from tkinter import simpledialog
        from GameProfiles import add_custom_profile
        name=simpledialog.askstring('New application profile','What is the drawing application called?',parent=self.root)
        if not name:return
        try:
            add_custom_profile(name,DATA_DIR/'profiles.json')
            self.profile_selector.configure(values=list(PROFILES))
            self.game.set(name.strip());self.change_profile()
        except (OSError,ValueError) as error:messagebox.showerror('Could not create profile',str(error))

    def test_mouse(self):
        """Run the no-click mouse test in a separate Python process.

        A bad native Win32 call can terminate a process without raising a normal
        Python exception. Keeping the probe out-of-process lets the GUI survive
        that failure and report the helper exit code/log to the user.
        """
        if self.activity:return
        if len(self.corners)!=2 or self.target_window is None:
            self.status.set('Select the drawing area first.');return
        import json
        import subprocess
        import sys

        x,y,w,h=self.area()
        handle,rect=self.target_window
        try:handle_value=int(handle)
        except (TypeError,ValueError):
            handle_value=getattr(handle,'value',None)
        if not handle_value:
            self.status.set('The target window handle is invalid. Select the drawing area again.');return

        log_event(f'Isolated mouse test requested. area={(x,y,w,h)} target={(handle_value,rect)!r}')
        self.root.iconify()

        def work():
            from RuntimePaths import helper_command
            command=helper_command(
                'mouse',
                '--handle', str(handle_value),
                '--rect', *map(str,rect),
                '--area', str(x),str(y),str(w),str(h),
            )
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)
            self.events.put(('status','Protected mouse test is running in a separate process. No clicks will be performed. Switch to the target application.'))
            started=time.monotonic()
            process=None
            output=''
            try:
                process=subprocess.Popen(
                    command,cwd=BASE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                    text=True,encoding='utf-8',errors='replace',creationflags=creationflags)
                self.mouse_probe_process=process
                interruption=None
                while True:
                    try:
                        output=process.communicate(timeout=.10)[0] or ''
                        break
                    except subprocess.TimeoutExpired:
                        if self.stop.is_set():interruption='Mouse test cancelled.'
                        elif time.monotonic()-started>35:interruption='The mouse test exceeded 35 seconds and was stopped.'
                        if interruption:
                            process.kill()
                            output=process.communicate(timeout=5)[0] or ''
                            break
            finally:
                if process is not None:
                    if process.poll() is None:
                        process.kill()
                        try:output=process.communicate(timeout=5)[0] or output
                        except subprocess.TimeoutExpired:pass
                    for stream in (process.stdout,process.stderr):
                        if stream is not None:stream.close()
                self.mouse_probe_process=None

            probe_log=BASE/'logs'/'DrawStudio-mouse-probe.log'
            try:
                probe_log.parent.mkdir(parents=True,exist_ok=True)
                probe_log.write_text(
                    f'Command: {command!r}\nExit: {process.returncode if process else "not-started"}\n\n{output}',
                    encoding='utf-8')
            except OSError:
                pass
            log_event(f'Isolated mouse probe exit={process.returncode if process else None}. Output={output!r}')

            if interruption:raise InterruptedError(interruption)

            messages=[]
            for line in output.splitlines():
                try:
                    payload=json.loads(line)
                    if isinstance(payload,dict):messages.append(payload)
                except (json.JSONDecodeError,TypeError):
                    continue
            error_text=next((m.get('value') for m in reversed(messages) if m.get('type')=='error'),None)
            result=next((m.get('value') for m in reversed(messages) if m.get('type')=='result'),None)
            code=process.returncode if process else -1
            if code!=0:
                unsigned=code & 0xffffffff
                code_text=f'{code} / 0x{unsigned:08X}'
                if unsigned==0xC0000005:
                    hint=' Windows reported 0xC0000005 (access violation/native crash). Enable crash dumps and run the test again.'
                else:
                    hint=''
                raise RuntimeError(f'{error_text or "The isolated mouse process exited unexpectedly."} Exit code: {code_text}.{hint} Log: {probe_log.name}')
            if not isinstance(result,dict) or not result.get('ok'):
                raise RuntimeError(f'The mouse test returned no valid result. See {probe_log.name}.')
            positions=result.get('positions') or []
            log_event(f'Isolated mouse test success. positions={positions!r} diagnostics={result.get("diagnostics")!r}')
            self.events.put(('status','Protected mouse test completed: the pointer moved without clicking. Next step: Draw a small test.'))

        try:
            if not self.begin_worker('mouse-test',work):self.root.deiconify()
        except Exception as error:
            self.root.deiconify()
            log_event(f'Mouse test could not start: {error!r}')
            self.status.set(f'Mouse test could not start: {error}')

    def paint_mode_changed(self):
        if uses_paint_color(self) and self.game.get()!='Microsoft Paint':
            self.outline.set(True)
            self.subject_focus.set('Off')
            self.brush_px.set('1')
            self.status.set('Single-color sketch: select black and a thin pencil in the game. No palette calibration is required.')
        self._schedule_paint_configuration_refresh()

    def paint_tool_changed(self,*args):
        self._schedule_paint_configuration_refresh()

    def _schedule_paint_configuration_refresh(self):
        # CTk callbacks can run while the widget is still drawing itself. Queue
        # palette/preview changes instead of mutating layout/state synchronously.
        if self.activity or self.closing:return
        if self.paint_config_after is not None:
            try:self.root.after_cancel(self.paint_config_after)
            except (tk.TclError,ValueError):pass
        try:self.paint_config_after=self.root.after_idle(self._apply_paint_configuration_refresh)
        except tk.TclError:self.paint_config_after=None

    def _apply_paint_configuration_refresh(self):
        self.paint_config_after=None
        if self.activity or self.closing:return
        self.refresh_palette();self.set_busy(None);self.plan=None;self.small_test_passed=False;self.options_changed()

    def _browser_one_click_supported(self):
        try:
            from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
            return PROFILES.get(self.game.get(),('',))[0] in SUPPORTED_BROWSER_PROFILES and self.game.get()!='Microsoft Paint'
        except Exception:
            return False

    def _browser_one_click_active(self):
        try:return bool(self.browser_one_click_enabled.get()) and DrawBotApp._browser_one_click_supported(self)
        except Exception:return False

    def _queue_browser_one_click_after_import(self, label='image'):
        if not DrawBotApp._browser_one_click_active(self) or self.original is None:return False
        self.browser_one_click_pending=True;self.browser_one_click_source_label=str(label)
        try:self.browser_one_click_text.set('One-Click queued · waiting for image loader/setup to become idle…')
        except Exception:pass
        log_event(f'Browser One-Click queued after image import: profile={self.game.get()!r} label={label!r}.')
        DrawBotApp._cancel_after_attr(self,'browser_one_click_after')
        try:self.browser_one_click_after=self.root.after(40,self._run_browser_one_click)
        except Exception:self.browser_one_click_after=None;return False
        return True

    def _run_browser_one_click(self):
        self.browser_one_click_after=None
        if not getattr(self,'browser_one_click_pending',False) or self.closing:return False
        if not DrawBotApp._browser_one_click_active(self):
            self.browser_one_click_pending=False;return False
        if self.activity:
            DrawBotApp._cancel_after_attr(self,'browser_one_click_after')
            try:self.browser_one_click_after=self.root.after(80,self._run_browser_one_click)
            except Exception:self.browser_one_click_after=None
            return True
        profile_name=self.game.get();profile_key=PROFILES.get(profile_name,('',))[0]
        current_handle=(self.target_window[0] if getattr(self,'target_window',None) else None)
        palette_path=Path(self.calibration_path)
        self.browser_one_click_pending=False
        self.drop_in_sync_phase=DROP_SYNC_AUTO_SETUP
        self.browser_auto_calibration_success=False
        self.status.set('One-Click: finding/verifying the game window, canvas and palette…')
        try:self.browser_one_click_text.set('One-Click setup running · read-only browser scan · no mouse input.')
        except Exception:pass
        def work():
            from BrowserOneClick import one_click_setup
            payload=one_click_setup(profile_name,profile_key,palette_path,current_handle=current_handle)
            self.events.put(('browser_one_click_setup_complete',payload))
        return bool(self.begin_worker('browser-one-click-setup',work))

    def _finish_browser_one_click(self):
        if self.closing or self.activity:return False
        if not DrawBotApp._browser_one_click_active(self) or self.original is None:return False
        ready,message=DrawBotApp._start_guard_ready(self,require_image=True)
        if not ready:
            self.status.set('One-Click blocked safely: '+message.replace('Start locked: ','',1))
            try:self.browser_one_click_text.set('One-Click blocked · '+message.replace('Start locked: ','',1))
            except Exception:pass
            return False
        self.status.set('One-Click setup ready. Running visual preflight and starting drawing…')
        log_event('Browser One-Click setup ready; entering normal draw preflight. CanvasGuard remains mandatory.')
        # draw() performs Auto-Recalibration, Browser Visual Preflight and
        # Automatic Brush Size before native input is armed. The image import is
        # the user's one-click authorization for supported browser profiles.
        return DrawBotApp.draw(self,user_initiated=True)

    def auto_calibrate_browser_profile(self, *, automatic=False):
        """Read-only one-click palette/canvas setup for supported browser games.

        The already selected target window is activated for a short screenshot,
        but no mouse move/click/press/release is generated. Manual capture remains
        available only as a fallback when the visual layout cannot be verified.
        """
        if self.activity or self.closing:
            return False
        profile_name=self.game.get()
        profile_key=PROFILES.get(profile_name,('',))[0]
        try:
            from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
        except Exception as error:
            self.status.set(f'Browser Auto Setup is unavailable: {error}')
            return False
        if profile_key not in SUPPORTED_BROWSER_PROFILES:
            if not automatic:self.status.set('Browser Auto Setup is available for Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.io.')
            return False
        target=getattr(self,'target_window',None)
        if not target:
            if not automatic:self.status.set('Select/confirm the target canvas once. Draw Studio will auto-detect the palette immediately afterwards.')
            return False
        # begin_worker owns the busy state. Setting it before begin_worker used to
        # make the worker reject itself as already busy.
        self.stop.clear();self.drop_in_sync_phase=DROP_SYNC_AUTO_SETUP
        self.browser_auto_calibration_success=False
        self.browser_auto_text.set('Auto setup: scanning the selected browser window… no mouse input.')
        log_event(f'Browser Auto Setup started: profile={profile_name!r} key={profile_key!r}. Mouse input remains DISARMED.')
        palette_path=Path(self.calibration_path)
        handle=int(target[0]);expected_rect=tuple(target[1])
        def work():
            import time as _time
            from ScreenGuard import WindowMonitor
            from TargetCapture import probe_handle_isolated
            from BrowserAutoCalibration import auto_calibrate_browser
            from LayoutFingerprintV2 import try_restore, record_from_calibration_file
            monitor=WindowMonitor()
            current_rect=monitor.rectangle(handle)
            if current_rect!=expected_rect:
                raise InterruptedError('Target browser moved or changed size before automatic calibration. Select the canvas again.')
            if not monitor.activate((handle,expected_rect)):
                raise InterruptedError('Windows could not activate the selected browser for automatic calibration.')
            _time.sleep(.20)
            meta=probe_handle_isolated(handle)
            # v1.0.76: try a previously verified layout first. One screenshot is
            # shared by the cache verifier and the full detector on cache miss.
            from PIL import ImageGrab
            screenshot=ImageGrab.grab(bbox=tuple(meta['client_rect']),all_screens=True).convert('RGB')
            cached=try_restore(profile_key,meta,palette_path,screenshot=screenshot)
            if cached.hit:
                payload=cached.as_dict()
                payload.update({
                    'palette_confidence':cached.confidence, 'canvas_confidence':max(.90,cached.confidence),
                    'method':'Layout Fingerprint v2 cache',
                    'note':'Verified local layout fingerprint restored without full palette detection.',
                    'target_meta':meta, 'profile_name':profile_name,
                    'layout_fingerprint_meta':cached.as_dict(),
                })
                self.events.put(('browser_auto_calibration_complete',payload))
                return
            result=auto_calibrate_browser(profile_key,meta,palette_path,screenshot=screenshot)
            try:
                fingerprint=record_from_calibration_file(profile_key,meta,result.canvas_box,palette_path,method=result.method) if result.canvas_box else None
            except Exception as error:
                fingerprint={'saved':False,'reason':str(error)}
            payload=result.as_dict();payload['target_meta']=meta;payload['profile_name']=profile_name
            payload['layout_fingerprint_meta']=fingerprint
            self.events.put(('browser_auto_calibration_complete',payload))
        started=self.begin_worker('browser-auto-calibration',work)
        if not started and self.drop_in_sync_phase==DROP_SYNC_AUTO_SETUP:
            self.drop_in_sync_phase=DROP_SYNC_IDLE
        return started

    def auto_calibrate_paint_tools(self):
        """Visually detect safe Paint toolbar controls without generating input."""
        if self.activity:return
        if self.game.get()!='Microsoft Paint':
            self.status.set('Automatic Paint calibration is available only for the Microsoft Paint profile.');return
        palette_path=Path(self.calibration_path)
        def work():
            from TargetCapture import probe_handle_isolated
            from PaintFullCalibration import choose_paint_window,detect_setup,save_setup
            from BrowserOneClick import _enumerate_windows
            from ScreenGuard import WindowMonitor
            from PIL import ImageGrab
            candidate=choose_paint_window(_enumerate_windows())
            target=(int(candidate['handle']),tuple(candidate['rect']))
            if not WindowMonitor().activate(target):
                raise ValueError('Could not activate Paint. Bring it into view and retry.')
            if self.stop.wait(.35):raise InterruptedError()
            meta=probe_handle_isolated(int(candidate['handle']))
            rect=tuple(meta['client_rect'])
            shot=ImageGrab.grab(bbox=rect,all_screens=True)
            if shot.size!=(rect[2]-rect[0],rect[3]-rect[1]):raise ValueError('Paint window changed size. Try again.')
            result=detect_setup(shot,screen_origin=rect[:2],cancelled=self.stop.is_set)
            if self.stop.is_set():raise InterruptedError()
            fresh=probe_handle_isolated(int(candidate['handle']))
            if tuple(fresh['client_rect'])!=rect:raise ValueError('Paint moved during calibration. Try again.')
            result=save_setup(result,meta,palette_path)
            self.events.put(('paint_auto_calibration_complete',result))
        self.status.set('Scanning Paint canvas, 20 palette colours and tools… No drawing clicks are sent.')
        self.begin_worker('paint-auto-calibration',work)

    def calibrate_paint_tools(self):
        if self.activity:return
        if self.game.get()!='Microsoft Paint':
            self.status.set('Paint tool calibration is available only for the Microsoft Paint profile.');return
        from PaintToolCalibration import PaintToolCalibrationApp
        import customtkinter as ctk
        self.set_busy('tool-calibration')
        window=ctk.CTkToplevel(self.root)
        def closed():
            self.refresh_tool_calibration();self.set_busy(None);self.status.set('Paint tool calibration closed.')
        from ScreenTaskWindow import ScreenTaskWindow
        visibility=ScreenTaskWindow(self.root)
        previous_closed=closed
        def closed():
            try:previous_closed()
            finally:visibility.restore()
        try:
            visibility.hide()
            PaintToolCalibrationApp(window,on_close=closed)
        except Exception:
            window.destroy();self.set_busy(None);visibility.restore();raise
        self.paint_tool_window=window

    def calibrate_app_tools(self):
        if self.activity:return
        if self.game.get()=='Microsoft Paint':
            self.status.set('Use Calibrate Paint tools for Microsoft Paint.');return
        from AppToolCalibration import AppToolCalibrationApp
        import customtkinter as ctk
        profile_key=PROFILES[self.game.get()][0]
        self.set_busy('tool-calibration')
        window=ctk.CTkToplevel(self.root)
        def closed():
            self.refresh_app_tool_calibration();self.set_busy(None);self.status.set('Application tool calibration closed.')
        from ScreenTaskWindow import ScreenTaskWindow
        visibility=ScreenTaskWindow(self.root)
        previous_closed=closed
        def closed():
            try:previous_closed()
            finally:visibility.restore()
        try:
            visibility.hide()
            AppToolCalibrationApp(window,profile_key,self.game.get(),on_close=closed)
        except Exception:
            window.destroy();self.set_busy(None);visibility.restore();raise
        self.app_tool_window=window

    def refresh_app_tool_calibration(self):
        if not hasattr(self,'app_tool_text'):return
        if self.game.get()=='Microsoft Paint':
            self.app_tool_text.set('Paint Fill is captured in Calibrate Paint tools.')
            return
        try:
            from AppTools import load_calibration, capability
            key=PROFILES[self.game.get()][0]
            try:
                from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
            except Exception:
                SUPPORTED_BROWSER_PROFILES=frozenset()
            if key in SUPPORTED_BROWSER_PROFILES:
                self.app_tool_text.set('✓ Normal browser drawing needs no manual tool calibration. Brush/Fill/Eraser capture is optional for advanced Fill/Eraser workflows.')
                return
            data=load_calibration(key);tools=data.get('tools',{})
            saved=[name for name in ('Brush','Fill','Eraser') if name in tools]
            cap=capability(key)
            if not saved:raise ValueError('No application tools captured.')
            ready='✓ Background Fill ready · ' if 'Brush' in tools and 'Fill' in tools else '✓ '
            self.app_tool_text.set(ready+', '.join(saved)+'. '+cap.get('note',''))
        except (OSError,ValueError,TypeError):
            self.app_tool_text.set('Optional Brush/Fill controls are not calibrated for this application.')

    def change_profile(self,event=None):
        if self.activity or self.closing:
            return
        DrawBotApp._disarm_manual_drop_in(self,'profile changed')
        DrawBotApp._clear_render_resume(self,'profile changed by user')
        # Profile changes are configuration-only. Explicitly lock native input
        # before doing anything else, even though this path contains no move/click.
        mouse=getattr(self,'mouse',None)
        if hasattr(mouse,'disarm_input'):
            try:mouse.disarm_input()
            except OSError:pass
        self.save_settings()
        selected=self.game.get()
        if selected not in PROFILES:
            self.status.set('Unknown drawing application profile.')
            return
        if self.profile_change_after is not None:
            try:self.root.after_cancel(self.profile_change_after)
            except (tk.TclError,ValueError):pass
        try:self.profile_change_after=self.root.after_idle(lambda value=selected:self._apply_profile_change(value))
        except tk.TclError:self.profile_change_after=None

    def _apply_profile_change(self,selected):
        self.profile_change_after=None
        if self.activity or self.closing or self.profile_change_in_progress:
            return
        # Ignore a stale queued selection if the user changed the menu again.
        if selected != self.game.get() or selected not in PROFILES:
            return
        self.profile_change_in_progress=True
        try:
            key,accent,hint=PROFILES[selected]
            log_event(f'Applying drawing profile {selected!r}. Mouse input remains DISARMED.')
            self.calibration_path=CALIBRATION_FILE if key=='generic' else DATA_DIR/f'calibration-{key}.json'
            self.settings_path=SETTINGS if key=='generic' else DATA_DIR/f'settings-{key}.json'
            # A profile change is configuration only.  It must never capture a
            # target, activate another window, move the pointer or click.
            self.corners=[];self.saved_area=None;self.canvas_anchor_detection=None;self.target_window=None;self.target_client_rect=None;self.target_dpi=None;self.plan=None;self.small_test_passed=False;self.color_session_cache.clear()
            self.mode.set(SMART_PATH_MODE);self.shape_order.set('Fill first');self.shape_model.set('Auto');self.max_stroke_cap.set('Auto');self.progressive_rendering.set('Auto');self.planning_watchdog.set('Auto');self.time_budget_mode.set('Manual');self.target_stroke_count.set('Auto');self.target_stroke_custom.set('2500');self.render_style.set('Auto');self.draw_quality.set('High likeness');self.human_mode.set('Off');self.gpu_mode.set('Auto');self.gpu_vram.set('Auto');self.gpu_performance.set('High throughput');self.cpu_workers.set('Auto');self.cpu_engine.set('Auto');self.ram_budget.set('Auto');self.ram_custom_mb.set('4096');self.planning_resolution.set('High');self.profile_engine.set('Auto');self.edge_behavior.set('Auto');self.background_fill.set('Conservative');self.fill_engine.set('Auto');self.background_simplification.set('Balanced');self.color_grouping.set('Smart');self.color_workflow.set('Finish color first');self.stroke_optimizer.set('Auto');self.adaptive_detail.set('Auto');self.color_rendering.set('Perceptual match');self.color_layers.set('Off');self.custom_color_workflow.set('Exact custom + palette fallback');self.exact_color_limit.set('Auto');self.preview_mode.set('Manual');self.tool_strategy.set('Auto');self.portrait_focus.set(True)
            self.quality.set('Balanced');self.speed.set('Balanced');self.precision.set('High')
            apply_profile_defaults(self,selected)
            # The Paint switch is always present in the layout; only its enabled
            # state changes.  This avoids a CTkScrollableFrame geometry loop.
            try:self.paint_check.configure(state='normal')
            except (tk.TclError,AttributeError):pass
            self.read_settings()
            # Profile-level saved settings from older builds may contain Auto preview.
            # Switching profile is a configuration action, so v1.0.16 forces Manual
            # after settings are loaded and cancels any queued preview worker.
            self.preview_mode.set('Manual')
            DrawBotApp._cancel_after_attr(self,'preview_after')
            self.refresh_palette();self.refresh_tool_calibration();self.refresh_app_tool_calibration();self.refresh_exact_color_status()
            self.area_text.set('Select the drawing area for the chosen application.')
            try:
                from AppTools import capability
                tool_note=capability(key).get('note','')
            except Exception:
                tool_note=''
            ui=profile_ui(selected)
            profile_tip=ui.get('tip','')
            self.profile_hint.set(hint + (f' {profile_tip}' if profile_tip else '') + (f' Tool model: {tool_note}' if tool_note else ''))
            self.root.title(f'Draw Studio · {selected}')
            self.status.set('Profile changed. Preview stayed Manual and mouse input is locked until you explicitly arm drawing.')
            self.set_busy(None)
            # Profile changes are never allowed to start preview planning. They only
            # invalidate the old plan and redraw the placeholder/original image.
            self._mark_plan_stale('Profile changed. Preview was not rebuilt. Press Build preview manually when ready.')
            self.show_previews();self._schedule_recovery_checkpoint(delay=300)
        finally:
            self.profile_change_in_progress=False

    def read_settings(self):
        try:
            from StabilityRC import migrate_settings
            data=migrate_settings(json.loads(self.settings_path.read_text(encoding='utf-8')))
            quality = {'Snabb skiss':'Quick sketch','Balanserad':'Balanced','Hög detalj':'High detail','Max detalj':'Maximum detail'}.get(data.get('quality'), data.get('quality'))
            if quality in QUALITY:self.quality.set(quality)
            try:
                speed=normalize_speed(data.get('speed','Balanced'))
                self.speed.set(speed)
            except ValueError:
                pass
            precision=data.get('precision','High')
            if hasattr(self,'precision') and precision in ('Normal','High','Ultra'):self.precision.set(precision)
            if data.get('mode') in DRAWING_MODES:self.mode.set(data['mode'])
            elif data.get('mode') == 'Linjer (snabbast)': self.mode.set('Lines (fastest)')
            elif data.get('mode') == 'Punkter': self.mode.set('Dots')
            shape_order=data.get('shape_order','Fill first')
            if hasattr(self,'shape_order') and shape_order in SHAPE_ORDERS:self.shape_order.set(shape_order)
            shape_model=data.get('shape_model','Auto')
            if hasattr(self,'shape_model') and shape_model in SHAPE_MODEL_MODES:self.shape_model.set(shape_model)
            max_stroke_cap=data.get('max_stroke_cap','Auto')
            if hasattr(self,'max_stroke_cap') and max_stroke_cap in STROKE_CAPS:self.max_stroke_cap.set(max_stroke_cap)
            progressive_rendering=data.get('progressive_rendering','Auto')
            if hasattr(self,'progressive_rendering') and progressive_rendering in PROGRESSIVE_RENDERING_MODES:self.progressive_rendering.set(progressive_rendering)
            planning_watchdog=data.get('planning_watchdog','Auto')
            if hasattr(self,'planning_watchdog') and planning_watchdog in PLANNING_WATCHDOG_MODES:self.planning_watchdog.set(planning_watchdog)
            time_budget_mode=data.get('time_budget_mode','Manual')
            if hasattr(self,'time_budget_mode') and time_budget_mode in TIME_BUDGET_MODES:self.time_budget_mode.set(time_budget_mode)
            target_stroke_count=data.get('target_stroke_count','Auto')
            if hasattr(self,'target_stroke_count') and target_stroke_count in TARGET_STROKE_COUNTS:self.target_stroke_count.set(target_stroke_count)
            if hasattr(self,'target_stroke_custom') and data.get('target_stroke_custom') is not None:
                try:self.target_stroke_custom.set(str(parse_custom_stroke_count(data.get('target_stroke_custom'))))
                except ValueError:pass
            render_style=data.get('render_style','Auto')
            if hasattr(self,'render_style') and render_style in ('Auto','Portrait / shaded','Standard / pixel'):self.render_style.set(render_style)
            draw_quality=data.get('draw_quality','High likeness')
            if hasattr(self,'draw_quality') and draw_quality in ('Balanced','High likeness','Maximum likeness','GPU enhanced','Pixel Accurate'):self.draw_quality.set(draw_quality)
            human_mode='Off'  # Ignore humanization saved by earlier versions.
            if hasattr(self,'human_mode') and human_mode in HUMAN_MODES:self.human_mode.set(human_mode)
            gpu_mode=data.get('gpu_mode','Auto')
            if hasattr(self,'gpu_mode') and gpu_mode in ACCELERATION_MODES:self.gpu_mode.set(gpu_mode)
            gpu_vram=data.get('gpu_vram','Auto')
            if hasattr(self,'gpu_vram') and gpu_vram in VRAM_BUDGETS:self.gpu_vram.set(gpu_vram)
            gpu_performance=data.get('gpu_performance','High throughput')
            if hasattr(self,'gpu_performance') and gpu_performance in GPU_PERFORMANCE_MODES:self.gpu_performance.set(gpu_performance)
            cpu_workers=data.get('cpu_workers','Auto')
            if hasattr(self,'cpu_workers') and cpu_workers in CPU_WORKER_CHOICES:self.cpu_workers.set(cpu_workers)
            cpu_engine=data.get('cpu_engine','Auto')
            if hasattr(self,'cpu_engine') and cpu_engine in CPU_ENGINE_MODES:self.cpu_engine.set(cpu_engine)
            ram_budget=data.get('ram_budget','Auto')
            if hasattr(self,'ram_budget') and ram_budget in RAM_BUDGETS:self.ram_budget.set(ram_budget)
            custom_ram=data.get('ram_custom_mb','4096')
            if hasattr(self,'ram_custom_mb'):
                try:self.ram_custom_mb.set(str(parse_custom_ram_mb(custom_ram)))
                except ValueError:pass
            planning_resolution=data.get('planning_resolution','High')
            if hasattr(self,'planning_resolution') and planning_resolution in PLANNING_RESOLUTION_MODES:self.planning_resolution.set(planning_resolution)
            resource_scheduler=data.get('resource_scheduler','Auto')
            if hasattr(self,'resource_scheduler') and resource_scheduler in RESOURCE_SCHEDULER_MODES:self.resource_scheduler.set(resource_scheduler)
            profile_engine=data.get('profile_engine','Auto')
            if hasattr(self,'profile_engine') and profile_engine in PROFILE_ENGINE_MODES:self.profile_engine.set(profile_engine)
            edge_behavior=data.get('edge_behavior','Auto')
            if hasattr(self,'edge_behavior') and edge_behavior in EDGE_BEHAVIOR_MODES:self.edge_behavior.set(edge_behavior)
            background_fill=data.get('background_fill','Balanced')
            if background_fill=='Auto': background_fill='Balanced'
            if hasattr(self,'background_fill') and background_fill in ('Off','Conservative','Balanced','Aggressive'):self.background_fill.set(background_fill)
            fill_engine=data.get('fill_engine','Auto')
            if hasattr(self,'fill_engine') and fill_engine in FILL_ENGINES:self.fill_engine.set(fill_engine)
            background_simplification=data.get('background_simplification','Balanced')
            if hasattr(self,'background_simplification') and background_simplification in ('Off','Conservative','Balanced','Strong'):self.background_simplification.set(background_simplification)
            color_grouping=data.get('color_grouping','Smart')
            if hasattr(self,'color_grouping') and color_grouping in COLOR_GROUPING_MODES:self.color_grouping.set(color_grouping)
            color_workflow=data.get('color_workflow','Finish color first')
            if hasattr(self,'color_workflow') and color_workflow in COLOR_WORKFLOWS:self.color_workflow.set(color_workflow)
            stroke_optimizer=data.get('stroke_optimizer','Auto')
            if hasattr(self,'stroke_optimizer') and stroke_optimizer in STROKE_OPTIMIZER_MODES:self.stroke_optimizer.set(stroke_optimizer)
            adaptive_detail=data.get('adaptive_detail','Auto')
            if hasattr(self,'adaptive_detail') and adaptive_detail in ADAPTIVE_DETAIL_MODES:self.adaptive_detail.set(adaptive_detail)
            visual_verification=data.get('visual_verification','Auto')
            if hasattr(self,'visual_verification') and visual_verification in VISUAL_VERIFICATION_MODES:self.visual_verification.set(visual_verification)
            color_rendering=data.get('color_rendering','Perceptual match')
            if hasattr(self,'color_rendering') and color_rendering in COLOR_RENDERING_MODES:self.color_rendering.set(color_rendering)
            color_layers=data.get('color_layers','Off')
            if hasattr(self,'color_layers') and color_layers in COLOR_LAYER_MODES:self.color_layers.set(color_layers)
            custom_color_workflow=data.get('custom_color_workflow','Calibrated palette')
            if hasattr(self,'custom_color_workflow') and custom_color_workflow in CUSTOM_COLOR_WORKFLOWS:self.custom_color_workflow.set(custom_color_workflow)
            exact_color_limit=data.get('exact_color_limit','Auto')
            if hasattr(self,'exact_color_limit') and str(exact_color_limit) in EXACT_COLOR_LIMITS:self.exact_color_limit.set(str(exact_color_limit))
            preview_mode=data.get('preview_mode','Manual')
            if hasattr(self,'preview_mode') and preview_mode in PREVIEW_MODES:self.preview_mode.set(preview_mode)
            tool_strategy=data.get('tool_strategy','Auto')
            if hasattr(self,'tool_strategy') and tool_strategy in TOOL_STRATEGIES:self.tool_strategy.set(tool_strategy)
            if hasattr(self,'portrait_focus') and type(data.get('portrait_focus')) is bool:self.portrait_focus.set(data['portrait_focus'])
            if type(data.get('skip_white')) is bool:self.skip_white.set(data['skip_white'])
            if hasattr(self,'render_preset'):self.render_preset.set(data.get('render_preset') if data.get('render_preset') in ('Auto','Manual','Masterpiece','Extra fast') else 'Auto')
            if hasattr(self,'read_gartic_timer'):self.read_gartic_timer.set(data.get('read_gartic_timer',True) is not False)
            if type(data.get('outline')) is bool:self.outline.set(data['outline'])
            if hasattr(self,'sketch_detail'):self.sketch_detail.set(data.get('sketch_detail') if data.get('sketch_detail') in ('Auto','Simple','Balanced','Detailed') else 'Auto')
            value=data.get('contrast',1)
            if isinstance(value,(float,int)) and math.isfinite(value) and .5<=value<=2:self.contrast.set(value)
            for key,var,low,high in [('brush_px',self.brush_px,1,50),('max_seconds',self.max_seconds,5,3600)]:
                raw=data.get(key)
                if type(raw) is int and low<=raw<=high:var.set(str(raw))
                elif isinstance(raw,str) and raw.isdecimal() and low<=int(raw)<=high:var.set(str(int(raw)))
            if hasattr(self,'paint_simple') and type(data.get('paint_simple')) is bool:self.paint_simple.set(data['paint_simple'])
            if hasattr(self,'paint_tool') and data.get('paint_tool') in ('Auto (recommended)','Use current tool','Brush','Pencil','Eraser'):
                self.paint_tool.set(data['paint_tool'])
            if hasattr(self,'drop_mode'):
                # Retire the old automatic-drop drawing mode safely.
                self.drop_mode.set('Show image')
            corners=data.get('corners')
            if isinstance(corners,list) and len(corners)==2 and all(isinstance(p,list) and len(p)==2 and all(type(n) is int for n in p) for p in corners):self.saved_area=corners
            anchors=data.get('canvas_anchor_detection')
            if isinstance(anchors,dict):self.canvas_anchor_detection=anchors
        except (OSError,ValueError,TypeError,AttributeError) as error:
            log_event(f'Settings ignored for {self.settings_path.name}: {error!r}')

    def save_settings(self):
        data={'settings_schema':2,'quality':self.quality.get(),'speed':self.speed.get(),'precision':getattr(getattr(self,'precision',None),'get',lambda:'High')(),'mode':self.mode.get(),'shape_order':getattr(getattr(self,'shape_order',None),'get',lambda:'Fill first')(),'shape_model':getattr(getattr(self,'shape_model',None),'get',lambda:'Auto')(),'max_stroke_cap':getattr(getattr(self,'max_stroke_cap',None),'get',lambda:'Auto')(),'progressive_rendering':getattr(getattr(self,'progressive_rendering',None),'get',lambda:'Auto')(),'planning_watchdog':getattr(getattr(self,'planning_watchdog',None),'get',lambda:'Auto')(),'time_budget_mode':getattr(getattr(self,'time_budget_mode',None),'get',lambda:'Manual')(),'target_stroke_count':getattr(getattr(self,'target_stroke_count',None),'get',lambda:'Auto')(),'target_stroke_custom':getattr(getattr(self,'target_stroke_custom',None),'get',lambda:'2500')(),'render_style':getattr(getattr(self,'render_style',None),'get',lambda:'Auto')(),'draw_quality':getattr(getattr(self,'draw_quality',None),'get',lambda:'High likeness')(),'human_mode':'Off','gpu_mode':getattr(getattr(self,'gpu_mode',None),'get',lambda:'Auto')(),'gpu_vram':getattr(getattr(self,'gpu_vram',None),'get',lambda:'Auto')(),'gpu_performance':getattr(getattr(self,'gpu_performance',None),'get',lambda:'High throughput')(),'cpu_workers':getattr(getattr(self,'cpu_workers',None),'get',lambda:'Auto')(),'cpu_engine':getattr(getattr(self,'cpu_engine',None),'get',lambda:'Auto')(),'ram_budget':getattr(getattr(self,'ram_budget',None),'get',lambda:'Auto')(),'ram_custom_mb':getattr(getattr(self,'ram_custom_mb',None),'get',lambda:'4096')(),'planning_resolution':getattr(getattr(self,'planning_resolution',None),'get',lambda:'High')(),'resource_scheduler':getattr(getattr(self,'resource_scheduler',None),'get',lambda:'Auto')(),'profile_engine':getattr(getattr(self,'profile_engine',None),'get',lambda:'Auto')(),'edge_behavior':getattr(getattr(self,'edge_behavior',None),'get',lambda:'Auto')(),'background_fill':getattr(getattr(self,'background_fill',None),'get',lambda:'Balanced')(),'fill_engine':getattr(getattr(self,'fill_engine',None),'get',lambda:'Auto')(),'background_simplification':getattr(getattr(self,'background_simplification',None),'get',lambda:'Balanced')(),'color_grouping':getattr(getattr(self,'color_grouping',None),'get',lambda:'Smart')(),'color_workflow':getattr(getattr(self,'color_workflow',None),'get',lambda:'Finish color first')(),'stroke_optimizer':getattr(getattr(self,'stroke_optimizer',None),'get',lambda:'Auto')(),'adaptive_detail':getattr(getattr(self,'adaptive_detail',None),'get',lambda:'Auto')(),'visual_verification':getattr(getattr(self,'visual_verification',None),'get',lambda:'Auto')(),'color_rendering':getattr(getattr(self,'color_rendering',None),'get',lambda:'Perceptual match')(),'color_layers':getattr(getattr(self,'color_layers',None),'get',lambda:'Off')(),'custom_color_workflow':getattr(getattr(self,'custom_color_workflow',None),'get',lambda:'Calibrated palette')(),'exact_color_limit':getattr(getattr(self,'exact_color_limit',None),'get',lambda:'Auto')(),'preview_mode':getattr(getattr(self,'preview_mode',None),'get',lambda:'Manual')(),'tool_strategy':getattr(getattr(self,'tool_strategy',None),'get',lambda:'Auto')(),'portrait_focus':getattr(getattr(self,'portrait_focus',None),'get',lambda:True)(),'skip_white':self.skip_white.get(),'contrast':self.contrast.get(),'corners':self.corners or self.saved_area,'outline':self.outline.get(),'brush_px':self.brush_px.get(),'max_seconds':self.max_seconds.get()}
        if getattr(self,'canvas_anchor_detection',None):data['canvas_anchor_detection']=self.canvas_anchor_detection
        if hasattr(self,'render_preset'):data['render_preset']=self.render_preset.get()
        if hasattr(self,'read_gartic_timer'):data['read_gartic_timer']=self.read_gartic_timer.get()
        if hasattr(self,'sketch_detail'):data['sketch_detail']=self.sketch_detail.get()
        if hasattr(self,'paint_simple'):data['paint_simple']=self.paint_simple.get()
        if hasattr(self,'paint_tool'):data['paint_tool']=self.paint_tool.get()
        # No automatic-drawing preference is persisted.
        try:
            atomic_write_text(self.settings_path,json.dumps(data,ensure_ascii=False))
        except OSError as error:
            log_event(f'Settings save failed for {self.settings_path.name}: {error!r}')
            if not self.closing:
                self.status.set('Settings could not be saved. Make sure the folder is writable.')

    def options(self):
        if getattr(getattr(self,'render_preset',None),'get',lambda:'Manual')()=='Masterpiece':
            self.time_budget_mode.set('Unlimited')
        if uses_paint_color(self) and self.game.get()!='Microsoft Paint':
            self.outline.set(True)
            self.subject_focus.set('Off')
        try:
            brush=int(self.brush_px.get());limit=int(self.max_seconds.get())
        except (TypeError,ValueError,tk.TclError) as error:
            raise ValueError('Brush width and time limit must be whole numbers.') from error
        if not 1<=brush<=50 or not 5<=limit<=3600:
            raise ValueError('Brush width: 1–50 px. Time limit: 5–3600 seconds.')
        quality=self.quality.get();speed=normalize_speed(self.speed.get());precision=self.precision.get();mode=self.mode.get();shape_order=getattr(getattr(self,'shape_order',None),'get',lambda:'Fill first')();shape_model=getattr(getattr(self,'shape_model',None),'get',lambda:'Auto')();max_stroke_cap=getattr(getattr(self,'max_stroke_cap',None),'get',lambda:'Auto')();progressive_rendering=getattr(getattr(self,'progressive_rendering',None),'get',lambda:'Auto')();planning_watchdog=getattr(getattr(self,'planning_watchdog',None),'get',lambda:'Auto')();time_budget_mode=getattr(getattr(self,'time_budget_mode',None),'get',lambda:'Manual')();target_stroke_count=getattr(getattr(self,'target_stroke_count',None),'get',lambda:'Auto')();target_stroke_custom=getattr(getattr(self,'target_stroke_custom',None),'get',lambda:'2500')();render_style=self.render_style.get();draw_quality=getattr(getattr(self,'draw_quality',None),'get',lambda:'High likeness')();human_mode='Off';gpu_mode=getattr(getattr(self,'gpu_mode',None),'get',lambda:'Auto')();gpu_vram=getattr(getattr(self,'gpu_vram',None),'get',lambda:'Auto')();gpu_performance=getattr(getattr(self,'gpu_performance',None),'get',lambda:'High throughput')();cpu_workers=getattr(getattr(self,'cpu_workers',None),'get',lambda:'Auto')();cpu_engine=getattr(getattr(self,'cpu_engine',None),'get',lambda:'Auto')();ram_budget=getattr(getattr(self,'ram_budget',None),'get',lambda:'Auto')();ram_custom_mb=getattr(getattr(self,'ram_custom_mb',None),'get',lambda:'4096')();planning_resolution=getattr(getattr(self,'planning_resolution',None),'get',lambda:'High')();resource_scheduler=getattr(getattr(self,'resource_scheduler',None),'get',lambda:'Auto')();profile_engine=getattr(getattr(self,'profile_engine',None),'get',lambda:'Manual settings')();edge_behavior=getattr(getattr(self,'edge_behavior',None),'get',lambda:'Auto')();background_fill=getattr(getattr(self,'background_fill',None),'get',lambda:'Balanced')();fill_engine=getattr(getattr(self,'fill_engine',None),'get',lambda:'Auto')();background_simplification=getattr(getattr(self,'background_simplification',None),'get',lambda:'Balanced')();color_grouping=getattr(getattr(self,'color_grouping',None),'get',lambda:'Smart')();color_workflow=getattr(getattr(self,'color_workflow',None),'get',lambda:'Finish color first')();stroke_optimizer=getattr(getattr(self,'stroke_optimizer',None),'get',lambda:'Auto')();adaptive_detail=getattr(getattr(self,'adaptive_detail',None),'get',lambda:'Auto')();visual_verification=getattr(getattr(self,'visual_verification',None),'get',lambda:'Auto')();color_rendering=getattr(getattr(self,'color_rendering',None),'get',lambda:'Perceptual match')();color_layers=getattr(getattr(self,'color_layers',None),'get',lambda:'Off')();custom_color_workflow=getattr(getattr(self,'custom_color_workflow',None),'get',lambda:'Calibrated palette')();exact_color_limit=getattr(getattr(self,'exact_color_limit',None),'get',lambda:'Auto')();preview_mode=getattr(getattr(self,'preview_mode',None),'get',lambda:'Manual')();tool_strategy=getattr(getattr(self,'tool_strategy',None),'get',lambda:'Auto')()
        validate_profile_engine(profile_engine)
        _requested_policy={
            'mode':mode,'shape_order':shape_order,'shape_model':shape_model,'max_stroke_cap':max_stroke_cap,
            'progressive_rendering':progressive_rendering,'planning_watchdog':planning_watchdog,
            'time_budget_mode':time_budget_mode,'target_stroke_count':target_stroke_count,'target_stroke_custom':target_stroke_custom,
            'render_style':render_style,'draw_quality':draw_quality,'quality':quality,'speed':speed,'precision':precision,
            'planning_resolution':planning_resolution,'resource_scheduler':resource_scheduler,
            'background_fill':background_fill,'fill_engine':fill_engine,'background_simplification':background_simplification,
            'color_grouping':color_grouping,'color_workflow':color_workflow,'stroke_optimizer':stroke_optimizer,
            'adaptive_detail':adaptive_detail,'visual_verification':visual_verification,'color_rendering':color_rendering,
            'color_layers':color_layers,'custom_color_workflow':custom_color_workflow,'exact_color_limit':exact_color_limit,
            'tool_strategy':tool_strategy,'edge_behavior':edge_behavior,
        }
        _effective_policy,profile_policy_meta=resolve_profile_policy(self.game.get(),_requested_policy,mode=profile_engine)
        mode=_effective_policy['mode'];shape_order=_effective_policy['shape_order'];shape_model=_effective_policy['shape_model'];max_stroke_cap=_effective_policy['max_stroke_cap']
        progressive_rendering=_effective_policy['progressive_rendering'];planning_watchdog=_effective_policy['planning_watchdog']
        time_budget_mode=_effective_policy['time_budget_mode'];target_stroke_count=_effective_policy['target_stroke_count'];target_stroke_custom=_effective_policy['target_stroke_custom']
        render_style=_effective_policy['render_style'];draw_quality=_effective_policy['draw_quality'];quality=_effective_policy['quality'];speed=normalize_speed(_effective_policy['speed']);precision=_effective_policy['precision']
        planning_resolution=_effective_policy['planning_resolution'];resource_scheduler=_effective_policy['resource_scheduler']
        background_fill=_effective_policy['background_fill'];fill_engine=_effective_policy['fill_engine'];background_simplification=_effective_policy['background_simplification']
        color_grouping=_effective_policy['color_grouping'];color_workflow=_effective_policy['color_workflow'];stroke_optimizer=_effective_policy['stroke_optimizer']
        adaptive_detail=_effective_policy['adaptive_detail'];visual_verification=_effective_policy['visual_verification'];color_rendering=_effective_policy['color_rendering']
        color_layers=_effective_policy['color_layers'];custom_color_workflow=_effective_policy['custom_color_workflow'];exact_color_limit=_effective_policy['exact_color_limit'];tool_strategy=_effective_policy['tool_strategy'];edge_behavior=_effective_policy.get('edge_behavior','Auto')
        if quality not in QUALITY:
            raise ValueError('Choose a valid detail level.')
        validate_precision(precision)
        if mode not in DRAWING_MODES:
            raise ValueError('Choose a valid drawing mode.')
        validate_shape_order(shape_order)
        validate_shape_model(shape_model)
        validate_stroke_cap(max_stroke_cap)
        validate_progressive_rendering(progressive_rendering)
        validate_planning_watchdog(planning_watchdog)
        validate_time_budget_mode(time_budget_mode)
        validate_target_stroke_count(target_stroke_count)
        if render_style not in ('Auto','Portrait / shaded','Standard / pixel'):
            raise ValueError('Choose a valid rendering style.')
        if draw_quality not in ('Balanced','High likeness','Maximum likeness','GPU enhanced','Pixel Accurate'):
            raise ValueError('Choose a valid draw quality.')
        validate_human_mode(human_mode)
        validate_acceleration_mode(gpu_mode)
        validate_vram_budget(gpu_vram)
        validate_gpu_performance(gpu_performance)
        validate_cpu_workers(cpu_workers)
        validate_cpu_engine(cpu_engine)
        validate_ram_budget(ram_budget)
        validate_planning_resolution(planning_resolution)
        validate_resource_scheduler(resource_scheduler)
        allocation=resolve_allocation(cpu_workers,cpu_engine,ram_budget,ram_custom_mb)
        try:
            area_size=(self.area()[2],self.area()[3]) if len(self.corners)==2 else None
        except Exception:
            area_size=None
        recommendation=load_resource_recommendation() if resource_scheduler!='Off' else None
        scheduler_plan=resolve_resource_schedule(
            allocation, mode=resource_scheduler, area=area_size, drawing_mode=mode,
            gpu_mode=gpu_mode, gpu_available=(gpu_mode!='CPU' and draw_quality in ('GPU enhanced','Pixel Accurate')),
            preview=False, recommendation=recommendation)
        allocation=dict(allocation)
        allocation['resource_scheduler']=resource_scheduler
        allocation['resource_scheduler_plan']=scheduler_plan
        allocation['cpu_workers_resolved']=int(scheduler_plan.get('effective_cpu_workers',allocation.get('cpu_workers_resolved',1)) or 1)
        allocation['cpu_engine']=scheduler_plan.get('recommended_engine',allocation.get('cpu_engine','Auto'))
        validate_background_fill(background_fill)
        validate_fill_engine(fill_engine)
        validate_background_simplification(background_simplification)
        validate_color_grouping(color_grouping)
        if color_workflow not in COLOR_WORKFLOWS:raise ValueError('Choose a valid color workflow.')
        validate_stroke_optimizer(stroke_optimizer)
        validate_adaptive_detail(adaptive_detail)
        validate_visual_verification(visual_verification)
        validate_color_rendering(color_rendering)
        validate_color_layers(color_layers)
        validate_custom_color_workflow(custom_color_workflow)
        validate_exact_color_limit(exact_color_limit)
        validate_preview_mode(preview_mode)
        validate_tool_strategy(tool_strategy)
        validate_edge_behavior(edge_behavior)
        paint_profile=self.game.get()=='Microsoft Paint'
        selected_tool=self.paint_tool.get() if paint_profile else 'Use current tool'
        if selected_tool not in ('Auto (recommended)','Use current tool','Brush','Pencil','Eraser'):
            raise ValueError('Choose a valid Paint drawing tool.')
        erase_mode=paint_profile and selected_tool=='Eraser'
        fill_available=False
        if background_fill!='Off' and not bypasses_palette(self):
            try:
                if paint_profile and selected_tool not in ('Use current tool','Eraser'):
                    from PaintTools import load_tool_calibration
                    tool_data=load_tool_calibration()
                    fill_available=(tool_data.get('tools',{}).get('Fill') is not None and self._paint_tool_preflight_ready())
                elif not paint_profile:
                    from AppTools import load_calibration
                    app_data=load_calibration(PROFILES[self.game.get()][0])
                    fill_available=all(name in app_data.get('tools',{}) for name in ('Brush','Fill'))
            except (OSError,ValueError,TypeError,AttributeError):
                fill_available=False
        effective_paint_tool=selected_tool
        if paint_profile and selected_tool=='Auto (recommended)':
            try:
                from PaintTools import load_tool_calibration
                tool_data=load_tool_calibration()
            except (OSError,ValueError,TypeError):
                tool_data={}
            portrait_hint=(render_style=='Portrait / shaded' or (render_style=='Auto' and self.paint_simple.get()))
            effective_paint_tool=choose_paint_tool(selected_tool,tool_strategy,tool_data,portrait=portrait_hint,brush_px=brush)
        contrast=float(self.contrast.get())
        if not math.isfinite(contrast) or not .5<=contrast<=2:
            raise ValueError('Contrast must stay between 0.5 and 2.0.')
        effective_limit, time_budget_active = resolve_time_budget_seconds(time_budget_mode, limit)
        target_cap, target_meta = resolve_target_stroke_count(
            target_stroke_count, target_stroke_custom,
            time_budget_mode=time_budget_mode, effective_time_seconds=effective_limit,
            speed=speed, drawing_mode=mode, preview=False)
        anchor_options={}
        anchor_detection=getattr(self,'canvas_anchor_detection',None)
        if isinstance(anchor_detection,dict):
            polygon=anchor_detection.get('canvas_polygon')
            anchors=anchor_detection.get('canvas_anchors')
            if polygon:
                anchor_options['canvas_polygon']=polygon
                anchor_options['canvas_polygon_space']=anchor_detection.get('canvas_polygon_space','normalized')
            if anchors:
                anchor_options['canvas_anchors']=anchors
                anchor_options['canvas_anchor_space']=anchor_detection.get('canvas_anchor_space','normalized')
                anchor_options['canvas_anchor_meta']=anchor_detection.get('canvas_anchor_meta',{})
        transform_meta=getattr(self,'canvas_anchor_transform_meta',None)
        if isinstance(transform_meta,dict):
            anchor_options['canvas_anchor_transform_meta']=dict(transform_meta)
        return {'detail':QUALITY[quality],'delay':SPEED[speed],'speed':speed,'precision':precision,'profile_name':self.game.get(),'profile_key':PROFILES[self.game.get()][0],'paint_profile':bool(paint_profile),
                'lines':mode!=DOT_MODE,'drawing_mode':mode,'smart_paths':mode==SMART_PATH_MODE,'shape_order':shape_order,'shape_model':shape_model,'max_stroke_cap':max_stroke_cap,'progressive_rendering':progressive_rendering,'planning_watchdog':planning_watchdog,'planning_timeout_seconds':45 if mode==SHAPE_PATH_MODE else 75,'render_style':render_style,'draw_quality':draw_quality,'human_mode':human_mode,'gpu_mode':gpu_mode,'gpu_vram':gpu_vram,'gpu_performance':gpu_performance,'cpu_workers':cpu_workers,'cpu_engine':cpu_engine,'ram_budget':ram_budget,'ram_custom_mb':ram_custom_mb,'planning_resolution':planning_resolution,'resource_scheduler':resource_scheduler,'profile_engine':profile_engine,'profile_policy_meta':profile_policy_meta,**allocation,'background_fill':background_fill,'fill_engine':fill_engine,'background_simplification':background_simplification,'color_grouping':color_grouping,'color_workflow':color_workflow,'stroke_optimizer':stroke_optimizer,'stroke_optimizer_resolved':resolve_stroke_optimizer(stroke_optimizer,drawing_mode=mode),'adaptive_detail':adaptive_detail,'visual_verification':visual_verification,'visual_verification_resolved':resolve_visual_verification(visual_verification,paint_profile=paint_profile,dry_run=False,test=False),'color_rendering':color_rendering,'color_layers':color_layers,'custom_color_workflow':custom_color_workflow,'exact_color_limit':exact_color_limit,'exact_color_limit_resolved':resolve_exact_color_limit(exact_color_limit,draw_quality=draw_quality,preview=False),'exact_color_available':custom_rgb_available(PROFILES[self.game.get()][0]),'preview_mode':preview_mode,'tool_strategy':tool_strategy,'subject_focus':self.subject_focus.get() if hasattr(self,'subject_focus') else 'Off','subject_region':getattr(self,'subject_region',None),'portrait_focus':bool(self.portrait_focus.get()),'skip_white':bool(self.skip_white.get()),'contrast':contrast,'outline':bool(self.outline.get()),'sketch_detail':getattr(getattr(self,'sketch_detail',None),'get',lambda:'Auto')(),'brush_px':brush,'canvas_edge_verification':'Auto','canvas_edge_margin_px':24,'canvas_edge_tolerance_px':4,'canvas_edge_search_px':24,'edge_behavior':edge_behavior,'edge_behavior_resolved':resolve_edge_behavior(edge_behavior, profile_name=self.game.get(), drawing_mode=mode, outline=bool(self.outline.get())),'max_seconds':effective_limit,'manual_max_seconds':limit,'time_budget_mode':time_budget_mode,'time_budget_seconds':effective_limit,'time_budget_active':time_budget_active,'target_stroke_count':target_stroke_count,'target_stroke_custom':target_stroke_custom,'target_stroke_count_resolved':target_cap,**target_meta,
                **anchor_options,
                'render_preset':getattr(getattr(self,'render_preset',None),'get',lambda:'Manual')(),'unlimited_time':time_budget_mode=='Unlimited',
                'read_gartic_timer':bool(getattr(getattr(self,'read_gartic_timer',None),'get',lambda:True)()),
                'paint_current_color':uses_paint_color(self) or erase_mode,'erase_mode':erase_mode,
                'adaptive_color_verification':bool(paint_profile and not erase_mode),'strict_color_verification':bool(paint_profile and not erase_mode),'visual_verification_enabled':bool(paint_profile and not erase_mode and resolve_visual_verification(visual_verification,paint_profile=paint_profile,dry_run=False,test=False)!='Off'),'color_verification_tolerance':48,'color_probe_source_span':4,
                'color_session_cache':getattr(self,'color_session_cache',{}),
                'render_resume_state':getattr(self,'pending_render_resume',None),
                'paint_tool':selected_tool,'effective_paint_tool':effective_paint_tool,'tool_actions':[],'fill_tool_available':fill_available,'fill_tool_actions':[],'fill_restore_actions':[]}

    def area(self):
        (x1,y1),(x2,y2)=self.corners
        return min(x1,x2),min(y1,y2),abs(x2-x1),abs(y2-y1)

    def refresh_tool_calibration(self):
        if not hasattr(self,'paint_tool_text'):return
        if self.game.get()!='Microsoft Paint':
            self.paint_tool_text.set('Automatic tool selection is available for Microsoft Paint.')
            return
        try:
            from PaintTools import load_tool_calibration
            data=load_tool_calibration()
            if data.get('version') not in (2,3):
                raise ValueError('Legacy calibration')
            tools=[name for name in ('Pencil','Fill','Eraser') if name in data.get('tools',{})]
            if data.get('brush_menu') and data.get('brush_preset'):tools.insert(0,'Brush')
            if not tools:raise ValueError('No Paint tools have been captured.')
            opacity=' · Brush 100% opacity saved' if data.get('opacity_100') is not None else ' · Brush opacity not calibrated'
            auto_ready=('Pencil' in data.get('tools',{}) or
                        (data.get('opacity_100') is not None and data.get('brush_menu') and data.get('brush_preset')))
            prefix='✓ Auto ready · ' if auto_ready else '✓ '
            auto_meta=data.get('auto') or {}
            auto_note=(f' · visual auto {float(auto_meta.get("confidence",0))*100:.0f}%' if auto_meta else '')
            self.paint_tool_text.set(prefix+', '.join(tools)+opacity+auto_note)
        except (OSError,ValueError):
            self.paint_tool_text.set('Paint tools need calibration. Use Calibrate Paint tools.')

    def refresh_palette(self):
        reset_palette()
        if bypasses_palette(self):
            self.palette_ready=False
            if uses_paint_eraser(self):
                self.palette_text.set('Eraser mode does not use the color palette. The source image is treated as an erase mask.')
            else:
                self.palette_text.set('No palette required. Select black and a thin pencil in the target app/game before Start. Preview is shown in black; the selected ink is used.')
            return
        try:
            load_calibration(self.calibration_path)
            self.palette_ready=True
            self.palette_text.set('✓ Colors saved')
        except (OSError,ValueError):
            reset_palette()
            from PaletteMaps import PRESETS
            from Colors import Color
            preset=PRESETS.get(PROFILES[self.game.get()][0])
            if preset:
                allColors.clear()
                for name,rgb in zip(preset.names,preset.colors):Color(name,*rgb)
                closest_color.cache_clear()
            self.palette_ready=False
            self.palette_text.set(f'{len(preset.colors)} colors ready · select the palette area.' if preset else 'Read the color grid or capture colors manually.')

    def drop_image(self,event,drop_to_draw=False):
        for name in ('original_canvas','result_canvas','safety_canvas','safety_debug_canvas','stroke_canvas','fill_canvas','color_canvas','coverage_canvas','accuracy_error_canvas'):
            canvas=getattr(self,name,None)
            if canvas is not None:
                try:canvas.configure(bg='#131a25')
                except tk.TclError:pass
        if self.activity or self.closing:return 'none'
        try:
            paths=self.root.tk.splitlist(event.data)
            if len(paths)!=1 or not Path(paths[0]).is_file():
                raise ValueError('Drop one image file at a time from File Explorer.')
            action=action_for_import(armed=DrawBotApp._manual_drop_in_armed(self))
            if drop_to_draw and action is None:
                if DrawBotApp._browser_one_click_active(self):
                    # Browser One-Click treats this direct canvas drop as the
                    # user's authorization, then performs read-only setup and
                    # visual preflight before drawing.
                    self.status.set('Canvas drop accepted. One-Click will verify the target and start drawing when ready.')
                elif self.game.get()!='Microsoft Paint':
                    # For generic non-Paint targets, a direct canvas drop can
                    # arm the existing one-shot path, but only if the complete
                    # target/canvas/palette guard already passes.
                    if DrawBotApp.arm_manual_drop_in(self):
                        action=DROP_IN_ACTION
                        log_event('Direct canvas drop armed one-shot Drop-In Start.')
                    else:
                        log_event('Direct canvas drop imported without auto-start because target setup was not ready.')
            loaded=self.load_source(paths[0],Path(paths[0]).name,action=action)
            if loaded is False:
                raise ValueError('The image could not be queued because Draw Studio is busy.')
        except (ValueError,tk.TclError,OSError) as error:self.status.set(str(error));return 'none'
        return 'copy'

    def update_guesses(self):
        if not hasattr(self,'guess_list'):return
        from WordGuesser import find_candidates
        self.guess_list.delete(0,'end')
        try:
            matches=find_candidates(self.guess_words,self.guess_pattern.get(),self.guess_length.get())
            for word in matches[:200]:self.guess_list.insert('end',word)
            if matches:self.guess_list.selection_set(0)
            self.guess_result.set(f'{len(matches)} possible words' + (' · showing first 200' if len(matches)>200 else '') + '. No confidence ranking.')
        except ValueError as error:self.guess_result.set(str(error))

    def import_words(self):
        if self.activity:return
        path=filedialog.askopenfilename(filetypes=[('Word list','*.txt')])
        if not path:return
        try:
            from WordGuesser import load_words
            words=load_words(Path(path))
            atomic_write_text(DATA_DIR/'guess-words.txt','\n'.join(words)+'\n')
            self.guess_words=words
            self.word_source.set(f'{len(self.guess_words)} words · {Path(path).name}')
            self.update_guesses()
        except (OSError,ValueError) as error:self.guess_result.set(str(error))

    def copy_guess(self):
        selection=self.guess_list.curselection()
        if selection:
            self.root.clipboard_clear();self.root.clipboard_append(self.guess_list.get(selection[0]));self.status.set('Word copied.')

    def open_file(self):
        path=filedialog.askopenfilename(filetypes=[('Images','*.png *.jpg *.jpeg *.webp *.bmp'),('All files','*.*')])
        if path:
            self.load_source(path,Path(path).name,action=action_for_import(armed=DrawBotApp._manual_drop_in_armed(self)))

    def upscale_dialog(self):
        if self.activity or self.closing: return
        if self.original is None:
            self.status.set('Load an image before upscaling.')
            return
        import customtkinter as ctk
        from ImageUpscale import suggested_factor,upscale_size,upscale_image
        self.browser_one_click_pending=False
        DrawBotApp._cancel_after_attr(self,'browser_one_click_after')
        DrawBotApp._disarm_manual_drop_in(self,'image editing')
        source=self.original
        dialog=ctk.CTkToplevel(self.root)
        dialog.title('Upscale image')
        dialog.transient(self.root)
        suggested=suggested_factor(source.size)
        factor=tk.StringVar(value='4×' if suggested==4 else '2×')
        method=tk.StringVar(value='Smooth')
        hint=tk.StringVar()
        ctk.CTkLabel(dialog,text=f'Image: {source.width} × {source.height}\n'+(f'Suggested: {suggested}×' if suggested>1 else 'Already reasonably large; upscaling may not help.')).pack(padx=24,pady=14)
        def update(*args):
            try:
                size=upscale_size(source.size,int(factor.get()[0]))
                hint.set(f'Result: {size[0]} × {size[1]} · {size[0]*size[1]/1e6:.1f} MP')
                apply_button.configure(state='normal')
            except ValueError as error:
                hint.set(str(error));apply_button.configure(state='disabled')
        ctk.CTkOptionMenu(dialog,variable=factor,values=['2×','4×'],command=update).pack(pady=5)
        ctk.CTkOptionMenu(dialog,variable=method,values=['Smooth','Pixel art']).pack(pady=5)
        ctk.CTkLabel(dialog,textvariable=hint,wraplength=380).pack(padx=24,pady=8)
        ctk.CTkLabel(dialog,text='Smooth: photos and illustrations. Pixel art: sharp blocks.\nNo AI: missing detail cannot be recovered.\nDrawing size is still controlled by your selected canvas.',wraplength=380).pack(padx=24,pady=8)
        def apply():
            scale=int(factor.get()[0]);selected_method=method.get()
            dialog.destroy()
            def work():
                result=upscale_image(source,scale,selected_method,self.stop.is_set)
                self.events.put(('upscaled',(result,source)))
            self.begin_worker('upscale',work)
        apply_button=ctk.CTkButton(dialog,text='Upscale image',command=apply)
        apply_button.pack(pady=(8,16))
        update()
        dialog.bind('<Escape>',lambda event:dialog.destroy())
        dialog.wait_visibility();dialog.grab_set()

    def undo_upscale(self):
        if self.activity or self.closing: return
        previous=getattr(self,'upscale_original',None)
        if previous is None:
            self.status.set('No upscaling to undo for this image.')
            return
        self.browser_one_click_pending=False
        DrawBotApp._cancel_after_attr(self,'browser_one_click_after')
        DrawBotApp._disarm_manual_drop_in(self,'undo upscaling')
        DrawBotApp._handle_event(self,'upscaled',(previous,None))

    def paste_shortcut(self,event=None):
        # Text fields retain native paste; elsewhere Ctrl+V imports an image.
        if event and isinstance(event.widget,(tk.Entry,ttk.Entry,ttk.Combobox)):
            return
        self.paste_image()
        return 'break'

    def paste_image(self):
        if self.activity:return
        from PIL import Image,ImageGrab
        try:
            content=ImageGrab.grabclipboard()
            if isinstance(content,Image.Image):
                if content.width*content.height>25_000_000:
                    raise ValueError('The image is too large. Choose an image up to 25 megapixels.')
                self._suppress_recovery=False;self.original=content.convert('RGBA');self.plan=None
                self.original.info.pop('draw_studio_format',None)
                self.upscale_original=None
                self.subject_region=None
                if hasattr(self,'subject_hint'): self.subject_hint.set('Auto: simple background or transparent PNG. Mark busy photos.')
                action=action_for_import(armed=DrawBotApp._manual_drop_in_armed(self))
                DrawBotApp._clear_render_resume(self,'new pasted image')
                from ImageFormatInfo import image_label
                self.file_label.set(image_label(self.original,'Pasted image'));self._mark_plan_stale('Image pasted. Press Build preview when ready.');self.show_previews();self._schedule_recovery_checkpoint(include_image=True,delay=40);self._maybe_auto_preview(delay=900, reason='paste-image')
                DrawBotApp._queue_drop_in_start(self,action,source_label='pasted image')
            elif isinstance(content,list) and content:
                self.load_source(content[0],Path(content[0]).name,action=action_for_import(armed=DrawBotApp._manual_drop_in_armed(self)))
            else:
                text=self.root.clipboard_get().strip()
                if text.startswith(('https://','http://')):
                    self.url.set(text);self.fetch_url()
                else:self.status.set('Copy an image or use Win+Shift+S, then press Ctrl+V here.')
        except (OSError,ValueError,tk.TclError) as error:
            self.status.set(f'Could not paste. Copy an image first. {error}')

    def capture_screen(self):
        if len(self.corners)!=2:
            self.status.set('Select the drawing area first.');return
        area=self.area()
        def work():
            for second in (3,2,1):
                self.events.put(('status',f'Capturing the drawing area in {second} s. Move this window aside.'))
                if self.stop.wait(1):raise InterruptedError()
            self.events.put(('screen',grab_area(area)))
        self.begin_worker('screen',work)

    def display_screen(self,image):
        from PIL import ImageTk
        window=tk.Toplevel(self.root);window.title('Captured drawing area')
        view=image.copy();view.thumbnail((800,480))
        photo=ImageTk.PhotoImage(view)
        label=ttk.Label(window,image=photo);label.image=photo;label.pack(padx=12,pady=12)
        ttk.Label(window,text='Check that the correct drawing area is selected. This is a screenshot, not automatic application recognition.').pack(padx=12)
        def use():
            if self.activity:return
            self._suppress_recovery=False;self.original=image.convert('RGBA');self.plan=None;self.file_label.set('Image from screen')
            self.subject_region=None;self.upscale_original=None
            if hasattr(self,'subject_hint'):self.subject_hint.set('Auto: simple background or transparent PNG. Mark busy photos.')
            DrawBotApp._clear_render_resume(self,'new screen image')
            window.destroy();self._mark_plan_stale('Screen image captured. Press Build preview when ready.');self.show_previews();self._schedule_recovery_checkpoint(include_image=True,delay=40);self._maybe_auto_preview(delay=900, reason='screen-image')
        def save():
            path=filedialog.asksaveasfilename(defaultextension='.png',filetypes=[('PNG','*.png')])
            if path:
                try:image.save(path)
                except OSError as error:messagebox.showerror('Could not save',str(error))
        ttk.Button(window,text='Use as source image',command=use).pack(side='left',padx=12,pady=12)
        ttk.Button(window,text='Save screenshot',command=save).pack(side='left',padx=12)
        ttk.Button(window,text='Close',command=window.destroy).pack(side='right',padx=12)

    def record_screen(self):
        if len(self.corners)!=2:
            self.status.set('Select the drawing area first.');return
        path=filedialog.asksaveasfilename(defaultextension='.gif',filetypes=[('Animated GIF','*.gif')],initialfile='DrawStudio-recording.gif')
        if not path:return
        area=self.area()
        def work():
            for second in (3,2,1):
                self.events.put(('status',f'Recording starts in {second} s. Move this window away from the drawing area.'))
                if self.stop.wait(1):raise InterruptedError()
            frames=[];durations=[]
            started=time.monotonic()
            for index in range(120):
                if self.stop.is_set() or time.monotonic()-started>=30:break
                tick=time.monotonic()
                frame=grab_area(area);frame.thumbnail((800,500))
                frames.append(frame.quantize(colors=128))
                self.events.put(('status',f'● RECORDING {time.monotonic()-started:.0f}/30 s • STOP/Esc ends and saves the GIF'))
                self.stop.wait(max(0,.25-(time.monotonic()-tick)))
                durations.append(max(20,round((time.monotonic()-tick)*1000)))
            if not frames:raise InterruptedError()
            self.events.put(('status','Saving recording…'))
            destination=Path(path);temporary=destination.with_name(destination.name+'.tmp')
            try:
                frames[0].save(temporary,format='GIF',save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=False)
                temporary.replace(destination)
            finally:
                temporary.unlink(missing_ok=True)
            self.events.put(('status',f'Recording saved: {destination.name}'))
        self.begin_worker('record',work)

    def paste_url(self):
        try:self.url.set(self.root.clipboard_get().strip())
        except tk.TclError:self.status.set('The clipboard does not contain text. Copy an image URL first.')

    def fetch_url(self):
        source=self.url.get().strip()
        if urlparse(source).scheme.lower() not in ('http','https'):
            self.status.set('Paste an image URL beginning with https:// and click Load.');return
        self.load_source(source,'Image from URL',action=action_for_import(armed=DrawBotApp._manual_drop_in_armed(self)))

    def begin_worker(self,activity,task):
        if self.activity or self.closing or getattr(self,'pending_clear_drawing',None) is not None:
            log_event(f'Worker {activity} not started: busy={self.activity!r} closing={self.closing!r}.')
            return False
        DrawBotApp._cancel_after_attr(self,'preview_after')
        DrawBotApp._cancel_after_attr(self,'preview_render_after')
        from ScreenTaskWindow import ScreenTaskWindow, SCREEN_ACTIVITIES
        screen_window=ScreenTaskWindow(getattr(self,'root',None))
        if activity in SCREEN_ACTIVITIES:screen_window.hide()
        self.screen_task_window=screen_window
        self.stop.clear();self.set_busy(activity)
        log_event(f'Worker {activity} started.')
        def work():
            started=time.monotonic()
            try:
                if activity in SCREEN_ACTIVITIES and self.stop.wait(.30):raise InterruptedError()
                task()
            except InterruptedError as error:
                log_event(f'Worker {activity} interrupted after {time.monotonic()-started:.3f} s: {error!r}')
                self.events.put(('status',str(error) or 'Cancelled. No automatic restart.'))
            except Exception as error:
                import traceback
                log_event(f'Worker {activity} failed after {time.monotonic()-started:.3f} s: {error!r}\n{traceback.format_exc()}')
                self.events.put(('status',f'Operation failed: {error}'))
            else:
                log_event(f'Worker {activity} finished in {time.monotonic()-started:.3f} s.')
            finally:
                self.events.put(('done',activity))
        self.worker=threading.Thread(target=work,daemon=True,name=f'drawstudio-{activity}')
        try:
            self.worker.start()
        except Exception:
            self.worker=None
            self.set_busy(None)
            screen_window.restore()
            raise
        return True

    def load_source(self,source,label,action=None,_from_sync=False):
        action=normalize_drop_in_action(action) if action is not None else None
        if (not _from_sync and action==DROP_IN_ACTION and
                drop_in_should_wait(activity=getattr(self,'activity',None),phase=getattr(self,'drop_in_sync_phase',None))):
            return DrawBotApp._queue_pending_drop_in_import(self,source,label,action)
        if self.activity or self.closing:
            log_event(f'Image load deferred/rejected: label={label!r} busy={self.activity!r} closing={self.closing!r}.')
            if action==DROP_IN_ACTION and not _from_sync:
                return DrawBotApp._queue_pending_drop_in_import(self,source,label,action) if drop_in_should_wait(activity=self.activity,phase=getattr(self,'drop_in_sync_phase',None)) else False
            return False
        self.status.set('Loading image…')
        log_event(f'Image load requested: {label!r}.')
        def work():
            image=load_image(source,self.stop.is_set)
            if self.stop.is_set():raise InterruptedError()
            log_event(f'Image loaded: size={image.size} label={label!r}.')
            self.events.put(('loaded',(image,label,action)))
        return bool(self.begin_worker('load',work))

    def _auto_preview_enabled(self):
        return getattr(getattr(self,'preview_mode',None),'get',lambda:'Manual')() != 'Manual'

    def _mark_plan_stale(self, message='Settings changed. Press Build preview or Start Drawing when ready.'):
        DrawBotApp._cancel_after_attr(self,'preview_after')
        self.needs_plan=False
        self.plan=None
        self.preview_dirty_reason=message
        self.small_test_passed=False
        DrawBotApp._invalidate_target_lock(self,'plan/setup became stale',disarm=True)
        if not self.closing:
            try:self.summary.set(message)
            except tk.TclError:pass
            if hasattr(self,'schedule_previews'):
                try:self.schedule_previews(delay=30)
                except (tk.TclError,RuntimeError,AttributeError):pass

    def _maybe_auto_preview(self, delay=900, reason='settings'):
        if self.activity or self.closing or self.original is None:
            return False
        if reason == 'profile-change':
            log_event('Preview auto-start blocked after profile-change. Build preview is manual after profile switches.')
            return False
        if not self._auto_preview_enabled():
            # Manual mode is a hard lock: no queued preview callback is left behind.
            DrawBotApp._cancel_after_attr(self,'preview_after')
            log_event(f'Preview auto-start blocked by Manual mode. reason={reason!r}')
            return False
        DrawBotApp._cancel_after_attr(self,'preview_after')
        try:self.preview_after=self.root.after(delay,lambda:self.update_plan(user_initiated=False,reason=reason))
        except (tk.TclError,RuntimeError):self.preview_after=None;return False
        log_event(f'Auto preview scheduled: reason={reason!r} delay={delay}ms.')
        return True

    def render_preset_changed(self,*args):
        if self.render_preset.get()=='Masterpiece':
            if self.time_budget_mode.get()!='Unlimited':self._before_master_time=self.time_budget_mode.get()
            self.time_budget_mode.set('Unlimited')
            self.status.set('Masterpiece uses unlimited drawing time. This cannot extend a game round.')
        elif hasattr(self,'_before_master_time'):
            if self.time_budget_mode.get()=='Unlimited':self.time_budget_mode.set(self._before_master_time)
            del self._before_master_time
        self.options_changed()

    def sketch_mode_changed(self):
        if self.activity or self.closing:return
        if self.outline.get():
            self.subject_focus.set('Off')
            self.render_style.set('Standard / pixel')
            self.brush_px.set('1')
            self.status.set('Black contour sketch enabled. Use a thin black pencil. Build preview before Start; no colour fills will be drawn.')
        self.options_changed()

    def subject_focus_changed(self, *args):
        if self.outline.get() and self.subject_focus.get() != 'Off':
            self.subject_focus.set('Off')
            self.status.set('Black contour sketch is active. Turn it off before enabling Subject focus.')
            self.options_changed()
            return
        if self.subject_focus.get() != 'Off':
            self.draw_quality.set('Pixel Accurate')
            self.brush_px.set('1')
            self.status.set('Subject focus uses Pixel Accurate and a 1 px pencil. Match the target brush and check Coverage preview before Start.')
        self.options_changed()

    def mark_subject(self):
        if self.activity or self.closing: return
        if self.original is None:
            self.status.set('Load an image first, then click Mark subject.')
            return
        from SubjectSelector import select_subject
        def selected(region):
            self.subject_region=region
            self.subject_hint.set('Marked rectangle: everything inside is included. Build preview to check.')
            if self.subject_focus.get()=='Off': self.subject_focus.set('Subject first')
            self.subject_focus_changed()
        select_subject(self.root,self.original,selected)

    def preview_subject(self):
        if self.activity or self.closing: return
        if self.original is None:
            self.status.set('Load an image first.')
            return
        from SubjectSelector import show_mask
        show_mask(self.root,self.original,self.subject_region)

    def reset_subject(self):
        if self.activity or self.closing: return
        self.subject_region=None
        self.subject_hint.set('Auto: simple background or transparent PNG. Mark busy photos.')
        self.options_changed()

    def options_changed(self,*args):
        if self.activity or self.closing:return
        self._mark_plan_stale('Settings changed. Press Build preview to refresh the preview. Start Drawing builds the final plan manually.')
        if hasattr(self,'recovery_checkpoint_after'):
            DrawBotApp._schedule_recovery_checkpoint(self,delay=300)
        self._maybe_auto_preview(delay=1000, reason='settings-change')

    def request_preview(self):
        if self.original is None:
            self.status.set('Load an image before building a preview.')
            return None
        return self.update_plan(user_initiated=True, reason='build-preview-button')

    def request_full_preview(self):
        return self.update_plan(user_initiated=True,reason='full-detail-preview',full_detail=True)

    def update_plan(self, user_initiated=False, reason='automatic',full_detail=False):
        self.preview_after=None
        if self.activity:
            return
        if self.original is None:
            if user_initiated:self.status.set('Load an image before building a preview.')
            return
        if not user_initiated and not self._auto_preview_enabled():
            log_event(f'Preview planning blocked in Manual mode. reason={reason!r}')
            return
        target_area=self.area()[2:] if len(self.corners)==2 else (640,400)
        preview_area=preview_area_for(target_area)
        try:
            # Preview generation is pure image planning. It must not require or
            # resolve screen-coordinate tool calibration. Tool actions are built
            # only inside an explicit Start/Test preflight.
            options=self.options()
        except ValueError as error:
            self.status.set(str(error));return
        preview_options=dict(options)
        preview_options['_preview_plan']=True
        preview_options['_target_area']=tuple(map(int,target_area))
        preview_options['_preview_area']=tuple(map(int,preview_area))
        # v1.0.30: Preview has its own bounded/cancellable planning pipeline.
        # Final drawing still receives the exact CPU/GPU/Extreme/color-layer settings.
        mode=getattr(getattr(self,'preview_mode',None),'get',lambda:'Manual')()
        preview_options['_preview_mode']=mode
        preview_options['max_seconds']=min(int(preview_options.get('max_seconds',180)),90 if user_initiated else 60)
        if mode=='Auto light' and preview_options.get('draw_quality') in ('GPU enhanced','Pixel Accurate'):
            preview_options['_final_draw_quality']=self.draw_quality.get()
            preview_options['draw_quality']='High likeness'
        try:
            preview_target, preview_target_meta = resolve_target_stroke_count(
                preview_options.get('target_stroke_count','Auto'),
                preview_options.get('target_stroke_custom','2500'),
                time_budget_mode=preview_options.get('time_budget_mode','Manual'),
                effective_time_seconds=int(preview_options.get('max_seconds',90)),
                speed=preview_options.get('speed','Balanced'),
                drawing_mode=preview_options.get('drawing_mode',SMART_PATH_MODE),
                preview=True)
            preview_options.update(preview_target_meta)
            preview_options['target_stroke_count_resolved']=preview_target
        except ValueError:
            preview_options['target_stroke_count_resolved']=1200 if mode=='Auto light' else None
        preview_options=preview_safe_options(preview_options,mode)
        if full_detail:
            from PreviewQuality import full_preview_options
            try:preview_options=full_preview_options(options,target_area)
            except ValueError as error:
                self.status.set(str(error));return
            preview_area=tuple(map(int,target_area))
        try:original=self.original.copy()
        except MemoryError:
            self.status.set('Not enough memory to build preview. Close other images or use a smaller source.');return
        def work():
            started=time.monotonic()
            requested=(preview_options.get('_preview_requested_planning_resolution'),
                       preview_options.get('_preview_requested_color_rendering'),
                       preview_options.get('_preview_requested_color_layers'))
            log_event(
                f'Preview planning started: reason={reason} mode={preview_options.get("_preview_mode")} '
                f'target={tuple(map(int,target_area))} preview={preview_area} quality={preview_options.get("draw_quality")} '
                f'color={preview_options.get("color_rendering")} safe_pipeline={not full_detail} requested_planning={requested[0]} '
                f'requested_color={requested[1]} requested_layers={requested[2]} {_resource_log_text(preview_options)}')

            def run_attempt(attempt_options, timeout):
                deadline=time.monotonic()+float(timeout)
                def preview_cancelled():
                    return self.stop.is_set() or self.closing or time.monotonic()>=deadline
                try:
                    result=make_plan(original,preview_area,attempt_options,preview_cancelled)
                except InterruptedError:
                    if self.stop.is_set() or self.closing:
                        raise
                    return None
                if time.monotonic()>=deadline:
                    return None
                return result

            plan=run_attempt(preview_options,60 if full_detail else PREVIEW_PLAN_TIMEOUT_SECONDS)
            used_fallback=False
            if plan is None and not full_detail and not self.stop.is_set() and not self.closing:
                used_fallback=True
                fallback=preview_safe_options(preview_options,mode,fallback=True)
                fallback['_preview_plan']=True
                fallback['_preview_mode']=mode
                fallback['_target_area']=tuple(map(int,target_area))
                fallback['_preview_area']=tuple(map(int,preview_area))
                log_event(
                    f'Preview safe attempt exceeded {PREVIEW_PLAN_TIMEOUT_SECONDS:.0f}s; retrying fast fallback '
                    f'for up to {PREVIEW_FALLBACK_TIMEOUT_SECONDS:.0f}s. No mouse input is armed.')
                plan=run_attempt(fallback,PREVIEW_FALLBACK_TIMEOUT_SECONDS)
            if plan is None:
                if self.stop.is_set() or self.closing:
                    raise InterruptedError()
                elapsed=time.monotonic()-started
                log_event(f'Preview planning abandoned safely after {elapsed:.1f}s. target={tuple(map(int,target_area))} preview={preview_area}')
                self.events.put(('preview_timeout',(tuple(map(int,target_area)),preview_area)))
                return
            plan['target_area']=tuple(map(int,target_area))
            plan['preview_area']=tuple(map(int,preview_area))
            plan['preview_elapsed_seconds']=round(time.monotonic()-started,3)
            plan['preview_safe_pipeline']=not full_detail
            plan['full_detail_preview']=bool(full_detail)
            plan['preview_fallback_used']=bool(used_fallback)
            log_event(f'Preview planning finished in {plan["preview_elapsed_seconds"]:.3f} s fallback={used_fallback}: {_plan_log_text(plan)}.')
            self.events.put(('planned',plan))
        # Historic v1.0.10 status string kept for release-test visibility: Planning optimized preview.
        self.status.set('Building preview…' if user_initiated else 'Planning lightweight auto preview…')
        self.begin_worker('preview',work)

    def schedule_previews(self,event=None,delay=45):
        """Coalesce resize events before redrawing preview canvases.

        Tk can emit nested <Configure> events while a widget hierarchy is still
        settling. Drawing synchronously inside that callback caused a real
        RecursionError on Windows. Scheduling one render after the burst breaks
        that call chain and also avoids doing dozens of redundant redraws.
        """
        if self.closing:
            return
        DrawBotApp._cancel_after_attr(self,'preview_render_after')
        try:self.preview_render_after=self.root.after(delay,self._run_scheduled_previews)
        except (tk.TclError,RuntimeError):self.preview_render_after=None

    def _run_scheduled_previews(self):
        self.preview_render_after=None
        if not self.closing:self.show_previews()

    def show_previews(self):
        # Never re-enter a Tk canvas render. A synchronous <Configure> callback
        # can otherwise nest show_previews() until Python exhausts its stack.
        if self.closing or getattr(self,'preview_rendering',False):
            return
        self.preview_rendering=True
        try:
            from PIL import Image,ImageTk
            photos=[]
            ui_previews=(self.plan or {}).get('ui_previews',{}) if self.plan else {}
            show_background=bool(getattr(getattr(self,'preview_show_background',None),'get',lambda:True)())
            show_fill=bool(getattr(getattr(self,'preview_show_fill',None),'get',lambda:True)())
            show_strokes=bool(getattr(getattr(self,'preview_show_strokes',None),'get',lambda:True)())
            drawing_image=(self.plan['preview'] if self.plan else None) if show_background else ui_previews.get('stroke')
            pairs=[
                (self.original_canvas,self.original),
                (self.result_canvas,drawing_image),
            ]
            for attr,key,enabled in (('safety_canvas','safety',True),('safety_debug_canvas','safety_debug',True),('stroke_canvas','stroke',show_strokes),('fill_canvas','fill',show_fill),('color_canvas','color',True),('coverage_canvas','coverage',True),('accuracy_error_canvas','accuracy_error',True)):
                canvas=getattr(self,attr,None)
                if canvas is not None:pairs.append((canvas,ui_previews.get(key) if enabled else None))
            for canvas,im in pairs:
                try:
                    if not canvas.winfo_exists():continue
                    if not canvas.winfo_ismapped():
                        canvas.delete('all');canvas._preview_photo=None
                        continue
                    canvas.delete('all');canvas._preview_photo=None
                    w,h=max(1,canvas.winfo_width()),max(1,canvas.winfo_height())
                    if im is None:
                        is_original=canvas is self.original_canvas
                        if is_original:
                            title='Drop your image here';hint='PNG, JPG, WEBP · drop on canvas to auto-start when setup is ready'
                        elif canvas is getattr(self,'safety_canvas',None):
                            title='Safety map';hint='CanvasGuard/Edge Behavior clipped, skipped and edge-follow paths will appear here.'
                        elif canvas is getattr(self,'safety_debug_canvas',None):
                            title='Safety debug overlay';hint='Exact drawn, clipped, skipped and edge-follow reasons will appear here.'
                        elif canvas in (getattr(self,'coverage_canvas',None),getattr(self,'accuracy_error_canvas',None)):
                            title='Available with Pixel Accurate'
                            hint='Choose Masterpiece for colour drawing, then build preview. This metric is not calculated for sketch mode.'
                        elif canvas is getattr(self,'stroke_canvas',None):
                            title='Stroke plan';hint='Planned brush paths will appear here.'
                        elif canvas is getattr(self,'fill_canvas',None):
                            title='Fill regions';hint='Safe Auto Fill regions will appear here.'
                        elif canvas is getattr(self,'color_canvas',None):
                            title='Color map';hint='A simplified source color map will appear here.'
                        elif canvas is getattr(self,'coverage_canvas',None):
                            title='Coverage map';hint='Pixel Accurate shows target coverage, missing pixels and brush spill here.'
                        elif canvas is getattr(self,'accuracy_error_canvas',None):
                            title='Accuracy error';hint='Pixel Accurate shows missing, wrong-color, spill and protected unresolved pixels here.'
                        else:
                            if self.original is None:
                                title='Drawing preview';hint='Select an image to generate a preview.'
                            else:
                                title='Preview not built';hint=getattr(self,'preview_dirty_reason','Press Build preview manually.') or 'Press Build preview manually.'
                        if w>250 and h>160:
                            cx,cy=w/2,h/2-45
                            canvas.create_oval(cx-25,cy-25,cx+25,cy+25,fill='#253d36',outline='')
                            canvas.create_line(cx,cy+11,cx,cy-10,fill='#98edce',width=2)
                            canvas.create_line(cx-7,cy-3,cx,cy-10,cx+7,cy-3,fill='#98edce',width=2)
                        canvas.create_text(w/2,h/2+2,text=title,fill='#f0f4fb',font=('Segoe UI',19,'bold'),justify='center',width=max(100,w-30))
                        canvas.create_text(w/2,h/2+38,text=hint,fill='#a6b2c5',font=('Segoe UI',11),justify='center',width=max(100,w-30))
                        continue
                    from PreviewQuality import viewport_image
                    zoom=float(getattr(getattr(self,'preview_zoom',None),'get',lambda:0)())
                    copy,scale=viewport_image(im,(max(1,w-16),max(1,h-16)),zoom,getattr(canvas,'_preview_pan',(0,0)))
                    canvas._preview_scale=scale
                    photo=ImageTk.PhotoImage(copy);photos.append(photo);canvas.create_image(w/2,h/2,image=photo)
                    canvas._preview_photo=photo
                except (ValueError,TypeError,MemoryError) as error:
                    log_event(f'Preview render failed: {type(error).__name__}: {error}')
                    canvas.create_text(max(1,canvas.winfo_width())/2,max(1,canvas.winfo_height())/2,text='This view could not be rendered. Try Fit or rebuild preview.',fill='#f0f4fb',width=280)
                except tk.TclError as error:
                    # A canvas can disappear while the application is closing or a
                    # tab is being rebuilt. That should not terminate the GUI.
                    log_event(f'Preview canvas redraw skipped after TclError: {error}')
            self.photos=photos
        finally:
            self.preview_rendering=False

    def _sync_mobile_preview(self):
        server=getattr(self,'mobile_preview_server',None)
        if server is None or not server.running:
            return
        try:
            ui_previews=(self.plan or {}).get('ui_previews',{}) if self.plan else {}
            server.update_images(
                original=self.original,
                preview=(self.plan or {}).get('preview') if self.plan else None,
                safety=ui_previews.get('safety'),
            )
        except Exception as error:
            log_event(f'Mobile Preview refresh failed safely: {error!r}')

    def _copy_mobile_preview_url(self):
        url=str(getattr(self,'mobile_preview_url',tk.StringVar(value='')).get() or '')
        if not url:
            self.status.set('Start Mobile Preview first.')
            return
        try:
            self.root.clipboard_clear();self.root.clipboard_append(url);self.root.update_idletasks()
            self.status.set('Mobile Preview address copied. Open it on a phone connected to the same Wi-Fi/LAN.')
        except tk.TclError as error:
            self.status.set(f'Could not copy Mobile Preview address: {error}')

    def stop_mobile_preview(self, *, quiet=False):
        server=getattr(self,'mobile_preview_server',None)
        if server is not None:
            try:server.stop()
            except Exception as error:log_event(f'Mobile Preview stop failed safely: {error!r}')
        self.mobile_preview_server=None
        try:self.mobile_preview_url.set('')
        except (tk.TclError,AttributeError):pass
        try:self.mobile_preview_status.set('Mobile Preview is off · local network only.')
        except (tk.TclError,AttributeError):pass
        if not quiet and not self.closing:
            self.status.set('Mobile Preview stopped. The local preview address is no longer available.')
        log_event('Mobile Preview stopped.')

    def show_mobile_preview(self):
        """Start/show the opt-in LAN preview page for phones and tablets."""
        if self.closing:return
        try:
            server=getattr(self,'mobile_preview_server',None)
            if server is None:
                server=MobilePreviewServer();self.mobile_preview_server=server
            if not server.running:
                self._sync_mobile_preview()  # no-op before start; keeps intent explicit
                state=server.start()
                self._sync_mobile_preview()
                log_event(f'Mobile Preview started locally on port {state.port}. No cloud service or telemetry is used.')
            urls=server.urls()
            url=urls[0] if urls else f'http://127.0.0.1:{server.port}/{server.token}/'
            self.mobile_preview_url.set(url)
            self.mobile_preview_status.set('Mobile Preview LIVE · same Wi-Fi/LAN required · auto-refresh 1s')
        except Exception as error:
            self.stop_mobile_preview(quiet=True)
            self.status.set(f'Could not start Mobile Preview: {error}')
            log_event(f'Mobile Preview start failed safely: {error!r}')
            return

        import customtkinter as ctk
        window=ctk.CTkToplevel(self.root)
        window.title('Mobile Preview')
        window.geometry('620x610');window.minsize(560,520);window.transient(self.root)
        window.configure(fg_color='#101319')
        card=ctk.CTkFrame(window,fg_color='#1a202b',corner_radius=18);card.pack(fill='both',expand=True,padx=18,pady=18)
        ctk.CTkLabel(card,text='Mobile Preview',font=('Segoe UI',24,'bold'),text_color='#f0f4fb').pack(anchor='w',padx=22,pady=(20,3))
        ctk.CTkLabel(card,text='Live preview over your local Wi-Fi/LAN. No cloud, account, telemetry or external scripts.',font=('Segoe UI',11),text_color='#a6b2c5',wraplength=550,justify='left').pack(anchor='w',padx=22,pady=(0,12))
        url_box=ctk.CTkTextbox(card,height=64,fg_color='#101319',text_color='#98edce',font=('Consolas',12),corner_radius=10)
        url_box.pack(fill='x',padx=22,pady=(0,10));url_box.insert('1.0',url);url_box.configure(state='disabled')
        qr_label=ctk.CTkLabel(card,text='')
        qr_label.pack(pady=(4,10))
        qr_photo=None
        try:
            import qrcode
            from PIL import ImageTk
            qr=qrcode.QRCode(version=None,box_size=5,border=2)
            qr.add_data(url);qr.make(fit=True)
            qr_image=qr.make_image(fill_color='black',back_color='white').convert('RGB').resize((210,210))
            qr_photo=ImageTk.PhotoImage(qr_image);qr_label.configure(image=qr_photo,text='');qr_label.image=qr_photo
        except Exception:
            qr_label.configure(text='QR code unavailable in this build. Copy the address above to your phone.',text_color='#a6b2c5',font=('Segoe UI',11),wraplength=500)
        ctk.CTkLabel(card,text='Phone: connect to the same Wi-Fi/LAN, then scan the QR code or open the address. If Windows asks, allow Draw Studio on Private networks only.',font=('Segoe UI',11),text_color='#a6b2c5',wraplength=540,justify='left').pack(anchor='w',padx=22,pady=(0,14))
        row=ctk.CTkFrame(card,fg_color='transparent');row.pack(fill='x',padx=22,pady=(0,18))
        ctk.CTkButton(row,text='Copy address',command=self._copy_mobile_preview_url,fg_color='#315c50',hover_color='#3e7465').pack(side='left')
        def open_local():
            try:
                import webbrowser;webbrowser.open(url)
            except Exception as error:self.status.set(f'Could not open Mobile Preview in browser: {error}')
        ctk.CTkButton(row,text='Open on this PC',command=open_local,fg_color='#252e3e',hover_color='#36445b').pack(side='left',padx=8)
        def stop_and_close():
            self.stop_mobile_preview();window.destroy()
        ctk.CTkButton(row,text='Stop Mobile Preview',command=stop_and_close,fg_color='#6b3030',hover_color='#814040').pack(side='right')
        window.protocol('WM_DELETE_WINDOW',window.destroy)
        self.status.set('Mobile Preview is live. Open the local address on a phone connected to the same network.')

    def export_preview(self):
        if not self.plan:self.status.set('Select an image first.');return
        path=filedialog.asksaveasfilename(defaultextension='.png',filetypes=[('PNG image','*.png')],initialfile='DrawStudio-preview.png')
        if path:
            try:self.plan['preview'].save(path);self.status.set('Preview saved.')
            except OSError as error:self.status.set(f'Could not save: {error}')

    def reuse_area(self):
        if self.saved_area:
            self.corners=[tuple(p) for p in self.saved_area]
            if min(self.area()[2:])<10:self.corners=[];self.status.set('The saved area is too small. Select a new one.');return
            try:self.capture_target()
            except (OSError,ValueError,AttributeError,InterruptedError) as error:
                self.corners=[];self.status.set(str(error));return
            self.area_text.set(f'✓ {self.area()[2]} × {self.area()[3]} px. Make sure the target application remains in the same position.')
            self.small_test_passed=False
            self.set_busy(None);self._mark_plan_stale('Drawing area restored. Press Build preview or Safety preflight / Dry run when ready.');self._maybe_auto_preview(delay=900, reason='reuse-area')

    def set_boundary(self):
        if self.activity:return
        from RegionPicker import select_region
        self.stop.clear();self.set_busy('capture')
        log_event('Drawing-area selection started.')
        def selected(box,image):
            left,top,right,bottom=map(int,box)
            width,height=right-left,bottom-top
            log_event(f'Drawing-area selected: box={(left,top,right,bottom)} size={(width,height)}')
            if width < 10 or height < 10:
                raise ValueError('The drawing area is too small. Select at least 10 × 10 pixels.')
            if width > 20000 or height > 20000:
                raise ValueError('The drawing area is unexpectedly large. Check Windows display scaling and select it again.')
            old=self.corners;old_anchor=self.canvas_anchor_detection;old_target=self.target_window;old_client=self.target_client_rect;old_dpi=self.target_dpi
            self.corners=[(left,top),(right,bottom)]
            try:
                from CanvasAnchorDetection import detect_canvas_anchors
                detected=detect_canvas_anchors(image)
                self.canvas_anchor_detection=detected.as_options()
                log_event(f'Canvas anchors detected: corners={detected.corner_count}/4 triangles={detected.triangle_count}/{detected.expected_triangles} confidence={detected.confidence:.3f}.')
            except Exception as anchor_error:
                self.canvas_anchor_detection=None
                log_event(f'Canvas anchor detection skipped; rectangle fallback remains active: {anchor_error!r}')
            try:
                self.capture_target()
                log_event(f'Drawing-area target captured safely: {self.target_window!r}')
            except Exception:
                self.corners=old;self.canvas_anchor_detection=old_anchor;self.target_window=old_target;self.target_client_rect=old_client;self.target_dpi=old_dpi
                raise
            self.saved_area=[tuple(p) for p in self.corners]
            self.small_test_passed=False;self.color_session_cache.clear()
            
            anchor_meta=(self.canvas_anchor_detection or {}).get('canvas_anchor_meta',{}) if isinstance(self.canvas_anchor_detection,dict) else {}
            tri_count=int(anchor_meta.get('triangle_count',0) or 0) if isinstance(anchor_meta,dict) else 0
            area_suffix=f'anchors 4/4 corners, {tri_count}/6 triangles'
            if self.game.get()=='Gartic Phone':
                try:
                    from GarticPhoneLayout import assess_canvas_size
                    from GarticEngineV2 import detect_gartic_canvas
                    gartic_layout=assess_canvas_size(width,height)
                    detected_canvas=detect_gartic_canvas(image)
                    if gartic_layout['likely']:
                        area_suffix += f" · Gartic canvas ✓ {gartic_layout['aspect']:.2f}:1"
                        log_event(f"Gartic Phone Engine v2 canvas geometry matched reference: aspect={gartic_layout['aspect']:.3f} confidence={gartic_layout['confidence']:.3f} detector={detected_canvas.confidence:.3f}.")
                    else:
                        area_suffix += f" · check Gartic canvas ({gartic_layout['aspect']:.2f}:1)"
                        log_event(f"Gartic Phone Engine v2 canvas geometry warning: selected aspect={gartic_layout['aspect']:.3f}, reference={gartic_layout['reference_aspect']:.3f}, detector={detected_canvas.confidence:.3f}.")
                except Exception as layout_error:
                    log_event(f'Gartic Phone layout check skipped: {layout_error!r}')
            self.area_text.set(f'✓ {width} × {height} px · {area_suffix}')
            self.save_settings();self._schedule_recovery_checkpoint(delay=100);self.set_busy(None)
            # RegionPicker restores the main window immediately after this callback.
            # Do not auto-build a heavy plan in Manual mode; configuration must
            # never feel like drawing/planning has started by itself.
            self._mark_plan_stale('Drawing area saved. Press Build preview or Safety preflight / Dry run when ready.')
            self._maybe_auto_preview(delay=900, reason='area-selected')
            self.show_previews()
            self.status.set('Drawing area saved and target window locked. Preview is manual by default.')
            try:
                from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
                profile_key=PROFILES.get(self.game.get(),('',))[0]
                if profile_key in SUPPORTED_BROWSER_PROFILES:
                    self.browser_auto_text.set('Canvas selected · automatic browser palette setup will start now.')
                    self.root.after(450,lambda:self.auto_calibrate_browser_profile(automatic=True))
            except Exception as auto_error:
                log_event(f'Browser Auto Setup scheduling skipped: {auto_error!r}')
        def failed(message):
            log_event(f'Drawing-area selection failed/aborted: {message}')
            self.set_busy(None);self.status.set(message)
        select_region(self.root,selected,failed)

    def refresh_exact_color_status(self):
        try:
            key=PROFILES[self.game.get()][0]
            custom=custom_rgb_available(key);eye=eyedropper_available(key);spectrum=spectrum_available(key);numeric=numeric_rgb_available(key)
            if custom:
                modes=[]
                if spectrum:modes.append('visual color scale')
                if numeric:modes.append('numeric RGB')
                self.exact_color_text.set('✓ Smart custom palette calibrated: '+ ' + '.join(modes) + '. Draw Studio chooses the requested color, then falls back to the nearest calibrated palette swatch if needed.' + (' Eyedropper reuse is also calibrated.' if eye else ''))
            elif eye:
                self.exact_color_text.set('Eyedropper is calibrated, but no exact color scale/RGB selector is complete. Nearest calibrated palette fallback remains active.')
            else:
                self.exact_color_text.set('Optional: calibrate the custom color spectrum/scale. Draw Studio can click the nearest visible point for each requested RGB; normal palette fallback always remains available.')
        except Exception:
            self.exact_color_text.set('Smart custom palette setup unavailable; nearest calibrated palette fallback remains active.')

    def calibrate_exact_colors(self):
        if self.activity or self.closing:return
        from RuntimePaths import helper_command
        import subprocess
        key=PROFILES[self.game.get()][0];log=BASE/'logs'/'DrawStudio-exact-color-calibration.log';log.parent.mkdir(parents=True,exist_ok=True)
        command=helper_command('exactcolor','--profile',key,'--log',str(log))
        self.status.set('Opening isolated smart custom palette calibration. Main drawing input remains DISARMED.')
        def work():
            started=time.monotonic()
            try:
                proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
                while True:
                    try:
                        output,_=proc.communicate(timeout=.10);code=proc.returncode;break
                    except subprocess.TimeoutExpired:
                        if self.stop.is_set():
                            proc.kill();proc.communicate();raise InterruptedError('Custom colour calibration cancelled.')
            except InterruptedError:raise
            except Exception as error:code=-1;output=repr(error)
            self.events.put(('exact_color_calibration_complete',{'code':code,'output':output[-1200:],'elapsed':time.monotonic()-started}))
        self.begin_worker('exact-color-calibration',work)

    def calibrate(self):
        """Open palette calibration in a protected helper process.

        The palette picker touches Tk image objects, screen capture and Win32 mouse/window
        APIs.  A native/GUI failure there must never terminate the main Draw Studio UI.
        """
        if self.activity:return
        import subprocess
        profile_key=PROFILES[self.game.get()][0]
        palette_log=BASE/'logs'/'DrawStudio-palette-calibration.log'
        log_event(f'Isolated color calibration requested: profile={profile_key!r}. Mouse input remains DISARMED.')
        def work():
            from RuntimePaths import helper_command
            command=helper_command('palette','--path',str(self.calibration_path),'--profile',profile_key,'--log',str(palette_log))
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)
            process=None;output=''
            started=time.monotonic()
            try:
                process=subprocess.Popen(command,cwd=BASE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                         text=True,encoding='utf-8',errors='replace',creationflags=creationflags)
                self.palette_probe_process=process
                self.events.put(('status','🎨 Color calibration is open in a protected process. Main Draw Studio will stay safe if the calibration window fails.'))
                while True:
                    try:
                        output=process.communicate(timeout=.10)[0] or ''
                        break
                    except subprocess.TimeoutExpired:
                        if self.stop.is_set():
                            process.kill();process.communicate()
                            raise InterruptedError('Color calibration cancelled.')
            finally:
                self.palette_probe_process=None
            code=process.returncode if process else -1
            launcher_log=BASE/'logs'/'DrawStudio-palette-launcher.log'
            try:
                launcher_log.parent.mkdir(parents=True,exist_ok=True)
                launcher_log.write_text(f'Command: {command!r}\nExit: {code}\nElapsed: {time.monotonic()-started:.3f}s\n\n{output}',encoding='utf-8')
            except OSError:pass
            log_event(f'Isolated color calibration exited code={code} after {time.monotonic()-started:.3f}s.')
            self.events.put(('palette_calibration_complete',{'code':code,'output':output[-1600:],'log':str(palette_log)}))
        self.begin_worker('calibration',work)

    def _browser_layout_state(self, *, client_rect=None, dpi=None):
        """Return client-relative browser canvas/palette geometry for change detection."""
        try:
            from BrowserAutoRecalibration import make_layout_state
            client=tuple(client_rect or getattr(self,'target_client_rect',None) or ())
            if len(client)!=4 or len(getattr(self,'corners',()))!=2:
                return None
            x,y,w,h=self.area();canvas=(x,y,x+w,y+h)
            palette=[(int(c.x),int(c.y)) for c in allColors] if bool(getattr(self,'palette_ready',False)) else []
            return make_layout_state(client, dpi if dpi is not None else getattr(self,'target_dpi',None), canvas, palette)
        except (ValueError,TypeError,AttributeError):
            return None

    def _auto_recalibrate_browser_from_meta(self, meta, *, reason='pre-input verification'):
        previous=getattr(self,'drop_in_sync_phase',DROP_SYNC_IDLE)
        self.drop_in_sync_phase=DROP_SYNC_AUTO_RECALIBRATING
        try:
            return DrawBotApp._auto_recalibrate_browser_from_meta_impl(self,meta,reason=reason)
        except Exception as error:
            if getattr(self,'pending_drop_in_import',None) is not None or normalize_drop_in_action(getattr(self,'drop_action_pending',None))==DROP_IN_ACTION:
                DrawBotApp._disarm_manual_drop_in(self,'browser auto-recalibration failed while Drop-In was waiting')
                try:self.status.set(f'Drop-In blocked: Auto-Recalibration failed: {error}')
                except Exception:pass
            raise
        finally:
            if getattr(self,'drop_in_sync_phase',None)==DROP_SYNC_AUTO_RECALIBRATING:
                self.drop_in_sync_phase=previous if previous!=DROP_SYNC_PENDING else DROP_SYNC_PENDING
            if getattr(self,'pending_drop_in_import',None) is not None or normalize_drop_in_action(getattr(self,'drop_action_pending',None))==DROP_IN_ACTION:
                DrawBotApp._schedule_drop_in_sync_tick(self,40)

    def _auto_recalibrate_browser_from_meta_impl(self, meta, *, reason='pre-input verification'):
        """Read-only rescan of supported browser games before any native input.

        Unlike the old Anchor Transform path, browser layouts may reflow while the
        outer Chrome client rectangle stays identical (browser zoom is the common
        case).  Therefore supported browser profiles are visually re-detected and
        their anchored palette is rewritten before coordinates can be armed.
        """
        try:
            from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES, auto_calibrate_browser
            from BrowserAutoRecalibration import compare_layout_states
            profile_name=self.game.get();profile_key=PROFILES.get(profile_name,('',))[0]
        except Exception as error:
            raise ValueError(f'Browser Auto-Recalibration is unavailable: {error}') from error
        if profile_key not in SUPPORTED_BROWSER_PROFILES:
            return False
        client=tuple(meta.get('client_rect') or ())
        if len(client)!=4:
            raise ValueError('Browser Auto-Recalibration could not read the browser client rectangle.')
        before=DrawBotApp._browser_layout_state(self)
        # The scan must see the browser itself, not Draw Studio or another window
        # covering it. Activating the existing target changes no canvas content and
        # sends no mouse/keyboard events.
        try:
            from ScreenGuard import WindowMonitor
            monitor=WindowMonitor();handle=int(meta['handle']);rect=tuple(meta['rect'])
            if not monitor.activate((handle,rect)):
                raise ValueError('Windows could not activate the selected browser for read-only auto-recalibration.')
            time.sleep(.18)
            rect=tuple(monitor.rectangle(handle));client=tuple(monitor.client_rectangle(handle));dpi=monitor.dpi(handle)
            meta=dict(meta);meta.update({'handle':handle,'rect':rect,'client_rect':client,'dpi':dpi})
        except InterruptedError as error:
            raise ValueError(f'Browser Auto-Recalibration could not verify the target browser: {error}') from error
        if uses_paint_color(self):
            from PIL import ImageGrab
            from BrowserAutoCalibration import detect_browser_canvas
            shot=ImageGrab.grab(bbox=client,all_screens=True).convert('RGB')
            detected=detect_browser_canvas(profile_key,shot,screen_origin=client[:2])
            canvas=detected['canvas_box']
            if canvas is None or detected['canvas_confidence']<.70:
                raise ValueError('Single-color sketch could not verify the game canvas. Show a blank drawing canvas and select the area again.')
            l,t,r,b=map(int,canvas)
            if r-l<40 or b-t<40 or not (client[0]<=l<r<=client[2] and client[1]<=t<b<=client[3]):
                raise ValueError('Detected sketch canvas is outside the browser or too small.')
            self.corners=[(l,t),(r,b)];self.saved_area=list(self.corners)
            self.target_window=(handle,tuple(meta['rect']))
            self.target_client_rect=client;self.target_dpi=meta.get('dpi')
            self.canvas_anchor_detection=None
            self.color_session_cache.clear()
            log_event('Single-color browser canvas verified without palette calibration or input.')
            return True
        # v1.0.76: reuse an already verified client-size/DPI/zoom-layout
        # fingerprint before running the heavier full palette/canvas detector.
        # Cache verification samples only saved palette control points and emits
        # no input. Browser Visual Preflight still runs before real drawing.
        from LayoutFingerprintV2 import try_restore, record_from_calibration_file
        from PIL import ImageGrab
        screenshot=ImageGrab.grab(bbox=client,all_screens=True).convert('RGB')
        cached=try_restore(profile_key,meta,Path(self.calibration_path),screenshot=screenshot)
        cache_hit=bool(cached.hit)
        if cache_hit:
            class _CachedResult:
                canvas_box=cached.canvas_box
                canvas_confidence=max(.90,cached.confidence)
                palette_count=cached.palette_count
                confidence=cached.confidence
                method='Layout Fingerprint v2 cache'
            result=_CachedResult()
        else:
            result=auto_calibrate_browser(profile_key,meta,Path(self.calibration_path),screenshot=screenshot)
            try:
                if result.canvas_box:
                    record_from_calibration_file(profile_key,meta,result.canvas_box,Path(self.calibration_path),method=result.method)
            except Exception as fingerprint_error:
                log_event(f'Layout Fingerprint v2 save skipped: {fingerprint_error!r}')
        canvas=result.canvas_box
        if not isinstance(canvas,(tuple,list)) or len(canvas)!=4 or float(result.canvas_confidence)<.70:
            raise ValueError(
                f'Browser Auto-Recalibration could not verify the canvas safely '
                f'(confidence {float(result.canvas_confidence)*100:.0f}%). No mouse input was sent.')
        l,t,r,b=map(int,canvas)
        if r-l<40 or b-t<40:
            raise ValueError('Browser Auto-Recalibration detected an implausibly small canvas. No mouse input was sent.')
        # Validate containment before mutating the live setup.
        if not (client[0] <= l < r <= client[2] and client[1] <= t < b <= client[3]):
            raise ValueError('Browser Auto-Recalibration detected a canvas outside the browser client area. No mouse input was sent.')

        self.corners=[(l,t),(r,b)];self.saved_area=[(l,t),(r,b)]
        self.target_window=(int(meta['handle']),tuple(meta['rect']))
        self.target_client_rect=client;self.target_dpi=meta.get('dpi')
        self.canvas_anchor_detection=None
        self.color_session_cache.clear()
        DrawBotApp.refresh_palette(self)
        if not bool(getattr(self,'palette_ready',False)):
            raise ValueError('Browser Auto-Recalibration saved the palette but it could not be reloaded safely. No mouse input was sent.')
        after=DrawBotApp._browser_layout_state(self,client_rect=client,dpi=meta.get('dpi'))
        delta=compare_layout_states(before,after,tolerance_px=4)
        self.canvas_anchor_transform_meta={
            'method':'browser-visual-recalibration','changed':bool(delta.changed),
            'reason':delta.reason,'max_palette_shift':int(delta.max_palette_shift),
            'max_canvas_shift':int(delta.max_canvas_shift),
            'confidence':float(result.confidence),
        }
        if delta.changed:
            # A new final plan will use the new geometry. Old safety simulations
            # are deliberately not carried across a real browser reflow.
            DrawBotApp._invalidate_safety_preflight(self,'browser layout auto-recalibrated',disarm=True)
            try:self.browser_auto_text.set(f'✓ Auto-recalibrated · {result.palette_count} colors · {delta.reason}.')
            except Exception:pass
            try:self.status.set(f'Browser layout changed ({delta.reason}). Auto-recalibration passed; no manual calibration needed.')
            except Exception:pass
            log_event(
                f'Browser Auto-Recalibration applied: profile={profile_name!r} reason={reason!r} '
                f'change={delta.reason!r} colors={result.palette_count} confidence={result.confidence:.3f} cache_hit={cache_hit} '
                f'canvas={tuple(canvas)!r}.')
        else:
            log_event(
                f'Browser Auto-Recalibration verified unchanged layout: profile={profile_name!r} '
                f'reason={reason!r} colors={result.palette_count} confidence={result.confidence:.3f} cache_hit={cache_hit}.')
        try:self.save_settings()
        except Exception:pass
        return bool(delta.changed)

    def _run_browser_visual_preflight(self, current_client, *, reason='before drawing'):
        previous=getattr(self,'drop_in_sync_phase',DROP_SYNC_IDLE)
        self.drop_in_sync_phase=DROP_SYNC_VISUAL_PREFLIGHT
        try:
            return DrawBotApp._run_browser_visual_preflight_impl(self,current_client,reason=reason)
        except Exception as error:
            if getattr(self,'pending_drop_in_import',None) is not None or normalize_drop_in_action(getattr(self,'drop_action_pending',None))==DROP_IN_ACTION:
                DrawBotApp._disarm_manual_drop_in(self,'browser visual preflight failed while Drop-In was waiting')
                try:self.status.set(f'Drop-In blocked: Visual Preflight failed: {error}')
                except Exception:pass
            raise
        finally:
            if getattr(self,'drop_in_sync_phase',None)==DROP_SYNC_VISUAL_PREFLIGHT:
                self.drop_in_sync_phase=previous if previous!=DROP_SYNC_PENDING else DROP_SYNC_PENDING
            if getattr(self,'pending_drop_in_import',None) is not None or normalize_drop_in_action(getattr(self,'drop_action_pending',None))==DROP_IN_ACTION:
                DrawBotApp._schedule_drop_in_sync_tick(self,40)

    def _run_browser_visual_preflight_impl(self, current_client, *, reason='before drawing'):
        """Read-only final browser check immediately before planning/input.

        Auto-Recalibration already refreshes geometry. Visual Preflight then
        independently verifies that the expected canvas and representative
        palette swatches are still visible at those coordinates. A mismatch gets
        one automatic re-scan/recalibration retry; persistent mismatch blocks
        drawing before native mouse input is armed.
        """
        try:
            from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
            from BrowserVisualPreflight import verify_browser_visual_preflight
            profile_name=self.game.get();profile_key=PROFILES.get(profile_name,('',))[0]
        except Exception as error:
            raise ValueError(f'Browser Visual Preflight is unavailable: {error}') from error
        if profile_key not in SUPPORTED_BROWSER_PROFILES:
            return current_client

        def verify(client):
            x,y,w,h=self.area();canvas=(x,y,x+w,y+h)
            palette_entries=[((int(c.x),int(c.y)),tuple(c.RGB)) for c in allColors]
            meta={
                'handle':int(self.target_window[0]),
                'rect':tuple(self.target_window[1]),
                'client_rect':tuple(client),
                'dpi':getattr(self,'target_dpi',None),
            }
            if uses_paint_color(self):
                return verify_browser_visual_preflight(profile_key,meta,canvas,(),require_palette=False)
            return verify_browser_visual_preflight(profile_key,meta,canvas,palette_entries)

        result=verify(current_client)
        if not result.passed:
            log_event(
                f'Browser Visual Preflight initial mismatch: profile={profile_name!r} reason={result.reason!r} '
                f'canvas_ok={result.canvas_ok} palette={result.palette_verified}/{result.palette_tested} '
                f'confidence={result.confidence:.3f}. Retrying read-only Auto-Recalibration.')
            from TargetCapture import probe_handle_isolated
            meta=probe_handle_isolated(int(self.target_window[0]))
            DrawBotApp._auto_recalibrate_browser_from_meta(self,meta,reason='visual preflight recovery')
            current_client=tuple(getattr(self,'target_client_rect',None) or meta.get('client_rect') or ())
            if len(current_client)!=4:
                raise ValueError('Browser Visual Preflight recovery could not read the browser client rectangle. No mouse input was sent.')
            if not bypasses_palette(self):
                load_calibration(self.calibration_path,current_client_rect=current_client,require_anchor=False)
            result=verify(current_client)

        if not result.passed:
            try:self.browser_auto_text.set(
                f'Visual preflight blocked · canvas={"OK" if result.canvas_ok else "FAIL"} · '
                f'palette={result.palette_verified}/{result.palette_tested}.')
            except Exception:pass
            raise ValueError(
                f'Browser Visual Preflight failed after automatic recalibration: {result.reason}. '
                'The page, canvas or palette does not match the calibrated browser layout. No mouse input was sent.')

        try:self.browser_auto_text.set(
            f'✓ Visual preflight PASS · canvas verified · palette {result.palette_verified}/{result.palette_tested} · '
            f'confidence {result.confidence*100:.0f}%.')
        except Exception:pass
        log_event(
            f'Browser Visual Preflight passed: profile={profile_name!r} reason={reason!r} '
            f'canvas_ok={result.canvas_ok} palette={result.palette_verified}/{result.palette_tested} '
            f'confidence={result.confidence:.3f} max_palette_error={result.max_palette_error:.1f}.')
        return current_client

    def capture_target(self):
        # WindowFromPoint/GetWindowRect/GetClientRect are native Win32 calls. Run
        # them outside the GUI process so an access violation cannot close it.
        import os
        from TargetCapture import capture_target_metadata_isolated
        meta=capture_target_metadata_isolated(self.area(),exclude_pid=os.getpid())
        self.target_window=(meta['handle'],meta['rect'])
        self.target_client_rect=meta['client_rect']
        self.target_dpi=meta.get('dpi')
        if self.target_dpi:
            log_event(f'Target DPI captured: {self.target_dpi} ({self.target_dpi/96:.2f}x scale).')

    def _carry_safety_signatures_after_rebase(self, old_signature):
        """Keep preflight/dry-run valid after a mathematically safe target rebase."""
        try:
            new_signature=DrawBotApp._current_safety_signature(self)
            if bool(getattr(self,'safety_preflight_passed',False)) and getattr(self,'safety_preflight_signature',None)==old_signature:
                self.safety_preflight_signature=new_signature
            if bool(getattr(self,'dry_run_passed',False)) and getattr(self,'dry_run_signature',None)==old_signature:
                self.dry_run_signature=new_signature
        except Exception:
            # Do not fail drawing because a UI-only validity cache could not be carried.
            pass

    def _refresh_target_for_draw(self, *, update_target_lock=True):
        """Refresh/rebase target geometry before any input is armed.

        v1.0.50: same-size window movement is rebased through Anchor Transform.
        Very small client-size changes can also be rebased with the saved
        corner/triangle anchors. Supported browser profiles are different:
        Gartic/Skribbl/SketchHeads are visually re-scanned before input so Chrome
        zoom, resize and DPI/layout reflow can auto-recalibrate safely.
        """
        if self.target_window is None:raise ValueError('Select the drawing area again to lock the correct window.')
        from TargetCapture import probe_handle_isolated
        handle=self.target_window[0];meta=probe_handle_isolated(handle)
        current=tuple(meta['client_rect'])
        current_dpi=meta.get('dpi')
        selected_dpi=getattr(self,'target_dpi',None)
        try:
            from BrowserAutoCalibration import SUPPORTED_BROWSER_PROFILES
            profile_key=PROFILES.get(self.game.get(),('',))[0]
            browser_profile=profile_key in SUPPORTED_BROWSER_PROFILES
        except Exception:
            browser_profile=False
        if browser_profile:
            # Browser zoom can reflow canvas/palette without changing the Chrome
            # window/client rectangle at all. Always perform a visual read-only
            # verification before coordinates can be armed.
            DrawBotApp._auto_recalibrate_browser_from_meta(self,meta,reason='pre-input target refresh')
            current=tuple(self.target_client_rect);current_dpi=getattr(self,'target_dpi',current_dpi)
            selected_dpi=current_dpi
            old=current
        else:
            if selected_dpi is not None and current_dpi is not None and current_dpi!=selected_dpi:
                raise ValueError(
                    f'The target DPI changed from {selected_dpi} to {current_dpi}. Paint likely moved to a display with different scaling. '
                    'Select the drawing area again so physical pixel coordinates can be recalibrated. No mouse input was sent.')
            old=tuple(self.target_client_rect) if self.target_client_rect is not None else current
        old_size=(old[2]-old[0],old[3]-old[1]);new_size=(current[2]-current[0],current[3]-current[1])
        old_area=self.area()
        try:old_safety_signature=DrawBotApp._current_safety_signature(self)
        except Exception:old_safety_signature=None
        moved_or_scaled=(old!=current)
        if not browser_profile:
            self.canvas_anchor_transform_meta=None
        if moved_or_scaled:
            try:
                rebased_area,transform=rebase_canvas_area(
                    old_area, old, current, getattr(self,'canvas_anchor_detection',None),
                    max_scale_delta=0.025, max_size_delta_px=32)
            except ValueError as error:
                raise ValueError(
                    f'The target window changed size from {old_size[0]}×{old_size[1]} to {new_size[0]}×{new_size[1]}. '
                    f'Anchor Transform could not safely rebase the canvas: {error} Select the drawing area again. No mouse input was sent.') from error
            if not area_inside_client(rebased_area,current,margin=0):
                raise ValueError('Anchor Transform would place the drawing area outside the target client area. Select the drawing area again. No mouse input was sent.')
            x,y,w,h=rebased_area
            self.corners=[(int(x),int(y)),(int(x+w),int(y+h))]
            self.saved_area=[tuple(p) for p in self.corners]
            self.canvas_anchor_transform_meta=transform.as_dict()
            log_event(
                f'Anchor Transform rebased drawing area: method={transform.method} dx={transform.dx:.2f} dy={transform.dy:.2f} '
                f'sx={transform.sx:.6f} sy={transform.sy:.6f} anchors={transform.used_anchors} triangles={transform.used_triangles}.')
        self.target_client_rect=current
        self.target_dpi=current_dpi if current_dpi is not None else selected_dpi
        self.target_window=(handle,tuple(meta['rect']))
        x,y,w,h=self.area()
        if not (current[0]<=x and current[1]<=y and x+w<=current[2] and y+h<=current[3]):
            raise ValueError('The drawing area is no longer fully inside the target client area. Select it again.')
        if update_target_lock and bool(getattr(self,'target_lock_passed',False)) and getattr(self,'target_lock_fingerprint',None):
            try:
                fingerprint=DrawBotApp._build_target_lock_fingerprint(self,current_client_rect=current,current_target_rect=self.target_window[1],current_dpi=self.target_dpi)
                self.target_lock_fingerprint=fingerprint
                self.target_lock_signature=DrawBotApp._target_lock_signature_from(fingerprint)
                DrawBotApp._carry_safety_signatures_after_rebase(self, old_safety_signature)
                if moved_or_scaled:
                    log_event('Target/setup lock fingerprint rebased after safe Anchor Transform.')
            except Exception as error:
                raise ValueError(f'Anchor Transform rebased the canvas, but the target lock could not be refreshed: {error}') from error
        return current

    def draw(self,test=False,dry_run=False,user_initiated=False):
        # Loading, dropping, profile switching and background callbacks must
        # never arm the mouse. Only explicit UI controls pass this flag.
        if not user_initiated:
            log_event('Blocked non-user-initiated drawing request.')
            self.status.set('Drawing did not start. Use Unlock full drawing, then Start Drawing, or run Draw small test explicitly.')
            return
        if self.activity or self.closing:return
        DrawBotApp._cancel_after_attr(self,'preview_after')
        DrawBotApp._cancel_after_attr(self,'preview_render_after')
        if not test and not dry_run:DrawBotApp._disarm_full_draw(self,'drawing started', update_text=True)
        action_label = 'small test' if test else ('dry run' if dry_run else 'drawing')
        log_event(f'User initiated {action_label}.')
        if len(self.corners)!=2:
            log_event('Drawing blocked: no drawing area selected.')
            self.status.set('Select the drawing area first.');return
        if self.original is None and not test:
            log_event('Drawing blocked: no source image loaded.')
            self.status.set('Load or paste an image before pressing Start Drawing.')
            try:self.summary.set('No image loaded. Choose an image, paste with Ctrl+V, or drag a file into Draw Studio first.')
            except (tk.TclError,AttributeError):pass
            return
        try:
            if not test and DrawBotApp._strict_safety_required(self):
                DrawBotApp._verify_target_lock(self)
            paint_profile=self.game.get()=='Microsoft Paint'
            current_client=self._refresh_target_for_draw()
            if not bypasses_palette(self):
                load_calibration(self.calibration_path,current_client_rect=current_client,require_anchor=paint_profile)
            current_client=DrawBotApp._run_browser_visual_preflight(self,current_client,reason=action_label)
            area=self.area()
            palette=() if bypasses_palette(self) else tuple((c.x,c.y) for c in allColors)
            if min(area[2:])<10:raise ValueError('Select a larger drawing area.')
            if any(area[0]<=x<=area[0]+area[2] and area[1]<=y<=area[1]+area[3] for x,y in palette):
                raise ValueError('The color palette overlaps the drawing area. Select only the canvas.')
            options=self.options()
            profile_key=PROFILES[self.game.get()][0]
            # v1.0.74: browser brush size is detected read-only from the already
            # verified layout. Only a visually plausible control row produces a
            # click target; otherwise execution leaves the website untouched and
            # uses a conservative CanvasGuard brush inset.
            try:
                from BrowserBrushSize import SUPPORTED as BRUSH_PROFILES,plan_browser_brush_size
                if profile_key in BRUSH_PROFILES:
                    from PIL import ImageGrab
                    shot=ImageGrab.grab(bbox=tuple(current_client),all_screens=True).convert('RGB')
                    pal_box=None
                    if palette:
                        xs=[p[0] for p in palette];ys=[p[1] for p in palette]
                        pal_box=(min(xs),min(ys),max(xs)+1,max(ys)+1)
                    x,y,w,h=area
                    brush_plan=plan_browser_brush_size(profile_key,shot,tuple(current_client),
                        canvas_box=(x,y,x+w,y+h),palette_box=pal_box,requested_px=options.get('brush_px',3))
                    options['browser_brush_plan']=brush_plan.as_dict()
                    options['brush_px']=int(brush_plan.effective_px)
                    options['canvas_guard_brush_px']=int(brush_plan.safe_guard_px)
                    log_event(f"Automatic browser brush preflight: profile={profile_key} requested={brush_plan.requested_px}px effective={brush_plan.effective_px}px target={brush_plan.target_position!r} selected={brush_plan.selected_index!r} confidence={brush_plan.confidence:.3f} guard={brush_plan.safe_guard_px}px.")
            except Exception as brush_error:
                # Brush automation is an optimization/convenience layer. A
                # detector failure must not invent clicks; keep the current brush
                # and enlarge only the safety inset.
                options['canvas_guard_brush_px']=max(int(options.get('brush_px',3) or 3),12)
                options['browser_brush_plan']={'target_position':None,'safe_guard_px':options['canvas_guard_brush_px'],'method':str(brush_error)}
                log_event(f'Automatic browser brush detection fell back safely: {brush_error!r}.')
            if options.get('custom_color_workflow') in ('Exact custom + palette fallback','Adaptive exact (recommended)'):
                try:
                    exact_actions=resolve_exact_color_controls(profile_key,current_client)
                    required=('OpenCustomColor','RedField','GreenField','BlueField','ConfirmColor')
                    options['exact_color_actions']=exact_actions
                    options['exact_color_available']=all(name in exact_actions for name in required)
                except (OSError,ValueError,TypeError):
                    options['exact_color_actions']={}
                    options['exact_color_available']=False
            log_event(f"Draw preflight options resolved: area={area} source={getattr(self.original, 'size', None)} profile={self.game.get()!r} paint_profile={paint_profile!r} palette_points={len(palette)} {_resource_log_text(options)}.")
            # Real tool actions were previously built only for preview planning,
            # leaving real drawing with an empty action list. Resolve them here.
            if paint_profile and options.get('effective_paint_tool',options.get('paint_tool'))!='Use current tool':
                from PaintTools import build_tool_actions
                options['tool_actions']=build_tool_actions(options.get('effective_paint_tool',options['paint_tool']),current_client_rect=current_client)
                for kind,position in options['tool_actions']:
                    x,y=position
                    if area[0]<=x<=area[0]+area[2] and area[1]<=y<=area[1]+area[3]:
                        raise ValueError(f'The calibrated Paint {kind} control overlaps the drawing area. Recalibrate Paint tools.')
            options['fill_tool_actions']=[];options['fill_restore_actions']=[]
            options['fill_unavailable_reason']=''
            if options.get('background_fill')!='Off' and not bypasses_palette(self):
                if paint_profile and options.get('paint_tool') not in ('Use current tool','Eraser'):
                    try:
                        from PaintTools import build_tool_actions
                        options['fill_tool_actions']=build_tool_actions('Fill',current_client_rect=current_client)
                        options['fill_restore_actions']=list(options.get('tool_actions',[]))
                    except (OSError,ValueError) as error:
                        options['fill_unavailable_reason']=str(error)
                elif not paint_profile:
                    try:
                        from AppTools import build_tool_action
                        profile_key=PROFILES[self.game.get()][0]
                        options['fill_tool_actions']=[build_tool_action(profile_key,'Fill',current_client)]
                        options['fill_restore_actions']=[build_tool_action(profile_key,'Brush',current_client)]
                    except (OSError,ValueError) as error:
                        options['fill_unavailable_reason']=str(error)
                options['fill_tool_available']=bool(options.get('fill_tool_actions') and options.get('fill_restore_actions'))
                for kind,position in options.get('fill_tool_actions',[])+options.get('fill_restore_actions',[]):
                    x,y=position
                    if area[0]<=x<=area[0]+area[2] and area[1]<=y<=area[1]+area[3]:
                        raise ValueError(f'The calibrated {kind} control overlaps the drawing area. Recalibrate application tools.')
        except (OSError,ValueError,InterruptedError) as error:
            self.status.set(f'Preflight stopped: {error}');return
        from ScreenGuard import GuardedMouse,WindowMonitor
        runtime_palette_guard=runtime_palette_guard_colors(profile_key,palette,allColors)
        if palette and not runtime_palette_guard:
            log_event(f"Runtime palette guard delegated to Browser Visual Preflight: profile={profile_key!r} swatches={len(palette)}.")
        guarded=GuardedMouse(self.mouse,WindowMonitor(),self.target_window,runtime_palette_guard,live_target_check=self._make_live_target_check() if (not test and DrawBotApp._strict_safety_required(self) and DrawBotApp._target_lock_valid(self)) else None)
        original=self.original.copy() if self.original else None
        if test:
            if options.get('erase_mode'):
                prompt='This erases one short line in the selected drawing area. Put a visible mark under the test area first so you can confirm the Eraser works. Continue?'
            else:
                prompt='This draws up to three lines in the selected drawing area. Use an empty test canvas. Continue?'
            if not messagebox.askokcancel('Drawing test',prompt):return
        self.paused.clear();self.progress['value']=0;self.save_settings()
        def work():
            started=time.monotonic()
            if not test and not dry_run and profile_key=='gartic-phone' and options.get('read_gartic_timer') and not options.get('unlimited_time'):
                from GarticTimer import observe_timer,apply_timer_budget
                from PIL import ImageGrab
                # Give the UI's queued minimization time to finish; no input is armed.
                if self.stop.wait(.35):raise InterruptedError()
                monitor=WindowMonitor()
                if not monitor.activate(self.target_window):raise ValueError('Show the Gartic window to read its timer.')
                def timer_capture():
                    if not monitor.active(self.target_window):raise ValueError('Gartic must stay visible while reading the timer.')
                    if tuple(monitor.client_rectangle(self.target_window[0]))!=tuple(current_client):
                        raise ValueError('Gartic changed size while reading the timer. Select the area again.')
                    return ImageGrab.grab(bbox=tuple(current_client),all_screens=True).convert('RGB')
                local_canvas=(area[0]-current_client[0],area[1]-current_client[1],area[0]+area[2]-current_client[0],area[1]+area[3]-current_client[1])
                reading=observe_timer(timer_capture,local_canvas,self.stop,lambda msg:self.events.put(('status',msg)))
                options.update(apply_timer_budget(options,reading))
                log_event(f"Gartic timer measured: approximate={reading['estimated_seconds']:.1f}s safe={reading['safe_seconds']:.1f}s observed={reading['observed_seconds']:.1f}s box={reading['box']}.")
                self.events.put(('status',f"Gartic timer: approximately {reading['estimated_seconds']:.0f}s left; planning with {options['max_seconds']:.0f}s conservative budget."))
            if dry_run:
                self.events.put(('status','Building dry-run plan… No clicks will be sent during this test.'))
            else:
                self.events.put(('status','Building final drawing plan… CPU/GPU/RAM allocation is used here before mouse input starts.'))
            log_event(f"Final planning started: area={area[2:]} source={getattr(original, 'size', None)} test={test!r} dry_run={dry_run!r} watchdog={options.get('planning_watchdog','Auto')} {_resource_log_text(options)}.")
            attempts=build_planning_attempts(options,test=test,preview=False,dry_run=dry_run)
            plan=None
            last_timeout=None
            for attempt in attempts:
                if self.stop.is_set() or self.closing:
                    raise InterruptedError()
                attempt_started=time.monotonic()
                attempt_deadline=attempt_started+float(attempt.timeout_seconds)
                planning_done=threading.Event()
                self.events.put(('status',f'Final planning attempt {attempt.index}/{attempt.total}: {attempt.name}. No mouse input is armed.'))
                log_event(f"Final planning attempt {attempt.index}/{attempt.total} started: name={attempt.name!r} area={area[2:]} source={getattr(original, 'size', None)} test={test!r} timeout={attempt.timeout_seconds:.1f}s {_resource_log_text(attempt.options)}.")
                def heartbeat(attempt=attempt, attempt_started=attempt_started, attempt_deadline=attempt_deadline, planning_done=planning_done):
                    while not planning_done.wait(5.0):
                        if self.stop.is_set() or self.closing:
                            return
                        elapsed=time.monotonic()-attempt_started
                        remaining=max(0.0,attempt_deadline-time.monotonic())
                        self.events.put(('status',f'Final planning {attempt.index}/{attempt.total}: {elapsed:.0f}s elapsed, fallback in {remaining:.0f}s. No mouse input has been armed yet.'))
                        log_event(f'Final planning watchdog heartbeat: attempt={attempt.index}/{attempt.total} name={attempt.name!r} elapsed={elapsed:.1f}s remaining={remaining:.1f}s mode={attempt.options.get("drawing_mode")} resolution={attempt.options.get("planning_resolution")} cpu={attempt.options.get("cpu_workers_resolved")} engine={attempt.options.get("cpu_engine")} target={attempt.options.get("target_stroke_count_resolved")}.')
                threading.Thread(target=heartbeat,daemon=True,name=f'drawstudio-plan-watchdog-{attempt.index}').start()
                def attempt_cancelled(deadline=attempt_deadline):
                    return self.stop.is_set() or self.closing or time.monotonic() >= deadline
                try:
                    plan=make_test_plan(area[2:],attempt.options) if test else make_plan(original,area[2:],attempt.options,attempt_cancelled)
                    planning_done.set()
                    elapsed=time.monotonic()-attempt_started
                    if attempt.fallback:
                        self.events.put(('status',f'Watchdog fallback succeeded with {attempt.name} in {elapsed:.1f}s. Mouse input is still not armed until execution starts.'))
                    log_event(f"Final planning attempt {attempt.index}/{attempt.total} finished in {elapsed:.3f} s: {_plan_log_text(plan)}.")
                    break
                except InterruptedError:
                    planning_done.set()
                    if self.stop.is_set() or self.closing:
                        raise
                    if time.monotonic() >= attempt_deadline:
                        last_timeout=attempt
                        log_event(f'Final planning attempt {attempt.index}/{attempt.total} timed out before mouse input was armed. name={attempt.name!r}.')
                        if attempt.index < attempt.total:
                            self.events.put(('status',f'{attempt.name} took too long. Retrying with safer fallback settings…'))
                            continue
                        raise ValueError('Planning watchdog stopped all attempts before mouse input. Try Planning resolution Standard, Target stroke count 1000–2500, CPU engine Threads, and Color layers Off.')
                    raise
                except Exception:
                    planning_done.set()
                    raise
            if plan is None:
                label=last_timeout.name if last_timeout else 'no attempt'
                log_event(f'Final planning failed before mouse input was armed. last={label!r}.')
                raise ValueError('Final planning did not produce a plan. Lower planning resolution or use a smaller target stroke count.')
            if dry_run:
                original_count=int(plan.get('count') or 0)
                plan=sample_dry_run_plan(plan, execution_seconds=DRY_RUN_EXECUTION_SECONDS)
                dm=plan.get('options') or {}
                self.events.put(('status',f"Fast Dry run: sampling up to {int(dm.get('dry_run_sample_paths',plan.get('count',0))):,} representative paths from {original_count:,}. Cursor test budget {DRY_RUN_EXECUTION_SECONDS:.0f}s. Reaching the budget is a normal PASS if no safety check fails. No clicks."))
                log_event(f"Dry-run route sampled: paths={dm.get('dry_run_sample_paths',plan.get('count'))}/{dm.get('dry_run_total_paths',original_count)} colors={dm.get('dry_run_sample_colors','n/a')}/{dm.get('dry_run_total_colors','n/a')} max_seconds={DRY_RUN_EXECUTION_SECONDS}.")
            log_event(f"Final planning finished in {time.monotonic()-started:.3f} s total using attempt={plan.get('options',{}).get('planning_attempt_name','Primary settings')!r}: {_plan_log_text(plan)}.")
            self.events.put(('planned',plan))
            if not plan['count'] and not (plan['options'].get('background_fill_plan') or {}).get('enabled') and not plan['options'].get('fill_regions'):
                log_event('Final planning produced no drawable strokes or fills.')
                raise ValueError('No brush strokes or safe Fill regions were found. Choose a darker image for simple Paint sketch mode, or check the color settings.')
            if plan['options'].get('gartic_timer_deadline') is not None and plan['estimate']>plan['options']['gartic_timer_deadline']-time.monotonic():
                raise ValueError('Gartic timer is too close to expiry after planning. Start again in the next round.')
            if not plan['options'].get('unlimited_time') and plan['estimate']>options['max_seconds']:
                log_event(f"Drawing blocked by time limit: estimate={plan['estimate']:.1f}s limit={options['max_seconds']:.1f}s.")
                raise ValueError('Estimated drawing time exceeds the time limit. Lower quality or increase the time limit.')
            log_event(f"Guarded mouse execution starting: count={plan['count']} estimate={plan['estimate']:.1f}s dry_run={dry_run!r}.")
            plan['options']['test_run']=bool(test)
            if test:
                plan['options']['visual_verification_enabled']=False
            def persist_checkpoint(payload):
                from SessionRecovery import save_render_progress
                save_render_progress(payload)
                self.events.put(('render_checkpoint',payload))
            execute_plan(plan,area,palette,guarded,self.stop,self.paused,lambda k,v:self.events.put((k,v)),dry_run=dry_run,keyboard=self.keyboard,
                         checkpoint=(None if (dry_run or test) else persist_checkpoint))
            if not dry_run and not test and not self.stop.is_set():
                try:
                    from SessionRecovery import clear_render_progress
                    clear_render_progress()
                    self.events.put(('render_resume_cleared',None))
                except Exception as error:log_event(f'Could not clear completed render resume state: {error!r}')
            log_event(f"Guarded mouse execution finished in {time.monotonic()-started:.3f} s total dry_run={dry_run!r}.")
            if dry_run and not self.stop.is_set():
                self.events.put(('dry_run_passed',True))
            if test and not self.stop.is_set():
                self.events.put(('test_passed',True))
        if self.begin_worker('dry-run' if dry_run else 'draw',work):
            if not dry_run and not test:self.drop_in_sync_phase=DROP_SYNC_DRAWING
            try:self.root.iconify()
            except tk.TclError:pass

    def toggle_pause(self):
        if self.activity!='draw':return
        if self.paused.is_set():
            self.paused.clear();self.pause_button.configure(text='Pause · F6')
        else:
            self.paused.set();self.pause_button.configure(text='Resume · F6')
            self.status.set('Pausing after the current brush stroke. Wait until the status says Paused before moving the mouse.')

    def cancel(self):
        # Emergency stop also revokes native mouse permission immediately.
        mouse=getattr(self,'mouse',None)
        if hasattr(mouse,'disarm_input'):
            try:mouse.disarm_input()
            except (OSError,RuntimeError):pass
        self.drop_action_pending=None
        DrawBotApp._disarm_manual_drop_in(self,'cancel/stop pressed')
        self.needs_plan=False
        DrawBotApp._disarm_full_draw(self,'cancel/stop pressed')
        DrawBotApp._cancel_after_attr(self,'preview_after')
        DrawBotApp._cancel_after_attr(self,'preview_render_after')
        DrawBotApp._cancel_after_attr(self,'browser_one_click_after')
        self.browser_one_click_pending=False
        self.stop.set();self.paused.clear()
        process=getattr(self,'mouse_probe_process',None)
        if process is not None:
            try:
                if process.poll() is None:process.terminate()
            except (OSError,AttributeError):pass
        palette_process=getattr(self,'palette_probe_process',None)
        if palette_process is not None:
            try:
                if palette_process.poll() is None:palette_process.terminate()
            except (OSError,AttributeError):pass
        if DrawBotApp._cancel_after_attr(self,'capture_job') and not getattr(self,'closing',False):
            self.set_busy(None)
        if not getattr(self,'closing',False):
            try:self.status.set('Stopping…' if self.activity else 'Stopped.')
            except tk.TclError:pass

    def launch_diagnostic_tool(self,filename,message):
        if self.activity:return
        import subprocess
        try:
            from RuntimePaths import resource_path
            path=resource_path(filename)
            if not path.exists():raise OSError(f'{filename} is missing.')
            subprocess.Popen(['cmd','/c','start','',str(path)],cwd=path.parent)
            self.status.set(message)
        except OSError as error:
            self.status.set(f'Could not start {filename}: {error}')

    def _diagnostics_context(self):
        """Return bounded non-sensitive state for a local diagnostics ZIP."""
        def safe_get(variable, default=''):
            try:return variable.get()
            except Exception:return default
        return {
            'profile': safe_get(self.game), 'activity': str(self.activity or 'idle'),
            'quality': safe_get(self.quality), 'speed': safe_get(self.speed),
            'precision': safe_get(self.precision), 'render_style': safe_get(self.render_style),
            'draw_quality': safe_get(self.draw_quality), 'human_mode': safe_get(self.human_mode),
            'gpu_mode': safe_get(self.gpu_mode), 'gpu_vram': safe_get(self.gpu_vram),
            'gpu_performance': safe_get(self.gpu_performance),
            'background_fill': safe_get(self.background_fill), 'fill_engine': safe_get(getattr(self,'fill_engine',None),'Auto'),
            'background_simplification': safe_get(self.background_simplification),
            'color_grouping': safe_get(self.color_grouping), 'color_workflow': safe_get(getattr(self,'color_workflow',None)),
            'stroke_optimizer': safe_get(getattr(self,'stroke_optimizer',None)), 'adaptive_detail': safe_get(getattr(self,'adaptive_detail',None)),
            'visual_verification': safe_get(getattr(self,'visual_verification',None)),
            'color_rendering': safe_get(self.color_rendering), 'color_layers': safe_get(self.color_layers),
            'custom_color_workflow': safe_get(self.custom_color_workflow), 'tool_strategy': safe_get(self.tool_strategy),
            'cpu_workers': safe_get(getattr(self,'cpu_workers',None)), 'cpu_engine': safe_get(getattr(self,'cpu_engine',None)),
            'ram_budget': safe_get(getattr(self,'ram_budget',None)), 'resource_scheduler': safe_get(getattr(self,'resource_scheduler',None),'Auto'),
            'drawing_mode': safe_get(self.mode), 'shape_model': safe_get(getattr(self,'shape_model',None)),
            'time_budget_mode': safe_get(getattr(self,'time_budget_mode',None)),
            'target_stroke_count': safe_get(getattr(self,'target_stroke_count',None)),
            'paint_single_color': bool(safe_get(self.paint_simple, False)), 'paint_tool': safe_get(self.paint_tool),
            'brush_px': safe_get(self.brush_px), 'time_limit_seconds': safe_get(self.max_seconds),
            'palette_ready': bool(self.palette_ready), 'drawing_area_selected': len(self.corners) == 2,
            'target_lock_valid': bool(DrawBotApp._target_lock_valid(self)),
        }

    # Backward-compatible alias for older tests/plugins; no network reporting remains.
    def _report_context(self):
        return self._diagnostics_context()

    def refresh_runtime_safety_ui(self):
        try:
            payload=load_latest_runtime_safety_report()
            self.runtime_safety_summary.set(runtime_safety_compact_summary(payload))
            if payload:
                stop=(payload.get('stop') or {}).get('reason') or ''
                when=str(payload.get('finished_utc') or payload.get('started_utc') or '')
                extra=(f" · Stop: {stop[:90]}" if stop else '')
                self.runtime_safety_detail.set(f"Latest: {when} · Profile: {payload.get('profile','')}{extra}")
            else:
                self.runtime_safety_detail.set('Local-only safety reports are saved after each execution.')
        except Exception as error:
            self.runtime_safety_summary.set('Safety report status unavailable.')
            self.runtime_safety_detail.set(str(error)[:180])

    def open_safety_reports_folder(self):
        try:
            import os
            RUNTIME_SAFETY_REPORT_DIR.mkdir(parents=True,exist_ok=True)
            if hasattr(os,'startfile'): os.startfile(RUNTIME_SAFETY_REPORT_DIR)
            else: self.status.set(f'Safety reports: {RUNTIME_SAFETY_REPORT_DIR}')
        except OSError as error:
            self.status.set(f'Could not open safety reports folder: {error}')

    def open_latest_safety_report(self):
        payload=load_latest_runtime_safety_report()
        if not payload:
            self.status.set('No runtime safety report exists yet. Run Fast Dry run or Start drawing first.');return
        path=Path(payload.get('text_path') or payload.get('json_path') or '')
        if not path.is_file():
            self.status.set('The latest safety report file could not be found.');return
        try:
            import os
            if hasattr(os,'startfile'): os.startfile(path)
            else:self.status.set(f'Latest safety report: {path}')
        except OSError as error:self.status.set(f'Could not open safety report: {error}')

    def check_for_updates(self):
        if self.activity:
            self.status.set('Stop the current operation before checking for updates.');return
        if hasattr(self,'show_tools'):self.show_tools()
        self.update_summary.set('Checking GitHub Releases…')
        self.update_detail.set('Manual check in progress. Nothing is downloaded or installed.')
        self.status.set('Checking Draw Studio releases on GitHub…')
        def work():
            from UpdateCenter import check_for_updates
            try:result=check_for_updates()
            except Exception as error:result={'error':str(error),'message':'Could not check for updates. Try again.'}
            self.events.put(('update_check_complete',result))
        self.begin_worker('update-check',work)

    def open_latest_release_page(self):
        import webbrowser
        url=str(getattr(self,'latest_release_url','') or 'https://github.com/yesverynice12/Draw-Studio/releases')
        if not url.startswith('https://github.com/yesverynice12/Draw-Studio/'):
            url='https://github.com/yesverynice12/Draw-Studio/releases'
        try:
            opened=webbrowser.open(url,new=2)
            if not opened:self.status.set(f'Releases: {url}')
        except Exception as error:
            self.status.set(f'Could not open GitHub Releases: {error}')

    def collect_diagnostics(self):
        if self.activity:
            self.status.set('Stop the current operation before creating diagnostics.');return
        self.status.set('Creating sanitized diagnostics package…')
        context=self._diagnostics_context()
        def work():
            from DiagnosticsPackage import create_diagnostics_package
            path=create_diagnostics_package(context)
            self.events.put(('diagnostics_ready',str(path)))
        self.begin_worker('diagnostics',work)

    def enable_crash_dumps(self):
        self.launch_diagnostic_tool('Enable-Crash-Dumps.bat','Windows .dmp configuration opened. Follow the instructions in the window.')

    def open_app_data_folder(self):
        try:
            import os
            folder=data_dir();folder.mkdir(parents=True,exist_ok=True)
            if hasattr(os,'startfile'):
                os.startfile(folder)
            else:
                self.status.set(f'App data: {folder}')
        except OSError as error:
            self.status.set(f'Could not open app data folder: {error}')

    def refresh_auto_tuner_ui(self):
        try:
            result=load_tune_result()
        except Exception as error:
            result=None
            log_event(f'Could not read performance auto tuner result: {error!r}')
        if not result:
            self.auto_tune_summary.set('Performance Auto Tuner has not been run on this machine yet.')
            self.auto_tune_detail.set('Local benchmark only. No mouse input, telemetry or network access.')
            return
        try:
            self.auto_tune_summary.set(format_tune_summary(result))
            rec=dict(result.get('recommendation') or {})
            self.auto_tune_detail.set(str(rec.get('reason') or 'Saved local recommendation is ready.'))
        except Exception as error:
            self.auto_tune_summary.set('Saved tuner result could not be displayed.')
            self.auto_tune_detail.set(str(error))

    def run_performance_auto_tuner(self, apply=False):
        if self.activity:
            self.status.set('Stop the current operation before running Performance Auto Tuner.')
            return
        self.status.set('Performance Auto Tuner: benchmarking CPU/RAM and optional CUDA locally… No mouse input will be sent.')
        self.auto_tune_summary.set('Benchmark running…')
        self.auto_tune_detail.set('Testing safe worker counts, RAM headroom and optional CUDA throughput.')
        def work():
            try:
                result=run_auto_tune(gpu_benchmark=gpu_benchmark, save=True)
                self.events.put(('performance_auto_tune_complete',{'result':result,'apply':bool(apply)}))
            except Exception as error:
                self.events.put(('performance_auto_tune_complete',{'error':f'{type(error).__name__}: {error}','apply':False}))
        threading.Thread(target=work,daemon=True,name='performance-auto-tuner').start()

    def apply_performance_tune(self, result=None):
        payload=result or load_tune_result()
        if not payload:
            self.status.set('No saved Performance Auto Tuner recommendation is available yet.')
            return False
        rec=dict(payload.get('recommendation') or {})
        try:
            # CPU workers stay Auto so Resource Scheduler can use the exact saved
            # benchmark recommendation even when it is not one of the UI presets.
            self.cpu_workers.set(str(rec.get('cpu_workers') or 'Auto'))
            self.cpu_engine.set(str(rec.get('cpu_engine') or 'Threads'))
            self.ram_budget.set(str(rec.get('ram_budget') or 'Auto'))
            self.ram_custom_mb.set(str(rec.get('ram_custom_mb') or '4096'))
            self.planning_resolution.set(str(rec.get('planning_resolution') or 'High'))
            self.resource_scheduler.set(str(rec.get('resource_scheduler') or 'Benchmark recommendations'))
            self.gpu_mode.set(str(rec.get('gpu_mode') or 'CPU'))
            self.gpu_vram.set(str(rec.get('gpu_vram') or 'Auto'))
            self.gpu_performance.set(str(rec.get('gpu_performance') or 'Balanced'))
            self.save_settings()
            self.refresh_auto_tuner_ui()
            workers=int(rec.get('cpu_workers_effective',1) or 1)
            self.status.set(f'Performance Auto Tuner applied: {workers} benchmark-selected planning workers · RAM {self.ram_budget.get()} · {self.gpu_mode.get()} · {self.planning_resolution.get()} planning.')
            return True
        except (tk.TclError, ValueError, OSError) as error:
            self.status.set(f'Could not apply Performance Auto Tuner recommendation: {error}')
            return False

    def test_gpu_acceleration(self):
        if self.activity:
            self.status.set('Stop the current operation before testing GPU acceleration.')
            return
        requested=self.gpu_mode.get(); vram=self.gpu_vram.get(); performance=self.gpu_performance.get()
        self.status.set('Testing CUDA image-analysis acceleration…')
        def work():
            try:
                result=gpu_benchmark(requested,1024,vram,performance)
                if result.get('used_gpu'):
                    cc=f" · CC {result.get('compute_capability')}" if result.get('compute_capability') else ''
                    sms=f" · {result.get('multiprocessors')} SMs" if result.get('multiprocessors') else ''
                    allocation=result.get('allocation_mode','Adaptive')
                    workspace=result.get('workspace_estimate_mb')
                    tile=result.get('tile_rows')
                    extra=(f" · workspace ~{workspace} MB" if workspace else '')+(f" · tile {tile} rows" if tile else '')
                    message=(f"CUDA ready: {result.get('device')}{cc}{sms} · {result.get('throughput_mp_s')} MP/s · "
                             f"{result.get('elapsed_ms')} ms · VRAM budget {result.get('vram_budget_mb')} MB · pool {result.get('pool_cached_mb')} MB · "
                             f"{allocation}{extra}. Raw CUDA kernels use the NVIDIA SM/CUDA-core path.")
                else:
                    if result.get('hardware_detected'):
                        driver=f" · driver {result.get('driver_version')}" if result.get('driver_version') else ''
                        source=f" · {result.get('hardware_source')}" if result.get('hardware_source') else ''
                        message=(f"NVIDIA GPU detected: {result.get('hardware_device') or result.get('device')}{driver}{source}. "
                                 f"CUDA benchmark is unavailable: {result.get('reason') or 'CuPy backend is not ready.'}")
                    else:
                        message=f"CPU fallback active. {result.get('reason') or 'No NVIDIA CUDA GPU found.'}"
                self.events.put(('status',message))
            except Exception as error:
                self.events.put(('status',f'GPU test failed safely; CPU fallback remains available: {error}'))
        threading.Thread(target=work,daemon=True,name='gpu-benchmark').start()

    def test_resource_allocation(self):
        if self.activity:
            self.status.set('Stop the current operation before testing resource allocation.')
            return
        try:
            allocation=resolve_allocation(self.cpu_workers.get(),self.cpu_engine.get(),self.ram_budget.get(),self.ram_custom_mb.get())
            available=allocation.get('available_ram_mb')
            available_text=f" · available RAM ~{available:,} MB" if isinstance(available,int) else ""
            self.status.set(
                f"Resource allocation ready: CPU {allocation['cpu_workers_resolved']} / {allocation['logical_cpus']} logical threads · "
                f"engine {allocation['cpu_engine']} · RAM budget {allocation['ram_budget_mb']:,} MB{available_text}. "
                "Running a short CPU worker benchmark…"
            )
        except Exception as error:
            self.status.set(f'Resource allocation setting is invalid: {error}')
            return
        def work():
            try:
                result=benchmark_allocation(self.cpu_workers.get(),self.cpu_engine.get(),self.ram_budget.get(),self.ram_custom_mb.get())
                schedule=benchmark_scheduler(result)
                self.events.put(('status',
                    f"CPU/RAM test complete: {result['benchmark_tasks']} task(s) on {result['benchmark_backend']} · "
                    f"{result['benchmark_score']} Mloops/s · {result['benchmark_elapsed_ms']} ms · "
                    f"Resource Scheduler saved recommendation: {schedule['recommended_workers']} worker(s) · "
                    f"RAM budget {result['ram_budget_mb']:,} MB. GPU is tested separately with Test GPU acceleration."))
            except Exception as error:
                self.events.put(('status',f'CPU/RAM benchmark failed safely: {error}'))
        threading.Thread(target=work,daemon=True,name='resource-benchmark').start()

    def run_performance_benchmark(self):
        """Benchmark the current planning pipeline without arming mouse input."""
        if self.activity:
            self.status.set('Stop the current operation before running the performance benchmark.')
            return
        try:
            options=self.options()
        except ValueError as error:
            self.status.set(str(error));return
        original=self.original.copy() if self.original is not None else None
        if original is None:
            from PIL import Image,ImageDraw
            original=Image.new('RGBA',(640,480),'white')
            pen=ImageDraw.Draw(original)
            pen.rectangle((45,45,595,435),fill=(235,235,245,255))
            pen.ellipse((120,70,520,430),fill=(70,130,210,255))
            pen.rectangle((230,160,410,390),fill=(235,90,70,255))
            pen.line((90,400,550,90),fill=(20,20,20,255),width=9)
        else:
            original.thumbnail((640,480))
        target=(800,450)
        self.status.set('Running planner benchmark… No mouse input can be armed by this test.')
        def work():
            try:
                started=time.monotonic()
                plan=make_plan(original,target,dict(options),self.stop.is_set)
                elapsed=time.monotonic()-started
                profile=plan.get('performance_profile') or {}
                phase,phase_seconds=profiler_dominant_phase(profile)
                phase_name=(phase or 'unknown').replace('_',' ')
                source=max(1,int(plan.get('source_count',0) or 0))
                throughput=source/max(elapsed,.001)
                benchmark_options=plan.get('options') or {}
                advanced=benchmark_options.get('advanced_color_meta') or {}
                portrait=benchmark_options.get('portrait_stats') or {}
                backend=advanced.get('acceleration_backend') or portrait.get('acceleration_backend') or advanced.get('cpu_backend') or 'CPU'
                device=advanced.get('acceleration_device') or portrait.get('acceleration_device') or ''
                backend_text=f"{backend}{' · '+str(device) if device else ''}"
                text=(f"Planner benchmark: {elapsed:.2f}s total · {throughput:,.0f} source strokes/s · backend {backend_text} · "
                      f"slowest phase: {phase_name} {phase_seconds:.2f}s. "
                      f"{format_performance_profile(profile, compact=True)}")
                log_event('Performance benchmark complete: '+text)
                self.events.put(('status',text))
                self.events.put(('performance_benchmark',{'text':text,'profile':profile,'elapsed':elapsed,'source':source,'count':plan.get('count',0)}))
            except InterruptedError:
                self.events.put(('status','Performance benchmark cancelled safely. No mouse input was sent.'))
            except Exception as error:
                self.events.put(('status',f'Performance benchmark failed safely: {error}'))
        self.stop.clear()
        threading.Thread(target=work,daemon=True,name='planning-benchmark').start()

    def clear_gpu_cache(self):
        if self.activity:
            self.status.set('Stop the current operation before clearing the GPU cache.')
            return
        try:
            result=gpu_clear_cache(self.gpu_mode.get())
            if result.get('cleared'):
                self.status.set(f"GPU cache cleared. Cached VRAM: {result.get('before_cached_mb',0)} MB → {result.get('after_cached_mb',0)} MB.")
            else:
                self.status.set(f"GPU cache was not active. {result.get('reason','')}")
        except Exception as error:
            self.status.set(f'Could not clear GPU cache: {error}')

    def run_self_test(self):
        """Run Draw Studio's built-in self-test out of process.

        Developer tooling must never block Tk's main loop, so the result is
        returned through the existing worker-event queue.
        """
        if self.activity or self.closing:return
        import subprocess,sys
        def work():
            try:
                if getattr(sys,'frozen',False):
                    command=[sys.executable,'--self-test']
                else:
                    command=[sys.executable,str(Path(__file__).resolve()),'--self-test']
                result=subprocess.run(command,capture_output=True,text=True,timeout=90,check=False)
                output=(result.stdout or result.stderr or '').strip().splitlines()
                tail=output[-1] if output else 'No output.'
                if result.returncode==0:
                    self.events.put(('status',f'Self-test passed. {tail}'))
                else:
                    self.events.put(('status',f'Operation failed: self-test exited with code {result.returncode}. {tail}'))
            except (OSError,subprocess.SubprocessError) as error:
                self.events.put(('status',f'Operation failed: self-test could not run: {error}'))
        self.begin_worker('self-test',work)

    def show_version_history(self):
        import customtkinter as ctk
        window=ctk.CTkToplevel(self.root)
        window.title('Draw Studio version history')
        window.geometry('850x680');window.minsize(720,520);window.transient(self.root)
        window.configure(fg_color='#101319')
        card=ctk.CTkFrame(window,fg_color='#1a202b',corner_radius=18)
        card.pack(fill='both',expand=True,padx=18,pady=18)
        ctk.CTkLabel(card,text='Version history',font=('Segoe UI',24,'bold'),text_color='#f0f4fb').pack(anchor='w',padx=22,pady=(18,4))
        ctk.CTkLabel(card,text='Local packaged release timeline. No network request is made.',font=('Segoe UI',12),text_color='#a6b2c5').pack(anchor='w',padx=22,pady=(0,12))
        box=ctk.CTkTextbox(card,wrap='word',font=('Consolas',11),fg_color='#101319',text_color='#dbe5f4',corner_radius=12)
        box.pack(fill='both',expand=True,padx=22,pady=(0,14))
        box.insert('1.0',read_version_history())
        box.configure(state='disabled')
        row=ctk.CTkFrame(card,fg_color='transparent');row.pack(fill='x',padx=22,pady=(0,16))
        ctk.CTkButton(row,text='Close',command=window.destroy,fg_color='#98edce',hover_color='#b2f6de',text_color='#15382d').pack(side='right')

    def show_about(self):
        import customtkinter as ctk
        from RuntimePaths import is_frozen
        window=ctk.CTkToplevel(self.root)
        window.title('About Draw Studio')
        window.geometry('610x500');window.resizable(False,False);window.transient(self.root)
        window.configure(fg_color='#101319')
        card=ctk.CTkFrame(window,fg_color='#1a202b',corner_radius=18)
        card.pack(fill='both',expand=True,padx=22,pady=22)
        ctk.CTkLabel(card,text='D',width=58,height=58,corner_radius=16,fg_color='#315c50',font=('Segoe UI',28,'bold'),text_color='#f0f4fb').pack(anchor='w',padx=24,pady=(24,10))
        ctk.CTkLabel(card,text='Draw Studio',font=('Segoe UI',26,'bold'),text_color='#f0f4fb').pack(anchor='w',padx=24)
        ctk.CTkLabel(card,text=f'{APP_VERSION} · {BUILD_CHANNEL.capitalize()} channel',font=('Segoe UI',13),text_color='#98edce').pack(anchor='w',padx=24,pady=(2,14))
        try:
            gpu=acceleration_info(self.gpu_mode.get(),self.gpu_vram.get(),self.gpu_performance.get())
            gpu_text=(f'{gpu.backend} · {gpu.device} · CC {gpu.compute_capability or "?"} · '
                      f'{gpu.multiprocessors or "?"} SMs · VRAM budget {gpu.vram_budget_mb or 0} MB · {gpu.cuda_execution or "CUDA"}'
                      if gpu.accelerated else 'CPU fallback')
        except Exception:
            gpu_text='CPU fallback'
        try:
            allocation=resolve_allocation(self.cpu_workers.get(),self.cpu_engine.get(),self.ram_budget.get(),self.ram_custom_mb.get())
            resource_text=f"CPU planning: {allocation['cpu_workers_resolved']} / {allocation['logical_cpus']} logical threads · {allocation['cpu_engine']} · RAM {allocation['ram_budget_mb']} MB"
        except Exception:
            resource_text='CPU planning: default allocation'
        details=(f'Build: {"Windows EXE" if is_frozen() else "Python source"}\n'
                 'Diagnostics: local only · no telemetry / report upload\n'
                 f'Image analysis: {gpu_text}\n'
                 f'{resource_text}\n'
                 f'App data: {data_dir()}\n\n'
                 'Mouse automation is intentionally disarmed until you explicitly start a test or drawing. '
                 'Normal Microsoft Paint use does not require administrator rights.')
        ctk.CTkLabel(card,text=details,font=('Segoe UI',12),text_color='#a6b2c5',justify='left',anchor='w',wraplength=520).pack(fill='x',padx=24,pady=(0,18))
        row=ctk.CTkFrame(card,fg_color='transparent');row.pack(fill='x',padx=24,pady=(0,22))
        ctk.CTkButton(row,text='Open app data',command=self.open_app_data_folder,fg_color='#252e3e',hover_color='#36445b').pack(side='left')
        ctk.CTkButton(row,text='How to use',command=self.help,fg_color='#252e3e',hover_color='#36445b').pack(side='left',padx=8)
        ctk.CTkButton(row,text='Version history',command=self.show_version_history,fg_color='#252e3e',hover_color='#36445b').pack(side='left')
        ctk.CTkButton(row,text='Close',command=window.destroy,fg_color='#98edce',hover_color='#b2f6de',text_color='#15382d').pack(side='right')

    def show_welcome(self):
        if self.closing or self.activity:return
        import customtkinter as ctk
        from ReleaseState import mark_welcome_seen
        window=ctk.CTkToplevel(self.root)
        window.title('Welcome to Draw Studio')
        window.geometry('760x720');window.minsize(700,660);window.transient(self.root);window.grab_set()
        window.configure(fg_color='#101319')
        outer=ctk.CTkFrame(window,fg_color='#1a202b',corner_radius=20)
        outer.pack(fill='both',expand=True,padx=22,pady=22)
        ctk.CTkLabel(outer,text=f'Draw Studio {APP_VERSION}',font=('Segoe UI',28,'bold'),text_color='#f0f4fb').pack(anchor='w',padx=28,pady=(26,3))
        ctk.CTkLabel(outer,text='From image to brush strokes — with a safe, test-first workflow.',font=('Segoe UI',13),text_color='#a6b2c5').pack(anchor='w',padx=28,pady=(0,20))
        steps=(
            ('1', 'Choose profile + image', 'Pick the target app profile, then select, paste or drag in an image. A direct drop on the preview canvas can one-shot start supported/non-Paint targets when setup is already safe; otherwise it only imports.'),
            ('2', 'Calibrate + select canvas', 'Read colors/tools when required. Select ONLY the drawable canvas; CanvasGuard treats it as a hard boundary.'),
            ('3', 'Run a small test', 'Use Test mouse and Small test first. This catches wrong tools, target focus and calibration before a full drawing.'),
            ('4', 'Verify safely', 'Run Lock setup → Safety preflight → Fast Dry run. Dry run moves through representative routes without clicking.'),
            ('5', 'Preview + start', 'Check Drawing preview / Safety map, then Unlock full drawing → Start drawing. Esc stops immediately; F6 pauses/resumes.'),
        )
        for number,title,body in steps:
            row=ctk.CTkFrame(outer,fg_color='#252e3e',corner_radius=14);row.pack(fill='x',padx=28,pady=4)
            ctk.CTkLabel(row,text=number,width=38,height=38,corner_radius=11,fg_color='#315c50',font=('Segoe UI',15,'bold'),text_color='#f0f4fb').pack(side='left',padx=14,pady=10)
            text=ctk.CTkFrame(row,fg_color='transparent');text.pack(side='left',fill='x',expand=True,pady=8)
            ctk.CTkLabel(text,text=title,font=('Segoe UI',14,'bold'),text_color='#f0f4fb').pack(anchor='w')
            ctk.CTkLabel(text,text=body,font=('Segoe UI',11),text_color='#a6b2c5',justify='left',wraplength=550).pack(anchor='w')
        ctk.CTkLabel(outer,text='Privacy: Draw Studio has no telemetry or bug-report server. Diagnostics and safety reports stay local. GitHub is contacted only when you explicitly use an image URL or press Check for updates.',font=('Segoe UI',11),text_color='#a6b2c5',wraplength=620,justify='left').pack(anchor='w',padx=28,pady=(14,8))
        def done():
            try:mark_welcome_seen()
            except OSError as error:log_event(f'Could not save welcome state: {error!r}')
            try:window.grab_release()
            except tk.TclError:pass
            window.destroy()
        window.protocol('WM_DELETE_WINDOW',done)
        ctk.CTkButton(outer,text='Get started',command=done,height=44,fg_color='#98edce',hover_color='#b2f6de',text_color='#15382d',font=('Segoe UI',13,'bold')).pack(anchor='e',padx=28,pady=(6,24))

    def help(self):
        messagebox.showinfo('How to use Draw Studio',
            '1. Select an image from your computer, paste an image, or load a direct image URL.\n\n'
            '2. Open the target drawing application. Read/calibrate colors if needed, then select the drawing area.\n\n'
            '3. For photos/portraits, use Auto or Portrait / shaded. For complex NVIDIA-GPU images use GPU enhanced + Auto CUDA + High throughput and choose a VRAM budget. High precision and a 1–2 px brush are good starting points.\n\n'
            '4. For Microsoft Paint, use Auto (recommended) and calibrate Pencil + the 100% opacity point. Start drawing and switch to the target application during the countdown.\n\n'
            'Safety order: Small test → Lock setup → Safety preflight → Fast Dry run → Unlock → Start drawing.\n\n'
            'F6 pauses/resumes. Esc stops. Do not move the mouse while drawing. CanvasGuard remains active in every profile.\n\n'
            'Recalibrate after changing zoom, display scaling or palette layout. Small safe window moves can be rebased automatically.')

    def _handle_event(self,kind,value):
        if getattr(self,'pending_clear_drawing',None) is not None:
            if kind=='done':
                self.activity=None;self.worker=None
                screen_window=getattr(self,'screen_task_window',None)
                if screen_window is not None:screen_window.restore()
            return
        if kind=='status':
            self.status.set(str(value))
        elif kind=='paint_auto_calibration_complete':
            if self.game.get()!='Microsoft Paint':return
            meta=value['target_meta'];l,t,r,b=map(int,value['canvas_box'])
            self.corners=[(l,t),(r,b)];self.saved_area=list(self.corners);self.canvas_anchor_detection=None
            self.target_window=(int(meta['handle']),tuple(meta['rect']))
            self.target_client_rect=tuple(meta['client_rect']);self.target_dpi=meta.get('dpi')
            self.paint_tool.set('Auto (recommended)');self.brush_px.set('1')
            self.area_text.set(f'✓ Paint canvas {r-l} × {b-t} px')
            self.color_session_cache.clear();self.refresh_palette();self.refresh_tool_calibration()
            self._mark_plan_stale('Paint setup changed. Build preview when ready.')
            self._invalidate_target_lock('Paint auto calibration changed',disarm=True)
            self.small_test_passed=False
            self.save_settings()
            self.status.set('Paint ready: canvas, 20 colours, Pencil and Fill calibrated. Set Pencil to 1 px in Paint and run Small test.')
        elif kind=='update_check_complete':
            payload=value if isinstance(value,dict) else {}
            action=getattr(self,'update_download_button',None)
            if action is not None:
                action.configure(text=(f"Download version {payload.get('latest_version')}" if payload.get('update_available') else 'Open GitHub Releases'))
            if payload.get('error'):
                self.update_summary.set('Could not check for updates. Try again.')
                self.update_detail.set(str(payload['error']))
                self.status.set('Update check failed. Check your connection and try again.')
                return
            self.latest_release_url=str(payload.get('release_url') or 'https://github.com/yesverynice12/Draw-Studio/releases')
            self.update_summary.set(str(payload.get('message') or 'Update check completed.'))
            latest=str(payload.get('latest_version') or 'No release found')
            release_name=str(payload.get('release_name') or '').strip()
            extra=f' · {release_name}' if release_name and release_name not in latest else ''
            self.update_detail.set(f'Current: {APP_VERSION} · Latest: {latest}{extra} · Manual GitHub check only.')
            if payload.get('update_available'):
                self.status.set(f'Draw Studio {latest} is available. Open GitHub Release to download it.')
            else:
                self.status.set(str(payload.get('message') or 'Update check completed.'))
        elif kind=='performance_auto_tune_complete':
            payload=value if isinstance(value,dict) else {}
            error=str(payload.get('error') or '')
            if error:
                self.auto_tune_summary.set('Performance Auto Tuner failed safely.')
                self.auto_tune_detail.set(error)
                self.status.set(f'Performance Auto Tuner failed safely: {error}')
            else:
                result=dict(payload.get('result') or {})
                self.auto_tune_summary.set(format_tune_summary(result))
                rec=dict(result.get('recommendation') or {})
                self.auto_tune_detail.set(str(rec.get('reason') or 'Local recommendation ready.'))
                if payload.get('apply'):
                    self.apply_performance_tune(result)
                else:
                    self.status.set('Performance Auto Tuner benchmark complete. Review the recommendation or press Apply saved recommendation.')
        elif kind=='screen':
            self.display_screen(value)
        elif kind=='toggle_pause':
            self.toggle_pause()
        elif kind=='exact_color_calibration_complete':
            code=int((value or {}).get('code',-1));self.refresh_exact_color_status();self.color_session_cache.clear()
            self._mark_plan_stale('Exact color controls changed. Press Build preview manually when ready.')
            self._invalidate_target_lock('exact color calibration changed',disarm=True)
            if code==0:
                self.status.set('Smart custom palette calibration closed. Visual scale / exact RGB will be used when calibrated; nearest palette fallback is always available.')
                log_event('Exact color calibration helper completed successfully.')
            else:
                self.status.set(f'Exact color calibration failed safely in helper process (exit {code}). Main Draw Studio stayed open; nearest palette fallback remains active.')
                log_event(f'Exact color calibration helper failed safely: exit={code}.')
        elif kind=='browser_one_click_setup_complete':
            payload=value if isinstance(value,dict) else {}
            profile_name=str(payload.get('profile_name') or self.game.get())
            if profile_name!=self.game.get():
                log_event('Ignored stale Browser One-Click setup result after profile change.')
            else:
                meta=payload.get('target_meta') or {};canvas=payload.get('canvas_box')
                if isinstance(canvas,(list,tuple)) and len(canvas)==4 and float(payload.get('canvas_confidence',0) or 0)>=.70:
                    l,t,r,b=map(int,canvas);self.corners=[(l,t),(r,b)];self.saved_area=[(l,t),(r,b)];self.canvas_anchor_detection=None
                    self.area_text.set(f'✓ One-Click canvas {r-l} × {b-t} px')
                if meta.get('handle') and meta.get('rect') and meta.get('client_rect'):
                    self.target_window=(int(meta['handle']),tuple(meta['rect']));self.target_client_rect=tuple(meta['client_rect']);self.target_dpi=meta.get('dpi')
                self.color_session_cache.clear();self.refresh_palette();self.small_test_passed=False
                self._mark_plan_stale('Browser One-Click refreshed canvas/palette.')
                count=int(payload.get('palette_count',0) or 0);confidence=float(payload.get('confidence',0) or 0)
                self.browser_auto_calibration_success=True;self.drop_in_sync_phase=DROP_SYNC_READY
                self.browser_auto_text.set(f'✓ One-Click auto setup · {count} colors · confidence {confidence*100:.0f}%')
                self.browser_one_click_text.set('✓ One-Click setup ready · visual preflight + auto brush will run before drawing.')
                log_event(f'Browser One-Click setup completed: profile={profile_name!r} colors={count} confidence={confidence:.3f} canvas={canvas!r}.')
        elif kind=='browser_auto_calibration_complete':
            payload=value if isinstance(value,dict) else {}
            profile_name=str(payload.get('profile_name') or self.game.get())
            if profile_name!=self.game.get():
                log_event('Ignored stale Browser Auto Setup result after profile change.')
            else:
                meta=payload.get('target_meta') or {}
                canvas=payload.get('canvas_box')
                if isinstance(canvas,(list,tuple)) and len(canvas)==4 and float(payload.get('canvas_confidence',0) or 0)>=.70:
                    l,t,r,b=map(int,canvas)
                    if r-l>=10 and b-t>=10:
                        self.corners=[(l,t),(r,b)];self.saved_area=[(l,t),(r,b)];self.canvas_anchor_detection=None
                        self.area_text.set(f'✓ Auto canvas {r-l} × {b-t} px · confidence {float(payload.get("canvas_confidence",0))*100:.0f}%')
                if meta.get('handle') and meta.get('rect') and meta.get('client_rect'):
                    self.target_window=(int(meta['handle']),tuple(meta['rect']))
                    self.target_client_rect=tuple(meta['client_rect']);self.target_dpi=meta.get('dpi')
                self.color_session_cache.clear();self.refresh_palette();self.small_test_passed=False
                self._mark_plan_stale('Browser Auto Setup changed canvas/palette. Build preview when ready.')
                self._invalidate_target_lock('browser auto calibration changed',disarm=True)
                count=int(payload.get('palette_count',0) or 0);confidence=float(payload.get('confidence',0) or 0)
                self.browser_auto_text.set(f'✓ Auto setup ready · {count} colors · confidence {confidence*100:.0f}% · manual calibration not required.')
                self.status.set(f'✓ {profile_name} Auto Setup ready: {count} verified colors. Add/drop the image and draw.')
                try:self.save_settings()
                except Exception:pass
                try:self.root.deiconify();self.root.lift()
                except tk.TclError:pass
                self.browser_auto_calibration_success=True
                self.drop_in_sync_phase=DROP_SYNC_READY
                fingerprint_meta=payload.get('layout_fingerprint_meta') or {}
                cache_hit=bool(isinstance(fingerprint_meta,dict) and fingerprint_meta.get('hit'))
                log_event(f'Browser Auto Setup completed: profile={profile_name!r} colors={count} confidence={confidence:.3f} canvas={canvas!r} layout_fingerprint_cache_hit={cache_hit}.')
        elif kind=='palette_calibration_complete':
            payload=value if isinstance(value,dict) else {};self.color_session_cache.clear()
            code=int(payload.get('code',-1))
            self.refresh_palette()
            self._mark_plan_stale('Color calibration changed. Press Build preview manually when ready.')
            self._invalidate_target_lock('color calibration changed',disarm=True)
            if code==0:
                if self.palette_ready:
                    self.status.set('✓ Color calibration saved and loaded. Preview remains Manual.')
                    log_event('Color calibration completed successfully and palette reloaded.')
                else:
                    self.status.set('Color calibration closed without a saved/valid palette. Read colors again before full drawing.')
                    log_event('Color calibration helper closed normally without a valid saved palette.')
            else:
                unsigned=code & 0xffffffff
                crash_hint=(' Native Windows access violation (0xC0000005).' if unsigned==0xC0000005 else '')
                self.status.set(f'Color calibration failed safely in its helper process (exit {code} / 0x{unsigned:08X}). Main Draw Studio stayed open.{crash_hint} Check the palette calibration log.')
                log_event(f'Color calibration helper failed safely: exit={code} / 0x{unsigned:08X}.')
        elif kind=='diagnostics_ready':
            path=Path(str(value))
            self.status.set(f'Diagnostics package created: {path.name}')
            messagebox.showinfo('Diagnostics created',f'Privacy-safe diagnostics ZIP created at:\n{path}\n\nSource/recovery images are not included.',parent=self.root)
        elif kind=='test_passed':
            self.small_test_passed=bool(value)
            DrawBotApp._invalidate_target_lock(self,'small test result changed',disarm=True)
            DrawBotApp._invalidate_safety_preflight(self,'small test result changed',disarm=True)
            DrawBotApp._invalidate_dry_run(self,'small test result changed',disarm=True)
            if self.small_test_passed:
                self.status.set('Small drawing test passed. Next press Lock setup; full drawing is still locked.')
        elif kind=='dry_run_passed':
            self.dry_run_passed=bool(value)
            if self.dry_run_passed:
                self.dry_run_signature=DrawBotApp._current_safety_signature(self)
                self.dry_run_valid_until=time.monotonic()+180.0
                DrawBotApp._disarm_full_draw(self,'dry run passed; waiting for explicit unlock',update_text=True)
                self.status.set('Fast Dry run passed for 3 minutes. Now press Unlock full drawing, then Start Drawing.')
                try:self.summary.set('Dry run PASS: representative calibrated routes were sampled within the time limit without clicks, presses or releases. Full drawing is still locked until Unlock + Start.')
                except (tk.TclError,AttributeError):pass
                log_event('Fast Dry run passed. Valid for 180 seconds or until the safety signature changes.')
        elif kind=='render_checkpoint':
            data=value if isinstance(value,dict) else {}
            self.pending_render_resume=dict(data) if data else None
            if self.pending_render_resume:
                completed=int(data.get('completed_count',0));total=int(data.get('total_colors',0));next_color=int(data.get('next_color',0))
                if data.get('path_level'):
                    color_no=int(data.get('active_color_number',next_color) or next_color)
                    path_no=int(data.get('next_path_index',0) or 0)+1;path_total=int(data.get('active_path_count',0) or 0)
                    self.color_plan_text.set(f'Smart Recovery checkpoint: {completed}/{total} colors complete · color {color_no} path {path_no}/{path_total} next')
                else:
                    self.color_plan_text.set(f'Render checkpoint: {completed}/{total} colors completed' + (f' · next color {next_color}' if next_color else ' · complete'))
        elif kind=='render_resume_cleared':
            self.pending_render_resume=None
        elif kind=='color_plan':
            data=value if isinstance(value,dict) else {}
            try:
                current=int(data.get('current',0));total=int(data.get('total',0));rgb=tuple(data.get('rgb') or ())
                method=str(data.get('method','Color selector'));confidence=float(data.get('confidence',0));matched=bool(data.get('matched'))
                if data.get('completed'):
                    self.color_plan_text.set(f'Color plan: {current}/{total} complete · RGB {rgb} · {method}')
                else:
                    verdict='verified' if matched else 'recovering'
                    self.color_plan_text.set(f'Color plan: {current}/{total} · RGB {rgb} · {method} · {confidence:.0f}% · {verdict}')
            except Exception:
                self.color_plan_text.set('Color verification status updated.')
        elif kind=='visual_verification':
            data=value if isinstance(value,dict) else {}
            try:
                current=int(data.get('current',0));total=int(data.get('total',0));ok=bool(data.get('ok',False));confidence=float(data.get('confidence',0));summary=str(data.get('summary','visual check'))
                verdict='OK' if ok else 'warning'
                self.color_plan_text.set(f'Visual verification: {current}/{total} · {confidence:.0f}% · {verdict} · {summary}')
            except Exception:
                self.color_plan_text.set('Visual verification status updated.')
        elif kind=='progress':
            done,total=value
            done=max(0,int(done));total=max(0,int(total))
            self.progress['value']=0 if total==0 else min(100,done*100/total)
            if total and not self.paused.is_set():
                if self.activity=='dry-run':
                    self.status.set(f'Dry run: {done:,} / {total:,} cursor paths simulated • no clicks • Esc stops')
                else:
                    self.status.set(f'Drawing: {done:,} / {total:,} brush strokes • Esc stops • F6 pauses')
        elif kind=='upscaled':
            self._suppress_recovery=False
            if self.stop.is_set() and value[1] is not None: return
            self.original,previous=value
            self.upscale_original=previous
            self.color_session_cache.clear()
            DrawBotApp._clear_render_resume(self,'image resampled')
            from ImageFormatInfo import image_label
            self.file_label.set(image_label(self.original,'Upscaled image' if previous is not None else 'Original restored'))
            self._mark_plan_stale('Image updated. Build preview to check the result before Start.')
            self.status.set('Image updated. Build preview to check the result before Start.')
            self.show_previews()
            self._schedule_recovery_checkpoint(include_image=True,delay=40)
        elif kind=='loaded':
            self._suppress_recovery=False
            self.upscale_original=None
            self.subject_region=None
            if hasattr(self,'subject_hint'): self.subject_hint.set('Auto: simple background or transparent PNG. Mark busy photos.')
            self.original,label,_action=value;self.color_session_cache.clear();DrawBotApp._clear_render_resume(self,'new image loaded')
            from ImageFormatInfo import image_label
            self.file_label.set(image_label(self.original,str(label)))
            self._mark_plan_stale('Image loaded. Preview was not rebuilt automatically in Manual mode.')
            DrawBotApp._queue_drop_in_start(self,_action,source_label=str(label))
            if normalize_drop_in_action(_action)!=DROP_IN_ACTION:
                DrawBotApp._queue_browser_one_click_after_import(self,str(label))
            if normalize_drop_in_action(_action)==DROP_IN_ACTION and self.drop_action_pending==DROP_IN_ACTION:
                self.status.set('Image loaded through Drop-In Start. Drawing will start after the loader finishes if the canvas setup is still valid.')
            else:
                self.status.set('Image loaded. Press Build preview when you want a preview, or continue setup and Safety preflight / Dry run when ready.')
            self.show_previews();self._sync_mobile_preview();self.needs_plan=False;self._schedule_recovery_checkpoint(include_image=True,delay=40);self._maybe_auto_preview(delay=900, reason='image-loaded')
        elif kind=='preview_timeout':
            target,preview=value
            self.summary.set('Preview calculation exceeded its time limit. The previous preview is retained. Try the normal Build preview or a smaller drawing area.')
            self.status.set('Preview took too long, so it was cancelled safely. You can still press Start drawing to generate the final plan.')
        elif kind=='planned':
            if not isinstance(value,dict) or 'preview' not in value or 'count' not in value or 'estimate' not in value:
                raise ValueError('The preview worker returned an invalid plan.')
            self.plan=value
            self.preview_dirty_reason=''
            self._sync_mobile_preview()
            estimate=max(0,float(value['estimate']));unit=f'{estimate/60:.1f} min' if estimate>=60 else f'{estimate:.0f} s'
            stats=value.get('options',{}).get('portrait_stats')
            portrait_note=(f" • portrait: {int(stats['edge_strokes']):,} contour + {int(stats['tone_strokes']):,} shading • {stats.get('draw_quality','High likeness')}" if stats else '')
            brush_px=int(value.get('options',{}).get('brush_px',3))
            brush_tip=(' Portrait tip: 1–2 px usually preserves facial detail better.' if stats and brush_px > 2 else '')
            priority_tip=(f" {int(stats.get('priority_strokes',0)):,} strokes were structure-prioritized." if stats and stats.get('priority_strokes') else '')
            time_tip=(' Detail was fitted to your time limit.' if stats and stats.get('time_fitted') else '')
            precision=value.get('options',{}).get('precision','High')
            human_mode=value.get('options',{}).get('human_mode','Off')
            human_note=(f' • Human: {human_mode}' if human_mode!='Off' else '')
            if stats and stats.get('gpu_accelerated'):
                budget=stats.get('vram_budget_mb'); perf=stats.get('gpu_performance','')
                memory=(f' · VRAM {int(budget):,} MB' if isinstance(budget,(int,float)) else '')
                scaler=stats.get('scaler','');allocation=stats.get('allocation_mode','')
                gpu_note=f" • {stats.get('acceleration_backend','CUDA')}: {stats.get('acceleration_device','GPU')}{memory}" + (f' · {perf}' if perf else '') + (f' · {allocation}' if allocation else '') + (f' · {scaler}' if scaler else '')
            elif stats:
                gpu_note=' • Analysis: CPU'
            else:
                gpu_note=''
            fill_meta=value.get('options',{}).get('background_fill_plan') or {}
            region_count=len(value.get('options',{}).get('fill_regions',[]) or [])
            if fill_meta.get('enabled'):
                fill_note=f" • Base Fill: {fill_meta.get('image_coverage',0)*100:.0f}% background"
            elif value.get('options',{}).get('background_fill')!='Off' and value.get('options',{}).get('fill_unavailable_reason'):
                fill_note=' • Auto Fill unavailable (calibrate Fill + drawing tool)'
            else:
                fill_note=''
            if region_count:fill_note+=f' • {region_count} safe region fill' + ('s' if region_count!=1 else '')
            simplify=value.get('options',{}).get('background_simplification_meta') or {}
            simplify_note=(f" • background simplified {simplify.get('coverage',0)*100:.0f}%" if simplify.get('enabled') and simplify.get('changed_pixels') else '')
            grouping=value.get('options',{}).get('color_grouping_meta') or {}
            grouping_note=(f" • colors: {grouping.get('active_colors',0)} grouped" if grouping else '')
            advanced=value.get('options',{}).get('advanced_color_meta') or {}
            if advanced and advanced.get('color_rendering'):
                layer_bits=f" + {advanced.get('color_layers')}" if advanced.get('color_layers')!='Off' else ''
                color_note=f" • color: {advanced.get('color_rendering')}{layer_bits}"
                if advanced.get('layered_pixels'):
                    color_note += f" ({int(advanced.get('layered_pixels',0)):,} layered px)"
            else:
                color_note=''
            path_stats=value.get('path_stats') or {}
            path_note=''
            if path_stats.get('mode') == 'Shape paths':
                skipped=int(path_stats.get('skipped_tiny_details',0) or 0)+int(path_stats.get('skipped_due_cap',0) or 0)
                skipped_note=f" · skipped {skipped:,} tiny/over-cap details" if skipped else ''
                cap=path_stats.get('max_stroke_cap_resolved')
                cap_note=f" · cap {int(cap):,}" if isinstance(cap,int) else ''
                progressive_note=''
                if path_stats.get('progressive_enabled'):
                    progressive_note=(f" · progressive: {int(path_stats.get('progressive_foundation_paths',0)):,} forms → "
                                      f"{int(path_stats.get('progressive_contour_paths',0)):,} contours → "
                                      f"{int(path_stats.get('progressive_detail_paths',0)):,} details")
                path_note=(f" • Shape paths: {int(path_stats.get('source_strokes',0)):,} source runs → "
                           f"{int(path_stats.get('execution_paths',value['count'])):,} optimized paths "
                           f"({path_stats.get('compression_ratio',0)*100:.0f}% fewer boundaries)"
                           f" · {path_stats.get('shape_order','Fill first')} · {path_stats.get('shape_model','Auto')}{cap_note}{skipped_note}{progressive_note}")
            elif path_stats.get('joined_strokes'):
                path_note=(f" • Smart paths: {int(path_stats.get('source_strokes',0)):,} source runs → "
                           f"{int(path_stats.get('execution_paths',value['count'])):,} continuous strokes "
                           f"({path_stats.get('compression_ratio',0)*100:.0f}% fewer boundaries)")
            optimizer_note=''
            if path_stats.get('stroke_optimizer_effective') not in (None,'Off'):
                optimizer_note=(f" • Stroke optimizer: {path_stats.get('stroke_optimizer_effective')}"
                                f" · merged {int(path_stats.get('optimizer_merged_paths',0) or 0):,} paths"
                                f" · pen-up travel -{float(path_stats.get('optimizer_travel_reduction',0) or 0)*100:.0f}%")
            opts=value.get('options',{})
            detail_meta=opts.get('adaptive_detail_meta') or {}
            adaptive_note=''
            if detail_meta.get('adaptive_detail_effective') not in (None,'Off'):
                adaptive_note=(f" • Adaptive detail: {detail_meta.get('adaptive_detail_effective')}"
                               f" · protected {float(detail_meta.get('adaptive_detail_protected_percent',0) or 0):.0f}%"
                               f" · simplified {100-float(detail_meta.get('adaptive_detail_protected_percent',0) or 0):.0f}%"
                               f" · pruned {int(detail_meta.get('adaptive_detail_pruned_micro_strokes',0) or 0):,} micro-strokes")
            cpu_backend=(advanced.get('cpu_backend') or ('parallel' if int(opts.get('cpu_workers_resolved',1) or 1)>1 else 'serial'))
            schedule=opts.get('resource_scheduler_plan') or {}
            phase= (schedule.get('phases') or {}).get('shape_extraction') or {}
            scheduler_suffix=(f" · scheduler {schedule.get('mode')} · shape {phase.get('workers')}w/{phase.get('chunks')} chunks" if schedule else '')
            resource_note=(f" • resources: CPU {int(opts.get('cpu_workers_resolved',1) or 1)}/{int(opts.get('logical_cpus',1) or 1)} · {opts.get('cpu_engine','Auto')}"
                           f" · RAM {int(opts.get('ram_budget_mb',0) or 0):,} MB"
                           + (f" · {cpu_backend}" if cpu_backend else '') + scheduler_suffix)
            budget_note=' • Full detail · target resolution' if value.get('full_detail_preview') else ''
            if opts.get('unlimited_time'):budget_note+=' • Unlimited time'
            auto_engine=opts.get('auto_drawing_meta') or {}
            if auto_engine:budget_note+=f" • {auto_engine['preset']}: {auto_engine['image_kind']} → {auto_engine['engine']}"
            timer_meta=opts.get('gartic_timer_meta') or {}
            if timer_meta:
                budget_note+=f" • timer read ≈{timer_meta['estimated_seconds']:.0f}s (before planning)"
            auto_sketch=opts.get('sketch_auto_meta') or {}
            if auto_sketch:
                budget_note+=f" • Auto sketch: {auto_sketch['selected_detail']} · {auto_sketch['estimated_seconds']:.1f}s · omitted {auto_sketch['paths_omitted']} paths"
            if opts.get('time_budget_active'):
                budget_note+=f" • budget: {opts.get('time_budget_mode')} ({int(opts.get('time_budget_seconds', opts.get('max_seconds', 0)) or 0)}s)"
            if path_stats.get('progressive_enabled') and path_stats.get('mode') != 'Shape paths':
                budget_note += f" • progressive: {path_stats.get('progressive_phase_order','large forms → contours → details')}"
            if opts.get('target_stroke_count_resolved') is not None:
                skipped=int(path_stats.get('target_skipped_paths',0) or 0)
                reason=opts.get('target_stroke_count_reason','')
                budget_note += f" • target: {int(opts.get('target_stroke_count_resolved')):,} strokes" + (f" · skipped {skipped:,}" if skipped else '') + (f" · {reason}" if reason and reason!='explicit' else '')
            watchdog_note=''
            if opts.get('planning_attempt_name'):
                level=int(opts.get('planning_watchdog_fallback_level',0) or 0)
                watchdog_note=f" • watchdog: {opts.get('planning_attempt_name')}" + (f" · fallback level {level}" if level else '')
            preview_safety_note=''
            safety_meta=opts.get('preview_safety_meta') or {}
            if isinstance(safety_meta,dict) and safety_meta.get('active'):
                preview_safety_note=(f" • preview safety: {safety_meta.get('mode','CanvasGuard')}"
                                     f" · draw {int(safety_meta.get('drawable_subpaths',0) or 0):,}"
                                     f" · skip {int(safety_meta.get('skipped_total',0) or 0):,}"
                                     f" · edge-follow {int(safety_meta.get('adapted_total',0) or 0):,}")
                debug_meta=safety_meta.get('safety_debug') if isinstance(safety_meta.get('safety_debug'),dict) else {}
                if debug_meta:
                    preview_safety_note+=(f" · debug clipped {int(debug_meta.get('clipped',0) or 0):,}"
                                          f"/blocked {int(debug_meta.get('blocked',0) or 0):,}")
                if safety_meta.get('stopped'):
                    preview_safety_note+=' · source outside canvas warning'
            accuracy_note=''
            accuracy_meta=opts.get('pixel_accuracy_meta') or {}
            if accuracy_meta:
                accuracy_note=(f" • pixel accuracy: {float(accuracy_meta.get('final_accuracy_percent',0) or 0):.2f}%"
                               f" · coverage {float(accuracy_meta.get('coverage_percent',0) or 0):.2f}%"
                               f" · edges {float(accuracy_meta.get('edge_accuracy_percent',0) or 0):.2f}%"
                               f" · errors {int(accuracy_meta.get('final_error_pixels',0) or 0):,}"
                               f" · corrections {int(accuracy_meta.get('correction_paths_added',0) or 0):,}")
            planner_note=''
            if opts.get('planning_resolution_effective'):
                sample=f"{opts.get('planner_sample_limit')} px" if opts.get('planner_sample_limit') else ''
                pixels=f"{int(opts.get('planner_max_pixels',0)):,} px budget" if opts.get('planner_max_pixels') else ''
                pieces=' · '.join(x for x in (sample,pixels) if x)
                planner_note=f" • planning: {opts.get('planning_resolution_effective')}" + (f" · {pieces}" if pieces else '')
            preview_note=''
            if opts.get('_preview_plan'):
                ta=value.get('target_area') or opts.get('_target_area')
                pa=value.get('preview_area') or opts.get('_preview_area')
                elapsed=value.get('preview_elapsed_seconds')
                preview_note=' Safe preview is optimized and cancellable; the final full-size plan is rebuilt with your selected CPU/GPU/quality settings when you press Start Drawing.'
                if value.get('preview_fallback_used'):
                    preview_note+=' Fast fallback was used because the accurate preview attempt exceeded its time limit.'
                elif opts.get('_preview_safe_pipeline'):
                    requested=opts.get('_preview_requested_planning_resolution')
                    effective=opts.get('planning_resolution_effective',opts.get('planning_resolution'))
                    if requested and effective and requested!=effective:
                        preview_note+=f' Preview planning was capped from {requested} to {effective} for UI stability.'
                if ta and pa and tuple(ta)!=tuple(pa):
                    preview_note+=f' Preview canvas: {pa[0]}×{pa[1]} from target {ta[0]}×{ta[1]}.'
                if isinstance(elapsed,(int,float)):
                    preview_note+=f' Preview planned in {elapsed:.1f}s.'
            perf=value.get('performance_profile') or {}
            perf_note=(f"\nProfiler: {format_performance_profile(perf, compact=True)}" if perf else '')
            self.summary.set(f"About {unit} • {int(value['count']):,} brush strokes{portrait_note} • {precision} precision{human_note}{gpu_note}{fill_note}{simplify_note}{grouping_note}{color_note}{path_note}{optimizer_note}{adaptive_note}{budget_note}{accuracy_note}{planner_note}{watchdog_note}{preview_safety_note}{resource_note}\nBrush: {brush_px} px. Set the same width in the target application.{brush_tip}{priority_tip}{time_tip}{preview_note}{perf_note}")
            self.show_previews()
        elif kind=='performance_benchmark':
            if isinstance(value,dict):
                text=str(value.get('text','Performance benchmark complete.'))
                self.status.set(text)
                try:self.summary.set('Performance benchmark (planning only; no mouse input):\n'+text)
                except (tk.TclError,AttributeError):pass
        elif kind=='done':
            # Ignore a stale completion event if a future operation somehow owns
            # the UI already. This makes the queue fail closed instead of enabling
            # controls for the wrong worker.
            from StabilityRC import current_completion
            if current_completion(self.activity,value):
                finished=self.activity
                screen_window=getattr(self,'screen_task_window',None)
                if screen_window is not None:screen_window.restore()
                self.set_busy(None)
                self.worker=None
                if finished in ('draw','dry-run','mouse-test') and not self.closing:
                    try:self.root.deiconify()
                    except tk.TclError:pass
                if finished in ('draw','dry-run') and not self.closing:
                    self.refresh_runtime_safety_ui()
                    if getattr(self,'drop_in_sync_phase',None)==DROP_SYNC_DRAWING:self.drop_in_sync_phase=DROP_SYNC_READY
                if finished=='load' and not self.closing:
                    DrawBotApp._schedule_pending_drop_in_start(self)
                if finished=='browser-one-click-setup' and not self.closing:
                    if bool(getattr(self,'browser_auto_calibration_success',False)):
                        try:self.root.after(40,self._finish_browser_one_click)
                        except Exception:DrawBotApp._finish_browser_one_click(self)
                    else:
                        self.drop_in_sync_phase=DROP_SYNC_IDLE
                        try:self.browser_one_click_text.set('One-Click setup failed safely. Bring the game window into view or use Auto setup browser manually.')
                        except Exception:pass
                if finished=='browser-auto-calibration' and not self.closing:
                    if bool(getattr(self,'browser_auto_calibration_success',False)):
                        if getattr(self,'drop_in_sync_phase',None)==DROP_SYNC_AUTO_SETUP:self.drop_in_sync_phase=DROP_SYNC_READY
                        DrawBotApp._schedule_drop_in_sync_tick(self,40)
                    else:
                        if getattr(self,'pending_drop_in_import',None) is not None or normalize_drop_in_action(getattr(self,'drop_action_pending',None))==DROP_IN_ACTION:
                            DrawBotApp._disarm_manual_drop_in(self,'browser auto setup failed while Drop-In was waiting')
                            try:self.status.set('Drop-In blocked: Browser Auto Setup did not complete successfully. No drawing was started.')
                            except Exception:pass
                        self.drop_in_sync_phase=DROP_SYNC_IDLE
        else:
            log_event(f'Ignored unknown UI event: {kind!r}')

    def _remove_hotkeys(self):
        if self.hotkeys_removed:return
        self.hotkeys_removed=True
        for hotkey in list(self.hotkeys):
            try:self.keyboard.remove_hotkey(hotkey)
            except Exception as error:log_event(f'Hotkey cleanup skipped: {error!r}')
        self.hotkeys.clear()

    def _finish_shutdown(self):
        if self.shutdown_complete:return
        self.shutdown_complete=True
        DrawBotApp._cancel_after_attr(self,'poll_after')
        DrawBotApp._cancel_after_attr(self,'recovery_checkpoint_after')
        self._remove_hotkeys()
        self.stop_mobile_preview(quiet=True)
        try:
            from SessionRecovery import clear_snapshot
            clear_snapshot()
            log_event('Clean shutdown: recovery checkpoint cleared.')
        except Exception as error:log_event(f'Could not clear recovery checkpoint on clean shutdown: {error!r}')
        clean_exit()
        try:self.root.destroy()
        except (tk.TclError,RuntimeError):pass

    def poll(self):
        self.poll_after=None
        processed=0
        while processed<250:
            try:kind,value=self.events.get_nowait()
            except queue.Empty:break
            processed+=1
            try:self._handle_event(kind,value)
            except Exception as error:
                import traceback
                log_event(f'UI event {kind!r} was contained: {error!r}\n{traceback.format_exc()}')
                if not self.closing:
                    try:self.status.set(f'UI event error contained: {error}')
                    except tk.TclError:pass
        if self.stop.is_set():
            self.drop_action_pending=None
            # A stop event may remain set until the next worker starts. Do not
            # repeatedly disarm/log the already-idle Drop-In state on every Tk
            # poll tick; one transition is enough.
            has_drop_state = (
                DrawBotApp._manual_drop_in_armed(self) or
                getattr(self,'pending_drop_in_import',None) is not None or
                getattr(self,'drop_in_start_context',None) is not None or
                getattr(self,'drop_in_sync_phase',DROP_SYNC_IDLE) != DROP_SYNC_IDLE
            )
            if has_drop_state:
                DrawBotApp._disarm_manual_drop_in(self,'stop requested')
        elif normalize_drop_in_action(getattr(self,'drop_action_pending',None)) is None:
            self.drop_action_pending=None
        # RC2 fallback: if Tk dropped/cancelled the original after() callback,
        # a queued One-Click request is re-scheduled as soon as the UI is idle.
        if (getattr(self,'browser_one_click_pending',False) and not self.activity and
                not self.closing and getattr(self,'browser_one_click_after',None) is None):
            try:self.browser_one_click_after=self.root.after(40,self._run_browser_one_click)
            except (tk.TclError,RuntimeError,AttributeError):self.browser_one_click_after=None
        if self.needs_plan and not self.activity and not self.closing:
            self.needs_plan=False
            if hasattr(self,'_maybe_auto_preview'):
                self._maybe_auto_preview(delay=900, reason='queued-plan')
            elif hasattr(self,'update_plan'):
                self.update_plan()
        if self.closing and (self.worker is None or not self.worker.is_alive()):
            self._finish_shutdown();return
        DrawBotApp._schedule_poll(self)

    def close(self):
        if self.closing or self.shutdown_complete:return
        self.closing=True
        log_event('Shutdown requested.')
        try:self.save_settings()
        except Exception as error:log_event(f'Settings save during shutdown failed: {error!r}')
        self.cancel()
        DrawBotApp._cancel_after_attr(self,'profile_change_after')
        DrawBotApp._cancel_after_attr(self,'paint_config_after')
        try:self.set_busy('closing')
        except (tk.TclError,RuntimeError):pass
        for name in ('calibration_window','paint_tool_window','app_tool_window'):
            window=getattr(self,name,None)
            if window is None:continue
            try:
                if window.winfo_exists():window.destroy()
            except (tk.TclError,RuntimeError,AttributeError):pass
        if self.worker is None or not self.worker.is_alive():
            self._finish_shutdown()


def create_root():
    """Create one CustomTkinter-native root with optional TkDND support.

    CustomTkinter widgets are most stable when their toplevel is CTk rather than
    a plain tkinter.Tk. TkinterDnD's wrapper can be mixed into CTk so drag/drop
    remains available without replacing the CTk root implementation.
    """
    try:
        import customtkinter as ctk
        try:
            from UiCompatibility import patch_customtkinter_scroll_guard
            patch_customtkinter_scroll_guard()
        except Exception as error:
            log_event(f'CustomTkinter scroll compatibility patch skipped: {error!r}')
    except ImportError:
        ctk=None
    if ctk is not None:
        try:
            from tkinterdnd2 import TkinterDnD
            class DrawStudioRoot(ctk.CTk,TkinterDnD.DnDWrapper):
                def __init__(self,*args,**kwargs):
                    ctk.CTk.__init__(self,*args,**kwargs)
                    self.TkdndVersion=TkinterDnD._require(self)
            return DrawStudioRoot()
        except (ImportError,RuntimeError,tk.TclError):
            return ctk.CTk()
    try:
        from tkinterdnd2 import TkinterDnD
        return TkinterDnD.Tk()
    except (ImportError,RuntimeError,tk.TclError):
        return tk.Tk()


def main():
    enable_dpi_awareness()
    from InstanceLock import InstanceLock
    lock=InstanceLock()
    root=create_root()
    if lock.already_running:
        root.withdraw();messagebox.showinfo('Draw Studio is already open','Close the other instance first.');root.destroy();lock.close();return
    begin_run_marker()
    try:
        DrawBotApp(root)
    except Exception as error:
        messagebox.showerror('Draw Studio could not start',str(error))
        root.destroy();lock.close();raise
    try:root.mainloop()
    finally:lock.close()


def self_test(gui=False):
    # Windows CI runs these modes without hooks, clicks, capture or network.
    from PIL import Image
    plan=make_plan(Image.new('RGBA',(8,4),'black'),(80,40),
                   dict(detail=10,delay=.01,lines=True,skip_white=True,contrast=1,outline=False))
    assert plan['count']>0
    if gui:
        class NoInput:
            def add_hotkey(self,*args):return len(args)
            def remove_hotkey(self,*args):pass
            def get_position(self):return (0,0)
        root=create_root()
        try:
            app=DrawBotApp(root,NoInput(),NoInput())
            assert hasattr(root,'drop_target_register')
            app.original=Image.new('RGBA',(120,80),'orange');app.plan=plan
            root.update_idletasks();root.update();app.show_previews();root.update_idletasks()
            assert app.start.winfo_ismapped()
            assert app.original_canvas.winfo_width()>100
            assert app.activity is None
        finally:root.destroy()


if __name__=='__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    import sys
    if '--collect-diagnostics' in sys.argv:
        from DiagnosticsPackage import main as collect_main
        raise SystemExit(collect_main())
    if '--configure-crash-dumps' in sys.argv:
        from CrashDumpConfig import main as dump_config_main
        raise SystemExit(dump_config_main(sys.argv[sys.argv.index('--configure-crash-dumps')+1:]))
    if '--internal-mouse-probe' in sys.argv:
        from MouseProbe import main as mouse_probe_main
        args=[arg for arg in sys.argv[1:] if arg!='--internal-mouse-probe']
        raise SystemExit(mouse_probe_main(args))
    if '--internal-target-probe' in sys.argv:
        from TargetProbe import main as target_probe_main
        args=[arg for arg in sys.argv[1:] if arg!='--internal-target-probe']
        raise SystemExit(target_probe_main(args))
    if '--internal-palette-calibration' in sys.argv:
        from GetColorPositions import main as palette_calibration_main
        args=[arg for arg in sys.argv[1:] if arg!='--internal-palette-calibration']
        raise SystemExit(palette_calibration_main(args))
    if '--internal-exact-color-calibration' in sys.argv:
        from ExactColorCalibration import main as exact_color_main
        args=[arg for arg in sys.argv[1:] if arg!='--internal-exact-color-calibration']
        raise SystemExit(exact_color_main(args))
    if '--gpu-info' in sys.argv:
        try:
            info=acceleration_info('Auto')
            print(json.dumps(info.as_dict(),ensure_ascii=False));sys.exit(0)
        except Exception as error:
            print(json.dumps({'backend':'CPU','accelerated':False,'reason':str(error)},ensure_ascii=False));sys.exit(0)
    if '--self-test' in sys.argv or '--smoke-test' in sys.argv:
        try:self_test(gui='--smoke-test' in sys.argv)
        except Exception:
            import traceback
            (DATA_DIR/'smoke-test-error.log').write_text(traceback.format_exc(),encoding='utf-8')
            sys.exit(1)
        sys.exit(0)
    main()
