# Docs Index — v1.0.68-beta

This release makes the documentation easier to follow from both source ZIP and frozen EXE builds.

## Main files

- `README.md` — install, first use, safety flow and build instructions.
- `README-INDEX.md` — short guide to every important documentation group.
- `VERSION-HISTORY.md` — readable timeline of what changed by version.
- `RELEASE-CHECKLIST.md` — release verification checklist.
- `BUILD-STATUS.txt` — current release verification snapshot.

## History folders

- `docs/README.md` — documentation landing page.
- `docs/history/README.md` — detailed historical file index.
- `docs/history/*.md` — older feature notes and recent release notes.
