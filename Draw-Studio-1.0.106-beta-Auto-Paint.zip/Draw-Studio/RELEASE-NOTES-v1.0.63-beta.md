# Draw Studio v1.0.63-beta — Adaptive Stroke & Input Ownership Fix

This release is a regression-focused update after v1.0.62.

## Changes

- Microsoft Paint no longer forces MOVE_NOCOALESCE + 2 px / 5 ms delivery by default.
- Paint Auto delivery uses the compatibility cursor backend with High-precision-friendly <=4 px sampling.
- Reliable SendInput delivery remains available internally as an explicit fallback.
- Manual-mouse detection confirms a cursor deviation twice before stopping.
- GuardedMouse records the actual Windows cursor endpoint after an owned move.
- A transient WindowFromPoint cover is retried once before stopping; wrong foreground, moved target and canvas violations still stop immediately.
- Dry Run remains click-free and keeps the v1.0.61 completion fix.
- CanvasGuard, SafeFillMask, FinalMouseGuard and edge safety are unchanged.

The goal is fewer false aborts and better compatibility without weakening hard canvas/window safety.
