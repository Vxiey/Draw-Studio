# Patchkontroll och sammanslagning – Draw Studio v1.0.91-beta

## Resultat

En separat v1.0.90-gren hade inte kommit med i Upscaling-paketet: **Adaptive Brush Draw Motor**. Den är nu sammanslagen med Upscaling och dess föregående fixar i v1.0.91-beta.

Mellan den uppladdade v1.0.85 och Upscaling saknades inga programfiler. 216 gamla filer i safety-reports hade tagits bort redan mellan v1.0.85 och v1.0.86. De finns fortfarande i originalarkivet v1.0.85; originalarkiven har inte ändrats. De återinförs inte i distributionspaketet.

## Kontrollerade steg

| Från → till | Borttagna filer | Tillagda filer | Ändrade filer |
|---|---:|---:|---:|
| 1.0.85-rc1-Auto-NVIDIA-CUDA-Setup → 1.0.86-beta-Block-A-Pixel-Accurate-Planner | 216 | 3 | 63 |
| 1.0.86-beta-Block-A-Pixel-Accurate-Planner → 1.0.87-beta-Block-B-Component-Stroke-Engine | 0 | 3 | 59 |
| 1.0.87-beta-Block-B-Component-Stroke-Engine → 1.0.88-beta-Block-C-Pixel-Accuracy-Engine | 0 | 3 | 60 |
| 1.0.88-beta-Block-C-Pixel-Accuracy-Engine → 1.0.89-beta-Block-D-GPU-Progressive-Accuracy | 0 | 3 | 64 |
| 1.0.89-beta-Block-D-GPU-Progressive-Accuracy → 1.0.90-beta-Review-Crash-Diagnostics | 0 | 8 | 71 |
| 1.0.90-beta-Review-Crash-Diagnostics → 1.0.90-beta-Image-Formats | 0 | 3 | 2 |
| 1.0.90-beta-Image-Formats → 1.0.90-beta-Upscaling | 0 | 3 | 4 |

Samtliga nio jämförda ZIP-arkiv passerade CRC-kontroll och hade inga dubbla filposter. Den uppladdade Upscaling-filen är byte-identisk med den tidigare levererade lokala filen. Inga modul-/klassmetoddefinitioner togs bort i den linjära serien från v1.0.85 till Upscaling. Detta verifierar struktur och förekomst, inte att varje beteende är identiskt.

## Det som saknades från den andra v1.0.90-grenen

- AdaptiveBrushEngine.py och test_draw_motor_v1090.py.
- Integration i DrawBot.py för penselstorlek per ritstreck och verifierade penselbyten i webbläsare.
- CPU- och CUDA-simulering med penselstorlek per ritstreck samt korrigering med detaljpensel.
- Komponentmetadata i PixelStrokeEngine.py.
- Byggintegration och den grenens ändringslogg.

Grenens 74 extra säkerhetsrapporter är körhistorik och ingår inte i den nya releasen. De finns kvar i originalarkivet för Adaptive Brush. Dess ändringslogg heter nu RELEASE-NOTES-v1.0.90-Adaptive-Brush.md så att den inte skriver över granskningsgrenens logg med samma versionsnummer.

## Så slogs koden ihop

V1.0.89 användes som gemensam bas i en trevägssammanslagning. Konflikterna i ritplaneringen löstes genom att behålla både adaptiv penselmetadata och motivlägets avstängda korrigeringspass. Motivets prefixed phases känns nu igen av penselpolicyn, utan att ritordningen ändras. Motivfokus fortsätter planera för 1 px penna.

Kraschdiagnostik, dumpkonfiguration, säkrare musprov, CPU-avbrott, begränsade CUDA-batcher, korrekt klippning utanför canvas och ordningsbevarande accuracy-checkpoints har behållits. Likaså motivmarkering, bildformatidentifiering, transparenshantering, uppskalning och Undo.

## Inställningar och användardata

RuntimePaths.py, StabilityRC.py och SessionRecovery.py var oförändrade mellan v1.0.85 och Upscaling. Inga bokstavliga ordboksnycklar försvann ur read_settings, save_settings eller options. Palettens indexkarta och de befintliga kalibreringsmodulerna finns kvar. NVIDIA-installationsskriptet finns kvar.

De uppladdade arkiven innehåller inte dina personliga settings-*.json, calibration-*.json eller profiles.json. Därför kan denna granskning inte verifiera inställningarna på din Windows-dator. Källkodsversionen sparar användardata intill skripten; EXE-versionen använder normalt %LOCALAPPDATA%\DrawBotStudio. Om du packar upp i en ny mapp kan gamla inställningar ligga kvar i den gamla mappen. Behåll den gamla mappen och säkerhetskopiera settings*.json, calibration*.json, profiles.json, paint-tools.json och eventuell recovery-mapp innan du byter. Nya automatiska startbehörigheter återställs inte från gamla inställningar.

## Verifiering av v1.0.91

- 739 automatiserade tester godkända: 725 från Upscaling, 10 från penselgrenen och 4 nya kombinationstester.
- Testet för uppdateringskontroll använder nu en uttrycklig äldre testversion, så versionshöjningen inte gör testet felaktigt.
- Python-syntax, gemensamma modul-/klassdefinitioner, paketets filinventering och ZIP-integritet kontrollerade.
- Source self-test godkänd.
- Windows-GUI, verklig musritning, WER-dumpinsamling och riktig NVIDIA CUDA är inte verifierade i Linuxmiljön. Ingen EXE har byggts.

Omfattningen är v1.0.85–v1.0.91 och de identifierade v1.0.90-grenarna. Detta är inte en granskning av samtliga patchar före v1.0.85 eller varje tidigare revision av samma ZIP-fil.

## Källarkivens SHA-256

- Draw-Studio-1.0.85-rc1-Auto-NVIDIA-CUDA-Setup(1).zip: `f9bb0808261855117a513101ea93c18239e8ebc8e6a4341f2f81eb55763991f6`
- Draw-Studio-1.0.86-beta-Block-A-Pixel-Accurate-Planner.zip: `4df3149897ac69b0b64007c9ebca978fb9871281ba997f9422271a13d5efe650`
- Draw-Studio-1.0.87-beta-Block-B-Component-Stroke-Engine.zip: `be188b16b817d571ebe9a11994e64e1dce806452ea5fa37fe42a6ffc0febbfd9`
- Draw-Studio-1.0.88-beta-Block-C-Pixel-Accuracy-Engine.zip: `434faab54db2f2266e2169ae76eb315ce9c9710caa8826f8638ece23b9f9b25f`
- Draw-Studio-1.0.89-beta-Block-D-GPU-Progressive-Accuracy.zip: `bcfe4ee5fe2d5ef84476659456b96e2933057b29107755893a31c3db0ce2945e`
- Draw-Studio-1.0.90-beta-Review-Crash-Diagnostics.zip: `f35ad98bd648ce9601d334ae12bc1fc8ce4a696b178ae3e467361b3150d2975b`
- Draw-Studio-1.0.90-beta-Image-Formats.zip: `3ea001c7b80440a7844fa47259cdb1a7d94412125bd9a8ec679f605899a88a8b`
- Draw-Studio-1.0.90-beta-Upscaling(1).zip: `62d7d32fdf88252178a7f0869be390a15b103f967eb6d4f5f1cafe2ac7d9a760`
- Draw-Studio-1.0.90-beta-Adaptive-Brush-Draw-Motor.zip: `feac7cb2a43dd9193aebf749555e16df5a5c742d7e4d850a3356f9394651f6a6`
