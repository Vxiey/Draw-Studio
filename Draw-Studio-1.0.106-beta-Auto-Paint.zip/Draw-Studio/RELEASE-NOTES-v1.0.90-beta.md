# Draw Studio v1.0.90-beta — Code review & crash diagnostics

Based on the supplied v1.0.89-beta Block D source ZIP. Original SHA-256:
`bcfe4ee5fe2d5ef84476659456b96e2933057b29107755893a31c3db0ce2945e`

## Fixed

- Windows LocalDumps setup now uses the documented HKLM location and explicitly requires one-time administrator setup. Previous values are backed up before changes. Disable restores only values still matching Draw Studio's changes.
- The mouse-test subprocess drains its output while waiting, avoiding a full-pipe deadlock. Cancel/timeout collects remaining output, waits for termination and closes streams.
- A mouse-test thread startup failure restores idle state and the minimized window.
- Input is disarmed even if releasing a held button fails.
- Shutdown marker ownership compares the complete PID rather than a substring.
- Auto Fill white repairs are restricted to interior fill bounds when no full-canvas background fill is planned. The original regression test failed before the patch and passes afterwards.
- CPU and CUDA rectangle compilation reject wholly out-of-bounds strokes instead of painting an artificial border pixel. Partially visible brush footprints remain clipped.
- Accuracy checkpoints retain actual execution order when a phase recurs.
- A progressive path budget no longer exceeds the total number of source paths.
- CUDA simulation limits both row tile size and per-launch pixel/rectangle work. This reduces excessively long launches; actual driver timing remains hardware-dependent.
- CUDA scoring uses CPU fallback if its full-frame mask allocation would exceed the selected budget estimate.
- CUDA simulation failures are logged; a synchronization error cannot be reported as successful GPU execution.
- Component construction and vertical-column scans check cancellation more often.
- Diagnostic filenames are unique even for two exports in the same second.
- Log export reads a bounded tail instead of loading an entire oversized log.
- Settings export uses an allowlist so unknown credential fields are not copied.
- Collecting diagnostics no longer initializes the CUDA driver. The BAT and UI use the same sanitized collector, which lists available dumps but does not attach raw memory automatically.

## Validation

The original suite ran 685 tests with one Auto Fill failure in this environment. After the fixes, 14 review regression tests and 12 subject-focus tests, 711 tests pass. Python syntax/definition scanning covered 214 Python files, with no duplicate function/class definitions in the same module/class. This is not proof of absence of all bugs or a line-by-line semantic audit of every function.

Source self-test and final archive integrity are checked separately. No Windows GUI, actual mouse input, Windows Error Reporting, frozen EXE, or real CUDA device was exercised here. A Windows crash dump from the user's failing action is still needed to diagnose that particular native crash. The release is a source ZIP, not a newly built executable.

## Remaining limitations

- GPU accuracy scoring remains a full-frame algorithm with conservative CPU fallback; it is not tiled scoring.
- CPU threads do not guarantee linear speedup for Python loops.
- Simulated pixel accuracy is not a measurement of pixels actually delivered to Paint or a game server.
- A release test that only reads source strings cannot establish GUI compatibility. Windows smoke tests and an actual small drawing test remain necessary.
- The app has many interacting profile/safety/calibration paths; the regression suite covers selected cases, not every combination.

## Native dump setup

Right-click `Enable-Crash-Dumps.bat` and run as administrator once. Then run `Start.bat` normally and reproduce the failure. Dumps are written by Windows under `%LOCALAPPDATA%\DrawBotStudio\dumps` when an eligible native crash occurs. Source mode also configures other processes named `python.exe`/`pythonw.exe`. Handled Python errors produce logs rather than native dumps.

The configuration change follows [Microsoft's LocalDumps documentation](https://learn.microsoft.com/en-us/windows/win32/wer/collecting-user-mode-dumps). Existing dump files remain local; share selected files manually.


Subject Focus added: Off / Subject first / Subject only, manual image rectangle, transparency or uniform-border background estimate, mask preview, timer priority and 12 regression tests. See MOTIVFOKUS.md for usage and limitations. No semantic detection; 1 px Pixel Accurate full-colour paths; correction passes disabled only while subject focus is enabled.
