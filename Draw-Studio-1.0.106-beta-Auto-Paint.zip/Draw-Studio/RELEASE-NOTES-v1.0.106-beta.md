# v1.0.106-beta — Auto setup Paint

## Så gör du
1. Packa upp hela ZIP-filen och kör Start.bat.
2. Öppna ett Paint-fönster med en tom, helt synlig rityta.
   Använd ljus appdesign, visa hela verktygsfältet och stäng öppna menyer.
3. Välj Microsoft Paint i Draw Studio och tryck Auto setup Paint.
4. Draw Studio minimeras och läser av rityta, 20 färger, Pencil, Fill och Eraser.
   Du behöver inte först markera ritytan. Inga ritklick skickas vid kalibreringen.
5. Appens Auto-verktyg väljer Pencil. Ställ Pencil på 1 px i Paint och kör Small test.
6. Lägg in din bild, välj exempelvis Extra fast och bygg preview innan Start.

Penselbredden kan ännu inte läsas automatiskt med tillräcklig säkerhet.
Brush-menyn och dess penseltyper kalibreras inte av detta flöde: Pencil används
som ett direkt, opakt ritverktyg och Fill får en separat verifierad position.

## Vad som ändrats
- Tidigare gissningar från ikonernas täthet/ordning används inte längre.
- Modern Paint identifieras genom färgrutornas inbördes placering och jämförelse
  med Pencil-, Fill- och Eraser-ikonerna från den uppladdade referensen.
- Riktiga RGB-värden läses från 20 verifierade färgrutor; dubletter undviks.
- Koordinater förankras i Paint-fönstret och inkluderar skärmens position.
- Storleken på analysbilderna begränsas och arbetet körs i bakgrundstråden.
- Täckta eller okända verktyg, flera Paint-fönster, täckta färger och osäker
  rityta ger ett tydligt fel. Manuell kalibrering finns kvar.
- Auto setup startar inte ritning eller väljer Done/Fill genom att klicka.

## Verifiering och begränsningar
821 automatiserade tester samt source self-test godkända på Linux.
Den uppladdade Paint-bilden och skalade kopior vid 80/100/125/150/200 procent
har kontrollerats. Det är bildtester, inte provkörning av verkliga Windows
DPI-inställningar. Själva Windows-aktiveringen, GUI-flödet och ritningen måste
fortfarande verifieras på Windows.

Detta är stöd för den moderna ljusa Paint-layouten i referensbilden, inte ett
löfte om alla äldre/nya Paint-versioner, mörkt tema eller hopfällda verktygsfält.
Befintliga bilder och ritytor som ligger utanför fönstret väljs manuellt.
Paketet innehåller källkod och Start.bat; ingen nybyggd EXE.
