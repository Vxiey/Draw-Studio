# Automatic Brush Size — v1.0.74-beta

Browser brush-size controls are derived from the already verified game layout and visually checked before Draw Studio creates a click target. Gartic Phone uses its five bottom brush controls, Skribbl uses the four size buttons beside the canvas toolbar, and SketchHeads uses the three grey circles immediately left of the true color row. Low-confidence detection never guesses a click and increases the CanvasGuard brush inset instead.
