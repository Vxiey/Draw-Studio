# v1.0.58-beta — Runtime Safety UI + Release Prep

- Latest local runtime safety counters are visible in Tools.
- Open latest report / report folder / refresh controls.
- Hover tooltips on critical safety buttons and improved first-run guidance.
- Remote report-server/client upload feature removed; diagnostics are local/manual-share only.
- GitHub Actions builds Windows x64 ZIP + Setup EXE and publishes tag releases.
- Frozen bundle no longer embeds the historical markdown/report-server setup files.
