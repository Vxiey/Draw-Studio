# Draw Studio v1.0.94-beta — Original UI restored

Restores the StudioUI.py layout from v1.0.91: original dark/green theme, three-column workspace, visible step cards and nine preview tabs. The v1.0.92 section navigation, preview dropdown and responsive row changes are no longer used by the main UI.

Keeps the newer manual GitHub update messages and release button, calibration window minimization/restoration, startup NameError fix and pointer-local scroll handling. Drawing engine, images, settings and calibration formats are unchanged. Existing historical documentation for v1.0.92 describes the reverted layout, not this release.

753 automated tests passed and source self-test passed. Windows GUI startup/layout not verified here; source package only, no EXE built.
