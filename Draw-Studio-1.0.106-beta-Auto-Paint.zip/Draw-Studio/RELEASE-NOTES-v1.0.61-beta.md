# Draw Studio v1.0.61-beta — Fast Dry Run Completion Fix

Fixes Fast Dry Run incorrectly reporting `Time limit reached` as a failed test. The 12-second budget now starts at cursor simulation, representative sampling is smaller, and a clean budget expiry counts as PASS. Real drawing deadlines and every CanvasGuard/safety stop remain hard failures.
