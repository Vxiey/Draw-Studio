# v1.0.101-beta — Read Gartic timer

## Användning

1. Välj **Gartic Phone** och ditt sketchläge. Välj svart i spelet.
2. Låt **Read Gartic timer at Start** vara aktiverat (ny standard).
3. Visa hela den runda timern och ritytan i webbläsaren.
4. Klicka Start. Appen minimeras och läser timern sju gånger under cirka sex
   sekunder. Inga mus-/tangenttryck skickas under avläsningen.
5. Status visar ungefärliga sekunder kvar och en försiktigare ritbudget.
   Sketch använder Auto-detaljer utifrån den uppmätta tiden.

Om avläsningen inte är säker stoppas starten. Visa timern tydligt och försök
igen, eller stäng av reglaget och ange tiden manuellt. Övriga spelprofiler,
små provritningar och dry run använder inte denna timeravläsning.
Preview före Start använder fortfarande appens manuella tidsbudget.

## Hur sekunderna beräknas

En ensam bild av cirkeln innehåller ingen total rundtid. Detektorn mäter den
vita andelen längs flera cirklar och följer minskningen. Andel kvar dividerad
med minskning per sekund ger en uppskattning av sekunder kvar. Ingen OCR/AI
eller antagen fast rundlängd används.

Ringen måste ha rätt form/färg, vara entydig och finnas utanför den valda
ritytan. En skymd ring, en stillastående timer, en återställning eller ojämn
minskning stoppar mätningen. Mätosäkerheten ger en lägre, konservativ budget.
Auto-sketch lämnar sedan sin vanliga marginal. Det kan ge färre detaljer,
men appen presenterar inte uppskattningen som exakta sekunder.

En absolut sluttid följer planen och begränsar musmotorn. Planering, väntan och
paus flyttar inte fram den. Om för mycket tid gått före ritstart stoppas den.
Motorn läser inte timern kontinuerligt medan den ritar: ändras spelets timer
senare kan den tidigare uppskattningen vara inaktuell. Stop/Esc finns kvar.

## Installation

Hela paketet: packa upp och kör Start.bat. Behåll den gamla mappen.
Patch för v1.0.100: stäng appen och kopiera DrawBot.py, StudioUI.py,
GarticTimer.py, Version.py och version_info.txt till mappen med Start.bat.
Välj Ersätt filer. Inställningar och kalibrering behålls.

## Verifiering

794 automatiserade tester och source self-test godkända. Åtta nya tester
kontrollerar skalning/andelar, flera rundlängder, återställning/stillastående
ring, avbrott, tidsbudget över gamla presets, simulerad avläsningsserie och
att en utgången sluttid inte skickar musnedtryck.

Den uppladdade timerbilden hittades vid bildkoordinater (100,64)-(176,140)
med cirka 46,5 procent vit fyllning. Den bilden ensam kan inte validera sekunder.
Tidmätningen har testats med syntetiska bildserier, inte en inspelning från
användarens riktiga runda. Windows-gränssnitt, live-avläsning och faktisk ritning
behöver fortfarande provköras. Källkod med Start.bat, ingen nybyggd EXE.
