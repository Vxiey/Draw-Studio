# Draw Studio v1.0.77-beta — Real-Speed Time Budget

Includes v1.0.76 Layout Fingerprint v2.

- Learns real completed browser drawing throughput per game.
- 30/60/90-second budgets use learned paths/second with a conservative safety reserve.
- Automatically lowers path count, active colors and micro-detail when the measured machine/browser combination cannot finish the full plan in time.
- Structural path priority keeps large outlines and important forms before small detail under tight caps.
- Gartic Phone and Skribbl Fast receive dynamic Turbo max-color limits.
- Interrupted drawings and Dry Runs never train the speed profile.
- Local timing data only; no telemetry or screenshots.
