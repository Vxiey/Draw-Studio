# Smart Recovery / Resume

## Added

- Path-level render checkpoints store completed color batches plus the active color and exact next unfinished path.
- Recoverable browser interruptions (bounded stroke-delivery failure, manual mouse takeover, transient overlay/foreground interruption) save the current unfinished path before execution stops.
- The next explicit Start follows the normal Browser Auto-Recalibration + Visual Preflight path before any input is armed, then resumes at the saved path.
- Already completed paths in the active color are skipped, so the whole image is not redrawn.
- Ordered path lists are fingerprinted; if replanning changes path order, Draw Studio refuses the path-level skip and restarts only that color batch safely.
- A lightweight checkpoint is also written every 25 completed paths for crash resilience.

## Hard-stop rules

- CanvasGuard/canvas geometry changes, target-window geometry changes, DPI/client-area changes and invalid drawing-area conditions do not create an automatic path-level resume.
- Smart Recovery never restores drawing authorization and never auto-steals the mouse. User Start remains explicit.

## Included

- All v1.0.78 Stroke Delivery Verification behavior, including the one-retry-per-stroke cap.
