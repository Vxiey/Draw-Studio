"""Conservative time selection for the existing closed-contour bucket engine."""
from Precision import CanvasTransform,precision_path_count
from SpeedOptimizer import phase_delay,estimated_motion_seconds


def select_fast_regions(regions,source_size,target_size,options,cancelled=lambda:False):
    transform=CanvasTransform(*source_size,target_size)
    delay=float(options.get('delay',.01));speed=options.get('speed','Balanced')
    precision=options.get('precision','High');step=options.get('stroke_step_px',8)
    accepted=[];rejected=0;seconds=0.;saved=0.
    for region in regions:
        if cancelled():raise InterruptedError()
        contour=list(region.get('contour') or ())
        if len(contour)<4 or contour[0]!=contour[-1]:
            rejected+=1;continue
        moves=sum(precision_path_count(transform.point(*a),transform.point(*b),precision,step)
                  for a,b in zip(contour,contour[1:]))
        # Include tool switches, palette selection, settle and verification time.
        # Charging switches per region is deliberately conservative; runtime groups colours.
        tool_cost=.8+sum(.28 if kind in ('brush-menu','brush-preset') else .22
                        for kind,_ in (options.get('fill_tool_actions') or [('tool',None)]))
        tool_cost+=sum(.28 if kind in ('brush-menu','brush-preset') else .22
                        for kind,_ in (options.get('fill_restore_actions') or [('tool',None)]))
        fill_cost=tool_cost+moves*max(.004,phase_delay(delay,speed,'path'))
        spans=region.get('row_spans') or ()
        scan_moves=sum(precision_path_count(transform.point(x0,y),transform.point(x1,y),precision,step)
                       for y,x0,x1 in spans)
        scan_cost=estimated_motion_seconds(scan_moves,len(spans),0,delay,speed)
        if not spans or fill_cost>=scan_cost*.75:
            rejected+=1;continue
        accepted.append(region);seconds+=fill_cost;saved+=scan_cost-fill_cost
    return accepted,{'accepted_regions':len(accepted),'cost_rejected_regions':rejected,
                     'fill_estimated_seconds':round(seconds,3),
                     'estimated_seconds_saved_vs_scanlines':round(saved,3)}
