# Draw Studio release checklist

1. Set `APP_VERSION` / `FILE_VERSION` in `Version.py` and update `version_info.txt`.
2. Run `python -m unittest discover -v` and `python DrawBot.py --self-test`.
3. Build on Windows with `Build-Release.bat` or GitHub Actions.
4. Confirm the frozen `DrawStudio.exe --self-test` passes (builder does this automatically).
5. Verify ZIP + Setup EXE checksums against `SHA256.txt`.
6. Test on a clean Windows 10/11 x64 standard-user account.
7. Test Paint: image → calibration → canvas → small test → Lock → Preflight → Dry run → Unlock → Start.
8. Verify CanvasGuard, Esc stop, F6 pause/resume and Runtime Safety UI.
9. Verify diagnostics/safety reports remain local and no report-upload UI/backend exists.
10. Add Authenticode signing before broad distribution when a certificate is available.
11. Push tag `v<APP_VERSION>` to publish the GitHub Release automatically.
