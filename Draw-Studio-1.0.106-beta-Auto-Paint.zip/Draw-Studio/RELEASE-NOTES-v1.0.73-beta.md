# Draw Studio v1.0.73-beta – Drop-In Synchronization

Drop-In Start now waits for read-only browser setup instead of rejecting a user-authorized image when timing overlaps Auto Setup, Auto-Recalibration or Visual Preflight.

## Added

- Bounded 30-second pending Drop-In queue for supported browser profiles.
- Latest image wins while a Drop-In request is waiting.
- Explicit synchronization states for Auto Setup, Auto-Recalibration, Visual Preflight, Draw Pending and Drawing.
- Target/profile identity check before a queued image is loaded or drawing begins.
- Pending authorization is one-shot, local to the process and never persisted.
- Automatic resume when browser setup completes.

## Fixed

- Browser Auto Setup no longer marks itself busy before `begin_worker`; that self-block could prevent the worker from starting.
- A loaded Drop-In image is no longer rejected just because read-only setup is still converging.
- Target changes while waiting cancel the pending request before native input.

## Tests

Regression coverage includes drop during Auto Setup, Visual Preflight, Auto-Recalibration, target change while waiting and replacement by a newer image.
