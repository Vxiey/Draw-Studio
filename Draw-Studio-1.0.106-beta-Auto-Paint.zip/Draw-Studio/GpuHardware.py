"""NVIDIA GPU hardware discovery for Draw Studio.

Hardware discovery is intentionally independent from CuPy so Draw Studio can
report an installed NVIDIA GPU even when the optional CUDA Python backend is
missing or broken. On Windows we prefer nvidia-smi and fall back to CIM/WMI.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Iterable


@dataclass(frozen=True)
class NvidiaGpu:
    index: int | None
    name: str
    memory_total_mb: int | None = None
    driver_version: str = ""
    bus_id: str = ""
    source: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


_CACHE: tuple[NvidiaGpu, ...] | None = None


def _creationflags() -> int:
    return int(getattr(subprocess, "CREATE_NO_WINDOW", 0)) if os.name == "nt" else 0


def _run(command: list[str], timeout: float = 3.0) -> str:
    completed = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        creationflags=_creationflags(),
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError((completed.stderr or completed.stdout or f"exit {completed.returncode}").strip())
    return completed.stdout.strip()


def _nvidia_smi_candidates() -> Iterable[str]:
    seen: set[str] = set()
    found = shutil.which("nvidia-smi")
    if found:
        seen.add(os.path.normcase(found))
        yield found
    if os.name != "nt":
        return
    candidates = [
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "nvidia-smi.exe",
        Path(os.environ.get("ProgramW6432", r"C:\Program Files")) / "NVIDIA Corporation" / "NVSMI" / "nvidia-smi.exe",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "NVIDIA Corporation" / "NVSMI" / "nvidia-smi.exe",
    ]
    for candidate in candidates:
        key = os.path.normcase(str(candidate))
        if key not in seen and candidate.is_file():
            seen.add(key)
            yield str(candidate)


def _parse_int(value: object) -> int | None:
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def _detect_with_nvidia_smi() -> list[NvidiaGpu]:
    for executable in _nvidia_smi_candidates():
        try:
            output = _run([
                executable,
                "--query-gpu=index,name,memory.total,driver_version,pci.bus_id",
                "--format=csv,noheader,nounits",
            ])
        except (OSError, RuntimeError, subprocess.TimeoutExpired):
            continue
        result: list[NvidiaGpu] = []
        for line in output.splitlines():
            parts = [part.strip() for part in line.split(",")]
            if len(parts) < 5:
                continue
            index, name, memory, driver = parts[:4]
            bus = ",".join(parts[4:]).strip()
            if "nvidia" not in name.lower() and not name.lower().startswith(("geforce", "quadro", "rtx", "tesla")):
                # nvidia-smi only reports NVIDIA devices, but keep the sanity check
                # permissive for consumer names that omit the NVIDIA prefix.
                pass
            result.append(NvidiaGpu(_parse_int(index), name, _parse_int(memory), driver, bus, "nvidia-smi"))
        if result:
            return result
    return []


def _detect_with_powershell() -> list[NvidiaGpu]:
    if os.name != "nt":
        return []
    powershell = shutil.which("powershell") or shutil.which("powershell.exe") or shutil.which("pwsh")
    if not powershell:
        return []
    script = (
        "$g=Get-CimInstance Win32_VideoController | Where-Object {$_.Name -match 'NVIDIA'} | "
        "Select-Object Name,DriverVersion,AdapterRAM,PNPDeviceID; "
        "if($null -ne $g){$g | ConvertTo-Json -Compress}"
    )
    try:
        output = _run([powershell, "-NoProfile", "-NonInteractive", "-Command", script], timeout=5.0)
        if not output:
            return []
        payload = json.loads(output)
    except (OSError, RuntimeError, subprocess.TimeoutExpired, json.JSONDecodeError):
        return []
    items = payload if isinstance(payload, list) else [payload]
    result: list[NvidiaGpu] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        name = str(item.get("Name") or "").strip()
        if "nvidia" not in name.lower():
            continue
        adapter_bytes = _parse_int(item.get("AdapterRAM"))
        memory_mb = int(adapter_bytes // (1024 * 1024)) if adapter_bytes and adapter_bytes > 0 else None
        result.append(NvidiaGpu(None, name, memory_mb, str(item.get("DriverVersion") or ""),
                                str(item.get("PNPDeviceID") or ""), "Windows CIM"))
    return result


def detect_nvidia_gpus(*, refresh: bool = False) -> tuple[NvidiaGpu, ...]:
    global _CACHE
    if _CACHE is not None and not refresh:
        return _CACHE
    found = _detect_with_nvidia_smi()
    if not found:
        found = _detect_with_powershell()
    # Stable order: CUDA/nvidia-smi index first, then highest reported VRAM.
    found.sort(key=lambda gpu: (gpu.index is None, gpu.index if gpu.index is not None else 9999,
                                -(gpu.memory_total_mb or 0), gpu.name.lower()))
    _CACHE = tuple(found)
    return _CACHE


def best_nvidia_gpu(*, refresh: bool = False) -> NvidiaGpu | None:
    gpus = detect_nvidia_gpus(refresh=refresh)
    if not gpus:
        return None
    # Prefer the device with most VRAM; use nvidia-smi index as deterministic tie-breaker.
    return max(gpus, key=lambda gpu: (gpu.memory_total_mb or 0, -(gpu.index or 0)))


def hardware_summary(*, refresh: bool = False) -> str:
    gpu = best_nvidia_gpu(refresh=refresh)
    if gpu is None:
        return "No NVIDIA GPU detected"
    memory = f" · {gpu.memory_total_mb:,} MB VRAM" if gpu.memory_total_mb else ""
    driver = f" · driver {gpu.driver_version}" if gpu.driver_version else ""
    return f"{gpu.name}{memory}{driver} · detected via {gpu.source or 'Windows'}"


def cupy_smoke_test() -> tuple[bool, str]:
    """Run a tiny real CUDA kernel so missing runtime/header issues are caught."""
    gpu = best_nvidia_gpu(refresh=True)
    if gpu is None:
        return False, "No NVIDIA GPU detected"
    try:
        import cupy as cp
        count = int(cp.cuda.runtime.getDeviceCount())
        if count < 1:
            return False, f"{gpu.name} detected, but CuPy reports no CUDA devices"
        target = gpu.index if gpu.index is not None and 0 <= gpu.index < count else 0
        with cp.cuda.Device(int(target)):
            kernel = cp.RawKernel(
                'extern "C" __global__ void drawstudio_probe(float* x){int i=blockDim.x*blockIdx.x+threadIdx.x;if(i<32)x[i]=x[i]*2.0f+1.0f;}',
                "drawstudio_probe",
            )
            arr = cp.arange(32, dtype=cp.float32)
            kernel((1,), (32,), (arr,))
            cp.cuda.Stream.null.synchronize()
            if float(cp.asnumpy(arr)[3]) != 7.0:
                return False, "CUDA probe returned an unexpected result"
        return True, f"CUDA ready on {gpu.name}"
    except Exception as exc:
        return False, f"{gpu.name} detected, but CUDA/CuPy smoke test failed: {type(exc).__name__}: {exc}"


def _main(argv: list[str]) -> int:
    if "--cupy-smoke" in argv:
        ok, message = cupy_smoke_test()
        print(message)
        return 0 if ok else 2
    gpus = detect_nvidia_gpus(refresh=True)
    if "--json" in argv:
        print(json.dumps([gpu.as_dict() for gpu in gpus], ensure_ascii=False))
    elif gpus:
        for gpu in gpus:
            print(hardware_summary())
            break
    elif "--quiet" not in argv:
        print("No NVIDIA GPU detected")
    return 0 if gpus else 1


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
