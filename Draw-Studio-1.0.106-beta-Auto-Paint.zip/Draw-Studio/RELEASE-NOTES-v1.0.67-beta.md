# Draw Studio v1.0.67-beta – Manual Drop-In Start

## Added

- New one-shot **Arm Drop-In Start** control in the Add image step.
- Browser/game profiles can now start drawing automatically after the next image import/drop.
- Works with drag/drop, Select image, Paste image and Load URL.
- 120-second arm expiry.
- Clear UI status for armed, expired, accepted and blocked Drop-In Start states.

## Safety

- Not persisted between sessions.
- Disabled for Microsoft Paint; Paint keeps Small test → Lock setup → Safety preflight → Dry run → Unlock → Start.
- Still requires canvas/target/palette readiness before arming.
- Still verifies target setup before drawing.
- CanvasGuard, FinalMouseGuard, target monitoring and safe polygon clipping are unchanged.
- Old `Draw immediately` setting remains retired and is ignored safely.

## Verification

- 551/551 unit tests passed.
- `compileall` passed.
- `DrawBot.py --self-test` passed.
