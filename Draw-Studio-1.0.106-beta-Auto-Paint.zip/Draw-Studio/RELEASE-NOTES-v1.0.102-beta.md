# Draw Studio v1.0.102-beta

## Enklaste arbetsflödet

1. Packa upp hela paketet och kör **Start.bat**. Behåll din tidigare mapp.
2. Välj **Gartic Phone**. Visa en tom spelcanvas i webbläsaren.
3. Klicka **Auto setup Gartic — full canvas**. Appen minimeras, söker en
   entydig spelvy och kalibrerar hela ritytan och paletten. Ingen ritning startas.
4. Lägg in bilden. Välj **Drawing preset → Auto**.
5. Bygg preview, kontrollera resultatet och klicka Start. Gartics timer läses
   vid Start om Read Gartic timer är aktivt och du inte valt Unlimited.

Penselstorleken verifieras med den befintliga avläsningen före ritning.
Single-color sketch använder färgen som redan är vald i spelet: välj svart.
Fullfärgsläget använder den kalibrerade paletten. En skymd/oklar spelvy kan
kräva manuell markering; detta är inte garanti för alla zoomnivåer eller teman.

## Drawing preset

| Val | Funktion |
| --- | --- |
| Auto | Klassificerar grovt med vitandel, färger och textur. Linjegrafik använder konturer; platta färgillustrationer Shape paths; fotoliknande färgbilder Smart paths. Befintligt enfärgsläge respekteras och får Auto-sketchdetaljer. |
| Manual | Dina egna motor-, kvalitets- och sketchval behålls. |
| Masterpiece | Ingen ritningstimer. Färgbilder använder Pixel Accurate utan snabbprofilens förenkling. Enfärg/sketch använder Detailed med den befintliga konturmotorn. |

Auto är en regelbaserad rekommendation, ingen AI eller visuell förståelse av
motivet. Du kan välja Manual om motorvalet inte passar bilden. Masterpiece är
namnet på kvalitetspreseten, ingen garanti för konstnärligt resultat. Det är
fortfarande den valda paletten, penseln och konturmotorns upplösning som begränsar
resultatet. Kontursketch använder fortsatt högst 720 pixlar på längsta sidan;
färg-Pixel-Accurate arbetar med hela målupplösningen.

## Unlimited

Välj **Unlimited** bland tidsinställningarna. Den vanliga ritningstimern och
Gartic-timeravläsningen används då inte. Stop/Esc, pauskontroll, mus-/fönstervakter,
resursbegränsningar och planerings-watchdog finns kvar. Unlimited förlänger inte
Gartics runda. Använd det i Paint eller ett spelläge som tillåter tillräckligt med tid.
Masterpiece väljer Unlimited automatiskt. Auto med Unlimited prioriterar
Pixel Accurate för färg och Detailed för enfärg.

## Clear image / Clear cached drawing

- **Clear image** stoppar arbetet och tar bort källbild, preview, ritplan och
  lokalt återupptagningscache. Lägg sedan in en ny bild.
- **Clear cached drawing** stoppar arbetet och rensar plan/återupptagning men
  behåller källbilden för en ny planering.

Knapparna kan användas under arbete. Rensningen väntar tills den avbrutna
arbetstråden är klar. Sena bild-/planresultat ignoreras under rensningen så att
den gamla bilden inte kommer tillbaka. Sparade profiler och kalibrering behålls.
Detta raderar INTE redan målade pixlar i Paint eller Gartic.

## Kalibreringsfix

Den stora förhandsvisningen av vald färg kunde felaktigt väljas som svart
palettknapp. Gartics 6×12-rutnät verifieras nu geometriskt och varje färgpunkt
kontrolleras mot skärmens färg. Kalibreringen ger inte klick på Done/Restore.
På den uppladdade hela skärmbilden hittades 72 färger och canvas
(496,244)-(1446,774), alltså 950×530 pixlar. Även skalade kopior på 80 och
125 procent gav 72 verifierade färger. Detta testar bilddetektion, inte live-input.

## Installation och verifiering

Hela paketet rekommenderas. Patchen kräver v1.0.101: stäng appen och kopiera
patchens kod-/versionsfiler till mappen med Start.bat. Ersätt filerna.

803 automatiserade tester och source self-test godkända. Nya tester täcker
motorval, Masterpiece/Unlimited, skydd mot snabbprofilens tidsöverskrivning,
cache-rensning och sena resultat, väntan på arbetstråd samt korrekt palettrutnät.
Windows-gränssnitt, upptäckt av live-fönster och faktisk ritning är fortfarande
inte provkörda här. Källkod med Start.bat; ingen nybyggd EXE.
