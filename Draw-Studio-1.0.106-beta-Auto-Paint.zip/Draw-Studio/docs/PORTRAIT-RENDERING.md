# Portrait rendering notes — 0.9.4 beta

The legacy single-color planner used one grayscale threshold followed by horizontal runs. That was fast, but photographs lost most mid-tones and facial structure before the mouse drawing started.

## 0.9.4 pipeline

1. Composite transparency over white.
2. Preserve EXIF orientation and aspect ratio.
3. Use a higher portrait-specific planning resolution.
4. Apply bounded auto-contrast, mild sharpening and a gentle mid-tone lift.
5. Optionally lighten peripheral background detail for centered portraits.
6. Build several luminance layers instead of one binary threshold.
7. Distribute layers across horizontal, vertical and diagonal hatch directions.
8. Detect strong Sobel gradients and convert them to short tangent contour strokes.
9. Rank contour candidates by edge strength with mild center weighting and spatial de-duplication.
10. Allocate stroke budget separately to contours and shading.
11. Fit the final plan to the configured drawing-time limit by evenly sampling across the complete image.
12. Render the exact planned brush geometry into the preview.

## Practical limitations

A single opaque Paint brush cannot reproduce continuous grayscale directly. Tone is approximated by line density and cross-hatching, so the result is intentionally sketch-like rather than a pixel-perfect photo reproduction. Larger canvases, a 1–2 px brush and a longer time limit allow more recognizable detail.

`Portrait / shaded` is designed primarily for single-color Paint sketches. Palette-based color drawings continue to use the standard color-run planner in this beta.
