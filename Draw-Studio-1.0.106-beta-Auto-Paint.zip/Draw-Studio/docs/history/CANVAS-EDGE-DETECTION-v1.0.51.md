# Draw Studio v1.0.51-beta – Edge Detection Step 5

This build adds deterministic canvas edge verification before drawing input.

## What changed

- Added `EdgeDetection.py`.
- Captures a read-only screenshot around the selected canvas when the guarded target is active.
- Looks for real contrast edges near the selected canvas boundary.
- Compares visible edge offsets against a strict tolerance.
- Stops before the first mouse move/click if a clear edge is offset too far from the saved canvas.
- Falls back to Canvas Guard when edges are weak, blank, or unavailable.

## Safety rule

Edge Detection is advisory-plus-stop: it can stop unsafe starts, but it cannot allow drawing outside canvas. `CanvasGuard` and `FinalMouseGuard` remain the final mandatory safety gates.

## No AI

The verifier uses deterministic RGB/luma gradients, band contrast, and fixed geometry thresholds. No AI, ML, neural network, OCR, or external recognition model is used.
