# Canvas Polygon — v1.0.48

v1.0.48 upgrades Canvas Guard Step 1 from a rectangle-only safety model to a polygon-first canvas model.

## What changed

- `CanvasModel.from_polygon(...)` can now model the drawable surface as a real polygon.
- `CanvasModel.from_area_or_polygon(...)` keeps the old selected rectangle as a fallback.
- `normalize_canvas_polygon(...)` accepts screen, area-relative, and normalized polygon coordinates.
- `SafePolygon.clamp_to_safe(...)` now projects into the polygon safe area instead of clamping only to a rectangular bounding box.
- `CanvasGuard.describe()` reports polygon vertex count so dry-run/final render logs show which safety model is active.
- `execute_plan()` reads optional `options["canvas_polygon"]` and `options["canvas_polygon_space"]` before falling back to the selected rectangle.

## Safety rule

Canvas Guard remains non-optional. Profile policy and Manual settings can change renderer quality/speed, but they cannot disable polygon safety, brush inset, final mouse guard, target lock, or emergency stop.

## Current scope

This step adds polygon modeling and polygon-safe coordinate protection. The next step can add automatic edge/triangle anchor detection that writes `canvas_polygon` into the plan options.
