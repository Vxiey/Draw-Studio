# Auto Paint Calibration — v1.0.40

Microsoft Paint can now use a conservative visual auto-calibration pass.

- Select the Paint drawing area first.
- Press **Auto-calibrate Paint**.
- Draw Studio screenshots only the selected Paint window; it sends no mouse input.
- The detector searches the Paint toolbar for safe direct drawing controls and only saves a result when Pencil reaches the confidence threshold.
- Calibration is anchored to Paint's client size and DPI signature. Moving the window is supported by the existing anchor translation; resizing/reflow still invalidates calibration.
- Manual Paint calibration remains available for missing controls, Brush preset/opacity, and layouts the visual detector cannot identify confidently.
- Auto calibration never guesses through a low-confidence result. Failure leaves the previous calibration unchanged.
- Microsoft Paint still requires the normal Small test / Target lock / Preflight / Dry run safety chain before full drawing.
