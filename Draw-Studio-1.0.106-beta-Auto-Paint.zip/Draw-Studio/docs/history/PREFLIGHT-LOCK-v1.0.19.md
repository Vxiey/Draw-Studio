# Draw Studio v1.0.19 beta — Step 1: Preflight Lock

Full drawing now requires this exact sequence:

1. Load image.
2. Select drawing area / target window.
3. Calibrate required palette and tools.
4. Run **Draw small test** successfully.
5. Run **Safety preflight**. This performs no mouse clicks or drawing.
6. Press **Unlock full drawing** within the preflight validity window.
7. Press **Start Drawing** within 12 seconds.

Any setup change invalidates the Safety preflight and locks full drawing again.
