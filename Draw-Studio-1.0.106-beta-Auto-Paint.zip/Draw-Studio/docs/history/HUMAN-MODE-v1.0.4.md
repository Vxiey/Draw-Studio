# Human Mode — v1.0.4 beta

Human Mode changes *cadence*, not geometry. It does not move strokes away from the coordinates produced by the precision engine.

## Presets

- **Off** — original deterministic order and constant timing.
- **Subtle** — recommended; small local order changes, occasional direction reversal and short pauses.
- **Natural** — stronger cadence variation and more local reordering.
- **Strong** — most visible natural cadence; slower and best used when speed is not the priority.

## Precision contract

Human Mode never adds coordinate jitter. High/Ultra precision retain the same target pixels as when Human Mode is Off. Stroke direction may reverse, but the same line segment is drawn.

## Reproducibility

Local ordering uses a deterministic seed derived only from non-sensitive plan geometry. This keeps runs debuggable and avoids storing image names or file paths.
