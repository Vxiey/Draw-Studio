# Draw Studio v1.0.17 beta – Skribbl Fast Renderer

This release adds a faster skribbl-oriented planning mode while keeping the safety changes from v1.0.16.

## New profile

- `Skribbl.io Fast` uses the skribbl palette preset and defaults to faster, more approximate shape planning.
- The profile keeps Preview mode on Manual after profile switches.
- It still requires a visible canvas and a captured/verified palette before full drawing can be armed.

## Shape paths

`Shape paths` compresses same-colour raster runs into connected components, hatch-like fill paths and lightweight contour strokes. It prioritizes recognizable large shapes over tiny isolated details.

Controls:

- `Shape order`: Fill first or Contour first.
- `Max stroke cap`: Auto, 1000, 2500, 5000, 10000 or Unlimited.

The preview/summary reports source strokes, optimized paths, estimated draw time and skipped tiny or over-cap details.

## Planning progress

Final planning now emits heartbeat status messages while it is still building the plan. These messages explicitly state that no mouse input has been armed yet. Shape paths also use a shorter default planning timeout so the app does not sit silently for a minute when a plan is too heavy.
