# v1.0.57-beta – Runtime Safety Report Step 11

Runtime Safety Report records the decisions made by the real execution path after CanvasGuard and Edge Behavior have resolved each brush path.

## Saved after every execution attempt

A successful drawing, successful Dry run, manual stop, time-budget stop, CanvasGuard stop or other interrupted execution produces a local report when the report directory is writable.

Reports are saved under `safety-reports/` as both:

- JSON for diagnostics and future tooling.
- TXT for quick reading.

## Runtime counters

The report separates paths that were:

- drawn unchanged;
- mathematically clipped;
- skipped;
- edge-followed by Adaptive Clip / Preserve Outline;
- blocked by CanvasGuard before they could reach mouse input;
- part of a run that stopped before completion.

Fill operations are recorded separately so they are not incorrectly counted as ordinary brush paths.

## Safety invariant

Reporting is read-only with respect to drawing decisions. Saving a report cannot enable input, disable CanvasGuard, change Edge Behavior, bypass Safe Fill Mask, or bypass FinalMouseGuard. A report write failure is logged in memory and must never hide the original execution result.

No AI, ML or OCR is used. Reports are local and do not store source image pixels or screenshots.
