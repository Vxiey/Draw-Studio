# Profile Engine v2 — v1.0.45

Profile Engine v2 gives each target application its own effective renderer policy instead of forcing one algorithmic compromise across every profile.

## Policies

- **Microsoft Paint** — Shape paths, Better Shapes v2, closed-region Fill, Adaptive Exact colors, 24-color budget, perceptual matching, protected detail and Strict visual verification.
- **Skribbl.io Fast** — 8-color budget, large Shape paths, Strong simplify, Reduced palette, Smart merge and a 90-second timer-aware budget.
- **Skribbl.io** — 16-color budget, High detail, protected contours/details, perceptual matching and a larger two-minute plan.
- **Gartic.io** — timer-aware 60-second progressive Shape plan with Reduced palette and aggressive simplification.
- **Gartic Phone** — timer-aware 90-second subject-first plan.
- **Sketchful / Drawize** — balanced game-specific Shape policies.
- **Other drawing app / custom profiles** — conservative generic policy.

## Control

`Profile policy = Auto` applies the profile renderer policy before planning. `Manual settings` keeps the user's renderer choices unchanged.

Profile Engine never stores or changes target lock state, mouse arming, coordinates, preflight state, dry-run authorization or Start authorization. Existing Paint safety gates remain authoritative.
