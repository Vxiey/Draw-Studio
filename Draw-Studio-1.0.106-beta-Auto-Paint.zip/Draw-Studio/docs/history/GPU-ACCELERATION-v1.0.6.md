# Draw Studio v1.0.6 — GPU Acceleration

Draw Studio keeps mouse drawing and Windows safety checks on the CPU. The GPU is used for expensive image-analysis work before drawing starts.

## NVIDIA CUDA path

The optional NVIDIA build uses CuPy (`cupy-cuda12x`). Draw Studio launches fused FP32 `RawKernel` CUDA kernels for portrait enhancement and saliency/Sobel analysis. These kernels execute on the NVIDIA streaming multiprocessors and CUDA-core execution path rather than merely using the GPU as image storage.

`GPU acceleration = Auto` is recommended. If CUDA is unavailable, initialization fails, or an allocation cannot be made safely, Draw Studio falls back to CPU processing without enabling mouse input.

## Adaptive VRAM allocation

The selected VRAM budget is a ceiling, not a target. Draw Studio:

- leaves Windows/desktop/target-app headroom;
- estimates the FP32 analysis workspace before allocating;
- uses a bounded CuPy memory pool;
- releases cached blocks when the pool is under pressure;
- switches to overlapped row tiles when a full-frame working set would exceed the safe budget;
- releases live analysis arrays after planning so Paint/browser rendering has VRAM available during the actual draw.

The Tools page includes **Test GPU** and **Clear GPU cache**.

## Advanced image scaling

GPU-enhanced analysis can use a CUDA cubic-spline scaler followed by a restrained adaptive unsharp pass. Very large source images are first reduced near the target scale to avoid wasting VRAM on a multi-megapixel FP32 frame that will ultimately become a much smaller stroke-planning image.

On high-VRAM cards, `GPU enhanced` may increase the internal analysis resolution. The boost is based on the configured safe VRAM budget, not total VRAM alone.

CPU fallback uses Pillow Lanczos.

## Recommended settings

For a dedicated NVIDIA GPU:

- Draw quality: **GPU enhanced**
- GPU acceleration: **Auto**
- GPU performance: **High throughput**
- VRAM budget: **Auto**
- Precision: **High**

Use `Maximum` GPU performance for complex source images when preprocessing time matters more than keeping a larger VRAM reserve.

The GPU does not make Microsoft Paint consume mouse events faster. v1.0.6 accelerates preprocessing and supports more detailed analysis; v1.0.5 remains responsible for mouse-path speed optimization.
