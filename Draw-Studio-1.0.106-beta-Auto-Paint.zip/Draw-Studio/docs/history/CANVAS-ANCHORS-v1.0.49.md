# Canvas Anchor Detection — v1.0.49

v1.0.49 adds deterministic anchor detection on top of Canvas Polygon Step 2.

## What changed

- New `CanvasAnchorDetection.py` module.
- Four corner anchors are always created from the user-selected drawing area.
- Up to six triangular marker anchors are detected from the selected area screenshot using geometry, contrast, connected components and triangle-shape checks.
- No AI, ML, model inference or external vision service is used.
- Anchor data is stored in normalized canvas coordinates so target-window translation does not break the detected model.
- `execute_plan()` now passes `canvas_anchors` into `CanvasModel`.
- `CanvasGuard.describe()` reports corner/triangle anchor counts.

## Safety rule

Canvas anchors improve geometry tracking and diagnostics. They do not replace Canvas Guard. Drawing coordinates still pass through polygon safety, brush inset and the final mouse guard before native input.

## Current scope

This step begins using the four corners and six triangles as actual `CanvasAnchor` records. The polygon itself is still conservative and rectangle-based unless a supplied polygon is present. A later step can use the anchors to recompute perspective/affine transforms automatically.
