# Draw Studio 0.9.3 — Stability Code Audit

This audit focuses on common failure modes for a Windows/Tkinter application that controls the mouse and uses helper processes. It is not a substitute for real Windows integration testing.

## High-risk paths reviewed

### 1. Tk / CustomTkinter event recursion

**Previous failure:** synchronous `<Configure>` and traced-variable UI updates could recursively trigger widget rendering until `RecursionError`.

**Current controls:**
- CustomTkinter-native root.
- Preview resize rendering is debounced.
- Preview rendering has a re-entry guard.
- Profile changes are deferred out of widget callbacks.
- Status UI refresh is queued with `after_idle`.
- Tk callback exceptions are contained and logged.
- Stored `after()` tokens are cancelled through a defensive helper during shutdown/config changes.

### 2. Worker-thread / UI ownership

**Risk:** Tk widgets are not thread-safe.

**Current controls:**
- Background work posts results to a `queue.Queue`.
- Tk/UI mutations happen from the main-thread polling loop.
- Worker completion is tagged with the activity name.
- Stale completion events cannot blindly enable controls for another activity.
- UI queue processing is bounded per polling tick so a burst of status/progress events cannot starve Tk.
- Malformed/unknown internal events are contained and logged.

### 3. Native mouse input

**Risk:** a stale target, wrong foreground window, manual mouse movement, or failed Win32 call could click the wrong place.

**Current controls:**
- Native input starts disarmed.
- Input is armed only during explicit Test/Start flow after target activation.
- Target window geometry and foreground state are checked before input.
- Another window covering a click position stops the operation.
- Manual pointer movement beyond tolerance stops automation.
- Stop/profile changes revoke input permission immediately.
- `SetCursorPos` movement is verified.
- Mouse button release is protected with `finally` paths.
- Native mouse and target-window probes are isolated in helper processes.

### 4. Microsoft Paint calibration drift

**Risk:** absolute coordinates become wrong after moving/resizing Paint or changing toolbar layout.

**Current controls:**
- Paint palette/tool calibration is anchored to Paint client geometry.
- Same-size window moves can be rebased.
- Client-size/layout changes stop before input and require reselection/recalibration.
- Palette RGB is verified before the first UI click.
- The first rendered stroke after a color change is checked against the expected RGB.
- Brush/Pencil automatic selection requires the calibrated tool sequence and 100% opacity.

### 5. Shutdown races

**Risk:** closing while a worker/helper/Tk callback is active can produce `TclError`, stale callbacks or orphaned hooks.

**Fixes in 0.9.3:**
- Close is idempotent.
- Scheduled preview/profile/config callbacks are cancelled defensively.
- Child calibration windows are destroyed defensively.
- Global hotkey removal is guarded.
- Helper termination is guarded.
- The clean-exit marker is removed only by the process that owns it.
- Root destruction is guarded against an already-destroyed interpreter.

### 6. Settings / calibration corruption

**Risk:** a crash or power loss during `write_text()` can leave truncated JSON/config files.

**Fixes in 0.9.3:**
- Shared same-directory atomic writer with unique temporary files and `os.replace()`.
- Settings, reporting preferences, custom profiles, legacy color positions, palette data, imported word lists and grid preferences use atomic replacement where applicable.
- Invalid settings are ignored and logged.
- User-controlled numeric/options values are validated before planning.

### 7. Memory / resource exhaustion

**Risk:** very large images or screen regions can allocate hundreds of MB/GB and terminate Python.

**Fixes in 0.9.3:**
- Local image file cap: 50 MB.
- URL image download cap: 20 MB while streaming.
- Decoded source image cap: 25 megapixels.
- Screen capture cap: 40 megapixels before `ImageGrab` allocation.
- Crash/session logs rotate at 2 MB and retain one backup.

### 8. Bug/crash report transport

**Risk:** accidental data leakage or runaway upload behavior.

**Current controls:**
- Normal reports exclude screenshots/source images.
- Logs are truncated and sanitized.
- Endpoint must be HTTPS with a host and no embedded credentials.
- Uploads do not follow redirects.
- Local report size must be 1 byte–5 MB before upload.
- Automatic crash upload remains opt-in and off by default.

## Medium-risk items reviewed

- Image URL request timeouts and streamed cancellation.
- Missing/deleted local image paths.
- Invalid brush width, time limit, quality, speed, mode and contrast values.
- Zero-total progress events.
- Duplicate/stale profile changes.
- Target-window movement and resize between calibration and drawing.
- Color/palette overlap with the selected drawing canvas.
- Recording temporary-file cleanup.
- EXE helper relaunch behavior when frozen with PyInstaller.
- Version metadata consistency between runtime and Windows resource file.

## Still requires real Windows testing

Automated tests cannot prove these environment-dependent behaviors:

1. Microsoft Paint layout differences across Windows builds.
2. Multi-monitor setups with mixed DPI/scaling and negative coordinates.
3. Focus restrictions imposed by Windows while `SetForegroundWindow` is called.
4. Elevated target applications vs non-elevated Draw Studio (UIPI).
5. Actual mouse timing under high system load.
6. PyInstaller onedir/onefile startup on clean Windows 10/11 systems.
7. SmartScreen/code-signing behavior for public distribution.
8. Actual reporting endpoint deployment, rate limiting and server-side retention.

## Verification result

- `python -m compileall`: PASS
- `python DrawBot.py --self-test`: PASS
- `python -m unittest discover`: **133 tests PASS**

The next roadmap milestone is **0.9.4 Portrait Rendering Upgrade**. Rendering changes should be kept separate from this stability baseline so image-quality regressions can be distinguished from UI/input crashes.
