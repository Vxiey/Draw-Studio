# Draw Studio v1.0.27-beta — Step 9 Performance Profiler + Benchmark

This release adds passive timing instrumentation to planning only. It does not change the Step 1–7 safety gates and cannot arm mouse input.

Measured phases:
- preprocessing
- color planning
- shape extraction
- path optimization
- preview rendering
- execution estimate
- total planning

The current plan summary displays these timings. Final-plan/watchdog logs include the same profiler data.

`Run performance benchmark` runs a bounded planning benchmark using the current resource/render settings (and a synthetic source if no image is loaded). It never calls `execute_plan` and therefore cannot click, press, release, or arm native mouse drawing.
