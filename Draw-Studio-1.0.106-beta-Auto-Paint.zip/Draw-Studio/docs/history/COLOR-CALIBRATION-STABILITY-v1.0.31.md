# Draw Studio v1.0.31-beta — Color Calibration Stability

- Palette calibration now runs in a separate helper process so a Tk/native calibration failure cannot terminate the main Draw Studio workspace.
- Replaced CustomTkinter widgets inside the palette helper with a stable Tk/ttk interface to avoid recursive CTk resize/render failures.
- Added `DrawStudio-palette-calibration.log` and `DrawStudio-palette-launcher.log`.
- A failed helper reports its Windows exit code (including 0xC0000005) while Draw Studio stays open and DISARMED.
- Palette readiness is revalidated only after the helper exits; closing without saving never marks the palette ready.
- Manual Preview remains manual after calibration.
