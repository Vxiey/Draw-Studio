# Canvas Guard — v1.0.47

Step 1 locks drawing safety before any renderer improvements.

## Added

- `CanvasModel`: immutable selected-canvas model built from the captured drawing area.
- `SafePolygon`: full canvas polygon plus a brush-inset safe polygon.
- `BrushInset`: automatic inset from brush radius + fixed edge margin.
- `CanvasGuard`: deterministic point/path validation with no AI and no profile-controlled off switch.
- `FinalMouseGuard`: final drawing-coordinate gate immediately before mouse movement, click or press.

## Rules

- Renderer/profile policy cannot disable Canvas Guard.
- Drawing points inside the selected canvas but too close to the edge are moved inward to the safe polygon.
- Drawing points outside the selected canvas raise `CanvasSafetyStop` before any canvas press/click.
- Palette/tool/modal UI clicks remain protected by the existing `ScreenGuard`, because those controls intentionally live outside the selected canvas.
- Dry Run and full drawing both use the same Canvas Guard path.

## Not included yet

This is only Step 1. It does not yet implement automatic corner/triangle anchor detection, polygon canvas recovery, edge following, or fill-mask clipping. Those belong in the next steps after the hard final safety layer is stable.
