# Draw Studio v1.0.34-beta – Smart Custom Palette + Color Batching

## Smart custom palette
The exact-color calibration can now capture the visible custom-color spectrum itself:

- Open custom color / Edit colors
- Spectrum top-left
- Spectrum bottom-right
- Optional brightness/value scale top + bottom
- Optional selected-color preview swatch
- Optional numeric R/G/B fields
- Confirm / OK
- Optional eyedropper

When Draw Studio needs an exact RGB, it opens the calibrated picker, screenshots only the calibrated spectrum, finds the rendered point visually nearest the requested RGB and clicks it. If a brightness/value scale is calibrated, it selects the nearest color on that scale and then refines the spectrum point.

If the visual scale is not close enough and numeric R/G/B fields are available, numeric RGB is used. If either exact method is unavailable, Draw Studio always falls back to the nearest actually calibrated palette swatch.

## Finish one color before switching
New `Color workflow` setting:

- `Finish color first` (default): Smart color order chooses the next useful color, then every path for that color is completed before selecting another color.
- `Progressive passes`: preserves the older cross-color foundation/contour/detail passes.

This reduces palette/custom-dialog interactions and makes color selection more deterministic.
