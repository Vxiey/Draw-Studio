# Draw Studio v1.0.33-beta – Color Engine v2

- Actual calibrated screen RGB is authoritative.
- Preset palette detection samples actual displayed RGB and falls back to geometry auto-detection if preset RGB changes.
- Exact custom RGB workflow clusters source colors and enters exact RGB through user-calibrated custom-color controls.
- Every exact color has a nearest calibrated palette fallback.
- Eyedropper can be calibrated as an optional profile control.
- Non-Paint profiles use simplified start gating: image + area + palette + explicit Unlock + Start. Paint keeps the full safety chain.
