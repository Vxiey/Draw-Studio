# Draw Studio v1.0.7 — Auto Fill + Smart Tool Control

## Auto Fill
Auto Fill supports Off, Conservative, Balanced and Aggressive modes. Balanced is the default. The planner can use a calibrated Fill tool for a dominant border-connected base background and for large, nearly rectangular interior regions. Interior regions receive a closed perimeter before the bucket click, and Draw Studio checks pixels outside the planned rectangle for unexpected changes.

## Background simplification
A border-connected background can be simplified before palette quantization. Conservative, Balanced and Strong modes change only pixels connected to the image border and close to the dominant background color. This reduces JPEG/gradient noise while protecting disconnected foreground regions.

## Smart color grouping
Accurate preserves the existing palette order. Smart keeps exact calibrated RGB values but renders larger color masses first and details later. Reduced palette may merge only rare colors that are already very close in the calibrated palette.

## Smart tool control
Auto chooses a calibrated Pencil for portrait/fine work and may use a calibrated solid Brush for larger standard drawings. Precision first and Speed first let the user bias the choice; Respect selected never overrides the explicit Paint tool. Fill is used only when calibrated and the drawing tool can be restored safely.

## Faster large-area rendering
Large flat backgrounds are painted with a base Fill where safe. Large interior rectangular regions can be closed and filled instead of rendered as many scanline strokes. Remaining details are drawn afterward, so small foreground colors can correct the fill layer.

## Safety
Auto Fill is never required. Turn it Off if a target app handles bucket fill differently. Conservative mode uses the strictest region tests. Mouse input remains gated behind an explicit Start/Test action and the existing target-window guard.
