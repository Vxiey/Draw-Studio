# Draw Studio v1.0.28-beta — Step 10 Safe Recovery + Diagnostics

- Crash-safe local checkpoint stores the source image and configuration locally.
- Recovery is offered only after an unclean shutdown.
- Recovery always returns DISARMED: no target handle, target lock, small-test pass, safety preflight, dry-run pass or Start authorization is restored.
- Preview mode is forced to Manual after recovery.
- A previously selected area is restored only as a suggestion; the target must be captured/verified again.
- Clean shutdown deletes the recovery checkpoint.
- In-app diagnostics ZIP contains sanitized logs, system/Python/package/GPU/resource details, settings summaries and calibration hashes.
- Diagnostics never includes source images, cached recovery images, clipboard contents or raw palette/tool coordinates.
