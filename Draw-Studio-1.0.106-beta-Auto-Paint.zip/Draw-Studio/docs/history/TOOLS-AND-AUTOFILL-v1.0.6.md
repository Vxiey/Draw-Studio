# Draw Studio v1.0.6 — Tool capabilities and Background Fill

## Tool capability model

Draw Studio no longer assumes every drawing application places Brush, Fill and Eraser in the same location. Known application profiles declare the tool semantics they can use, while screen positions are always calibrated by the user and anchored to that target window's client rectangle.

For Microsoft Paint, **Calibrate Paint tools** can capture Pencil, Brush, Eraser, Fill and 100% opacity.

For other supported/custom drawing applications, **Calibrate app Brush / Fill** can capture:

- Brush
- Fill
- Eraser

A resize of the target window invalidates anchored control positions rather than risking a click in the wrong place.

## Automatic background fill

`Background fill = Auto` looks for a strong, mostly uniform border/background color. It is intentionally conservative.

When a safe base color is detected and both Fill and the normal drawing tool are calibrated, Draw Studio can:

1. select the detected palette color;
2. select the Fill tool;
3. fill the blank canvas from a safe corner point;
4. verify that the expected color rendered;
5. restore Brush/Pencil;
6. skip redundant strokes of the base color.

This is useful for large flat green, orange, blue, red, etc. backgrounds.

If the border contains several competing colors, the background occupies too little of the image, the detected color is effectively white, or the Fill/Brush controls are not calibrated, Draw Studio keeps the normal stroke plan.

If a non-white base Fill is used, white source regions are explicitly restored even if `Skip white` was enabled, so the optimization does not silently turn intended white areas into the background color.

Use a blank canvas for automatic Fill.
