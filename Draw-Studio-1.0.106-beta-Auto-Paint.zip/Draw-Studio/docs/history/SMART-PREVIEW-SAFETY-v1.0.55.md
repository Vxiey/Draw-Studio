# v1.0.55-beta – Smart Preview Safety Step 9

- Preview rendering now replays CanvasGuard + Edge Behavior in preview-local coordinates before drawing the preview image.
- Drawing preview and Stroke plan show the same clipped/skipped/adaptive paths that execution can draw.
- Adds a Safety map tab showing the selected canvas polygon, brush-inset safe polygon and counts for drawn, skipped and edge-follow paths.
- Hard Clip remains the safe fallback; Adaptive Clip and Preserve Outline still cannot bypass CanvasGuard/FinalMouseGuard.
- Preview Safety is UI-only and deterministic. It never sends mouse input and uses no AI/ML/OCR.
