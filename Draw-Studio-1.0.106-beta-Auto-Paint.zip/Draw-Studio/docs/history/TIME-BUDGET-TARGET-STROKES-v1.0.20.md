# Draw Studio v1.0.20 beta — Step 2: Time Budget + Target Stroke Count

This release is built on top of v1.0.19 and keeps the full safety flow unchanged:
Small test → Safety preflight → Unlock full drawing → Start Drawing.

## Added

- Time Budget Mode:
  - Manual
  - 30 sec
  - 60 sec
  - 90 sec
  - 2 min
  - 5 min
  - 10 min
- Target Stroke Count:
  - Auto
  - 500
  - 1000
  - 2500
  - 5000
  - 10000
  - Custom
  - Unlimited
- Custom target stroke field.
- Global target cap pass for Smart paths and Shape paths.
- Plan metadata now reports effective time budget, resolved target stroke count and skipped paths.

## Behaviour

- Manual time budget preserves the old manual time-limit field.
- Preset time budgets override the effective final drawing time limit.
- Target Stroke Count = Auto only applies a cap when a preset time budget is selected.
- Custom target stroke count accepts 50–50000.
- Target capping keeps the most visible/longest paths first and preserves stable per-colour ordering.
- The final estimate remains the safety gate before any mouse input is armed.

## Skribbl.io Fast default

The Skribbl.io Fast profile now starts with:

- Shape paths
- Time budget: 90 sec
- Target stroke count: Auto
- Speed: Fast
- Precision: Normal
- Planning resolution: Standard
- Color grouping: Reduced palette
- Color rendering: RGB nearest
- Preview mode: Manual
