# Resource Scheduler v2 — v1.0.44

Resource Scheduler v2 chooses resources per planning phase instead of using one global CPU/GPU/RAM setting for everything.

## Phase policy
- Color analysis: CPU/SIMD/cache-friendly workers.
- Image resize / matrix work: GPU only when CUDA is available, the image is large enough, and the scheduler expects transfer overhead to pay off.
- Shape extraction: parallel CPU chunks with RAM-aware row sizing.
- Path optimization: capped CPU workers to avoid overhead.

## Worker cap
Auto mode keeps headroom for Tk, Paint and Windows input. On high-core systems it avoids 32/32 worker usage unless the user explicitly chooses a manual value, and even All logical keeps headroom for UI/input safety.

## Benchmark recommendations
The CPU/RAM test now also stores a per-machine scheduler recommendation in resource-scheduler-v2.json. Auto and Benchmark recommendations can reuse it, but still obey safety caps.

The drawing cursor remains single-stream and disarmed by default. This scheduler only affects planning and analysis.
