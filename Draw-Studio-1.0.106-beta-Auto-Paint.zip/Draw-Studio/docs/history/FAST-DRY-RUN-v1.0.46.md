# Fast Calibrated Dry Run — v1.0.46

Dry Run is now a bounded safety sample instead of a replay of every final path.

- Planning watchdog: 8 seconds.
- Cursor simulation: maximum 12 seconds.
- Samples up to 8 active colour batches and roughly 40 representative paths distributed through the plan.
- Uses Standard planning resolution, a small CPU worker cap, CPU matrix path, no background Fill, no visual verification, and a 500-stroke planning cap during Dry Run only.
- Sends no clicks, presses, releases, typing, or Fill actions.
- A successful Dry Run remains valid for 180 seconds, but is invalidated immediately when the safety signature changes.
- Target Lock, Safety Preflight and all normal Start/Unlock gates remain required for Microsoft Paint.
- Full drawing still rebuilds the real final-quality plan; Dry Run reductions never leak into the actual render.
