# Better Fill Engine v1.0.39

Draw Studio v1.0.39 expands conservative Auto Fill beyond rectangles while keeping a scanline fallback.

- **Closed regions v2** traces hole-free 4-connected components and draws their real perimeter before bucket fill.
- **Safe rectangles** keeps the legacy almost-rectangular behavior.
- **Auto** selects Closed regions v2 whenever Auto Fill is enabled.
- Regions touching the image border, containing holes, lacking an interior seed, or exceeding contour complexity limits remain normal drawing strokes.
- Irregular filled regions remove only their exact per-row spans from later drawing, not their whole bounding boxes.
- Guard pixels are sampled outside the perimeter before Fill and checked afterward. A detected leak stops drawing.
- Perimeters are executed as one continuous mouse-down path to reduce corner gaps.
