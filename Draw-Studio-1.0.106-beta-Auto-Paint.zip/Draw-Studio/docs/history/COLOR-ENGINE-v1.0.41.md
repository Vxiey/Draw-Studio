# Color Engine v3 — v1.0.41

Built on the v1.0.35 exact/palette pipeline, but upgraded with smarter planning.

## What changed
- Perceptual reduction merges nearly identical source colours before execution.
- Large colours are prioritised by coverage so the most visible tones are kept first.
- The planner automatically balances:
  - exact custom RGB,
  - calibrated palette swatches,
  - nearest perceptual palette fallback.
- Exact custom-colour dialogs are now bounded.  Draw Studio only spends them on
  colours where the nearest calibrated palette would be visibly worse.
- The old workflow `Exact custom + palette fallback` still works.
- New recommended workflow: `Adaptive exact (recommended)`.

## Expected effect
An image that originally produces 40 distinct sampled colours can often be
reduced to roughly 14–20 execution colours with no obvious visual loss, while
also reducing how often the Paint Custom Color dialog opens.
