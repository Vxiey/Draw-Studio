# v1.0.50-beta — Anchor Transform Step 4

This release makes the v1.0.49 anchor system active before drawing starts.

## Added

- `AnchorTransform.py` deterministic coordinate-transform layer.
- Rebase canvas area when the target window is moved.
- Allow very small client-geometry changes only within strict scale/size limits.
- Use saved corner anchors plus detected triangle anchors as transform evidence.
- Store transform metadata in the final render options and Canvas Guard status.
- Refresh the target/setup lock fingerprint after a safe anchor rebase.

## Safety rules

- No AI/ML/model dependency.
- DPI changes still stop before input.
- Large resize/layout changes still stop before input.
- Palette/tool/modal controls remain protected by ScreenGuard/calibration anchors.
- Canvas Guard remains the final non-optional gate for every drawing coordinate.
