# Draw Studio v1.0.13 — CPU / GPU / RAM Allocation

v1.0.13 keeps the v1.0.12 Smart Continuous Paths engine and adds explicit planning-resource controls.

## What changed

- New **CPU / RAM allocation** settings panel.
- New **CPU workers** setting: Auto, fixed worker counts, or All logical.
- New **CPU engine** setting:
  - Auto: safe default; threads for preview/smaller work, process pool for larger final plans.
  - Threads: lower startup overhead.
  - Processes: higher CPU utilisation on large plans, slower to start.
- New **RAM budget** setting: Auto, fixed sizes, or Custom MB.
- Existing **VRAM budget** remains the GPU allocation control for CUDA.
- Plan summaries now show CPU worker count, RAM budget and backend.
- About/diagnostics include resource allocation settings.

## Important limitation

Mouse drawing is intentionally single-stream. Draw Studio cannot draw with several mouse cursors or run several Paint strokes at once safely. CPU/GPU/RAM allocation affects the heavy planning phase before drawing starts: image analysis, color matching, chunking and plan building.

## Recommended settings

For most gaming PCs:

```text
CPU workers: Auto
CPU engine: Auto
RAM budget: Auto or 4 GB
GPU acceleration: Auto or NVIDIA CUDA
GPU performance: High throughput
VRAM budget: 50–75%
Preview mode: Manual
Drawing mode: Smart paths (recommended)
```

For maximum planning throughput on a large image:

```text
CPU workers: All logical
CPU engine: Processes
RAM budget: 8 GB or Custom
GPU acceleration: NVIDIA CUDA
GPU performance: Maximum
VRAM budget: 75–90%
```

If the app becomes less responsive, switch CPU engine back to Auto or Threads and use fewer workers.
