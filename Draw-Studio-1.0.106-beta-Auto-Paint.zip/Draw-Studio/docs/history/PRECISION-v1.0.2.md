# Precision Upgrade — v1.0.2 beta

## Levels

- **Normal**: compatibility mode; lowest movement density.
- **High**: default; approximately 4 px maximum path spacing, exact cursor endpoint checks.
- **Ultra**: approximately 2 px maximum path spacing; slowest and intended for small facial/line details.

## Coordinate fixes

The engine now maps source pixel centers with the standard `((p + 0.5) * scale) - 0.5` transform. The old mapping omitted the final half-pixel correction and then used Python banker's rounding, which could alternate endpoint placement by one physical pixel. Preview planning and native drawing now share the same transform.

## DPI safety

Draw Studio records the target window DPI when the canvas is selected. If the target moves to a monitor with a different DPI before drawing, input is stopped before the mouse is armed and the user is asked to select the canvas again.
