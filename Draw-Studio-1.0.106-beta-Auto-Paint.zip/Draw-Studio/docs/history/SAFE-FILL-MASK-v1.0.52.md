# v1.0.52-beta – Safe Fill Mask Step 6

Deterministic bucket-fill safety layer. No AI/ML/OCR.

## What changed

- Added `SafeFillMask.py`.
- Background Fill seeds are chosen inside a brush-inset source mask.
- Better Fill regions too close to the source/canvas edge are rejected before detail strokes are removed.
- Runtime Better Fill checks seed, bbox, spans and contour against CanvasGuard's safe polygon without clamping.
- If the runtime mask disagrees with the plan, Fill is stopped before clicking.

## Safety rule

Bucket Fill is allowed only when both masks pass:

1. Source Safe Fill Mask during planning.
2. Runtime Safe Fill Mask against `CanvasGuard.safe_polygon` before mouse input.

Rejected fill regions remain normal stroke work, so planning does not silently remove detail near unsafe edges.
