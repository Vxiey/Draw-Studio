# Draw Studio v1.0.37-beta – Smart Stroke Optimizer

The v1.0.37 optimizer reduces mouse-up travel and redundant path boundaries inside each color batch without changing the intended drawing geometry.

## Modes

- **Auto** – Smart merge for Smart paths / Shape paths; Travel only for legacy modes.
- **Off** – preserves the planner's original path order.
- **Travel only** – reorders and reverses paths to reduce cursor travel, but does not merge them.
- **Smart merge** – additionally joins paths only when two endpoints are exactly identical.

## Safety rule

Smart merge never creates a connector merely because two paths are close. A merge is allowed only at an exact shared endpoint, so the optimizer cannot draw a shortcut through an unpainted gap.

## Planning integration

Optimization happens before execution estimation. Preview, ETA, path counts and real drawing therefore share the same optimized execution groups. When progressive rendering is enabled, foundation, contour and detail phases are optimized independently so phase ordering is retained.

## Metrics

The planner records:

- paths before / after optimization,
- exact endpoint joins,
- merged path count,
- pen-up distance before / after,
- percentage travel reduction,
- requested and effective optimizer mode.
