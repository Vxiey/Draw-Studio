# v1.0.53-beta – Stroke Clip Step 7

- Added deterministic segment-by-segment stroke clipping for normal brush paths.
- Normal strokes are clipped against `CanvasGuard.safe_polygon` before native mouse input.
- Endpoints near the brush-inset canvas edge are no longer independently clamped in a way that changes stroke geometry.
- Strokes that only touch the unsafe edge band are skipped instead of being shifted inward.
- Polyline clipping preserves gaps as separate subpaths so the mouse never draws shortcut lines across unsafe/outside areas.
- Planned source points outside the selected canvas polygon still stop before input.
- `FinalMouseGuard` remains the last hard coordinate gate before every drawing move/press/click.
- No AI/ML/OCR is used.
