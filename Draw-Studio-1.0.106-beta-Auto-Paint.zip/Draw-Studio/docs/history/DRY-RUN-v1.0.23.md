# Draw Studio v1.0.23-beta — Step 5: Dry Run / No-click Plan Test

Step 5 adds a full-route dry run between Safety preflight and Unlock full drawing.

## Required full drawing order

1. Draw small test
2. Safety preflight
3. Dry run · no clicks
4. Unlock full drawing
5. Start Drawing

## What Dry run does

- Builds the same final plan used by full drawing.
- Activates/verifies the same target window.
- Moves the cursor through the planned route.
- Never sends click, press or release events.
- Marks the dry run valid for 60 seconds.
- Invalidates the dry run if setup changes.

## Safety behavior

Unlock full drawing is blocked until the dry run has passed. Start Drawing also checks that the dry run is still valid.
