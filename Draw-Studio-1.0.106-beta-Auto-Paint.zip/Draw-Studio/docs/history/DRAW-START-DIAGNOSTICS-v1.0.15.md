# Draw Studio v1.0.15 – Drawing Start Diagnostics

This release keeps the v1.0.14 CPU/GPU/RAM allocation work and adds clearer start-of-drawing diagnostics.

## Why this was added

A real user log ended at `User initiated drawing` with no image-load event and no final-planning event. In earlier builds, pressing Start Drawing with no loaded image could return silently. That made it look like the CPU/GPU/RAM allocation was not doing anything, even though final planning never actually started.

## Changes

- Start Drawing now logs and shows a clear message when no image is loaded.
- Start Drawing now logs when no drawing area is selected.
- Image load requests and successful image loads are written to the crash/session log.
- Worker start, finish, interrupt and failure events include elapsed time.
- Final planning now logs the active planning resolution, CPU workers, CPU engine, RAM budget, GPU mode, VRAM mode, backend, source-stroke count and execution-path count.
- Preview planning now logs the same compact resource summary.

## Expected log sequence

A good run should show this order:

1. `Image loaded: size=(...)`
2. `Drawing-area selected: ...`
3. `User initiated drawing.`
4. `Draw preflight options resolved: ...`
5. `Worker draw started.`
6. `Final planning started: ...`
7. `Final planning finished in ...`
8. `Guarded mouse execution starting: ...`

If a future log stops before step 6, Draw Studio now records the reason instead of failing silently.
