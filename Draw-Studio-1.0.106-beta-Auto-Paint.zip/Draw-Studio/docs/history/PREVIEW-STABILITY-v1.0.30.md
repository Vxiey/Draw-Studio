# Draw Studio v1.0.30-beta — Preview Stability Fix

Preview planning is isolated from final drawing resource settings. Manual Build preview uses a bounded, cancellable CPU preview pipeline, caps Ultra/Extreme internally, disables expensive color layering in the preview approximation, and retries with a fast RGB/Standard fallback when needed. Final Start Drawing still uses the selected full settings.
