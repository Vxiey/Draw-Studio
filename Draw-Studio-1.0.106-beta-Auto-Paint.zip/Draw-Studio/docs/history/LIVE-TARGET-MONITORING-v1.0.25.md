# Draw Studio v1.0.25-beta — Step 7: Live Target Monitoring

Builds on v1.0.24 Target Lock + Calibration Fingerprint.

## What changed

- GuardedMouse now accepts a live target monitor callback.
- During real drawing and dry-run, Draw Studio revalidates the locked target while the cursor is moving.
- The monitor checks:
  - target window handle
  - target window rectangle
  - target client rectangle
  - target DPI / display scaling
  - selected drawing-area offset relative to the client area
  - current setup fingerprint
- If anything changes, drawing stops immediately, the safety gates are invalidated, and the mouse backend is disarmed.
- Small test stays independent and does not require a full target-lock fingerprint.

## Safety behavior

The Step 6 chain stays the same:

Small test → Lock setup → Safety preflight → Dry run · no clicks → Unlock full drawing → Start Drawing

Step 7 adds live monitoring after Start/Dry run has begun. It does not add any new start path.
