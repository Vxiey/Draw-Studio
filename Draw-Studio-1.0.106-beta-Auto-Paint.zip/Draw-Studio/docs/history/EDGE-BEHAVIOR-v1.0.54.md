# v1.0.54-beta – Edge Behavior Step 8

Adds deterministic edge behavior modes above the v1.0.53 stroke clipping layer.

## Modes

- **Hard Clip**: strict v1.0.53 behavior. Strokes are clipped segment-by-segment against `safe_polygon`. Edge-band-only strokes are skipped.
- **Adaptive Clip**: starts with Hard Clip. If a stroke is fully removed but lies close to the canvas edge, it can be projected onto the brush-inset safe boundary.
- **Preserve Outline**: starts with Hard Clip and allows a slightly wider near-edge projection so silhouettes/contours are kept when safe.
- **Auto**: resolves to a concrete mode from profile/drawing context. Safety fallback is Hard Clip.

## Safety rules

Edge Behavior never disables Canvas Guard. Every source point still has to be inside the selected canvas polygon. Every output point still has to be inside `safe_polygon`. FinalMouseGuard remains the last native input gate.

No AI, ML or OCR is used.
