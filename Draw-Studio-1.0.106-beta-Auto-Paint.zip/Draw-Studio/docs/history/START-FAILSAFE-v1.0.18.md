# Draw Studio v1.0.18-beta — Start Failsafe

This release separates the full drawing start into two controls:

1. **Unlock full drawing** validates image, drawing area, palette/tool readiness and unlocks for 12 seconds.
2. **Start Drawing** remains disabled until the unlock is active.

Changing profile, image, area, palette, tool, preview, or planning settings resets the safety unlock.
The unlock button never moves the mouse and never starts final planning.

Manual Preview remains a hard lock after profile changes; profile changes and settings changes only mark previews stale.
