# Draw Studio v1.0.8 — Advanced Color Rendering

v1.0.8 upgrades palette drawings for colour images.  It does not require AI or
cloud services; it uses calibrated Paint/application swatches and builds a more
accurate drawing plan locally.

## Color rendering modes

- **RGB nearest**: legacy behaviour. Fast and exact Euclidean RGB matching.
- **Perceptual match**: default for colour drawings. Uses luminance/chroma aware
  matching so skin tones, dark blues/greens and saturated colours choose better
  calibrated swatches.
- **Layered color mix**: approximates missing colours by drawing a primary
  calibrated colour plus a controlled second-colour layer. This can better
  represent colours that are not directly available in Paint.

## Color layers

- **Off**: one colour per source pixel/run.
- **Light shading**: conservative second-colour stipple for tonal correction.
- **Dual-color mix**: recommended for colour images; adds a second pass only when
  it improves the match enough.
- **Full color mix**: strongest layer mode. Slower but useful for colourful or
  difficult images.

Layering never invents hidden colours.  It only reuses swatches the user has
calibrated.

## Custom color workflow

- **Calibrated palette**: use the available palette normally.
- **Custom colors first**: prefer extra/custom calibrated colours when they are
  nearly as good as a default swatch. Good for custom skin/background colours.
- **Custom colors only**: use custom colours when any exist; fall back to the full
  palette if no custom colours are available.

## Recommended starting point

For Paint colour drawings:

```text
Color rendering: Perceptual match
Color layers: Dual-color mix
Custom color workflow: Custom colors first
Color grouping: Smart
Auto Fill: Conservative or Balanced
Brush: 1–2 px
```

Use **Layered color mix + Full color mix** only after a small test looks stable,
because it intentionally creates more strokes.
