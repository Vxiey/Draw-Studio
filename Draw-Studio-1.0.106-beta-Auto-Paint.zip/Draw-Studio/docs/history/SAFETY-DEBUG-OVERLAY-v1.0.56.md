# v1.0.56-beta – Safety Debug Overlay Step 10

Safety Debug Overlay is a deterministic preview-only diagnostic layer. It does not change CanvasGuard, Edge Behavior, Stroke Clip, Safe Fill Mask or FinalMouseGuard decisions.

## What it adds

- New `SafetyDebugOverlay.py`.
- New preview tab: **Debug overlay**.
- Per-path debug records for preview-safe paths.
- Counts for drawn, clipped, skipped, edge-follow and blocked paths.
- First visible exact reasons are rendered directly on the overlay.
- Raw source references are shown for skipped/blocked paths.
- Executable output paths are shown for drawn/clipped/edge-follow paths.

## Classification

- **drawn** – the path was already inside the brush-inset safe polygon.
- **clipped** – the path crossed or touched the safe polygon and was clipped mathematically.
- **skipped** – the path was removed because it only existed in the unsafe edge band or was too far outside to project safely.
- **edge-follow** – Adaptive Clip or Preserve Outline projected a near-edge path onto the safe inset boundary.
- **blocked** – CanvasGuard rejected source points outside the selected canvas polygon.

## Safety rule

The overlay is read-only. It visualizes the result of `CanvasGuard` + `EdgeBehavior`; it never authorizes mouse input and never bypasses the final mouse guard.

No AI/ML/OCR is used.
