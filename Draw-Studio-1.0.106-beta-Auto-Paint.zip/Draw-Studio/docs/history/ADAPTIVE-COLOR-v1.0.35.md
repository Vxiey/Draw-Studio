# Draw Studio v1.0.35-beta – Adaptive Color Verification + Auto-Recovery

## Purpose

Microsoft Paint can accept a palette/custom-color click but still render a different RGB because a tool, custom-color dialog, opacity control or Paint layout changed. v1.0.35 verifies the color once before committing an entire color batch.

## Paint batch flow

1. Select the planned RGB using the best available method.
2. Draw a short probe derived from the first planned path. The full path overwrites this probe immediately.
3. Measure the rendered pixels and calculate a color confidence score.
4. If the probe matches, finish every path of that color before switching.
5. If it does not match, retry the same probe with the next safe selector method.

Recovery methods are bounded and deterministic: calibrated eyedropper/session reuse when available, smart visual custom palette, exact numeric RGB fields, then nearest calibrated palette fallback.

## Session learning

A verified RGB stores the successful selector method, confidence and a safe sample point for the current setup. The cache is cleared when the image, drawing area, profile, target lock or color calibration changes.

## Non-Paint profiles

Browser/game profiles do not run the extra rendered-color probe by default. Their shorter Unlock -> Start flow remains available; Small test, Target Lock, Safety preflight and Dry run are optional diagnostics.

## Safety

No background/automatic draw start is added. Recovery only happens after an explicit drawing/test action. If every safe color method fails, Draw Studio stops on that color batch and reports the rendered RGB/confidence; already completed color batches are left untouched.
