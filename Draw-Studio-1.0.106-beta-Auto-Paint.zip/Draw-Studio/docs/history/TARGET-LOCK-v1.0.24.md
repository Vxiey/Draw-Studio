# Draw Studio v1.0.24-beta — Step 6: Target Lock + Calibration Fingerprint

This step adds a stricter safety gate before full drawing.

Full drawing flow is now:

1. Draw small test
2. Lock setup
3. Safety preflight
4. Dry run · no clicks
5. Unlock full drawing
6. Start Drawing

`Lock setup` fingerprints the current target window and drawing setup before Safety preflight can pass. The fingerprint includes:

- target window handle
- target window rectangle
- target client rectangle
- target DPI
- selected drawing area relative to the target client area
- source image size
- palette positions relative to the target client area
- palette color order/RGB values
- Paint tool/opacity positions where automatic Paint tools are used

If Paint, the browser, DPI/scaling, selected canvas, palette layout or Paint tool calibration changes after locking, Safety preflight / Dry run / Unlock / Start are blocked before any mouse input is armed.

Changing image, profile, drawing area, calibration or planner settings invalidates the setup lock and clears Safety preflight, Dry run and Unlock state.
