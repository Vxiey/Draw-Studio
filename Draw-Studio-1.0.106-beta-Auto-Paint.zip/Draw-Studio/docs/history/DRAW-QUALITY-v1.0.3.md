# Draw Quality Upgrade — v1.0.3 beta

`Detail level` controls how much drawing work is allowed. `Draw quality` controls how that fixed stroke budget is selected.

## Profiles

- **Balanced** — closest to the previous portrait planner and lowest preprocessing cost.
- **High likeness** — recommended default. Higher analysis resolution, local-contrast boost, structure-aware stroke priority and shorter ambiguous runs.
- **Maximum likeness** — highest CPU preprocessing cost. Uses the largest planning image, strongest structure priority, denser contour candidates and short local hatch segments.

The quality planner is deterministic and CPU-only in v1.0.3. GPU acceleration is reserved for the planned v1.0.6 step.

## What is prioritised

The planner does not perform face recognition. It scores useful image structure using local gradients/contrast, darkness and, when enabled, a soft centre-subject prior. This helps portraits without storing or identifying facial data.

## Suggested portrait starting point

- Rendering style: Auto or Portrait / shaded
- Draw quality: High likeness
- Detail level: Balanced or High detail
- Precision: High
- Brush: 1–2 px
- Portrait: emphasize centered subject: On for centred portraits
