# Adaptive Detail Engine — v1.0.38-beta

Adaptive Detail is a local image-planning pass. It does not lower the whole image to one global resolution.

## Modes

- **Off** — no adaptive simplification.
- **Auto** — measures local image complexity and selects Preserve detail, Balanced or Strong simplify.
- **Preserve detail** — protects more local structure and removes only isolated micro-runs.
- **Balanced** — keeps object borders/high local contrast while smoothing low-detail texture.
- **Strong simplify** — stronger flat-region smoothing and micro-run reduction for fast browser profiles.

## Safety / geometry rules

- High local luminance range is protected before color planning.
- Protected pixels are restored from the original sampled image after smoothing.
- Optional centered-subject focus gives extra protection to the middle of the image.
- Micro-strokes are removed only when all sampled points are in low-detail regions.
- Dot mode is not pruned by the execution integration.
- Outline-only rendering bypasses Adaptive Detail because the source is already reduced to edges.

## Profile defaults

- Microsoft Paint: Auto
- Other drawing app: Auto
- Skribbl.io: Preserve detail
- Skribbl.io Fast: Strong simplify
- Gartic.io: Strong simplify
- Other browser drawing profiles: Balanced

The final preview/status text reports effective mode, protected/simplified area and removed low-detail micro-strokes.
