# Render Resume + Color Checkpoints — v1.0.42

Draw Studio now checkpoints completed color batches during real drawing and can
resume from the next unfinished color after a crash or forced close.

## Dual Checkpoint System

Draw Studio keeps two separate local checkpoint files:

- **Session Checkpoint** (`session-recovery.json`): source-image cache pointer,
  settings, profile, saved-area suggestion and non-authoritative target-lock
  hints.
- **Render Checkpoint** (`render-resume.json`): final-plan fingerprint,
  completed color batches, total colors, next color and whether prelude/fill
  work had already completed.

The render checkpoint is deliberately separate. If `render-resume.json` is
missing, corrupt or incompatible, the session checkpoint can still restore the
image/settings while drawing restarts safely from color 1.

## Crash example

If drawing crashes while color 12 of 18 is in progress, only the 11 fully
completed batches are persisted. On restart the recovery UI shows:

`11/18 colors completed · next color 12 · DISARMED`

## Safety invariants

Recovery restores only local work state: source image, settings, saved-area
suggestion, non-authoritative target-lock hints and completed-batch metadata. It
never restores:

- mouse/input arming;
- target window lock authorization;
- Small test pass;
- Safety preflight pass;
- Dry run pass;
- Unlock/Start authorization.

The user must reselect/reuse the target area and complete the full Paint safety
chain again. Before skipping any completed color, Draw Studio rebuilds the final
plan and verifies a deterministic fingerprint of the processed image, colors,
selectors, order and plan size. A mismatch starts safely from color 1.

## Fill and progressive behavior

When a compatible checkpoint already contains completed colors, Background Fill
and Better Fill prelude work is not repeated, avoiding overwrite of finished
colors. Whole-color resume is supported for the default `Finish color first`
workflow. Progressive passes are rejected for batch resume because a color can
be only partially complete across phases.
