# Draw Studio v1.0.26-beta — Step 8: Renderer v2 / Better Shapes

Step 8 improves the Shape paths renderer without changing the guarded start flow.

## Added

- `Shape model` setting:
  - `Auto`
  - `Fast raster`
  - `Better shapes v2`
- Better Shapes v2 uses connected component analysis to identify compact same-color masses.
- Dense shapes get fewer, wider fill bands instead of row-by-row hatching.
- Large components get a simplified closed silhouette path.
- Fill paths keep overlap-safe connector points; smoothing is only used for contours, not fill bridges.
- `Skribbl.io Fast` defaults to `Better shapes v2`.

## Safety

The Step 1–7 gates remain unchanged:

`Draw small test → Lock setup → Safety preflight → Dry run · no clicks → Unlock full drawing → Start Drawing`

No new code path can start drawing, click, press, release, or arm native input.
