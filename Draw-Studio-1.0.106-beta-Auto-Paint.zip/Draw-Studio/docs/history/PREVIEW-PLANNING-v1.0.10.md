# Draw Studio v1.0.11 — Preview Planning Fix

v1.0.11 fixes a release-level issue where the live preview worker could spend minutes building a full drawing plan after selecting the drawing area. The drawing area and target window were captured correctly, but the preview worker remained active until shutdown.

Changes:

- Live previews now use a preview-sized planning canvas.
- Start Drawing still rebuilds the final full-size plan before mouse input is armed.
- Preview planning has a 45 second watchdog.
- Preview maps sample very large stroke plans instead of drawing every planned segment into the UI tabs.
- Planning start/finish/timeout is written to the session log.
- A timeout unlocks the UI and shows a clear message instead of looking like a crash.

This does not reduce final drawing quality. It only makes the automatic preview more responsive.
