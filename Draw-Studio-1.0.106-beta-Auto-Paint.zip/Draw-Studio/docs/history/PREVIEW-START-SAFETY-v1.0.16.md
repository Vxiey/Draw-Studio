# Draw Studio v1.0.16 beta – Manual Preview and Start Guard

## What changed

- Profile switching now forces Preview mode back to Manual after legacy saved settings are loaded.
- Profile switching never schedules automatic preview planning.
- Stale previews stay visible as a clear placeholder: press Build preview manually.
- Full drawing now uses a two-click safety lock: Arm full drawing, then Confirm Start Drawing within 12 seconds.
- Full drawing stays locked until image, drawing area, palette/tool readiness, and target checks pass.
- CPU Auto is capped to a safer GUI-friendly worker count; CPU engine Auto uses threads instead of Windows process spawning.
- Final planning has a timeout before mouse input is armed, so a stuck planner fails safely.
