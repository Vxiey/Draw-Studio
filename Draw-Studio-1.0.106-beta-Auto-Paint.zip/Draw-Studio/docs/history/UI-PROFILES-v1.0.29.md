# Draw Studio v1.0.29-beta — Step 11 UI Icons + Profile Experience

Step 11 improves the desktop interface without changing the safety chain or native input model.

## UI clarity
- Text icons/emoji identify the five workflow steps and high-impact actions.
- Readiness rows use explicit ✓ / ! / × states instead of color alone.
- Safety actions use distinct lock/shield/mouse/start labels.
- The selected profile gets an icon, category badge, contextual preparation text and recommended renderer summary.

## Profile-aware workflow
The preparation step is no longer hard-coded to Microsoft Paint. Microsoft Paint, Other drawing app,
Gartic Phone, Skribbl.io, Skribbl.io Fast, Sketchful.io, Drawize and Gartic.io each have dedicated:
- setup guidance,
- palette/canvas/tool labels,
- profile-safe renderer defaults.

Saved per-profile user settings are loaded after the defaults, so explicit user choices still win.
Manual Preview remains forced after profile changes for safety/performance.

## Profile defaults
Browser drawing profiles favor Shape paths + Better Shapes v2 + progressive rendering. Paint retains the
higher-likeness Smart paths workflow. Skribbl.io Fast keeps the strongest simplification and stroke budget.

## Safety
No extra start route was added. The full chain remains:
Small test → Lock setup → Safety preflight → Dry run → Unlock → Start.
