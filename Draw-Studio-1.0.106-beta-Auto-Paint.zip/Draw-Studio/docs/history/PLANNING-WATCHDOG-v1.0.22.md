# Draw Studio v1.0.22-beta — Step 4: Planning Watchdog + Fallback

This release builds on v1.0.21 Step 3 and keeps the safety chain unchanged.

## New

- New Planning watchdog control: Auto / On / Off.
- Final planning now runs as bounded attempts before mouse input can be armed.
- Primary attempt uses the selected settings but has an earlier watchdog deadline.
- Fallback 1 switches to safer Standard planning, Threads, Color layers Off and a smaller target cap.
- Fallback 2 switches to an emergency fast planner: CPU, RGB nearest, no fill, strong background simplification and a smaller stroke target.
- Heartbeat logs every 5 seconds show attempt number, fallback deadline, CPU engine, resolution and target stroke count.
- If every attempt fails, drawing stops safely before any mouse input is sent.

## Safety notes

The watchdog never bypasses Step 1. Full drawing still requires:

Draw small test → Safety preflight → Unlock full drawing → Start Drawing

The watchdog only changes planning options after a timeout. It does not move the mouse, click the target app, change calibration or start preview automatically.
