# Draw Studio 1.0.9 beta — Modern UI / UX Redesign

v1.0.9 reorganizes Draw Studio around a five-step workflow without removing the
rendering, GPU, automation, reporting or diagnostic features from earlier builds.

## Workspace

The main window now uses three stable columns:

1. **Workflow sidebar** — target app, image input, Paint preparation, drawing
   configuration and the final draw step.
2. **Preview workspace** — Original, Drawing preview, Stroke plan, Fill regions
   and Color map tabs with fit/zoom controls.
3. **Readiness panel** — explicit setup checklist, next-step help and a bounded
   error card with log/report/retry actions.

A fixed bottom bar keeps Start, Pause, Stop, progress and status visible.

## Settings visibility

The Configure step has three display modes:

- **Simple** — quality preset and brush width.
- **Advanced** — collapsible Quality, Precision & Speed, Smart tools and GPU cards.
- **Developer** — Advanced plus reporting state, app-data/log access, GPU probe,
  built-in self-test, diagnostic bundle and Windows dump controls.

These modes only change what is shown in the interface. They do not modify drawing
settings behind the user's back.

## Preview maps

Planning workers now also generate UI-only preview maps:

- **Stroke plan** shows planned paths on a dark map.
- **Fill regions** highlights safe Auto Fill regions and the background-fill plan.
- **Color map** provides a simplified source color view.

Auxiliary preview failures are non-fatal and never invalidate a drawing plan.

## Readiness and errors

Readiness logic is isolated in `UIState.py` and covered by display-independent
unit tests. The top status uses: Not ready, Setup needed, Ready to test, Ready to
draw, Drawing/Working and Error.

Common failures are translated into short, actionable error cards. Technical detail
still remains in the normal log/report pipeline.

## Safety and responsiveness

- Worker threads do not update Tk widgets directly.
- Status/UI traces schedule one `after_idle` refresh instead of reconfiguring CTk
  widgets synchronously.
- Preview `<Configure>` rendering remains debounced and re-entry guarded.
- Collapsible layout updates are also deferred to the Tk event queue.
- The small drawing test is now tracked as a readiness signal and is reset when
  target/tool/area configuration changes.

## README screenshot placeholders

For public release documentation, capture these from the Windows build:

- `docs/ui-v109-workspace.png` — default five-step workspace.
- `docs/ui-v109-advanced.png` — Advanced settings cards.
- `docs/ui-v109-error-card.png` — bounded Paint error guidance.
- `docs/ui-v109-tools.png` — Tools & diagnostics workspace.

The source package intentionally does not include fabricated screenshots.
