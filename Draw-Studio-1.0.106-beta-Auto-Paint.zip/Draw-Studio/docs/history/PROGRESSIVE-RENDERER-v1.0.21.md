# Draw Studio v1.0.21-beta — Step 3: Progressive Renderer

This release is built on v1.0.20 Step 2. It does not change the full drawing safety flow:

Small test → Safety preflight → Unlock full drawing → Start Drawing

## New

- Added **Progressive renderer** setting:
  - Auto
  - On
  - Off
- Progressive execution sequence for safe path modes.
- Draw order becomes:
  1. Large forms / foundation paths
  2. Important contours
  3. Small details
- Skribbl.io Fast defaults to Progressive renderer: On.
- Time-budget and target-stroke features from v1.0.20 remain active.
- Plan summary now shows progressive phase counts.
- During drawing, status text shows which progressive pass is currently being sent.

## Why

Old execution still tended to complete one colour before moving to the next. With time-limited drawing, that could leave the image looking unfinished until late in the run. Progressive rendering prioritizes visual recognizability earlier.

## Safety

Progressive renderer only reorders paths already produced by the safe planner. It does not bypass target-window checks, palette validation, preflight, Start Guard, or guarded mouse execution.
