# Speed Optimization — v1.0.5 beta

v1.0.5 accelerates the physical drawing loop without changing the renderer's planned line geometry.

## Speed profiles

- **Safe** — conservative motion timing for target applications that miss fast cursor updates.
- **Balanced** — recommended default. Shorter pen-up/boundary waits and moderate path timing.
- **Fast** — lowest motion waits and the largest local travel-optimization window. Use a small test first.

Older saved values migrate automatically: `Careful` -> `Safe`, `Normal` -> `Balanced`.

## Geometry-preserving travel optimization

Each color group is optimized in bounded windows. The first stroke in each window remains a priority anchor, then nearby strokes are chosen greedily by endpoint distance. Lines may be reversed because A->B and B->A have identical geometry for the solid drawing tools Draw Studio recommends.

The optimizer never changes line endpoints and never creates connecting lines between separate strokes. Bounded windows are important for portrait mode because high-priority facial structure must still be drawn before low-priority shading.

## Faster movement loop

v1.0.4 waited before each path point and then added another wait after the endpoint. v1.0.5 moves to each planned precision point first, waits for Paint to receive that point, and removes the duplicate endpoint wait.

Pen-up travel, in-stroke motion and stroke-boundary settling now have separate timing factors. Palette/tool selection keeps conservative fixed settle times even in Fast mode so speed does not make calibration UI clicks less reliable.

## Precision and Human Mode

Speed profiles do not change the Precision path. High still targets about 4 px movement spacing and Ultra about 2 px. Human Mode runs after bounded speed ordering, so exact geometry is preserved and natural cadence/direction variation remains available.

## Safety

Fast mode does not bypass target-window checks, cursor tracking, Paint ink verification, the time limit, Esc stop, or the explicit mouse-arm requirement. If Paint misses strokes, switch back to Balanced or Safe.
