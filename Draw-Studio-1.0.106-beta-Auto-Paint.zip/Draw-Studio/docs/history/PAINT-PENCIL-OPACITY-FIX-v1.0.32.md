# Draw Studio v1.0.32-beta — Paint Pencil / opacity safety

- Pencil no longer requires or clicks the Brush 100% opacity coordinate.
- Auto prefers a calibrated Pencil even when Brush opacity is not calibrated.
- Brush still requires Brushes menu + concrete preset + 100% opacity.
- This prevents newer Paint layouts from interpreting a stale opacity coordinate as another toolbar control while Pencil is active.
- First-stroke color verification remains enabled; wrong colors still stop immediately without retry.
