# Visual Verification — v1.0.43

After each completed color batch, Draw Studio can read the selected canvas and run a fast sanity check.

## What it checks
- Planned stroke/sample points match the expected batch color.
- The new canvas diff mostly stays inside the planned stroke regions.
- Large outside changes are flagged as possible Fill leakage or drawing in the wrong place.

## Safety model
- The snapshot is read-only: no click, press, release or cursor movement is generated.
- Visual verification never restores or arms native mouse input.
- Failure stops the current drawing so the user can inspect the canvas.
- Render Resume checkpoints remain available for already completed color batches.

## Modes
- Auto: Balanced for Microsoft Paint, Off for generic/browser profiles unless changed manually.
- Fast: fewer samples, more tolerant.
- Balanced: default Paint behavior.
- Strict: more samples and tighter thresholds.
- Off: disables post-batch canvas verification.

This is intentionally not pixel-perfect comparison. It is designed to catch major errors such as wrong color, missed regions, leaked fills, or strokes appearing outside the planned batch.
