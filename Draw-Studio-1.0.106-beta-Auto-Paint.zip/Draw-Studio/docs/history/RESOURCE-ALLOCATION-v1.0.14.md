# Draw Studio v1.0.14 – Real CPU/GPU/RAM Workload Allocation

This build keeps the v1.0.13 resource controls and adds planning-resolution scaling so the selected CPU workers, process/thread backend, RAM budget and CUDA colour pipeline have enough source pixels to process.

## New

- Planning resolution: Auto / Standard / High / Ultra / Extreme.
- Standard keeps the older low-resolution planner for quick drafts.
- High, Ultra and Extreme build larger planning rasters before Smart Paths compress them into continuous strokes.
- CPU/RAM benchmark now runs a real short worker test instead of only validating settings.
- CUDA palette planning can accelerate Perceptual match / RGB-nearest single-layer colour plans when NVIDIA CUDA is available.
- The summary shows effective planning resolution, source sample limit, pixel budget, CPU backend and CUDA colour metadata where available.

## Still single-stream

Mouse drawing remains single-stream. Draw Studio can use CPU/GPU/RAM during planning, but it must send one cursor path at a time to Paint or another drawing app.
