# Draw Studio v1.0.12 — Smart Continuous Paths

v1.0.12 keeps the complete v1.0.11 planning pipeline and adds a faster execution model after planning.

## Why Lines and Dots were slow

The old raster planner creates many independent straight runs. Each run requires pen-up travel, mouse-down, multiple movement events, mouse-up and a boundary settle. GPU acceleration can make image analysis faster, but it cannot remove those native mouse boundaries.

## New drawing model

**Smart paths (recommended)** starts from the same final color runs used by the existing renderer. It joins runs only when:

- they use the same final drawing color;
- they are on directly adjacent sampled rows; and
- their horizontal intervals overlap.

The connector moves along already-valid color pixels to an overlap point and then moves one sampled row vertically. It never intentionally bridges a blank row or a non-overlapping gap.

This creates longer serpentine / hatch-like brush paths with one mouse-down across multiple source runs.

## Compatibility

Smart paths are built **after** the existing planners, so these features remain in place:

- Manual Preview / Build preview;
- GPU enhanced analysis;
- Perceptual and layered color rendering;
- color grouping;
- background simplification;
- Auto Fill and safe interior Fill regions;
- Paint tool calibration and guarded native mouse input;
- precision, speed and Human mode;
- portrait contour prioritization.

Portrait contour strokes are deliberately kept independent. Compatible horizontal tone hatches can be joined while retaining structure-first ordering.

## Legacy modes

- **Smart paths (recommended)** — new default, optimized continuous execution.
- **Lines (fastest)** — retained unchanged for compatibility with previous releases.
- **Dots** — retained unchanged for stipple/dither cases.

## Diagnostics

Plans now expose:

- `source_count`: source raster/portrait runs before path joining;
- `count`: actual continuous execution paths;
- `path_stats.joined_strokes`;
- `path_stats.compression_ratio`.

The UI summary displays source runs → continuous strokes when Smart paths produces a reduction.
