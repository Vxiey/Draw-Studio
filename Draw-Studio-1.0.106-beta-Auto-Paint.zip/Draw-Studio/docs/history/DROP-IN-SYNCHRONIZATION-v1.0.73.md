# Drop-In Synchronization — v1.0.73-beta

A manually armed browser Drop-In can now wait for the read-only setup pipeline instead of being rejected because of timing. The pending request has a 30-second bound, keeps only the newest image, validates the same browser/profile identity and resumes automatically after setup. No mouse input is sent while waiting.
