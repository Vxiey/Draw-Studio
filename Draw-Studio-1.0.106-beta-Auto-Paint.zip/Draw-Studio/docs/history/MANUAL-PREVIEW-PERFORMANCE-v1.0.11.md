# Draw Studio v1.0.11 — Manual Preview + Stability Defaults

v1.0.11 changes preview planning so configuration changes no longer start heavy analysis by default. The new Preview mode setting defaults to Manual.

## Why

Logs showed repeated preview planning while changing settings. Expensive GPU enhanced and advanced color settings could rebuild the preview many times before the user pressed Start Drawing.

## Changes

- New Preview mode: Manual, Auto light, Auto full.
- Manual is the default and blocks automatic preview planning after image load, profile changes, drawing-area selection, and setting changes.
- Build preview is now an explicit button.
- Start Drawing still builds the final full-size plan manually.
- Automatic preview mode logs why it starts and uses lighter settings in Auto light.
- Microsoft Paint profile defaults are more conservative: Auto Fill Conservative and Color layers Off.
- Previous plans become stale when settings change, instead of silently triggering a heavy rebuild.

## Recommended stable settings

Use Preview mode Manual, Draw quality High likeness, Color layers Off, Auto Fill Conservative, Speed Balanced, Precision High.
