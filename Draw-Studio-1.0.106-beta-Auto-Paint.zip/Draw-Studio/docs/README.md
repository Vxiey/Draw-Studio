# Draw Studio Documentation

This folder is the documentation landing page bundled with Draw Studio.

## Start here

- `../README.md` — main user guide.
- `../README-INDEX.md` — quick map of all documentation files.
- `../VERSION-HISTORY.md` — version-by-version timeline.
- `history/README.md` — detailed index of feature notes and release notes.

## Runtime privacy

Draw Studio has no telemetry or automatic report upload. Runtime safety reports and diagnostics are local unless the user manually shares a generated ZIP.
