# Draw Studio v1.0.65-beta — Gartic Phone Turbo Renderer

This release adds a dedicated deterministic fast path for **Gartic Phone** while leaving Paint and Skribbl behavior unchanged.

## Gartic Phone Turbo

- Fixed calibrated-palette drawing: no custom RGB dialog workflow in Auto profile mode.
- Reduces the active palette to at most 8 useful colors while preserving the darkest structural color.
- Draws one color batch at a time to reduce palette switching.
- Compresses adjacent same-color raster pixels into longer runs.
- Evaluates both **horizontal** and **vertical** runs per color and chooses the orientation with fewer mouse strokes.
- Uses the vertical-column idea from classic Gartic Phone autodraw code and the color-batched run compression already used by Skribbl Turbo.
- Uses Smart Paths, Strong simplify, a 60-second profile budget and a 1000-path safety/performance cap.
- Browser stroke interpolation is widened to reduce native cursor events while keeping exact path endpoints.

## Gartic palette calibration

- Adds a conservative 18-color Gartic Phone reference preset arranged as a 3 × 6 palette.
- The screen remains authoritative: matched swatches are sampled from the current display.
- If the preset no longer matches a future Gartic UI/theme, calibration falls back to normal swatch detection instead of guessing click positions.

## Safety

- CanvasGuard, SafePolygon, FinalMouseGuard, target monitoring and edge clipping are unchanged.
- Turbo is planning-only and cannot disable safety layers.
- `Profile policy: Manual settings` does not force Gartic Turbo.

## Verification

- 533/533 unit tests pass.
- `compileall` passes.
- `DrawBot.py --self-test` passes.
