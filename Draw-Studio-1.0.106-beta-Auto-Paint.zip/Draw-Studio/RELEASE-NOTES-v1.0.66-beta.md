# Draw Studio v1.0.66-beta – Gartic Engine v2

## Highlights

- Gartic Phone Engine v2 for the current web layout.
- 6×12 / 72-color Gartic palette reference.
- Automatic canvas-geometry confidence check for the wide white drawing paper.
- Fixed-palette Gartic batching, similar to Skribbl Turbo but Gartic-specific.
- Dual-axis run optimizer chooses horizontal or vertical runs per color.
- StrokeGraph travel optimization reduces pen-up movement inside each color batch.
- Runtime profile can become more aggressive when the timer is low.
- HTML5 canvas mode uses fewer movement events than Paint.

## Safety

No AI, OCR, browser injection, telemetry or automatic uploads. CanvasGuard, FinalMouseGuard, target monitoring, Safe Fill and edge safety remain global hard safety layers.

## Testing

Unit/regression suite passes on source. Windows EXE should still be built and smoke-tested through GitHub Actions or a clean Windows machine before public release.
