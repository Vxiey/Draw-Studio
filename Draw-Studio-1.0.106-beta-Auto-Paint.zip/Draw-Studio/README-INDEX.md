# v1.0.106-beta — Auto setup Paint

## Så gör du
1. Packa upp hela ZIP-filen och kör Start.bat.
2. Öppna ett Paint-fönster med en tom, helt synlig rityta.
   Använd ljus appdesign, visa hela verktygsfältet och stäng öppna menyer.
3. Välj Microsoft Paint i Draw Studio och tryck Auto setup Paint.
4. Draw Studio minimeras och läser av rityta, 20 färger, Pencil, Fill och Eraser.
   Du behöver inte först markera ritytan. Inga ritklick skickas vid kalibreringen.
5. Appens Auto-verktyg väljer Pencil. Ställ Pencil på 1 px i Paint och kör Small test.
6. Lägg in din bild, välj exempelvis Extra fast och bygg preview innan Start.

Penselbredden kan ännu inte läsas automatiskt med tillräcklig säkerhet.
Brush-menyn och dess penseltyper kalibreras inte av detta flöde: Pencil används
som ett direkt, opakt ritverktyg och Fill får en separat verifierad position.

## Vad som ändrats
- Tidigare gissningar från ikonernas täthet/ordning används inte längre.
- Modern Paint identifieras genom färgrutornas inbördes placering och jämförelse
  med Pencil-, Fill- och Eraser-ikonerna från den uppladdade referensen.
- Riktiga RGB-värden läses från 20 verifierade färgrutor; dubletter undviks.
- Koordinater förankras i Paint-fönstret och inkluderar skärmens position.
- Storleken på analysbilderna begränsas och arbetet körs i bakgrundstråden.
- Täckta eller okända verktyg, flera Paint-fönster, täckta färger och osäker
  rityta ger ett tydligt fel. Manuell kalibrering finns kvar.
- Auto setup startar inte ritning eller väljer Done/Fill genom att klicka.

## Verifiering och begränsningar
821 automatiserade tester samt source self-test godkända på Linux.
Den uppladdade Paint-bilden och skalade kopior vid 80/100/125/150/200 procent
har kontrollerats. Det är bildtester, inte provkörning av verkliga Windows
DPI-inställningar. Själva Windows-aktiveringen, GUI-flödet och ritningen måste
fortfarande verifieras på Windows.

Detta är stöd för den moderna ljusa Paint-layouten i referensbilden, inte ett
löfte om alla äldre/nya Paint-versioner, mörkt tema eller hopfällda verktygsfält.
Befintliga bilder och ritytor som ligger utanför fönstret väljs manuellt.
Paketet innehåller källkod och Start.bat; ingen nybyggd EXE.

---

# v1.0.105-beta — Extra fast

## Använd läget
1. Packa upp hela paketet och kör Start.bat.
2. Välj programprofil och kalibrera rityta och färgpalett som vanligt.
3. För bucket fill behöver profilen även ha Brush/Pencil och Fill kalibrerade.
4. Välj Drawing preset → Extra fast. Läs in bilden och bygg preview.
5. Kör Safety preflight / ett litet prov på tom rityta före vanlig Start.

Extra fast använder befintliga Closed regions v2: ritar slutna konturer i
regionens färg, fyller deras insidor och fortsätter med kvarvarande penseldrag.
Konturer och fyllningar grupperas per färg; det är inte en separat svart
kontur över hela bilden. Inga automatiska klick sker när förvalet väljs.

En ny kostnadsberäkning inkluderar konturrörelse, verktygsbyten och väntetider.
Fyllning väljs bara om uppskattningen är minst 25 procent snabbare än regionens
scanlines. Detta är en uppskattning, ingen uppmätt hastighetsgaranti jämfört med
alla andra ritmotorer. Högst 12 regioner från den befintliga regiondetektorn
utvärderas. Avvisade regioner behåller vanliga penseldrag.

Läget använder kalibrerad palett, slutna regioner, ingen bakgrundsfyllning av
hela duken och inga extra färglager. Det fungerar bäst för illustrationer,
logotyper och stora enhetliga färgytor. Foton kan få få eller inga fyllningar.
Utan Fill-kalibrering används Smart paths. Vid enfärg/Outline används enkel
svart sketch utan fyllning. Eraser stöds inte i detta förval.

Befintliga kontroller av rityta, fyllningsfärg och förändringar utanför regionen
behålls. Kantnära, öppna och osäkra regioner faller tillbaka till penseldrag.
Analysen av stora sammanhängande ytor har tätare avbrytningskontroller.
Minnesgränser och preview-förbättringar från v1.0.104 finns kvar.

815 automatiserade tester och source self-test godkända på Linux.
Windows-GUI, musritning och verklig Gartic/Paint-fyllning är inte provkörda här.
Källkod med Start.bat; ingen nybyggd EXE. Tidigare sparade inställningar behålls.

---

# v1.0.104-beta — Detailed preview

## Börja här
1. Packa upp hela ZIP-filen och kör Start.bat.
2. Läs in en bild och välj ritområde som vanligt.
3. Använd Build preview för en snabb förhandsvisning.
4. Välj Full detail preview för ritplanen i målupplösning.
5. Välj 1:1 för originalstora målpixlar, +/− för zoom och dra för att panorera.
   Fit visar hela bilden igen. Full detail startar aldrig musritning.

## Stabilitet och visning
- Zoom renderar bara det synliga utsnittet. Bilden förstoras inte till en jättestor bitmap.
- Bara synliga previewflikar skapar Tk-bilder. Dolda flikars Tk-bilder släpps.
- Full detail har en förkontroll av målupplösningen mot vald RAM-budget, högst
  8 miljoner målpixlar, och använder en CPU-worker. Detta är en uppskattad
  planeringsgräns, inte en hård gräns för processens totala minnesanvändning.
- Beräkningen har avbrytningskontroller och en tidsgräns på 60 sekunder.
  En enskild biblioteksoperation kan behöva avslutas innan avbrottet märks.
- Full detail faller inte tillbaka till en förenklad preview i hemlighet.
- Color map delar ritplanens bild och gör ingen separat färgkvantisering.
- Fel i hjälpkartor lämnar huvudbilden tillgänglig. Vid timeout behålls tidigare preview.
- Coverage och Accuracy förklarar när de kräver Pixel Accurate; sketch beräknar inte dessa kartor.

Förhandsvisningen simulerar den planerade ritningen, inte verkligt resultat i spelet.
Ritmotorns valda upplösning/stil gäller fortfarande. En ny plan vid Start kan
ändras av återstående tid, automatisk stil och CPU/GPU-backend.

810 automatiserade tester samt source self-test godkända på Linux.
Windows-GUI, verklig musritning och CUDA har inte provkörts i denna miljö.
Paketet innehåller källkod och Start.bat; ingen nybyggd EXE.

---

# v1.0.103-beta — Human mode off

Human mode är borttaget från gränssnittet och alltid Off i appens ritplanering.
Gamla profilval (Subtle/Natural/Strong) ignoreras. Profilbyte och nya sparade
inställningar använder Off. Human modes extra pauser och variationer används
inte längre. Säkerhetskontroller och nödvändiga inmatningsfördröjningar behålls.

Fullständigt paket: packa upp och kör Start.bat.
Patch för v1.0.102: stäng appen och kopiera DrawBot.py, StudioUI.py, Version.py
och version_info.txt till mappen med Start.bat. Ersätt filerna och starta igen.
Kalibrering och övriga profilinställningar behålls.

803 automatiserade tester samt source self-test godkända. Det befintliga
testet av appens human_mode-val förväntar nu Off även med ett äldre sparat val.
Äldre hjälpfunktioner finns kvar för källkodskompatibilitet, men appen väljer
aldrig deras aktiva lägen. Windows-ritning har inte provkörts här.
Källkod med Start.bat; ingen nybyggd EXE.

---

v1.0.102-beta: Single-color sketch for games. 803 automated tests passed. See RELEASE-NOTES-v1.0.102-beta.md. Windows input not verified here.

v1.0.102-beta: Single-color sketch for games. 803 automated tests passed. See RELEASE-NOTES-v1.0.102-beta.md. Windows input not verified here.

v1.0.101-beta: Single-color sketch for games. 794 automated tests passed. See RELEASE-NOTES-v1.0.101-beta.md. Windows input not verified here.

v1.0.100-beta: Single-color sketch for games. 786 automated tests passed. See RELEASE-NOTES-v1.0.100-beta.md. Windows input not verified here.

v1.0.99-beta: Single-color sketch for games. 781 automated tests passed. See RELEASE-NOTES-v1.0.99-beta.md. Windows input not verified here.

v1.0.98-beta: Single-color sketch for games. 777 automated tests passed. See RELEASE-NOTES-v1.0.98-beta.md. Windows input not verified here.

v1.0.97-beta: Single-color sketch for games. 770 automated tests passed. See RELEASE-NOTES-v1.0.97-beta.md. Windows input not verified here.

v1.0.96-beta — Sketch start fix. Se RELEASE-NOTES-v1.0.96-beta.md.

v1.0.95-beta: Black contour sketch. See RELEASE-NOTES-v1.0.95-beta.md.
761 automated tests passed. Windows GUI and real input not verified. Source package with Start.bat; no compiled EXE.

# Draw Studio README / Version Index

Open these files depending on what you need:

| File | Purpose |
|---|---|
| `README.md` | Main install, first-use, safety and build instructions. |
| `VERSION-HISTORY.md` | Complete readable timeline of what was added by version. |
| `RELEASE-NOTES-v1.0.94-beta.md` | Notes for the current release. |
| `RELEASE-NOTES-v1.0.88-beta.md` | Block C accuracy-engine notes. |
| `RELEASE-NOTES-v1.0.87-beta.md` | Block B component-stroke release notes. |
| `BUILD-STATUS.txt` | Current release verification result. |
| `RELEASE-CHECKLIST.md` | Steps to verify a release before publishing. |
| `docs/README.md` | Documentation landing page. |
| `docs/history/README.md` | Index of every historical feature/release markdown file. |

The Windows app also has **About → Version history** for reading the same timeline from inside Draw Studio.
