# Per-Game Input Engine — v1.0.75-beta

Gartic Phone, Skribbl.io, Skribbl.io Fast and SketchHeads no longer share one generic browser mouse policy. Each profile has deterministic interpolation, path-spacing, mouse-down/up settle and palette/control-click timing. The policy is exposed in runtime metadata/logging for debugging and does not control any safety decision.
