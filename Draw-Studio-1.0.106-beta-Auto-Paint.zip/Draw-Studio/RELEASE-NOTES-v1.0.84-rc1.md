# Draw Studio v1.0.84-rc1 — Browser palette guard hotfix

Field diagnostics from v1.0.83-rc3 confirmed that CUDA was working, but Gartic Phone drawing was stopped before input by a Paint-specific strict palette check after Browser Visual Preflight had already passed.

## Fixed
- Supported browser profiles no longer run Paint's strict per-swatch ScreenGuard color comparison.
- Gartic Phone, Skribbl.io/Fast and SketchHeads use Browser Visual Preflight as the runtime palette/layout authority.
- Paint and generic calibrated apps retain the strict palette safety guard.
- Palette mismatch wording is now application-neutral.

## GPU diagnostics
- Added `Detect / benchmark NVIDIA GPU` directly to the GPU settings card.
- Planner benchmark now reports the effective backend/device so `cuda` versus CPU is obvious in the UI/log.
- Existing NVIDIA hardware discovery and CuPy/CUDA smoke benchmark remain unchanged.
