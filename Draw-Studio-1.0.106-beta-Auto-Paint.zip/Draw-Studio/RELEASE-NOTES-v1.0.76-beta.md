# Draw Studio v1.0.76-beta — Layout Fingerprint v2

- Local browser layout fingerprints for Gartic Phone, Skribbl.io/Fast, SketchHeads and Sketchful.io.
- Saves canvas, palette geometry, client size, DPI and an inferred zoom/layout signature.
- Fast cache hit restores anchored palette/canvas after read-only swatch verification.
- Multiple zoom/reflow fingerprints may coexist for the same client size.
- Cache miss falls back to full Browser Auto Calibration.
- Browser Visual Preflight and CanvasGuard remain unchanged and cannot be bypassed.
- No screenshots, source images, URLs or telemetry are persisted by the cache.
