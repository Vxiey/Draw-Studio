# Draw Studio v1.0.74-beta – Automatic Brush Size

- Read-only brush-size control detection for Gartic Phone, Skribbl.io/Fast and SketchHeads.
- Maps Draw Studio brush width to the nearest verified in-game brush preset.
- Selects the brush preset only after the explicit drawing action has armed the target.
- Verifies an already-selected size visually when possible and checks for a visual response after changing size.
- If the control row cannot be verified, no guessed click is sent; CanvasGuard uses a conservative brush-inset fallback.
- Fixes SketchHeads palette-row detection so brush-size circles and distant toolbar icons are not misclassified as colors.
