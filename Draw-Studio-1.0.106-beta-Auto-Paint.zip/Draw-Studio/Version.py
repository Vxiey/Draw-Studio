"""Single source of truth for Draw Studio release metadata."""
APP_VERSION = '1.0.106-beta'
FILE_VERSION = "1.0.106"
BUILD_CHANNEL = 'beta'
