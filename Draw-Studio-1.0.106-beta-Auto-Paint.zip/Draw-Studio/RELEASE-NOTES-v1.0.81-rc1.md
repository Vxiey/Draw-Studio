# Draw Studio v1.0.81-rc1 — Stability / Release Candidate

- No major new renderer features.
- Stress coverage for Drop-In, zoom/resize/DPI and 100+ lifecycle cycles.
- Mouse-up + input-disarm cleanup hardened for exceptions.
- Stale worker completion cannot clear a newer busy state.
- One-Click delayed callbacks are tracked/cancelled on stop/shutdown.
- Settings schema migration strips retired automatic-drawing authorization.
- Existing layout-cache version mismatch continues to fail closed into a clean v2 cache.
