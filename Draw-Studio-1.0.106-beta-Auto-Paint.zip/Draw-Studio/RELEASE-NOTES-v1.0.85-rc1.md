# Draw Studio v1.0.85-rc1 — Automatic NVIDIA CUDA Setup

This release makes NVIDIA acceleration a self-healing source-install feature instead of a separate manual prerequisite.

## What changed

- `Start.bat` detects NVIDIA hardware before checking CUDA.
- If a real CuPy CUDA kernel already works, startup continues immediately without reinstalling anything.
- If CUDA is missing or broken, Draw Studio automatically installs/repairs `requirements-gpu-nvidia.txt` inside `.venv`.
- The GPU bootstrap removes conflicting CuPy package families before installing the selected backend, avoiding mixed `cupy`, `cupy-cuda12x`, and `cupy-cuda13x` environments.
- CuPy uses its `[ctk]` extra, so the matching CUDA runtime, NVRTC, and headers are installed in Draw Studio's virtual environment. A separate system-wide CUDA Toolkit is not required; the NVIDIA driver is still required.
- Setup ends with a fresh-process `RawKernel` smoke test. CUDA is only considered ready after the kernel executes successfully.
- GPU setup failures do not prevent the app from opening. Draw Studio uses CPU fallback and can retry on the next launch.
- `Install-GPU-NVIDIA.bat` remains available as a forced repair path, but normal users should only need `Start.bat`.

## Verification

Run `Start.bat`, then use **Detect / benchmark NVIDIA GPU** in the GPU settings card. The effective planner backend should report CUDA when acceleration is active.
