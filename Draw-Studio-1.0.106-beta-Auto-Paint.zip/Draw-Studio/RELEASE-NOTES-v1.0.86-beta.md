# Draw Studio v1.0.86-beta — Pixel Accurate Planner, Block A

This release changes the renderer priority from **compress first** to **preserve image information first** when `Draw quality = Pixel Accurate`.

## 10 Block A patches

1. **Pixel Accurate mode** — a new quality mode dedicated to fidelity rather than timer fitting.
2. **Quality-first profile lock** — Auto profile policies cannot force Strong simplify, reduced palette, low resolution or low stroke caps over Pixel Accurate.
3. **Full fitted target raster** — the planner preserves the full pixel resolution of the image after aspect-ratio fitting to the selected canvas.
4. **PixelMap** — every analysed target pixel stores RGB, calibrated palette index, drawable state, edge strength, importance and protection state.
5. **CUDA palette mapping** — CuPy compares target pixels against the calibrated palette on NVIDIA GPUs; NumPy is the CPU fallback.
6. **Perceptual palette distance** — Pixel Accurate can use perceptual matching instead of destructive pre-quantization.
7. **CUDA edge map** — Sobel edge analysis runs through the NVIDIA backend when available.
8. **Importance map** — edges, local contrast, rare colours and dark structure contribute to detail priority.
9. **Tiny-feature protection** — high-value small structures are explicitly protected; adaptive micro-pruning is disabled.
10. **No destructive browser turbo** — RealSpeedBudget, target path caps, background simplification and Gartic Phone Turbo cannot reduce Pixel Accurate plans. Planner logs expose PixelMap resolution and GPU/CPU analysis backends.

## Scope

Block A deliberately does **not** add connected-region scheduling or the new multi-pass stroke engine. Those belong to v1.0.87 Block B so the pixel-analysis foundation can be tested independently.
