# Input Ownership — v1.0.63-beta

Draw Studio distinguishes its own expected cursor endpoint from a persistent external cursor deviation using a short confirmation read. A single transient mismatch no longer ends a drawing. Persistent deviation still stops.

The default Microsoft Paint drag backend is again SetCursorPos-compatible. Dense SendInput delivery can still be selected by policy when needed.
