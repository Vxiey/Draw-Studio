# Draw Studio v1.0.83-rc3 — NVIDIA discovery + canvas drop-to-draw

## Fixed

- NVIDIA hardware is now detected independently from CuPy using `nvidia-smi` first and Windows CIM as fallback.
- `Start.bat` automatically checks NVIDIA hardware and prepares the optional CUDA/CuPy backend only on NVIDIA systems.
- CUDA setup now uses CuPy 14 with matched CUDA runtime/NVRTC/header components through the `[ctk]` extra.
- GPU benchmark distinguishes **GPU not found** from **NVIDIA GPU found but CUDA backend missing/broken**.
- GPU benchmark re-probes CUDA instead of keeping a stale failed backend cache.
- Multi-NVIDIA systems select the visible CUDA device with the largest VRAM for analysis.
- The CUDA installer runs a real `RawKernel` smoke test before declaring the GPU ready.
- Performance Auto Tuner preserves detected NVIDIA model/driver details even when CUDA falls back to CPU.
- Dropping an image directly on a preview canvas can one-shot start drawing when a non-Paint target is already safe and ready.
- Supported browser profiles continue through Browser One-Click setup and visual preflight before drawing.
- Microsoft Paint retains the stricter Lock → Safety preflight → Dry run → Unlock → Start chain.

## Startup / recovery

If CUDA installation failed previously, run `Start.bat --update` to force a retry. `Install-GPU-NVIDIA.bat` remains available for a manual retry and now verifies the GPU with a real CUDA kernel.
