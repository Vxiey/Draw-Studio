# Browser One-Click Mode — v1.0.80

Supported browser profiles can now use the normal flow **choose game → add/drop image → draw**. Draw Studio performs a read-only discovery/reuse of the target browser, automatic canvas and palette calibration, Layout Fingerprint restore where possible, Browser Visual Preflight and Automatic Brush Size before native input.

Safety: Paint is excluded. Ambiguous browser matches fail closed. CanvasGuard, FinalMouseGuard, target monitoring, Auto-Recalibration and Visual Preflight remain mandatory.
