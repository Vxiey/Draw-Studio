# Draw Studio v1.0.95-beta — Black contour sketch

## Användning

1. Packa upp hela ZIP-filen och kör **Start.bat**. Behåll din gamla mapp som säkerhetskopia.
2. Lägg in en bild och välj programmets profil och rityta som vanligt.
3. Slå på **Black contour sketch** i steg 4, vid ritinställningarna.
4. Välj en tunn penna, helst 1 px, i ritprogrammet. I **Single-color Paint** måste du själv välja svart. Med kalibrerad färgpalett väljer boten den svarta färgrutan.
5. Bygg förhandsvisningen, kontrollera resultatet och klicka Start när du är redo.

Reglaget ersätter den tidigare avancerade inställningen Outline only. Avstängt återgår planeringen till färgläget. Det tidigare gränssnittet behålls.

## Ändringar

- Egen konturbehandling: utjämning, tunna kanter och borttagning av mycket små kantfragment.
- Enbart svarta linjer; ingen färgfyllning, vit övermålning eller porträttskuggning.
- Genomskinliga pixlar behandlas mot vit bakgrund. Helt enfärgade bilder ger ingen ritning.
- Färg- och förenklingsmotorerna för spel kan inte ersätta sketchplaneringen.
- Motivfokus stängs av när sketchreglaget slås på. Välj endast ett av dessa lägen.
- Test drawing använder också enbart svart när sketch är aktivt.
- Om paletten saknar exakt svart stoppas planeringen med ett tydligt fel i stället för att välja en annan färg.

Det är vanlig kantdetektering utan AI: den förstår inte vilka objekt som är viktiga och kan behålla bakgrundskanter. Arbetsbildens längsta sida är högst 720 pixlar. Inställd tidsgräns kan fortfarande stoppa ritningen innan alla konturer är klara. På en redan målad canvas raderas inte bakgrunden; börja på en tom vit yta.

## Kontroll

761 automatiserade tester godkända, inklusive åtta nya sketchtester. Source self-test godkänd. Windows-gränssnitt, faktisk musritning och NVIDIA-hårdvara är inte verifierade här. Paketet innehåller källkod och Start.bat, ingen nybyggd EXE.
