# Gartic Phone Layout Reference — v1.0.66

Observed reference at 1920×1080:

- Palette: 6 columns × 12 rows = 72 colors.
- White canvas: approximately 982 × 549 px, aspect ~1.789:1.
- Right tool panel: 2 columns × 5 rows.
- Brush: row 1 left.
- Eraser: row 1 right.
- Fill: row 4 right.

These values are used for validation/guidance only. Mouse click positions remain calibrated by the user and anchored to the target window; Draw Studio does not blindly click reference coordinates.
