# Kodgranskning – Draw Studio v1.0.90-beta

Utgångspunkt: v1.0.89-beta Block D. ZIP-filens SHA-256 matchade den checksumma du skickade. Den äldre koden från början av tråden har inte lagts ovanpå den nya versionen.

## Omfattning

Alla 214 Python-filer kontrollerades med syntaxträd och sökning efter dubbla funktions-/klassdefinitioner inom samma klass/modul; inga sådana dubbletter hittades. Djupare manuell granskning riktades mot musstest, input, start och trådar, kraschhantering, diagnostik, bildplanering, autofyllning, CPU/GPU-simulering, tidsbudget och avbrott. Övriga funktioner ingår i den befintliga regressionssviten. Detta är en bred genomgång, inte ett löfte att varje rad eller kombination är felfri.

## Reproducerade eller kodbelagda fel

| Område | Fel | Ändring |
| --- | --- | --- |
| Autofyllning | Ett test gav 1 074 drag med Fill mot 576 utan. Vita korrigeringar skapades utanför fyllda regioner. | Korrigeringar begränsas till relevanta områden; det ursprungliga testet passerar. |
| Mus | Misslyckad release kunde lämna input armerat. | Avväpning sker även vid release-fel. |
| Mustest | Output lästes först efter processavslut. Timeout/avbrott kunde dessutom missa sista loggen. | Output töms under väntan; processen avslutas och loggen tas om hand. |
| Start av test | Ett trådstartfel kunde lämna appen upptagen och minimerad. | Återställning av aktivitetsläge och fönster. |
| CPU/GPU-simulering | Helt osynliga streck klämdes till kantpixlar. | Streck helt utanför bilden hoppas över; delvis synliga penselavtryck klipps. |
| Noggrannhet | Återkommande faser grupperades om och kunde ändra övermålning. | Kontrollpunkter följer den verkliga sekvensen. |
| Tidsbudget | Den rapporterade budgeten kunde vara större än hela planen. | Begränsad till befintligt antal paths. |
| CUDA | Stor VRAM-budget kunde ge extremt mycket arbete i en kernel. | Begränsat antal pixel/rektangeltester per körning och mindre row-tiles. Behöver benchmarkas på riktig GPU. |
| CUDA-score | Fullstora temporära matriser tog inte hänsyn till vald budget. | Konservativ uppskattning med CPU-fallback. |
| Avbrott | Vissa långa CPU-loopar saknade tillräckligt täta avbrottskontroller. | Kontroller i komponent- och kolumnbearbetning. |
| Kraschmarkör | PID-jämförelse använde delsträng. | Exakt ägarskapskontroll. |
| Diagnostik | Samma sekund kunde ge samma ZIP-namn; stora loggar lästes helt; CUDA startades under insamlingen. | Unika namn, begränsad loggläsning och ingen GPU-initiering under insamling. |
| Inställningsexport | Okända strängfält kunde följa med. | Tillåtelselista för tekniska fält. |
| Native dump | Den tidigare konfigurationen använde HKCU och påstod att admin inte behövdes. | Dokumenterad HKLM-konfiguration, backup och återställning. |

## Skapa underlag för din krasch

1. Packa upp hela den nya ZIP-filen i en ny mapp.
2. Högerklicka **Enable-Crash-Dumps.bat → Kör som administratör** en gång. Kontrollera att inställningen lyckas.
3. Kör **Start.bat normalt**, inte som administratör. Upprepa mustestet.
4. Kör **Collect-Diagnostics.bat** för en ZIP med loggar. Den öppnar resultatmappen.
5. Leta efter en ny `.dmp` under `%LOCALAPPDATA%\DrawBotStudio\dumps`. Skicka den separat om den skapades.

Vid körning från Python gäller dumpinställningen även andra processer med namnen python.exe/pythonw.exe. Dumpfiler kan innehålla delar av processminnet och skickas aldrig automatiskt. Disable-Crash-Dumps.bat återställer den nya konfigurationens sparade värden när det går utan att skriva över senare ändringar.

Vanliga fångade Python-fel ger logg/traceback, inte nödvändigtvis en native minidump. En strömförlust eller tvångsavslutning behöver inte ge någon dump. Dumpen måste analyseras för att avgöra den faktiska kraschorsaken.

[Microsofts dokumentation om LocalDumps](https://learn.microsoft.com/en-us/windows/win32/wer/collecting-user-mode-dumps) beskriver HKLM, administratörskrav och begränsningarna.

## Verifiering

Originalversionen: 685 tester, ett underkänt autofyllningstest i denna miljö. Patchen har 14 nya regressionstester och uppdaterade versionskontroller. Slutresultat: 711 godkända tester samt godkänt source self-test. Inget riktigt Windows-fönster, musklick, Windows-dump eller NVIDIA CUDA-kernel provkördes här. Ingen EXE har byggts.

Jag kan därför inte säga att just din native krasch är löst eller att alla buggar är borta. Den här versionen rättar påvisade fel och ger bättre underlag för nästa felsökningssteg.


Subject Focus added: Off / Subject first / Subject only, manual image rectangle, transparency or uniform-border background estimate, mask preview, timer priority and 12 regression tests. See MOTIVFOKUS.md for usage and limitations. No semantic detection; 1 px Pixel Accurate full-colour paths; correction passes disabled only while subject focus is enabled.
