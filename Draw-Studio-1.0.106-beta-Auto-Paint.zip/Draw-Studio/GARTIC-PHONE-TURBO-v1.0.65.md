# Gartic Phone Turbo — v1.0.65

The Gartic Phone profile uses a deterministic raster fast path inspired by two common autodraw strategies:

1. color-batched horizontal runs, and
2. Gartic-style vertical column runs.

For each retained color, Draw Studio compares both orientations and uses the one requiring fewer separate strokes. The optimizer works only on already-planned palette pixels and does not bypass CanvasGuard or mouse safety.

Auto policy defaults:

- Smart paths
- Calibrated palette
- RGB nearest
- up to 8 active colors in Turbo reduction
- Strong simplify
- Smart merge
- Progressive rendering off
- 60-second target budget
- 1000-path cap

Manual settings leave the renderer policy under user control.
