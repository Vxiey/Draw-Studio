"""Deterministic image-based presets; no AI or changes to native input safeguards."""
import numpy as np
from PIL import Image

PRESETS=('Auto','Manual','Masterpiece','Extra fast')

def resolve_drawing(image,options):
    out=dict(options);preset=out.get('render_preset','Manual')
    if preset not in PRESETS:raise ValueError('Choose Auto, Manual, Masterpiece or Extra fast.')
    if preset=='Manual' or out.get('auto_engine_resolved'):return out
    out['auto_engine_resolved']=True
    if preset=='Extra fast':
        if out.get('erase_mode'):
            raise ValueError('Extra fast needs Brush or Pencil, not Eraser.')
        out.update(extra_fast=True,profile_engine='Manual settings',
            render_style='Standard / pixel',subject_focus='Off',draw_quality='High likeness',
            drawing_mode='Smart paths (recommended)',smart_paths=True,lines=True,
            color_layers='Off',custom_color_workflow='Calibrated palette',
            color_rendering='RGB nearest',background_simplification='Off',
            background_fill='Balanced' if out.get('fill_tool_available') else 'Off',
            fill_engine='Closed regions v2',human_mode='Off')
        engine='Closed contours + bucket fill' if out.get('fill_tool_available') else 'Smart paths (calibrate Fill to enable buckets)'
        if out.get('paint_current_color') or out.get('outline'):
            out.update(outline=True,sketch_detail='Simple',background_fill='Off')
            engine='Simple black contours (single-colour mode)'
        out['auto_drawing_meta']={'preset':preset,'image_kind':'palette drawing','engine':engine}
        return out
    rgba=image.convert('RGBA');flat=Image.new('RGBA',rgba.size,'white');flat.alpha_composite(rgba)
    flat.thumbnail((128,128));a=np.asarray(flat.convert('RGB'),dtype=np.int16)
    white=float(np.mean(np.min(a,axis=2)>235))
    chroma=float(np.mean(a.max(axis=2)-a.min(axis=2)>35))
    # Quantized colour occupancy is a texture heuristic, not object recognition.
    bins=(a//32).astype(np.int32);codes=bins[:,:,0]*64+bins[:,:,1]*8+bins[:,:,2]
    hist=np.bincount(codes.ravel(),minlength=512);dominant=float(np.sort(hist)[-12:].sum()/hist.sum())
    source_kind='line art' if white>.65 and chroma<.12 else 'flat illustration' if dominant>.90 else 'photo / texture'
    if out.get('paint_current_color') or out.get('outline'):
        engine='black contours';out.update(outline=True,subject_focus='Off',sketch_detail='Detailed' if preset=='Masterpiece' else 'Auto')
    elif preset=='Masterpiece' or out.get('unlimited_time') or out.get('time_budget_mode')=='Unlimited':
        engine='Pixel Accurate';out.update(draw_quality='Pixel Accurate',brush_px=1,profile_engine='Manual settings')
    elif source_kind=='line art':
        engine='black contours';out.update(outline=True,subject_focus='Off',sketch_detail='Auto')
    elif source_kind=='flat illustration':
        engine='Shape paths';out.update(drawing_mode='Shape paths',lines=True,draw_quality='High likeness',profile_engine='Manual settings')
    else:
        engine='Smart color paths';out.update(drawing_mode='Smart paths (recommended)',lines=True,smart_paths=True,draw_quality='High likeness',profile_engine='Manual settings',background_simplification='Balanced')
    if preset=='Masterpiece':
        out.update(unlimited_time=True,time_budget_mode='Unlimited',time_budget_active=False,
            background_simplification='Off',adaptive_detail='Off',stroke_optimizer='Travel only',
            target_stroke_count='Auto',target_stroke_count_resolved=None,read_gartic_timer=False)
        out.pop('gartic_timer_deadline',None);out.pop('gartic_timer_meta',None)
    out['auto_drawing_meta']={'preset':preset,'image_kind':source_kind,'engine':engine,'white_fraction':white,'dominant_colors_fraction':dominant}
    return out
