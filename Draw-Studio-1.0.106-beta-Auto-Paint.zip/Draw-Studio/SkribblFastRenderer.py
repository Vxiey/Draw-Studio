"""Deterministic fast-path optimizer for the Skribbl.io Fast profile.

Inspired by classic Skribbl autodraw strategies: quantize to the calibrated game
palette, draw one colour at a time, and collapse adjacent raster pixels into long
horizontal runs.  This module is pure planning code: no mouse, network or GUI.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Sequence

Segment = tuple[int, int, int, int]


def _run_weight(seg: Segment) -> int:
    x1, y1, x2, y2 = map(int, seg)
    return max(1, abs(x2 - x1) + abs(y2 - y1) + 1)


def _distance2(a, b) -> int:
    return sum((int(a[i]) - int(b[i])) ** 2 for i in range(3))


def _is_white(rgb) -> bool:
    try:
        return min(map(int, rgb[:3])) >= 245
    except Exception:
        return False


def _coalesce_rows(strokes: Sequence[Segment], *, gap_join: int = 1, min_run: int = 2,
                   keep_short: bool = False) -> list[Segment]:
    """Merge same-colour horizontal runs on each row and prune tiny fragments.

    ``gap_join`` may bridge a one-source-pixel gap after palette reduction.  This
    turns nearby fragments that now represent the same reduced colour into one
    mouse stroke instead of several press/release actions.
    """
    rows: dict[int, list[tuple[int, int]]] = defaultdict(list)
    passthrough: list[Segment] = []
    for stroke in strokes:
        x1, y1, x2, y2 = map(int, stroke)
        if y1 != y2:
            passthrough.append((x1, y1, x2, y2))
            continue
        if x2 < x1:
            x1, x2 = x2, x1
        rows[y1].append((x1, x2))

    out: list[Segment] = []
    for y in sorted(rows):
        runs = sorted(rows[y])
        if not runs:
            continue
        sx, ex = runs[0]
        for nx1, nx2 in runs[1:]:
            if nx1 <= ex + max(0, int(gap_join)) + 1:
                ex = max(ex, nx2)
            else:
                length = ex - sx + 1
                if keep_short or length >= max(1, int(min_run)):
                    out.append((sx, y, ex, y))
                sx, ex = nx1, nx2
        length = ex - sx + 1
        if keep_short or length >= max(1, int(min_run)):
            out.append((sx, y, ex, y))
    out.extend(passthrough)
    return out


def optimize_skribbl_groups(groups: Sequence[Sequence[Segment]], palette_rgb: Sequence[Sequence[int]], *,
                            max_colors: int = 6, gap_join: int = 1, min_run: int = 2) -> tuple[list[list[Segment]], dict]:
    """Aggressively reduce palette switches and stroke boundaries for Skribbl.

    The most-used calibrated colours are kept. Less-used colours are remapped to
    the nearest kept calibrated colour, preserving geometry while reducing colour
    changes.  Dark structure is explicitly retained when present.
    """
    work = [list(map(tuple, group)) for group in groups]
    color_count = len(work)
    palette = [tuple(map(int, rgb[:3])) for rgb in palette_rgb]
    if len(palette) < color_count:
        palette.extend([(0, 0, 0)] * (color_count - len(palette)))

    weights = [sum(_run_weight(s) for s in group) for group in work]
    active = [i for i, w in enumerate(weights) if w and i < len(palette) and not _is_white(palette[i])]
    before_colors = len(active)
    before_runs = sum(len(g) for g in work)
    if not active:
        return work, {
            'active_colors_before': 0, 'active_colors_after': 0,
            'runs_before': before_runs, 'runs_after': before_runs,
            'remapped_colors': 0, 'max_colors': int(max_colors),
        }

    max_colors = max(2, int(max_colors))
    ranked = sorted(active, key=lambda i: (-weights[i], i))
    keep = ranked[:max_colors]

    # Preserve the darkest structural colour when it carries visible content.
    darkest = min(active, key=lambda i: (sum(palette[i]), -weights[i], i))
    if darkest not in keep:
        if len(keep) >= max_colors:
            keep[-1] = darkest
        else:
            keep.append(darkest)
    keep = list(dict.fromkeys(keep))

    result: list[list[Segment]] = [[] for _ in work]
    remapped = 0
    mapping: dict[int, int] = {}
    for index in active:
        if index in keep:
            target = index
        else:
            target = min(keep, key=lambda j: (_distance2(palette[index], palette[j]), -weights[j], j))
            remapped += 1
        mapping[index] = target
        result[target].extend(work[index])

    for index in keep:
        # Dark outlines/details may contain short but important fragments.
        keep_short = index == darkest
        result[index] = _coalesce_rows(result[index], gap_join=gap_join, min_run=min_run, keep_short=keep_short)

    after_runs = sum(len(g) for g in result)
    after_colors = sum(bool(g) for g in result)
    return result, {
        'active': True,
        'strategy': 'fixed-palette color batches + horizontal run compression',
        'active_colors_before': before_colors,
        'active_colors_after': after_colors,
        'max_colors': max_colors,
        'remapped_colors': remapped,
        'runs_before': before_runs,
        'runs_after': after_runs,
        'run_reduction': 0.0 if before_runs <= 0 else max(0.0, 1.0 - after_runs / before_runs),
        'gap_join': int(gap_join),
        'min_run': int(min_run),
        'darkest_color_index': int(darkest),
        'kept_color_indexes': tuple(map(int, keep)),
        'color_mapping': {str(k): int(v) for k, v in mapping.items()},
    }
