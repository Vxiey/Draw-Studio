# Draw Studio v1.0.70-beta – Browser Auto Calibration

## Added

- New **Browser Auto Setup** for Gartic Phone, Skribbl.io, Skribbl.io Fast, SketchHeads and Sketchful.io.
- After the target canvas is selected, Draw Studio automatically scans the selected browser window and saves an anchored palette without manual swatch capture.
- Gartic Phone verifies the current 72-color palette and wide white canvas.
- Skribbl verifies the known game palette and can recover a conservative canvas from palette geometry when a partly drawn canvas is no longer one connected white area.
- SketchHeads detects the visible bottom color row and builds a conservative safe canvas above the toolbar.
- Added a dedicated **SketchHeads** profile.
- Manual Brush/Fill/Eraser calibration is now optional for the supported browser profiles when normal drawing is used; it remains available for advanced Fill/Eraser workflows.

## Safety

- Auto Setup is read-only: it may activate the already selected browser window for a screenshot, but it sends no mouse movement, clicks, presses or releases.
- Low-confidence or changed layouts fail closed and keep manual calibration as fallback.
- Saved palette coordinates remain anchored to the selected target client rectangle.
- CanvasGuard, FinalMouseGuard, target monitoring and the existing browser Start/Unlock safety flow are unchanged.
