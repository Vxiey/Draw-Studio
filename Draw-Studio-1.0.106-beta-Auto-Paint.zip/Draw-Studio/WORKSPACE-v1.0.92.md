# Draw Studio – kompakt arbetsyta

## Hitta rätt

Välj sektion i vänsterpanelen: **Target**, **Image**, **Setup**, **Drawing** eller **Safety**. Bara en sektion visas åt gången. Avancerade inställningar finns fortfarande under Drawing → Advanced/Developer.

Preview-väljaren ovanför bilden innehåller Original, Drawing preview, Safety map, Debug overlay, Stroke plan, Fill regions, Color map, Coverage map och Accuracy error. Inga preview-vyer har tagits bort. Build preview, Start, Pause och Stop finns i den fasta nederdelen. Åtgärdsknappar får radbrytas när fönstret blir smalare. De vanliga säkerhetskraven gäller fortfarande.

**Tools** innehåller Readiness, detaljerad planeringssammanfattning, diagnostik och uppdateringskontroll. Display options under bilden visar lagerinställningar och Mobile Preview. Temat är nu blågrått med en ljusblå accent. Fönstret öppnas som högst 1180 × 800 beroende på tillgänglig skärm, och kan normalt minskas till 860 × 580. Windows DPI påverkar det faktiska utrymmet; 100/125/150 % behöver verifieras på en Windows-dator.

## Scrollning

En gemensam scrollhanterare ersätter flera globala CTk-scrollbindningar. Bara panelen under muspekaren scrollas. Händelser samlas under 16 ms och väntande rörelse begränsas till 12 steg. Det förhindrar lång eftersläpning efter en snabb scrollburst. Delsteg från högupplösta mushjul sparas. Text- och listfält behåller sin egen scrollning. Detta är testat med simulerade händelser, inte fysisk mus/touchpad i Windows.

## Kalibrering utan fönster i vägen

Huvudappen minimeras under palett-/exaktfärgskalibrering, automatisk browser-/Paint-kalibrering samt skärmfångst/inspelning. Manuella verktygsfönster minimeras under tidsstyrd punktavläsning. Fönstret återställs vid avslut och fel; föregående maximerat/minimerat läge bevaras. Ritytemarkeringen använder redan ett dolt huvudfönster och återställer nu även maximerat läge.

Färgkodsfångst väntar tre sekunder så att du hinner placera pekaren på färgrutan. Palett- och exaktfärgshjälparna läser sin processutmatning löpande så att en full loggpipe inte blockerar avslut. Avbrott kan stoppa de egna hjälpprocesserna. Native Windows-krascher och fysisk fönsteråterställning är inte testade här.

## Uppdateringar

**Check for updates** gör en manuell GET mot GitHubs publika Releases-API för **yesverynice12/Draw-Studio**. Betaversionen jämför giltiga versionsnummer bland de senaste 100 publicerade releaserna, inklusive betareleaser. Drafts ignoreras.

- Ingen nyare publicerad version: **You are on the latest version.**
- Nyare version: **Download version X**, en knapp som öppnar releasen på GitHub.
- Inga publicerade releaser: ett separat meddelande om detta.
- Nätverksfel eller otillgängligt repository: ett felmeddelande, inte ett falskt besked om senaste version.

Programmet installerar inte över sig självt. Hämta paketet från GitHub-sidan och behåll din tidigare programmapp/kalibrering tills den nya är kontrollerad. GitHub Releases måste innehålla en publicerad release med läsbart taggnamn, exempelvis v1.0.93-beta; enbart en commit eller uppladdad fil ger ingen releaseuppdatering.

API-referens: https://docs.github.com/en/rest/releases/releases#list-releases

## Verifiering

752 automatiserade tester godkända, inklusive 13 nya tester för scrollning, fönstertillstånd, layoutbeslut och uppdateringsbesked. Source self-test, Python-syntax och ZIP-integritet godkända. CustomTkinter och grafisk Windows-miljö saknas här: faktisk rendering, touchpad/hjul, kalibrering, musritning och live GitHub-förbindelse är inte verifierade. Ingen EXE är byggd. Paketet innehåller källkod och Start.bat.
