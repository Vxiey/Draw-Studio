# Draw Studio v1.0.88-beta — Pixel Accurate Planner, Block C

Block C adds a measurable accuracy loop on top of Block A's full-resolution PixelMap and Block B's component-safe stroke engine.

## 10 Block C patches

1. **Coverage map** — records every target pixel touched by the simulated brush.
2. **Brush-aware stroke simulation** — replays the actual planned execution sequence in palette-index space using the configured brush width.
3. **Final simulated color buffer** — stores the last planned color at every touched pixel, so ordering/overpainting is measurable.
4. **Categorical pixel error map** — distinguishes missing target pixels, wrong-color target pixels and brush spill outside the drawable target.
5. **Pixel Accuracy Score** — exact palette-index match over the meaningful evaluation area, without inflating the score with untouched background.
6. **Coverage / edge / protected-feature scores** — exposes separate quality metrics for coverage, high-gradient structure and protected micro-features.
7. **Automatic correction pass 1** — converts current error pixels into exact desired-color correction runs.
8. **Automatic correction pass 2** — allows one additional refinement iteration when the first accepted correction still leaves measurable errors.
9. **Improvement gate** — a correction pass is appended only when simulation proves that accuracy improves or the error count falls without reducing accuracy.
10. **Accuracy diagnostics UI + release integration** — adds Coverage map and Accuracy error preview tabs, logs the score/corrections, and bundles PixelAccuracyEngine in frozen builds.

## Important behavior

- Block C does not replace the PixelMap or component scheduler. It evaluates the exact Block B execution order.
- Correction passes remain quality-first; they do not re-enable RealSpeedBudget, reduced palette, destructive simplification or forced Gartic Turbo.
- The current score describes the **planned strokes before CanvasGuard/runtime delivery**. Runtime delivery verification remains a separate safety layer.
- With a 1 px brush, a lossless Block B plan can reach 100% target palette coverage. Wider brushes are intentionally simulated so spill and overpainting become visible instead of being hidden by the planner.
