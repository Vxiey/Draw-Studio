# Draw Studio v1.0.67-beta – Manual Drop-In Start

Manual Drop-In Start is a one-shot convenience flow for browser/game canvas profiles.

## Behavior

1. Select the target app profile.
2. Select/calibrate the target canvas and palette.
3. Press **Arm Drop-In Start**.
4. Drop, paste, select, or load the next image.
5. Draw Studio starts the drawing automatically after the image is loaded, if the setup is still valid.

## Safety

- The mode is one-shot and expires after 120 seconds.
- It is not saved to settings.
- It is disabled for Microsoft Paint, which keeps the full safety chain.
- CanvasGuard, FinalMouseGuard, target monitoring and safe polygon clipping still run before and during drawing.
- Old saved `Draw immediately` drop preferences are still discarded.

## Scope

This change is intended for fast browser games such as Gartic Phone, Skribbl.io and similar canvas-based profiles. It does not change Paint safety requirements.
