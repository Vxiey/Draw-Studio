# Draw Studio v1.0.72-beta – Browser Visual Preflight

This release adds a final read-only visual safety gate for supported browser drawing profiles.

## What changed

- Immediately before every browser drawing/test/dry-run, Draw Studio verifies the visible page again.
- The currently detected canvas must still match the calibrated safe canvas within a small pixel tolerance.
- Up to six representative palette swatches are sampled across the palette and compared with the calibrated RGB values.
- One transient/selected-swatch difference can be tolerated when enough control swatches still verify.
- If the first visual check fails, Draw Studio performs one automatic Browser Auto-Recalibration and repeats the visual preflight.
- If the second check still fails, drawing is blocked before native mouse input is armed.
- Logs include canvas status, palette controls verified/tested, confidence and maximum palette color error.

## Supported profiles

- Gartic Phone
- Skribbl.io
- Skribbl.io Fast
- SketchHeads
- Sketchful.io

## Safety model

Visual Preflight uses screenshots only. It does not click colors, tools or the canvas. CanvasGuard, FinalMouseGuard and live target monitoring remain mandatory during actual drawing.
