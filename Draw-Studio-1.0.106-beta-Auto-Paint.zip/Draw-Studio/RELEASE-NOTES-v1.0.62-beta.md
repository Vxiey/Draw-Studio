# Draw Studio v1.0.62-beta — Paint Stroke Delivery Fix

This release targets missing/broken drag segments observed in Microsoft Paint even when planning, CanvasGuard and mouse positioning were valid.

## Changed

- While Draw Studio owns a real left-button drag, Windows movement now uses absolute `SendInput` with `MOUSEEVENTF_MOVE_NOCOALESCE` instead of cursor teleports alone.
- Microsoft Paint real drawing uses <=2 px runtime movement spacing.
- Paint real drawing enforces a 5 ms minimum between delivered drag points.
- A short 10 ms button-down settle and 6 ms endpoint settle are used before/after Paint drags.
- Dry Run and the no-click mouse probe keep the existing button-up cursor backend.
- Profile name / Paint profile state is now preserved in runtime options so execution policies can resolve the correct target profile.
- CanvasGuard, clipping, Safe Fill and FinalMouseGuard are unchanged and remain mandatory.

No AI/ML/OCR or telemetry was added.
