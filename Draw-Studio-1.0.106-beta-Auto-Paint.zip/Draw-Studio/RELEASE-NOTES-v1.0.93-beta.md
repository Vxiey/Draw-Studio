# Draw Studio v1.0.93-beta — Startup hotfix

Fixed a startup-blocking NameError in StudioUI.build_ui. The release button had been renamed to a.update_download_button but its tooltip still referenced release_page_btn. This prevented the workspace from opening before any drawing operation.

Added a symbol-table regression check across six UI/window modules. This check identifies the stale name in v1.0.92 and passes after the fix. It does not replace real Windows GUI testing.

753 automated tests passed; source self-test passed. Native Windows GUI startup remains unverified in this Linux environment. All v1.0.92 features and files retained; no settings or calibration format changes.
