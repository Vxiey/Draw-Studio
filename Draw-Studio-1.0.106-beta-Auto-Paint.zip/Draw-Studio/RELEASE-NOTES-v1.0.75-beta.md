# Draw Studio v1.0.75-beta – Per-Game Input Engine

Includes the v1.0.74 Automatic Brush Size work and adds separate native input delivery policies for the supported browser games.

## Per-game timing

- Gartic Phone: HTML5-canvas interpolation up to the Normal-precision 12 px limit, 0.7 ms minimum path spacing, 4.5 ms mouse-down settle, 3 ms release settle and 75 ms palette settle.
- Skribbl.io: 10 px target interpolation, 0.65 ms path floor, 4/2.5 ms press/release settle and 60 ms palette settle.
- Skribbl.io Fast: 12 px target interpolation, 0.45 ms path floor, 3/2 ms press/release settle and 50 ms palette settle.
- SketchHeads: 8 px target interpolation, 1 ms path floor, 6/4 ms press/release settle and 85 ms palette settle.
- Browser tool/brush UI controls receive their own per-game settle time.
- Microsoft Paint keeps its existing compatible/reliable policies unchanged.
- Dry Run remains click-free; browser press/release timing is removed while route density remains representative.

## Safety

These policies only alter input delivery timing/density. CanvasGuard, FinalMouseGuard, target monitoring, Visual Preflight and Auto-Recalibration remain mandatory and unchanged.
