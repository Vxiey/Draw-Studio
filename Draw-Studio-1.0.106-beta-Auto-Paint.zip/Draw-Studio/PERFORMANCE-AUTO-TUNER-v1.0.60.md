# Performance Auto Tuner — v1.0.60-beta

The tuner is a local planning-resource benchmark. It never sends mouse input and never contacts a server.

It benchmarks or inspects:

- safe CPU worker scaling
- current available RAM and a headroom-aware planning budget
- optional NVIDIA CUDA throughput and VRAM availability
- a matching planning resolution

The recommendation can be benchmarked without applying it, benchmarked and applied immediately, or re-applied later from the saved local result. CanvasGuard, FinalMouseGuard, Fill safety, edge verification and all other drawing safety controls are intentionally outside the tuner.
