# Draw Studio v1.0.89-beta — Pixel Accurate Planner, Block D

Block D accelerates the accuracy pipeline without changing the analysis-first contract introduced in Blocks A–C. Pixel Accurate still preserves the full PixelMap before speed decisions; Block D moves planned-stroke simulation and score reduction toward NVIDIA CUDA, uses VRAM-aware tiles/batches, parallelizes independent CPU region work, and adds progressive accuracy for explicit time limits.

## 10 engine patches

1. CUDA planned-stroke simulation using the same square swept-brush model as the CPU simulator.
2. Ordered stroke-to-rectangle compilation so GPU simulation preserves final paint order and overdraw semantics.
3. Adaptive row-tiled CUDA rasterization for large canvases.
4. VRAM-aware rectangle batching based on the selected Draw Studio GPU memory budget.
5. CUDA categorical error-map and accuracy metric reduction with deterministic CPU fallback.
6. Parallel CPU vertical-run extraction over independent column chunks.
7. Parallel CPU component path construction with deterministic component ordering.
8. Progressive time-budget scheduling that limits only executable paths, never PixelMap resolution, palette fidelity or protected features.
9. Reserved protected-cleanup capacity and correction-pass caps inside tight time budgets.
10. Progressive accuracy checkpoints and Block-D diagnostics: simulation backend, CUDA device, tiles, batches, CPU workers, path budget and accuracy after each phase.

## Accuracy contract

- Full-resolution PixelMap remains the source of truth.
- Gartic/browser turbo and destructive palette/detail simplification remain bypassed in Pixel Accurate.
- An explicit time limit may omit later executable paths, but it does not mutate the source PixelMap.
- Protected cleanup is scheduled before low-priority fine detail when the timer is tight.
- CUDA failures fall back to the CPU simulator without preventing drawing.
