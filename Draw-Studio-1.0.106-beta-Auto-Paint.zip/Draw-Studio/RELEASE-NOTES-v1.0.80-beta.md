# Draw Studio v1.0.80-beta — Browser One-Click Mode

- Choose Gartic Phone, Skribbl.io/Fast, SketchHeads or Sketchful.io and add an image.
- Reuses a known target or discovers a unique visible matching browser layout read-only.
- Auto canvas → auto palette → automatic brush preflight → Browser Visual Preflight → drawing.
- Layout Fingerprint v2 remains the fast path for known layouts.
- Ambiguous/low-confidence window discovery blocks safely instead of guessing.
- Microsoft Paint is never auto-started by One-Click Mode.
